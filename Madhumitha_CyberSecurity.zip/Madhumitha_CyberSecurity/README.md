# AI-Powered Cybersecurity Incident Response Assistant
**Autonomous Multi-Agent Triage, Exact Hybrid RAG, and Calibrated Intrusion Risk Assessment for Telecom & Enterprise SOC Operations**

---

## 1. Project Overview
The **AI-Powered Cybersecurity Incident Response Assistant** is an end-to-end Generative AI and Multi-Agent operational system engineered for high-throughput Security Operations Centers (SOC) and Telecom Network Operations Centers (NOC). 

Security teams monitor millions of network flow records across telecommunications infrastructure, enterprise firewalls, and server gateways. This assistant provides automated, explainable triage: it ingests real **CIC-IDS2017** network telemetry, classifies attack families using balanced machine learning models, retrieves similar confirmed historical cases via hybrid dense-lexical RAG, computes transparent risk priority scores (P1 Critical to P4 Low), and synthesizes actionable investigation reports using a multi-agent LangGraph workflow. Every decision is fully observable with millisecond span traces, local SHAP feature attributions, and strict human-in-the-loop containment gates.

---

## 2. Problem Statement
Tier-1 SOC and NOC analysts face severe operational bottlenecks:
* **Alert Overload & False Positives:** Analysts receive 500–1,000 alerts per shift. Over 85% of triage time is squandered verifying benign network noise.
* **Lack of Historical Context:** Analysts repeatedly investigate recurring threat patterns from scratch because historical investigation records remain siloed.
* **Prolonged Investigation Latency (MTTR):** Manually collecting flow metrics, cross-referencing IP reputation, and identifying lateral movement takes 30+ minutes per incident.
* **GenAI Hallucinations & Safety Risks:** Standard conversational LLMs frequently hallucinate non-existent CVEs or ticket IDs, and propose dangerous unverified automated network reconfigurations.

---

## 3. Business Objective
* **Accelerate Triage & MTTR by 90%:** Reduce initial alert triage and correlation from 30 minutes to under 5 seconds.
* **Empirical Retrieval Precision:** Achieve over 95% Precision@1 in retrieving genuinely relevant historical precedents from the security knowledge base.
* **Explainable & Transparent Risk Scoring:** Eliminate black-box decision making by combining supervised ML, calibrated intrusion probabilities, Isolation Forest anomaly percentiles, and SHAP feature attributions into a deterministic 0–100 priority score.
* **Enterprise Security & Compliance:** Enforce 0.0% unsafe autonomous actions by requiring mandatory human-in-the-loop analyst verification on all containment actions (e.g., firewall IP blocks).
* **Self-Contained Local Execution:** Run fully locally on commodity hardware without mandatory cloud GPU dependencies, external vector database clusters, or complex container engines.

---

## 4. Solution Summary
The system integrates a closed-loop multi-agent architecture:
1. **Telemetry Ingestion & Guardrails:** Validates flow features and screens inputs against prompt injections.
2. **Tri-Model Predictive ML:** Random Forest classifier (99.0% accuracy, 0.952 macro-F1), Calibrated Gradient Boosting intrusion-risk model (ROC-AUC 0.997), and Isolation Forest anomaly detector (ROC-AUC 0.939).
3. **Exact Hybrid RAG:** Qdrant embedded on-device vector database (384-dimensional dense vectors) fused with Okapi BM25 lexical search ($\alpha = 0.60$) with reciprocal bound widening.
4. **LangGraph Multi-Agent Orchestration:** 6 specialized agents coordinating triage, correlation, risk scoring, technical synthesis, and output validation.
5. **LLM Synthesis & Fallback Hierarchy:** Primary cloud inference (AICredits GPT-4o-mini) with seamless automatic fallback to local Ollama and offline deterministic playbooks.
6. **Full Observability & Audit:** End-to-end tracing (`X-Trace-ID`), sub-millisecond span waterfalls, and active analyst feedback retraining loop.

---

---

## System Architecture Diagram
![AI-Powered Cybersecurity Incident Response Assistant Architecture](architecture/Architecture_Diagram.png)

### 10-Component System Architecture Decomposition
The solution architecture is organized into **10 decoupled components** operating along the operational lifecycle: **Detect • Analyse • Investigate • Respond • Report**:
1. **Data Sources / Ingestion:** Ingests Network Traffic (PCAP, NetFlow, logs), Firewall & IDS/IPS Alerts, Endpoint Logs (EDR, system logs), and User-Submitted Files (CSV, JSON).
2. **Data Ingestion Pipeline:** Deterministic 6-step pipeline: **Collect • Parse & Normalize • Validate • Deduplicate • Enrich • Queue/Batch**.
3. **Backend & Orchestration:** High-concurrency **FastAPI** ASGI service, Pydantic v2 schemas, JWT RBAC security, input guardrails, and **LangGraph** orchestrator connected to the **React 19 SPA** and **Streamlit** frontends.
4. **LangGraph Investigation Workflow:** 6-node stateful workflow: **1. Validate Input → 2. Detection Agent → 3. Analysis Agent → 4. Risk Agent → 5. Response Agent → 6. Final Validation Gate**.
5. **ML Models (Tri-Model + XAI):** Random Forest Classifier (99.0% acc), Gradient Boosting Intrusion Model (0.998 AUC), Isolation Forest Anomaly Detector, and SHAP TreeExplainer local feature attribution.
6. **LLM Providers (Multi-Tier Hierarchy):** Primary **AICredits** (GPT-4o-mini) → Fallback **NVIDIA NIM** (Llama-3.2-11B) → Local **Ollama** (Llama 3.1) → **Offline Deterministic Playbooks**.
7. **RAG Knowledge Base:** 4,236 confirmed incidents, FastEmbed ONNX (`sentence-transformers/all-MiniLM-L6-v2`), and **Qdrant** Embedded HNSW vector store + Okapi BM25 keyword matching.
8. **Guardrails:** 4-layer defense: schema bounds, prompt injection filtering, output formatting validation, and factual flow reference enforcement.
9. **Investigation Report:** Standardized four-section incident report with transparent mathematical risk score (0–100), priority (P1–P4), telemetry evidence, and Trace ID.
10. **Monitoring & Evaluation:** DeepEval (100% Relevancy, 96.25% Faithfulness, 0% Hallucination), RAG metrics (P@1: 98.41%, MRR: 0.9889), OpenTelemetry span tracing, and Analyst Feedback loop.


### End-to-End System Data Flow Architecture
![End-to-End System Data Flow Architecture](architecture/Data_Flow_Architecture.png)

The application follows an active 7-stage data lifecycle:
1. **Raw Telemetry Ingestion:** Captures raw PCAP, NetFlow, or CIC-IDS2017 flows (80+ statistical metrics).
2. **Ingestion Pipeline & Guardrails:** Cleans NaN/infinite values, deduplicates flows, asserts IP RFC bounds, and screens inputs for prompt injection.
3. **Triage Queue & API:** Seeds 4,236 resolved cases into RAG; routes 95 active flows to SQLite (`NEW` / `INVESTIGATING`); analyst dispatches `POST /incidents/{id}/analyze`.
4. **LangGraph Multi-Agent Engine:**
   - **Validate Input:** Schema check.
   - **Detection Agent:** Tri-Model ML (Random Forest 99% acc, Gradient Boosting 0.998 AUC, Isolation Forest anomaly) + SHAP local feature attribution.
   - **Analysis Agent (Hybrid RAG):** Label-free behavioral query -> FastEmbed (MiniLM 384-d) dense search in Qdrant (4,236 cases) + Okapi BM25 lexical match ($lpha = 0.60$).
   - **Risk Agent:** Deterministic mathematical risk score (0-100) and priority (P1-P4).
   - **Response Agent:** **AICredits GPT-4o-mini** (primary) crafts 4-part incident report and containment playbook.
   - **Final Validation Gate:** Enforces 6 safety checks and prevents hallucinations.
5. **Dual Persistence & Observability:** Commits results to SQLite (`analysis_results`), logs audit trails, and records OpenTelemetry span latencies.
6. **React 19 Dashboard:** Displays real-time triage queue, SHAP waterfall charts, similar incident cards, AICredits model badge, and interactive containment checklists.
7. **Human-in-the-Loop Feedback Loop:** SOC analyst verifies classification, authorizes containment, marks case `RESOLVED`, re-vectorizes flow into Qdrant, and triggers retraining if model drift occurs.


### End-to-End Operational Flow (7 Stages)
1. **Collect & Ingest Data** → 2. **Normalize & Validate** → 3. **Detect & Classify** → 4. **Analyse & Enrich** → 5. **Assess Risk & Explain** → 6. **Generate Response & Report** → 7. **Validate & Monitor**.

---

## 5. Technology Stack

### Programming Language
* **Python 3.11 / 3.12:** Core backend, machine learning pipeline, agent graph, and evaluation engines.
* **TypeScript (ES2022):** Frontend single-page application typing and contracts.

### LLM Used
* **Primary Cloud LLM:** AICredits (`gpt-4o-mini`) via OpenAI-compatible endpoint.
* **Secondary Cloud Fallback:** NVIDIA NIM (`meta/llama-3.2-11b-vision-instruct`).
* **Independent Evaluation Judge:** `gpt-4o-mini` / `nvidia/nemotron-3-super-120b-a12b` (strict mode, zero canned fallbacks).
* **Local Offline Fallback:** Ollama (`llama3.2:latest`) and curated rule-based playbooks.

### Embedding Model
* **Model:** `sentence-transformers/all-MiniLM-L6-v2` (384-dimensional dense vector space).
* **Inference Engine:** `fastembed` (ONNX Runtime, lightweight CPU inference, PyTorch-free).

### Vector Database
* **Database:** **Qdrant (Embedded On-Device)**.
* **Configuration:** Local disk storage (`backend/data/qdrant`), Cosine distance metric, HNSW index graph, differential sync from SQLite system-of-record.

### Frameworks Used
* **Backend:** FastAPI, Uvicorn ASGI, Pydantic v2, SQLAlchemy.
* **Machine Learning:** scikit-learn, SHAP (`TreeExplainer`), NumPy, Pandas.
* **Agent Orchestration:** LangGraph (StateGraph cyclical workflow).
* **Evaluation:** DeepEval v4.2, RAGAS Triad, PyTest (195 test suite).
* **Frontend:** Streamlit (`frontend.py`) and React 19 + Vite + Tailwind CSS + Recharts (`frontend/`).

---

## 6. Installation Instructions

### Prerequisites
* **Operating System:** Windows 10/11, macOS, or Linux.
* **Python:** Version 3.11 or 3.12 (64-bit).
* **Node.js:** Node.js 20.19+ or 22.12+ (Required if running the Vite React UI).
* **Hardware:** 8 GB RAM minimum (16 GB recommended), ~6 GB free disk space.

### Environment Setup
1. Clone the repository and navigate to the project directory:
   ```bash
   cd soc-incident-assistant
   ```

2. Create and activate a Python virtual environment:
   ```powershell
   # Windows PowerShell
   python -m venv .venv
   .\.venv\Scripts\activate
   ```
   ```bash
   # macOS / Linux
   python3 -m venv .venv
   source .venv/bin/activate
   ```

### Dependency Installation
Install backend dependencies:
```bash
pip install -r backend/requirements.txt -c backend/constraints.txt
```

If using the React web UI, install frontend dependencies:
```bash
cd frontend
npm ci
cd ..
```

### API Key Configuration
Create your environment file by copying `.env.example` to `.env`:
```powershell
copy .env.example .env
```

Configure your LLM provider credentials in `.env`:
```ini
# Primary LLM Provider: AICredits
AICREDITS_API_KEY=your_aicredits_key_here
AICREDITS_BASE_URL=https://api.aicredits.in/v1
AICREDITS_MODEL=gpt-4o-mini

# Fallback LLM Provider: NVIDIA NIM (Optional)
NVIDIA_API_KEY=your_nvidia_key_here
NVIDIA_BASE_URL=https://integrate.api.nvidia.com/v1
NVIDIA_MODEL=meta/llama-3.2-11b-vision-instruct

# Security
JWT_SECRET=generate_a_random_secret_here
ENVIRONMENT=development
```
*(Note: Never commit `.env` containing live API keys to version control.)*

---

## 7. Local Deployment Instructions

### One-Command Automated Setup
The project provides automated setup scripts that check dependencies, prepare datasets, train models, build vector indices, and start the servers:

| Operating System | Setup Command | Quick Start Command (subsequent runs) |
| :--- | :--- | :--- |
| **Windows** | Double-click `setup.bat` (or `.\setup.ps1`) | `start.bat` |
| **macOS / Linux** | `./setup.sh` | `./start.sh` |

### Manual Step-by-Step Server Startup

1. **Start the FastAPI Backend Server:**
   ```powershell
   python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
   ```
   * Interactive OpenAPI Documentation: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
   * Backend Health Check: [http://127.0.0.1:8000/api/v1/health](http://127.0.0.1:8000/api/v1/health)

2. **Start the Streamlit SOC Operations Console:**
   ```powershell
   python -m streamlit run frontend.py --server.port 8501
   ```
   * Access URL: [http://127.0.0.1:8501](http://127.0.0.1:8501)

3. **(Alternative) Start the React Single-Page Application:**
   ```powershell
   cd frontend
   npm run dev -- --host 127.0.0.1 --port 5173
   ```
   * Access URL: [http://127.0.0.1:5173](http://127.0.0.1:5173)

### Demo Accounts (Local Development)
* **Analyst Role:** `analyst` / `analyst123!` (Triage alerts, trigger AI investigation, submit feedback)
* **Administrator Role:** `admin` / `admin123!` (Manage users, trigger model retraining, inspect audit logs)
* **Viewer Role:** `viewer` / `viewer123!` (Read-only incident review)

---

## 8. Sample Queries & Expected Outputs

### Sample Query 1: Investigating an Infiltration Alert (TCP Port 444)
* **User Query / Alert:**
  > "Investigate alert for flow `192.168.10.8 -> 205.174.165.73:444` (Protocol 6, duration 1,260 us, 4 packets, packet mean 31.0). Determine attack family and mitigation actions."
* **System Processing:**
  * Random Forest predicts `Infiltration` (Confidence: 0.92).
  * Anomaly score: 0.9967 (99.7th percentile).
  * Hybrid RAG retrieves historical incident `#4307` (Metasploit payload transfer on port 444).
  * Risk Score: **P1 Critical (82/100)** due to mandatory policy floor on confirmed infiltration.
* **Expected Output:**
  ```markdown
  ### SOC Investigation Summary
  - Threat Assessment: Highly suspicious Infiltration payload transfer on non-standard TCP port 444.
  - Telemetry Alignment: Packet length profile matches Metasploit reverse shell payload delivery.
  - Historical Precedent: Correlates with Incident #4307 (Similarity 0.892).

  ### Recommended Analyst Actions
  1. [Immediate Triage] Inspect host 192.168.10.8 active process table for unauthorized child processes.
  2. [Containment Gate] Isolate host 192.168.10.8 from enterprise VLAN [Requires Analyst Approval].
  3. [Network Rule] Block egress traffic to external IP 205.174.165.73 on perimeter firewall.
  ```

### Sample Query 2: Hybrid RAG Similarity Search
* **User Query:**
  > "Search past incidents involving slow HTTP flood attacks with low packet rates and high duration."
* **API Call:** `POST /api/v1/search` with query text and `alpha = 0.60`.
* **Expected Output:**
  * Top match: Incident `#2041` — Family: `DoS / DDoS` (Slowloris variant).
  * Hybrid Score: `0.8841` (Dense Cosine: 0.891, BM25: 0.874).
  * Telemetry Evidence: Flow duration 118,000,000 us; median rate 2.4 packets/sec.

### Sample Query 3: Real-Time Flow Classification with SHAP Explainability
* **User Query / Input:** Flow telemetry payload containing 28 forward packets, 14 backward packets, high backward bytes (55,095x benign median).
* **API Call:** `POST /api/v1/incidents/classify`
* **Expected Output:**
  * `attack_type`: `"DoS / DDoS"`
  * `confidence`: `0.941`
  * `intrusion_probability`: `0.982`
  * `shap_drivers`: Top positive contributor `total_bwd_bytes` (+0.342) and `flow_packets_per_sec` (+0.281).

---

## 9. Empirical Results (Measured on CIC-IDS2017 Benchmark)

| Evaluation Area | Metric | Measured Value | Methodology & Context |
| :--- | :--- | :---: | :--- |
| **Attack Classifier** | Accuracy / Macro-F1 | **99.0% / 0.952** | 31,675 unseen test flows (Random Forest, 150 balanced trees) |
| **Intrusion Risk** | ROC-AUC | **0.997** | Calibrated Gradient Boosting; 86.6% detection at 1% FPR |
| **Zero-Day Anomaly** | ROC-AUC | **0.939** | Isolation Forest trained strictly on benign traffic against unseen attacks |
| **Hybrid Retrieval** | Precision@1 / MRR | **98.41% / 0.9889** | Leave-one-out benchmark across 4,235 labelled incidents |
| **DeepEval Judge** | Answer Relevancy | **100.0%** | Independent judge LLM (`gpt-4o-mini`) over live investigations |
| **DeepEval Judge** | Faithfulness | **93.92%** | Verification of assertions grounded in retrieved incident telemetry |
| **DeepEval Judge** | Hallucination Rate | **0.00%** | Zero hallucination; zero fabricated ticket IDs or CVEs |
| **DeepEval G-Eval** | Recommendation Safety | **82.50%** | Evaluates mitigation specificity and mandatory human approval gates |
| **Safety Guardrail** | Unsafe Action Rate | **0.00%** | 100% human-in-the-loop review enforced on containment actions |
| **Tracing Overhead** | Per-Span Overhead | **4 µs** | Total trace persistence overhead ~11 ms per traced request |

---

## 10. Repository Directory Structure

```
soc-incident-assistant/
├── architecture/
│   ├── Architecture_Diagram.pdf      # Complete 10-stage system architecture diagram
│   └── Architecture_Diagram.png      # High-resolution 300 DPI architecture visual
├── design/
│   └── Design_Document.pdf           # Comprehensive 7-section System Design Document
├── docs/
│   ├── API_Documentation.pdf         # REST API specification with schemas & examples
│   ├── Evaluation_Report.pdf         # DeepEval, RAGAS & ML benchmark report
│   ├── Dataset_Details.pdf           # CIC-IDS2017 dataset specification
│   ├── DESIGN.md                     # Technical architecture documentation
│   └── architecture.svg              # Vector architecture diagram
├── data/
│   └── Dataset_Details.pdf           # Dataset documentation mirror
├── presentation/
│   └── Project_Presentation.pptx     # 12-slide 10-minute presentation deck with speaker notes
├── tests/
│   └── Sample_Test_Cases.md          # 12 comprehensive verified test cases
├── backend/
│   ├── app/
│   │   ├── api/v1/                   # FastAPI route endpoints
│   │   ├── agents/                   # LangGraph agent definitions
│   │   ├── graph/                    # Multi-agent StateGraph workflow
│   │   ├── ml/                       # Predictive models, training & SHAP
│   │   ├── rag/                      # Qdrant vector store, FastEmbed & BM25
│   │   ├── llm/                      # Provider chains, fallback & playbooks
│   │   ├── guardrails/               # Security & input validation
│   │   ├── observability/            # Distributed tracing & metrics
│   │   └── database/                 # SQLAlchemy models & migrations
│   ├── scripts/                      # Bootstrap, indexing & data download scripts
│   ├── tests/                        # 195 PyTest test suite
│   ├── requirements.txt              # Pinned backend dependencies
│   └── constraints.txt               # Validated package version constraints
├── frontend/
│   ├── src/                          # React 19 + TypeScript components & pages
│   ├── package.json                  # Frontend dependencies
│   └── vite.config.ts                # Vite bundler configuration
├── frontend.py                       # Streamlit SOC dashboard application
├── Dataset_Details.pdf               # Dataset specification (root deliverable)
├── README.md                         # Project documentation (this file)
├── setup.bat / setup.ps1 / setup.sh  # One-command automated environment setup
├── start.bat / start.sh / stop.bat   # Server lifecycle controls
├── package.bat / package_project.py  # Portable distribution packager
└── docker-compose.yml                # Optional containerized deployment configuration
```

---

## 11. Limitations & Operational Notes
* **Rare Attack Class Support:** Rare attack families in CIC-IDS2017 such as Heartbleed (11 flows) and Infiltration (36 flows) have limited sample support; the system enforces strict policy floors to guarantee escalation regardless of classifier confidence.
* **Embedded Vector Storage:** Embedded Qdrant runs directly on disk (`backend/data/qdrant`), which is optimal for single-process local execution. For multi-worker production clusters, configure `QDRANT_URL` to point to a distributed Qdrant instance.
* **LLM Judge Signals:** Judge LLM scores serve as empirical evaluation signals rather than mathematical ground truth; the system complements LLM evaluation with deterministic guardrail unit tests.
* **Human-in-the-Loop Governance:** AI investigation summaries draft recommended firewall and isolation commands, but all network modification actions strictly require manual review and execution by a human SOC analyst.
