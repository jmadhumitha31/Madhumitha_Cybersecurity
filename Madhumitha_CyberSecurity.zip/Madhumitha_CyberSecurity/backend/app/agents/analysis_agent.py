from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from app.logging_config import logger
from app.rag.retriever import rag_retriever


class AnalysisAgent:
    def run(self, db: Session, incident_data: Dict[str, Any], exclude_id: Optional[int] = None) -> Dict[str, Any]:
        """Analysis Agent: hybrid (semantic + BM25) retrieval of similar *labelled* historical incidents.

        Never fabricates history: if nothing clears the similarity threshold the result is the explicit empty state.
        """
        logger.info(f"Analysis Agent searching history for incident {incident_data.get('flow_id')}")
        r = rag_retriever.retrieve_similar_incidents(db=db, incident_dict=incident_data, top_k=4, exclude_id=exclude_id)
        return {
            "found_similar": r["found"],
            "retrieved_incidents": r["matches"],
            "retrieval_message": r["message"],
            "evidence_context": r["evidence_context"],
            "class_votes": r["class_votes"],
        }


analysis_agent = AnalysisAgent()
