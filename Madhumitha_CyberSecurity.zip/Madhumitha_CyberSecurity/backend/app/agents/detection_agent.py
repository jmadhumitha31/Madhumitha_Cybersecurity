from typing import Any, Dict

from app.logging_config import logger
from app.ml.predictor import ml_predictor


class DetectionAgent:
    def run(self, incident_data: Dict[str, Any]) -> Dict[str, Any]:
        """Detection Agent: classify the flow, score intrusion risk and anomaly, and explain which features drove it."""
        logger.info(f"Detection Agent analyzing flow {incident_data.get('flow_id', 'UNKNOWN')}")
        return ml_predictor.predict_attack(incident_data, explain=True)


detection_agent = DetectionAgent()
