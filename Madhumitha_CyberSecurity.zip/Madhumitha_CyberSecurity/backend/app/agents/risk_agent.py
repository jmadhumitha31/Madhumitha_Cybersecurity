from typing import Any, Dict

from app.logging_config import logger
from app.ml.predictor import ml_predictor


class RiskAssessmentAgent:
    def run(self, incident_data: Dict[str, Any], detection_result: Dict[str, Any], analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """Risk Assessment Agent: severity (Critical..Low), priority (P1..P4) and a 0-100 score from
        class severity, calibrated intrusion probability, anomaly score, traffic indicators and retrieval agreement."""
        attack_type = detection_result.get("attack_type", "Unclassified")
        logger.info(f"Risk Assessment Agent evaluating threat impact for {attack_type}")

        agreement = None
        if analysis_result.get("found_similar"):
            agreement = float(analysis_result.get("class_votes", {}).get(attack_type, 0.0))

        risk = ml_predictor.predict_risk(
            incident_data,
            attack_type,
            float(detection_result.get("confidence", 0.0)),
            intrusion_probability=detection_result.get("intrusion_probability"),
            anomaly_score=detection_result.get("anomaly_score"),
            neighbor_agreement=agreement,
        )
        if detection_result.get("low_confidence"):
            risk["factors"].append("Low classifier confidence: treat the label as a hypothesis and confirm manually")
        if analysis_result.get("found_similar"):
            crit = [m for m in analysis_result.get("retrieved_incidents", []) if m.get("risk_level") == "Critical"]
            if crit and risk["risk_level"] != "Critical":
                risk["factors"].append(f"{len(crit)} similar historical incident(s) were rated Critical")
        else:
            risk["factors"].append("No sufficiently similar historical incident: risk rests on model outputs alone")
        return risk


risk_agent = RiskAssessmentAgent()
