from collections import OrderedDict
from typing import Any, Dict, List

from fastapi import APIRouter, Depends
from sqlalchemy import desc, func
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import Incident, User
from app.domain import PROTOCOL_NAMES
from app.schemas.common import ApiResponse
from app.services.auth_service import get_current_user

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/overview", response_model=ApiResponse[Dict[str, Any]])
def get_overview(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    open_filter = Incident.status.in_(["NEW", "INVESTIGATING"])
    # confidence is only meaningful for incidents the model has actually scored; None (not a made-up default) otherwise
    avg_conf = db.query(func.avg(Incident.prediction_confidence)).filter(Incident.prediction_confidence.isnot(None), Incident.label_source == "model").scalar()
    scored = db.query(func.count(Incident.id)).filter(Incident.prediction_confidence.isnot(None)).scalar() or 0
    return ApiResponse(data={
        "total_incidents": db.query(func.count(Incident.id)).scalar() or 0,
        "open_incidents": db.query(func.count(Incident.id)).filter(open_filter).scalar() or 0,
        # open (NEW / INVESTIGATING) only: resolved historical knowledge-base incidents are not SOC workload
        "critical_incidents": db.query(func.count(Incident.id)).filter(Incident.risk_level == "Critical", open_filter).scalar() or 0,
        "high_incidents": db.query(func.count(Incident.id)).filter(Incident.risk_level == "High", open_filter).scalar() or 0,
        "p1_open": db.query(func.count(Incident.id)).filter(Incident.priority == "P1", open_filter).scalar() or 0,
        "investigations_in_progress": db.query(func.count(Incident.id)).filter(Incident.status == "INVESTIGATING").scalar() or 0,
        "model_scored_incidents": scored,
        "mean_model_confidence": round(float(avg_conf), 4) if avg_conf is not None else None,
        "analyst_confirmed": db.query(func.count(Incident.id)).filter(Incident.label_source == "analyst").scalar() or 0,
        "knowledge_base_size": db.query(func.count(Incident.id)).filter(Incident.label_source.in_(["dataset", "analyst"])).scalar() or 0,
        "data_sources": {s or "unknown": n for s, n in db.query(Incident.data_source, func.count(Incident.id)).group_by(Incident.data_source).all()},
    })


@router.get("/attacks", response_model=ApiResponse[List[Dict[str, Any]]])
def get_attack_distribution(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    rows = db.query(Incident.attack_type, func.count(Incident.id)).group_by(Incident.attack_type).order_by(desc(func.count(Incident.id))).all()
    return ApiResponse(data=[{"attack_type": r[0] or "Unknown", "count": r[1]} for r in rows])


@router.get("/severity", response_model=ApiResponse[List[Dict[str, Any]]])
def get_severity_distribution(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    order = {"Critical": 1, "High": 2, "Medium": 3, "Low": 4}
    rows = db.query(Incident.risk_level, func.count(Incident.id)).group_by(Incident.risk_level).all()
    data = [{"risk_level": r[0] or "Low", "count": r[1]} for r in rows]
    data.sort(key=lambda x: order.get(x["risk_level"], 99))
    return ApiResponse(data=data)


@router.get("/protocols", response_model=ApiResponse[List[Dict[str, Any]]])
def get_protocol_distribution(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    rows = db.query(Incident.protocol, func.count(Incident.id)).group_by(Incident.protocol).all()
    return ApiResponse(data=[{"protocol": PROTOCOL_NAMES.get(r[0], f"Proto-{r[0]}"), "count": r[1]} for r in rows])


@router.get("/ports", response_model=ApiResponse[List[Dict[str, Any]]])
def get_top_ports(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    rows = db.query(Incident.destination_port, func.count(Incident.id)).group_by(Incident.destination_port).order_by(desc(func.count(Incident.id))).limit(8).all()
    return ApiResponse(data=[{"port": r[0], "count": r[1]} for r in rows])


@router.get("/trends", response_model=ApiResponse[List[Dict[str, Any]]])
def get_incident_trends(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Daily incident counts by *event* time (flow timestamp), with critical/high breakdown."""
    rows = db.query(Incident.timestamp, Incident.risk_level).filter(Incident.timestamp.isnot(None)).all()
    buckets: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()
    for ts, level in sorted(rows, key=lambda r: r[0]):
        day = ts.strftime("%Y-%m-%d")
        b = buckets.setdefault(day, {"date": day, "total": 0, "critical": 0, "high": 0})
        b["total"] += 1
        if level == "Critical":
            b["critical"] += 1
        elif level == "High":
            b["high"] += 1
    return ApiResponse(data=list(buckets.values()))
