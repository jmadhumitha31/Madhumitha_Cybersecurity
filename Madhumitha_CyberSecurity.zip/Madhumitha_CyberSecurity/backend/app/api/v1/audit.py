from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import User
from app.database.repositories.audit_repo import audit_repo
from app.schemas.common import ApiResponse
from app.services.auth_service import require_role

router = APIRouter(prefix="/audit", tags=["Audit"])


@router.get("", response_model=ApiResponse[Dict[str, Any]])
def list_audit_logs(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    action: Optional[str] = None,
    username: Optional[str] = None,
    incident_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(["ADMIN"])),
):
    """Immutable activity trail (logins, analyses, searches, feedback, retraining). Administrators only."""
    rows, total = audit_repo.list_logs(db, page, page_size, action, username, incident_id)
    return ApiResponse(data={
        "total": total, "page": page, "page_size": page_size,
        "items": [
            {"id": r.id, "timestamp": r.timestamp, "username": r.username, "action": r.action, "incident_id": r.incident_id,
             "endpoint": r.endpoint, "model_provider": r.model_provider, "fallback_used": r.fallback_used, "status": r.status,
             "ip_address": r.ip_address, "details": r.details}
            for r in rows
        ],
    })
