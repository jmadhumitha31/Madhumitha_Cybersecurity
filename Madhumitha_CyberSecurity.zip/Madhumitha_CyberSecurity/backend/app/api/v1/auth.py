from typing import List

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.config import settings
from app.database.connection import get_db
from app.database.models import User
from app.database.repositories.audit_repo import audit_repo
from app.schemas.auth import Token, UserCreate, UserLogin, UserResponse
from app.schemas.common import ApiResponse
from app.services.auth_service import (
    create_access_token,
    get_current_user,
    get_password_hash,
    login_throttle,
    require_role,
    verify_password,
)

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


@router.post("/login", response_model=ApiResponse[Token])
def login(login_data: UserLogin, request: Request, db: Session = Depends(get_db)):
    ip = _ip(request)
    wait = login_throttle.blocked_for(login_data.username, ip)
    if wait:
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail=f"Too many failed attempts. Try again in {wait}s.")
    user = db.query(User).filter(User.username == login_data.username).first()
    if not user or not user.is_active or not verify_password(login_data.password, user.hashed_password):
        login_throttle.fail(login_data.username, ip)
        audit_repo.record(db, action="LOGIN_FAILED", username=login_data.username[:50], status="FAILURE", ip_address=ip, details={"reason": "Invalid credentials"})
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect username or password")

    login_throttle.reset(login_data.username, ip)
    token = create_access_token({"sub": user.username, "role": user.role, "user_id": user.id})
    audit_repo.record(db, action="LOGIN_SUCCESS", user_id=user.id, username=user.username, ip_address=ip)
    return ApiResponse(data=Token(access_token=token, token_type="bearer", user_id=user.id, username=user.username, role=user.role))


@router.get("/me", response_model=ApiResponse[UserResponse])
def get_current_user_profile(current_user: User = Depends(get_current_user)):
    return ApiResponse(data=UserResponse.model_validate(current_user))


@router.post("/register", response_model=ApiResponse[UserResponse], status_code=status.HTTP_201_CREATED)
def register(user_in: UserCreate, request: Request, db: Session = Depends(get_db), current_user: User = Depends(require_role(["ADMIN"]))):
    """Create an account. Admin only: self-service registration is disabled (it allowed anyone to mint ADMIN accounts)."""
    return _create_user(user_in, request, db, actor=current_user)


@router.post("/signup", response_model=ApiResponse[UserResponse], status_code=status.HTTP_201_CREATED)
def public_signup(user_in: UserCreate, request: Request, db: Session = Depends(get_db)):
    """Self-registration (VIEWER only). Disabled unless ALLOW_PUBLIC_REGISTRATION=true."""
    if not settings.ALLOW_PUBLIC_REGISTRATION:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Self-registration is disabled; ask an administrator for an account")
    user_in.role = "VIEWER"
    return _create_user(user_in, request, db, actor=None)


def _create_user(user_in: UserCreate, request: Request, db: Session, actor):
    existing = db.query(User).filter((User.username == user_in.username) | (User.email == user_in.email)).first()
    if existing:
        raise HTTPException(status_code=400, detail="Username or email already registered")
    user = User(username=user_in.username, email=user_in.email, hashed_password=get_password_hash(user_in.password), role=user_in.role)
    db.add(user)
    db.commit()
    db.refresh(user)
    audit_repo.record(
        db, action="USER_CREATED", user_id=actor.id if actor else user.id, username=actor.username if actor else user.username,
        ip_address=_ip(request), details={"new_user": user.username, "role": user.role},
    )
    return ApiResponse(data=UserResponse.model_validate(user))


@router.get("/users", response_model=ApiResponse[List[UserResponse]])
def list_users(db: Session = Depends(get_db), current_user: User = Depends(require_role(["ADMIN"]))):
    return ApiResponse(data=[UserResponse.model_validate(u) for u in db.query(User).order_by(User.id).all()])
