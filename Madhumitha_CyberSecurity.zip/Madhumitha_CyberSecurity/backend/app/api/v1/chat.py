from typing import Any, Dict, List

from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import User
from app.schemas.chat import ChatQueryRequest, ChatQueryResponse
from app.schemas.common import ApiResponse
from app.services.auth_service import get_current_user
from app.services.chat_service import chat_service

router = APIRouter(prefix="/chat", tags=["SOC AI Chatbot & Copilot"])

SUGGESTED_PROMPTS = [
    {"id": "triage", "title": "What should I look at first?", "category": "Triage",
     "prompt": "Which kinds of suspicious network activity should be prioritized for investigation, and why?"},
    {"id": "similar", "title": "Has this happened before?", "category": "Incident Forensics",
     "prompt": "Has a similar network security incident occurred previously, and what type of attack was involved?"},
    {"id": "traffic_profile", "title": "Attack traffic characteristics", "category": "Telemetry Analysis",
     "prompt": "What network traffic characteristics are associated with a Port Scan compared with benign traffic in CIC-IDS2017?"},
    {"id": "ddos_mitigation", "title": "DDoS playbook", "category": "Mitigation Playbooks",
     "prompt": "What are the analyst-supervised containment and mitigation steps for an HTTP flood DDoS based on NIST SP 800-61 r2?"},
    {"id": "mitre", "title": "MITRE ATT&CK mapping", "category": "Threat Intelligence",
     "prompt": "Which MITRE ATT&CK techniques correspond to Infiltration and Botnet C2 beaconing?"},
    {"id": "bruteforce", "title": "SSH brute-force triage", "category": "Network Defense",
     "prompt": "How do I tell a successful SSH brute-force from failed attempts in flow data and auth logs?"},
]


def _ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


@router.post("/message", response_model=ApiResponse[ChatQueryResponse], summary="Query the SOC AI Copilot")
def chat_message(payload: ChatQueryRequest, request: Request, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return ApiResponse(data=chat_service.process_chat(db, payload, current_user.username, _ip(request), current_user.id))


@router.get("/suggestions", response_model=ApiResponse[List[Dict[str, Any]]])
def get_suggestions(current_user: User = Depends(get_current_user)):
    return ApiResponse(data=SUGGESTED_PROMPTS)


@router.post("/incident/{incident_id}", response_model=ApiResponse[ChatQueryResponse], summary="Focused incident chat")
def chat_incident(incident_id: int, payload: ChatQueryRequest, request: Request, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    payload.incident_id = incident_id
    return ApiResponse(data=chat_service.process_chat(db, payload, current_user.username, _ip(request), current_user.id))
