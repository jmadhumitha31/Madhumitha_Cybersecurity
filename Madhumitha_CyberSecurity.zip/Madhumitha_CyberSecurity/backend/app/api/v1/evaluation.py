from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import AnalysisResult, Incident, User
from app.database.repositories.evaluation_repo import evaluation_repo
from app.evaluation.deepeval_eval import start_deepeval
from app.evaluation.llm_judge import run_llm_judge, run_llm_judge_batch
from app.evaluation.retrieval_eval import run_retrieval_evaluation
from app.ml.evaluation import run_ml_evaluation
from app.observability.tracing import tracer
from app.schemas.common import ApiResponse
from app.schemas.evaluation import EvaluationRunResponse
from app.services.auth_service import get_current_user, require_role

router = APIRouter(prefix="/evaluation", tags=["Evaluation"])
WRITE = ["ADMIN", "ANALYST"]


def _latest(db: Session, eval_type: str, label: str) -> ApiResponse:
    run = evaluation_repo.get_latest(db, eval_type)
    if not run:
        return ApiResponse(success=False, data={"status": "not_executed", "message": f"{label} has not been executed yet."})
    return ApiResponse(data={**run.metrics, "run_id": run.id, "run_status": run.status, "run_created_at": run.created_at})


# --- ML (classifier + intrusion-risk + anomaly) ------------------------------------------------
@router.get("/ml", response_model=ApiResponse[Dict[str, Any]])
def get_ml_evaluation(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return ApiResponse(data=run_ml_evaluation(None, recompute=False))


@router.post("/ml", response_model=ApiResponse[Dict[str, Any]])
def trigger_ml_evaluation(db: Session = Depends(get_db), current_user: User = Depends(require_role(WRITE))):
    """Re-score the active model on the deterministic held-out split of the dataset."""
    tracer.set_query("re-score the ML models on the held-out split")
    res = run_ml_evaluation(db, recompute=True)
    tracer.summarize(status=res.get("status"), dataset_source=res.get("dataset_source"), n_test=res.get("n_test"))
    return ApiResponse(data=res)


# --- Retrieval quality --------------------------------------------------------------------------
@router.get("/retrieval", response_model=ApiResponse[Dict[str, Any]])
def get_retrieval(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return _latest(db, "RETRIEVAL", "Retrieval evaluation")


@router.post("/retrieval", response_model=ApiResponse[Dict[str, Any]])
def trigger_retrieval(db: Session = Depends(get_db), current_user: User = Depends(require_role(WRITE))):
    tracer.set_query("retrieval benchmark (leave-one-out)")
    res = run_retrieval_evaluation(db)
    hybrid = (res.get("with_endpoints") or {}).get("hybrid") or {}
    tracer.summarize(status=res.get("status"), queries=res.get("queries"), precision_at_1=hybrid.get("precision_at_1"), precision_at_5=hybrid.get("precision_at_5"),
                     mrr=hybrid.get("mrr"))
    return ApiResponse(data=res)


# --- DeepEval (background job: dozens of judge-LLM calls) ----------------------------------------------
@router.get("/deepeval", response_model=ApiResponse[Dict[str, Any]])
def get_deepeval(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return _latest(db, "DEEPEVAL", "DeepEval evaluation")


@router.post("/deepeval", response_model=ApiResponse[Dict[str, Any]], status_code=202)
def trigger_deepeval(limit: int = Query(4, ge=1, le=10), db: Session = Depends(get_db), current_user: User = Depends(require_role(WRITE))):
    """Starts DeepEval on the latest stored investigations; poll GET /evaluation/deepeval for status and scores."""
    tracer.set_query(f"DeepEval on the latest {limit} investigations")
    out = start_deepeval(db, limit)
    tracer.summarize(status=out.get("status"), run_id=out.get("run_id"), cases=limit)
    return ApiResponse(data=out)


# --- LLM-as-Judge ------------------------------------------------------------------------------------
@router.get("/judge", response_model=ApiResponse[Dict[str, Any]])
def get_judge(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    run = evaluation_repo.get_latest(db, "LLM_JUDGE_BATCH") or evaluation_repo.get_latest(db, "LLM_JUDGE")
    if not run:
        return ApiResponse(success=False, data={"status": "not_executed", "message": "LLM-as-Judge has not been executed yet."})
    return ApiResponse(data={**run.metrics, "run_id": run.id, "run_status": run.status, "run_created_at": run.created_at})


@router.post("/judge", response_model=ApiResponse[Dict[str, Any]])
def trigger_llm_judge(incident_id: int = Query(...), db: Session = Depends(get_db), current_user: User = Depends(require_role(WRITE))):
    incident = db.query(Incident).filter(Incident.id == incident_id).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    latest = (
        db.query(AnalysisResult).filter(AnalysisResult.incident_id == incident_id).order_by(AnalysisResult.created_at.desc(), AnalysisResult.id.desc()).first()
    )
    if not latest:
        raise HTTPException(status_code=400, detail="Incident has not undergone AI investigation yet. Run /analyze first.")
    incident_dict = {c.name: getattr(incident, c.name) for c in Incident.__table__.columns}
    analysis_dict = {
        "attack_prediction": latest.attack_prediction, "historical_matches": latest.historical_matches, "analysis": latest.analysis,
        "recommendations": latest.recommendations, "llm_model": latest.llm_model, "llm_provider": latest.llm_provider,
    }
    tracer.set_incident(incident_id)
    tracer.set_query(f"LLM-as-Judge on the latest analysis of incident #{incident_id}")
    result = run_llm_judge(incident_dict, analysis_dict, db)
    tracer.summarize(status=result.get("status"), judge_model=result.get("judge_model"), independent=result.get("independent"),
                     verdict=(result.get("scores") or {}).get("verdict"))
    return ApiResponse(success=result["status"] == "ok", data=result)


@router.post("/judge/batch", response_model=ApiResponse[Dict[str, Any]])
def trigger_judge_batch(limit: int = Query(5, ge=1, le=15), db: Session = Depends(get_db), current_user: User = Depends(require_role(WRITE))):
    tracer.set_query(f"LLM-as-Judge batch over {limit} analyses")
    result = run_llm_judge_batch(db, limit)
    tracer.summarize(status=result.get("status"))
    return ApiResponse(success=result["status"] == "ok", data=result)


# --- history -----------------------------------------------------------------------------------------
@router.get("/runs", response_model=ApiResponse[List[EvaluationRunResponse]])
def get_evaluation_runs(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return ApiResponse(data=[EvaluationRunResponse.model_validate(r) for r in evaluation_repo.list_all(db, limit=50)])
