from typing import Any, Dict, List

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import User
from app.database.repositories.feedback_repo import feedback_repo
from app.schemas.common import ApiResponse
from app.schemas.incident import FeedbackResponse
from app.services.auth_service import get_current_user

router = APIRouter(prefix="/feedback", tags=["Feedback Loop"])


@router.get("", response_model=ApiResponse[List[FeedbackResponse]])
def list_feedback(limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0), db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return ApiResponse(data=[FeedbackResponse.model_validate(f) for f in feedback_repo.list_all(db, limit=limit, offset=offset)])


@router.get("/stats", response_model=ApiResponse[Dict[str, Any]])
def feedback_stats(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Analyst agreement rate, most frequent corrections and how many confirmed labels await the next retrain."""
    return ApiResponse(data=feedback_repo.stats(db))
