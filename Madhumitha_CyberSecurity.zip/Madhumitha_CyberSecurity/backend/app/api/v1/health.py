import importlib.util
from typing import Any, Dict

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, text
from sqlalchemy.orm import Session

from app.config import settings
from app.database.connection import get_db
from app.database.models import Incident, IncidentEmbedding
from app.llm.fallback import llm_fallback_handler
from app.ml.predictor import ml_predictor
from app.rag.embeddings import embedding_service
from app.rag.index import hybrid_index
from app.schemas.common import ApiResponse

router = APIRouter(prefix="/health", tags=["System Health"])


@router.get("", response_model=ApiResponse[Dict[str, Any]])
def check_health(deep: bool = Query(False, description="Also probe NVIDIA/Ollama live (slower)"), db: Session = Depends(get_db)):
    c: Dict[str, Any] = {}

    try:
        db.execute(text("SELECT 1"))
        n = db.query(func.count(Incident.id)).scalar() or 0
        c["database"] = {"status": "Healthy", "details": f"{n} incidents stored", "incidents": n, "engine": settings.DATABASE_URL.split(":")[0]}
    except Exception as e:  # noqa: BLE001
        c["database"] = {"status": "Unavailable", "details": str(e)[:200]}

    emb = embedding_service.info() if deep or embedding_service._loaded else {"backend": "not loaded yet", "model": embedding_service.model_name, "dimension": None, "semantic": None}
    if emb["backend"] == "fastembed":
        c["embeddings"] = {"status": "Healthy", "model": emb["model"], "dimension": emb["dimension"], "details": "Sentence-embedding model loaded (ONNX)"}
    elif emb["backend"] == "hashing-fallback":
        c["embeddings"] = {"status": "Degraded", "model": emb["model"], "dimension": emb["dimension"], "details": f"Hashing fallback active (no semantic generalisation): {emb['error']}"}
    else:
        c["embeddings"] = {"status": "Healthy", "model": emb["model"], "details": "Model loads on first use"}

    try:
        total = db.query(func.count(IncidentEmbedding.id)).scalar() or 0
        if emb["backend"] == "not loaded yet":
            current = total  # cannot compare model identifiers before the backend is chosen
        else:
            current = db.query(func.count(IncidentEmbedding.id)).filter(IncidentEmbedding.embedding_model == embedding_service.identifier).scalar() or 0
        store = hybrid_index.stats()
        place = {"local": "embedded, on-device", "memory": "in memory", "server": "server"}[store["mode"]]
        indexed = store.get("points")
        in_sync = indexed is None or indexed == current  # None: collection not opened yet in this process
        c["vector_index"] = {
            "status": "Healthy" if total and current == total and in_sync else ("Degraded" if total else "Unavailable"),
            "documents": total, "current_model_documents": current, "engine": "qdrant", "store_mode": store["mode"],
            "store_location": store["location"], "qdrant_points": indexed,
            "details": f"Qdrant vector store ({place}: {store['location']}) + BM25"
            + ("" if current == total else f"; {total - current} vectors need POST /search/reindex")
            + ("" if in_sync else f"; Qdrant holds {indexed} of {current} points (syncs on next search)"),
        }
    except Exception as e:  # noqa: BLE001
        c["vector_index"] = {"status": "Unavailable", "details": str(e)[:200]}

    if ml_predictor.is_loaded:
        info = ml_predictor.info()
        c["ml_model"] = {"status": "Healthy", "model_version": info["version"], "dataset_source": info["dataset_source"],
                         "details": f"Classifier + intrusion-risk + anomaly models ({len(info['classes'])} classes) trained on {info['n_train']} flows ({info['dataset_source']})"}
    else:
        c["ml_model"] = {"status": "Degraded", "details": "No trained model: run `python -m app.ml.training`"}

    if deep:
        st = llm_fallback_handler.status(force=True)
        ac, nv, ol = st["aicredits"], st["nvidia"], st["ollama"]
        if ac.get("model_callable"):
            c["aicredits_llm"] = {"status": "Healthy", "role": "Primary LLM", "model": settings.AICREDITS_MODEL, "configured": True, "latency_ms": ac.get("latency_ms"), "details": "AICredits API key accepted; model answered live probe"}
        elif ac.get("configured"):
            c["aicredits_llm"] = {"status": "Degraded", "role": "Primary LLM", "model": settings.AICREDITS_MODEL, "configured": True, "details": ac.get("error", "unreachable")}
        else:
            c["aicredits_llm"] = {"status": "Degraded", "role": "Primary LLM", "configured": False, "details": "AICREDITS_API_KEY not set"}

        if nv.get("model_callable"):
            c["nvidia_llm"] = {"status": "Healthy", "role": "Fallback LLM", "model": settings.NVIDIA_MODEL, "judge_model": settings.JUDGE_MODEL, "configured": True, "latency_ms": nv.get("latency_ms"), "details": "API key accepted; generation model answered a live probe"}
        elif nv.get("configured"):
            c["nvidia_llm"] = {"status": "Degraded", "role": "Fallback LLM", "model": settings.NVIDIA_MODEL, "configured": True, "details": nv.get("error", "unreachable")}
        else:
            c["nvidia_llm"] = {"status": "Degraded", "role": "Fallback LLM", "configured": False, "details": "NVIDIA_API_KEY not set; using Ollama/offline playbooks"}
        c["ollama_llm"] = (
            {"status": "Healthy", "model": ol["model"], "details": "Local Ollama daemon reachable"}
            if ol.get("reachable") and ol.get("model_installed", True)
            else {"status": "Degraded", "model": ol.get("model"), "details": "Ollama not reachable/model missing; offline playbooks are the last fallback"}
        )
    else:
        ac = llm_fallback_handler.aicredits
        nv = llm_fallback_handler.nvidia
        c["aicredits_llm"] = {"status": "Healthy" if ac.is_available() else "Degraded", "role": "Primary LLM", "model": settings.AICREDITS_MODEL, "configured": ac.is_available(),
                              "details": "Key configured (use ?deep=true for a live probe)" if ac.is_available() else "AICREDITS_API_KEY not set"}
        c["nvidia_llm"] = {"status": "Healthy" if nv.is_available() else "Degraded", "role": "Fallback LLM", "model": settings.NVIDIA_MODEL, "configured": nv.is_available(),
                           "details": "Key configured (use ?deep=true for a live probe)" if nv.is_available() else "NVIDIA_API_KEY not set"}

    c["evaluation_services"] = {
        "status": "Healthy" if importlib.util.find_spec("deepeval") else "Degraded",
        "suites": ["ML Evaluation", "Retrieval Evaluation", "DeepEval", "LLM-as-Judge"],
        "details": "deepeval installed" if importlib.util.find_spec("deepeval") else "deepeval package missing",
    }
    c["rag_pipeline"] = {"status": "Healthy", "threshold": settings.SIMILARITY_THRESHOLD, "alpha": settings.HYBRID_ALPHA}

    if c["database"]["status"] == "Unavailable":
        overall = "Unavailable"
    elif any(v["status"] in ("Degraded", "Unavailable") for v in c.values()):
        overall = "Degraded"
    else:
        overall = "Healthy"
    return ApiResponse(data={"status": overall, "app_name": settings.APP_NAME, "version": settings.APP_VERSION, "environment": settings.ENVIRONMENT, "components": c})
