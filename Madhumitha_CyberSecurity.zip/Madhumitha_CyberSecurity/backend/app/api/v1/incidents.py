from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import AnalysisResult, User
from app.database.repositories.audit_repo import audit_repo
from app.database.repositories.feedback_repo import feedback_repo
from app.database.repositories.incident_repo import incident_repo
from app.domain import INCIDENT_STATUSES
from app.graph.workflow import run_investigation_workflow
from app.guardrails.input_validation import validate_network_incident
from app.logging_config import logger
from app.ml.predictor import ml_predictor
from app.ml.risk import assess_risk
from app.observability.tracing import tracer
from app.schemas.common import ApiResponse, PaginatedResponse, PaginationMeta
from app.schemas.incident import (
    AnalysisResponse,
    ClassifyRequest,
    FeedbackCreate,
    FeedbackResponse,
    IncidentCreate,
    IncidentResponse,
    StatusUpdate,
)
from app.services.auth_service import get_current_user, require_role
from app.services.incident_service import FeedbackError, apply_analysis, apply_feedback, create_incident, incident_to_flow

router = APIRouter(prefix="/incidents", tags=["Incidents"])
WRITE_ROLES = ["ADMIN", "ANALYST"]


def _ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _guard(data: Dict[str, Any]) -> None:
    ok, errors = validate_network_incident(data)
    if not ok:
        raise HTTPException(status_code=422, detail={"message": "Input validation guardrail failed", "errors": errors})


def _flow_brief(data: Dict[str, Any]) -> Dict[str, Any]:
    """Compact, non-sensitive description of a flow for the trace input."""
    keys = ("flow_id", "source_ip", "source_port", "destination_ip", "destination_port", "protocol", "flow_duration", "total_fwd_packets",
            "total_bwd_packets", "flow_packets_per_sec", "flow_bytes_per_sec", "syn_count", "rst_count", "ack_count", "packet_length_mean")
    return {k: data.get(k) for k in keys if data.get(k) is not None}


def _get_or_404(db: Session, incident_id: int):
    inc = incident_repo.get_by_id(db, incident_id)
    if not inc:
        raise HTTPException(status_code=404, detail="Incident record not found")
    return inc


@router.post("", response_model=ApiResponse[IncidentResponse], status_code=status.HTTP_201_CREATED)
def create_incident_endpoint(incident_in: IncidentCreate, request: Request, db: Session = Depends(get_db), current_user: User = Depends(require_role(WRITE_ROLES))):
    """Create an incident. The flow is validated, embedded for retrieval and automatically triaged by the ML models."""
    data = incident_in.model_dump()
    tracer.set_query(f"create incident {data.get('flow_id') or '(auto flow id)'}")
    tracer.set_input(flow=_flow_brief(data))
    _guard(data)
    if data.get("flow_id") and incident_repo.get_by_flow_id(db, data["flow_id"]):
        raise HTTPException(status_code=409, detail=f"flow_id '{data['flow_id']}' already exists")
    inc = create_incident(db, data)
    tracer.set_incident(inc.id)
    tracer.summarize(attack_type=inc.attack_type, label_source=inc.label_source, risk_level=inc.risk_level, priority=inc.priority, risk_score=inc.risk_score)
    tracer.set_output(incident_id=inc.id, attack_type=inc.attack_type, confidence=inc.prediction_confidence, risk_level=inc.risk_level)
    audit_repo.record(db, action="INCIDENT_CREATED", user_id=current_user.id, username=current_user.username, incident_id=inc.id,
                      endpoint="/api/v1/incidents", ip_address=_ip(request), details={"attack_type": inc.attack_type, "risk": inc.risk_level})
    return ApiResponse(data=IncidentResponse.model_validate(inc))


@router.post("/classify", response_model=ApiResponse[Dict[str, Any]])
def classify_flow(flow: ClassifyRequest, db: Session = Depends(get_db), current_user: User = Depends(require_role(WRITE_ROLES))):
    """Classify a flow without storing it: attack type, intrusion probability, anomaly score, risk/priority and explanation."""
    data = flow.model_dump()
    tracer.set_query(f"classify flow {data.get('flow_id') or data.get('source_ip')}")
    tracer.set_input(flow=_flow_brief(data))
    _guard(data)
    det = ml_predictor.predict_attack(data, explain=True)
    if det.get("status") != "ok":
        raise HTTPException(status_code=503, detail="ML model is not available")
    risk = assess_risk(data, det["attack_type"], det["confidence"], det["intrusion_probability"], det["anomaly_score"])
    tracer.summarize(attack_type=det["attack_type"], confidence=det["confidence"], risk_level=risk["risk_level"], risk_score=risk["risk_score"])
    tracer.set_output(attack_type=det["attack_type"], confidence=det["confidence"], risk_level=risk["risk_level"])
    return ApiResponse(data={"prediction": det, "risk": risk, "trace_id": tracer.current_trace_id()})


@router.get("", response_model=PaginatedResponse[IncidentResponse])
def list_incidents(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    attack_type: Optional[str] = None,
    risk_level: Optional[str] = None,
    status_filter: Optional[str] = Query(None, alias="status"),
    search: Optional[str] = Query(None, max_length=100),
    label_source: Optional[str] = None,
    data_source: Optional[str] = None,
    min_risk: Optional[float] = Query(None, ge=0, le=100),
    sort: str = Query("created_at", pattern="^(created_at|timestamp|risk|priority)$"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    items, total = incident_repo.list_incidents(
        db, page=page, page_size=page_size, sort=sort, attack_type=attack_type, risk_level=risk_level, status=status_filter,
        search=search, label_source=label_source, data_source=data_source, min_risk=min_risk,
    )
    return PaginatedResponse(
        data=[IncidentResponse.model_validate(i) for i in items],
        pagination=PaginationMeta(page=page, page_size=page_size, total=total, total_pages=max(1, (total + page_size - 1) // page_size)),
    )


@router.get("/queue", response_model=ApiResponse[List[IncidentResponse]])
def triage_queue(limit: int = Query(25, ge=1, le=100), db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Prioritised triage queue: open incidents, highest risk score first - 'what should be investigated next?'"""
    return ApiResponse(data=[IncidentResponse.model_validate(i) for i in incident_repo.queue(db, limit=limit)])


@router.get("/{incident_id}", response_model=ApiResponse[Dict[str, Any]])
def get_incident_details(incident_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    incident = _get_or_404(db, incident_id)
    latest = (
        db.query(AnalysisResult).filter(AnalysisResult.incident_id == incident_id).order_by(AnalysisResult.created_at.desc(), AnalysisResult.id.desc()).first()
    )
    analysis = None
    if latest:
        analysis = {
            "id": latest.id, "attack_prediction": latest.attack_prediction, "risk_assessment": latest.risk_assessment,
            "historical_matches": latest.historical_matches, "analysis": latest.analysis, "recommendations": latest.recommendations,
            "llm_provider": latest.llm_provider, "llm_model": latest.llm_model, "llm_attempts": latest.llm_attempts,
            "fallback_used": latest.fallback_used, "quality_checks": latest.quality_checks, "execution_trace": latest.workflow_trace,
            "execution_time_ms": latest.execution_time_ms, "created_at": latest.created_at, "trace_id": latest.trace_id,
        }
    feedback = [FeedbackResponse.model_validate(f) for f in feedback_repo.list_by_incident(db, incident_id)]
    return ApiResponse(data={"incident": IncidentResponse.model_validate(incident), "latest_analysis": analysis, "feedback": feedback})


@router.get("/{incident_id}/explain", response_model=ApiResponse[Dict[str, Any]])
def explain_incident(incident_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Per-flow SHAP attribution for the model's prediction (no LLM, instant)."""
    inc = _get_or_404(db, incident_id)
    tracer.set_incident(inc.id)
    tracer.set_query(f"explain incident #{inc.id}")
    det = ml_predictor.predict_attack(incident_to_flow(inc), explain=True)
    if det.get("status") != "ok":
        raise HTTPException(status_code=503, detail="ML model is not available")
    tracer.summarize(attack_type=det["attack_type"], confidence=det["confidence"], method=(det.get("explanation") or {}).get("method"))
    tracer.set_output(attack_type=det["attack_type"], confidence=det["confidence"])
    return ApiResponse(data={**det, "trace_id": tracer.current_trace_id()})


@router.post("/{incident_id}/analyze", response_model=ApiResponse[AnalysisResponse])
def analyze_incident(incident_id: int, request: Request, db: Session = Depends(get_db), current_user: User = Depends(require_role(WRITE_ROLES))):
    """Full multi-agent investigation: Detection -> Analysis (RAG) -> Risk -> Response (LLM) -> Output validation."""
    inc = _get_or_404(db, incident_id)
    tracer.set_incident(inc.id)
    tracer.set_query(f"investigate incident #{inc.id} ({inc.flow_id})")
    tracer.set_input(flow=_flow_brief(incident_to_flow(inc)), ground_truth_label=inc.ground_truth_label, label_source=inc.label_source)
    state = run_investigation_workflow(incident_to_flow(inc), db)
    resp = state["final_response"]
    if resp.get("errors"):
        raise HTTPException(status_code=422, detail={"message": "Stored incident failed validation", "errors": resp["errors"]})
    pred, risk = resp["attack_prediction"], resp["risk"]
    checks = resp["quality_checks"]
    tracer.summarize(attack_type=pred.get("attack_type"), confidence=pred.get("confidence"), risk_level=risk["risk_level"], risk_score=risk["risk_score"],
                     llm_provider=resp["llm_provider"], model=resp["llm_model"], fallback_used=resp["fallback_used"], n_matches=len(resp["historical_matches"]),
                     checks_passed=sum(1 for c in checks if c.get("passed")), n_checks=len(checks))
    tracer.set_output(attack_type=pred.get("attack_type"), risk_level=risk["risk_level"], priority=risk["priority"], llm_provider=resp["llm_provider"],
                      model=resp["llm_model"], n_recommendations=len(resp["recommendations"]), requires_analyst_review=resp["requires_analyst_review"])

    apply_analysis(db, inc, pred, risk)
    record = AnalysisResult(
        incident_id=incident_id, workflow_trace=state["execution_trace"], attack_prediction=pred, risk_assessment=risk,
        historical_matches=resp["historical_matches"], analysis=resp["analysis"], recommendations=resp["recommendations"],
        llm_provider=resp["llm_provider"], llm_model=resp["llm_model"], fallback_used=resp["fallback_used"], llm_attempts=resp["llm_attempts"],
        quality_checks=resp["quality_checks"], execution_time_ms=resp.get("execution_time_ms", 0.0), trace_id=tracer.current_trace_id(),
    )
    db.add(record)
    db.commit()
    audit_repo.record(
        db, action="INCIDENT_ANALYZED", user_id=current_user.id, username=current_user.username, incident_id=inc.id,
        endpoint=f"/api/v1/incidents/{incident_id}/analyze", model_provider=resp["llm_provider"], fallback_used=resp["fallback_used"],
        ip_address=_ip(request), details={"llm_model": resp["llm_model"], "risk": risk["risk_level"], "ms": resp.get("execution_time_ms")},
    )
    return ApiResponse(data=AnalysisResponse(
        incident_id=incident_id, attack_prediction=pred, risk_assessment=risk, historical_matches=resp["historical_matches"],
        analysis=resp["analysis"], recommendations=resp["recommendations"], llm_provider=resp["llm_provider"], llm_model=resp["llm_model"],
        llm_attempts=resp["llm_attempts"], fallback_used=resp["fallback_used"], quality_checks=resp["quality_checks"],
        requires_analyst_review=resp["requires_analyst_review"], ground_truth_label=inc.ground_truth_label,
        label_mismatch=bool(inc.ground_truth_label and pred.get("attack_type") and inc.ground_truth_label != pred.get("attack_type")),
        execution_trace=state["execution_trace"], execution_time_ms=resp.get("execution_time_ms", 0.0), trace_id=tracer.current_trace_id(),
    ))


@router.post("/{incident_id}/feedback", response_model=ApiResponse[FeedbackResponse])
def submit_feedback(incident_id: int, feedback_in: FeedbackCreate, request: Request, db: Session = Depends(get_db), current_user: User = Depends(require_role(WRITE_ROLES))):
    """Analyst feedback. Judged feedback relabels the incident (analyst ground truth) and re-indexes it; retraining uses it."""
    inc = _get_or_404(db, incident_id)
    tracer.set_incident(inc.id)
    tracer.set_query(f"feedback on incident #{inc.id}: {feedback_in.feedback_type}")
    tracer.set_input(feedback_type=feedback_in.feedback_type, actual_label=feedback_in.actual_label, comment_chars=len(feedback_in.analyst_feedback or ""))
    try:
        fb = apply_feedback(db, inc, feedback_in.feedback_type, feedback_in.actual_label, feedback_in.analyst_feedback, current_user)
    except FeedbackError as e:
        raise HTTPException(status_code=422, detail=str(e))
    tracer.summarize(feedback_type=fb.feedback_type, predicted=fb.prediction, actual=fb.actual_label, applied=fb.applied)
    tracer.set_output(feedback_id=fb.id, applied=fb.applied, actual_label=fb.actual_label)
    audit_repo.record(
        db, action="FEEDBACK_SUBMITTED", user_id=current_user.id, username=current_user.username, incident_id=inc.id, ip_address=_ip(request),
        details={"type": fb.feedback_type, "predicted": fb.prediction, "actual": fb.actual_label, "applied": fb.applied},
    )
    return ApiResponse(data=FeedbackResponse.model_validate(fb))


@router.get("/{incident_id}/feedback", response_model=ApiResponse[List[FeedbackResponse]])
def incident_feedback(incident_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    _get_or_404(db, incident_id)
    return ApiResponse(data=[FeedbackResponse.model_validate(f) for f in feedback_repo.list_by_incident(db, incident_id)])


@router.patch("/{incident_id}/status", response_model=ApiResponse[IncidentResponse])
def update_status(incident_id: int, body: StatusUpdate, request: Request, db: Session = Depends(get_db), current_user: User = Depends(require_role(WRITE_ROLES))):
    if body.status not in INCIDENT_STATUSES:
        raise HTTPException(status_code=422, detail=f"status must be one of {INCIDENT_STATUSES}")
    inc = _get_or_404(db, incident_id)
    old, inc.status = inc.status, body.status
    db.commit()
    db.refresh(inc)
    audit_repo.record(db, action="INCIDENT_STATUS_CHANGED", user_id=current_user.id, username=current_user.username, incident_id=inc.id,
                      ip_address=_ip(request), details={"from": old, "to": body.status})
    return ApiResponse(data=IncidentResponse.model_validate(inc))
