from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Request

from app.config import settings
from app.database.connection import SessionLocal
from app.database.models import User
from app.database.repositories.audit_repo import audit_repo
from app.ml import retrain
from app.ml.bundle import list_versions
from app.ml.evaluation import stored_ml_metrics
from app.ml.predictor import ml_predictor
from app.observability.tracing import tracer
from app.schemas.common import ApiResponse
from app.services.auth_service import get_current_user, require_role

router = APIRouter(prefix="/ml", tags=["Machine Learning"])


@router.get("/model", response_model=ApiResponse[Dict[str, Any]])
def model_info(current_user: User = Depends(get_current_user)):
    """Active model provenance, held-out metrics (classifier, intrusion-risk, anomaly) and version history."""
    if not ml_predictor.is_loaded:
        return ApiResponse(success=False, data={"loaded": False, "message": "No trained model. Run `python -m app.ml.training`."})
    return ApiResponse(data={**ml_predictor.info(), "metrics": stored_ml_metrics(), "versions": list_versions(settings.MODEL_DIR)})


@router.get("/profiles", response_model=ApiResponse[Dict[str, Any]])
def attack_profiles(current_user: User = Depends(get_current_user)):
    """Explainability, global view: which traffic features characterise each attack family (vs benign) + mean |SHAP|."""
    if not ml_predictor.is_loaded:
        raise HTTPException(status_code=503, detail="ML model is not available")
    b = ml_predictor.bundle
    return ApiResponse(data={"model_version": b.version, "profiles": ml_predictor.profiles(), "global_feature_importance": b.global_importance})


@router.post("/retrain", response_model=ApiResponse[Dict[str, Any]], status_code=202)
def start_retraining(request: Request, current_user: User = Depends(require_role(["ADMIN"]))):
    """Retrain on the base dataset + analyst-confirmed labels (background job); promoted only if it does not regress."""
    tracer.set_query("retrain the models on the base dataset + analyst-confirmed labels")
    out = retrain.start_retrain(current_user.username)
    tracer.summarize(started=out.get("started"))
    db = SessionLocal()
    try:
        audit_repo.record(db, action="MODEL_RETRAIN_REQUESTED", user_id=current_user.id, username=current_user.username,
                          ip_address=request.client.host if request.client else None, details={"started": out.get("started")})
    finally:
        db.close()
    return ApiResponse(data=out)


@router.get("/retrain/status", response_model=ApiResponse[Dict[str, Any]])
def retraining_status(current_user: User = Depends(get_current_user)):
    return ApiResponse(data=retrain.status())
