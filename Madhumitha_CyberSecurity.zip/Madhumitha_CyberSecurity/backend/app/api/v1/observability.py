"""Observability and explainability API: a trace for every analyst query, metrics over those traces, and the decision logic.

* ``GET /observability/traces``                 - list/filter the traces (who asked what, outcome, latency)
* ``GET /observability/traces/{trace_id}``      - one trace: span tree, deterministic explanation, linked audit entries
* ``GET /observability/traces/export``          - CSV (summary rows) or JSON (full traces) for offline analysis
* ``GET /observability/metrics``                - volume / outcomes / latency / LLM / retrieval / guardrail statistics
* ``GET /observability/metrics/prometheus``     - the same headline numbers in Prometheus text format
* ``GET /observability/explain/system``         - how the platform decides, with live parameters
* ``DELETE /observability/traces``              - retention (administrators)

Analysts and administrators see every trace; viewers only see their own.
"""
import csv
import io
import json
from datetime import timedelta
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import PlainTextResponse, Response
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import AuditLog, Trace, User
from app.database.repositories.audit_repo import audit_repo
from app.observability.explain import explain_trace, system_explanation
from app.observability.metrics import WINDOWS, compute_metrics, to_prometheus
from app.observability.tracing import tracer
from app.rag.filters import to_naive_utc
from app.schemas.common import ApiResponse
from app.services.auth_service import get_current_user, require_role

router = APIRouter(prefix="/observability", tags=["Observability & Explainability"])
PRIVILEGED = ["ADMIN", "ANALYST"]


def _scope(q, user: User):
    """Viewers are limited to their own traces."""
    return q if user.role in PRIVILEGED else q.filter(Trace.username == user.username)


def _filtered(db: Session, user: User, kind, status, username, incident_id, q, since, until, min_duration_ms, hide_system):
    query = _scope(db.query(Trace), user)
    if kind:
        query = query.filter(Trace.kind == kind) if "*" not in kind else query.filter(Trace.kind.like(kind.replace("*", "%")))
    if status:
        query = query.filter(Trace.status == status)
    if username:
        query = query.filter(Trace.username == username)
    if incident_id is not None:
        query = query.filter(Trace.incident_id == incident_id)
    if q:
        needle = q.strip()
        query = query.filter(or_(Trace.query_text.ilike(f"%{needle}%"), Trace.name.ilike(f"%{needle}%"), Trace.kind.ilike(f"%{needle}%"),
                                 Trace.username.ilike(f"%{needle}%"), Trace.trace_id.startswith(needle.lower())))
    try:
        if since:
            query = query.filter(Trace.started_at >= to_naive_utc(since))
        if until:
            query = query.filter(Trace.started_at <= to_naive_utc(until))
    except ValueError:
        raise HTTPException(status_code=422, detail="since/until must be ISO-8601 timestamps")
    if min_duration_ms is not None:
        query = query.filter(Trace.duration_ms >= min_duration_ms)
    if hide_system:
        query = query.filter(~Trace.kind.like("system.%"))
    return query


def _row(t: Trace) -> Dict[str, Any]:
    summary = {k: v for k, v in (t.summary or {}).items() if k != "counters"}
    return {
        "trace_id": t.trace_id, "kind": t.kind, "name": t.name, "status": t.status, "http_status": t.http_status, "username": t.username, "role": t.role,
        "incident_id": t.incident_id, "query": (t.query_text or "")[:240], "started_at": t.started_at, "duration_ms": t.duration_ms,
        "db_time_ms": t.db_time_ms, "db_queries": t.db_queries, "n_spans": t.n_spans, "summary": summary, "error": (t.error or "")[:300] or None,
    }


def _span_rows(t: Trace) -> List[Dict[str, Any]]:
    by_id = {s.span_id: s for s in t.spans}

    def depth(s) -> int:
        d, seen, cur = 0, set(), s
        while cur.parent_id and cur.parent_id in by_id and cur.parent_id not in seen:
            seen.add(cur.parent_id)
            cur = by_id[cur.parent_id]
            d += 1
        return d

    return [
        {"span_id": s.span_id, "parent_id": s.parent_id, "name": s.name, "component": s.component, "status": s.status,
         "start_offset_ms": s.start_offset_ms, "duration_ms": s.duration_ms, "self_ms": s.self_ms, "depth": depth(s),
         "attributes": s.attributes or {}, "error": s.error}
        for s in sorted(t.spans, key=lambda x: (x.start_offset_ms, x.id))
    ]


def _full(t: Trace) -> Dict[str, Any]:
    return {**_row(t), "query_text": t.query_text, "input": t.input_data or {}, "output": t.output_data or {},
            "summary": {k: v for k, v in (t.summary or {}).items() if k != "counters"}, "counters": (t.summary or {}).get("counters") or {},
            "request_id": t.request_id, "dropped_spans": t.dropped_spans, "error": t.error, "spans": _span_rows(t)}


@router.get("/traces", response_model=ApiResponse[Dict[str, Any]])
def list_traces(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    kind: Optional[str] = Query(None, max_length=48, description="Exact kind, or a prefix pattern such as 'evaluation.*'"),
    status: Optional[str] = Query(None, pattern="^(ok|degraded|rejected|error)$"),
    username: Optional[str] = None,
    incident_id: Optional[int] = None,
    q: Optional[str] = Query(None, max_length=200, description="Text in the query, kind, user or a trace-id prefix"),
    since: Optional[str] = None,
    until: Optional[str] = None,
    min_duration_ms: Optional[float] = Query(None, ge=0),
    include_system: bool = False,
    sort: str = Query("newest", pattern="^(newest|slowest)$"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = _filtered(db, current_user, kind, status, username, incident_id, q, since, until, min_duration_ms, hide_system=not include_system)
    total = query.count()
    order = Trace.duration_ms.desc() if sort == "slowest" else Trace.started_at.desc()
    rows = query.order_by(order, Trace.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    facets_q = _scope(db.query(Trace.kind, Trace.status, func.count(Trace.id)), current_user)
    if not include_system:
        facets_q = facets_q.filter(~Trace.kind.like("system.%"))
    kinds: Dict[str, int] = {}
    statuses: Dict[str, int] = {}
    for k, s, n in facets_q.group_by(Trace.kind, Trace.status).all():
        kinds[k] = kinds.get(k, 0) + int(n)
        statuses[s] = statuses.get(s, 0) + int(n)
    return ApiResponse(data={
        "total": total, "page": page, "page_size": page_size, "items": [_row(t) for t in rows],
        "facets": {"kinds": dict(sorted(kinds.items(), key=lambda kv: kv[1], reverse=True)), "statuses": statuses},
    })


@router.get("/traces/export")
def export_traces(
    request: Request,
    format: str = Query("csv", pattern="^(csv|json)$"),
    kind: Optional[str] = None,
    status: Optional[str] = Query(None, pattern="^(ok|degraded|rejected|error)$"),
    username: Optional[str] = None,
    incident_id: Optional[int] = None,
    q: Optional[str] = Query(None, max_length=200),
    since: Optional[str] = None,
    until: Optional[str] = None,
    min_duration_ms: Optional[float] = Query(None, ge=0),
    limit: int = Query(1000, ge=1, le=5000),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(PRIVILEGED)),
):
    """Download traces for offline analysis. CSV = one summary row per trace (<= 5000); JSON = full traces with spans (<= 500)."""
    query = _filtered(db, current_user, kind, status, username, incident_id, q, since, until, min_duration_ms, hide_system=True)
    if format == "json":
        limit = min(limit, 500)
    rows = query.order_by(Trace.started_at.desc()).limit(limit).all()
    audit_repo.record(db, action="TRACE_EXPORT", user_id=current_user.id, username=current_user.username, endpoint="/api/v1/observability/traces/export",
                      ip_address=request.client.host if request.client else None, details={"format": format, "rows": len(rows)})
    if format == "json":
        return Response(content=json.dumps({"exported": len(rows), "traces": [_full(t) for t in rows]}, default=str, indent=1),
                        media_type="application/json", headers={"Content-Disposition": 'attachment; filename="soc_traces.json"'})
    buf = io.StringIO()
    w = csv.writer(buf)
    cols = ["trace_id", "started_at", "kind", "status", "http_status", "username", "incident_id", "duration_ms", "db_time_ms", "db_queries", "n_spans", "query", "error"]
    w.writerow(cols)

    def safe(v: Any) -> Any:  # neutralise spreadsheet formula injection from analyst-supplied text
        return "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r") else v

    for t in rows:
        r = _row(t)
        w.writerow([safe(r[c]) if c in ("query", "error", "username") else r[c] for c in cols])
    return Response(content=buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="soc_traces.csv"'})


@router.get("/traces/{trace_id}", response_model=ApiResponse[Dict[str, Any]])
def get_trace(trace_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    t = _scope(db.query(Trace), current_user).filter(Trace.trace_id == trace_id.lower()).first()
    if t is None:
        raise HTTPException(status_code=404, detail="Trace not found")
    full = _full(t)
    # audit entries written during this trace (same account, same moment, carrying this trace id)
    lo, hi = t.started_at - timedelta(seconds=2), t.started_at + timedelta(milliseconds=(t.duration_ms or 0) + 2000)
    logs = db.query(AuditLog).filter(AuditLog.timestamp >= lo, AuditLog.timestamp <= hi)
    if t.username:
        logs = logs.filter(AuditLog.username == t.username)
    audit = [{"action": a.action, "status": a.status, "timestamp": a.timestamp, "model_provider": a.model_provider, "fallback_used": a.fallback_used}
             for a in logs.all() if (a.details or {}).get("trace_id") == t.trace_id]
    return ApiResponse(data={"trace": full, "explanation": explain_trace(full), "audit": audit})


@router.get("/metrics", response_model=ApiResponse[Dict[str, Any]])
def metrics(window: str = Query("24h", pattern="^(1h|6h|24h|7d|30d)$"), db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Volume, outcomes, latency percentiles, LLM / retrieval / guardrail statistics and where the time goes."""
    return ApiResponse(data={**compute_metrics(db, window), "windows": list(WINDOWS)})


@router.get("/metrics/prometheus", response_class=PlainTextResponse)
def metrics_prometheus(window: str = Query("24h", pattern="^(1h|6h|24h|7d|30d)$"), db: Session = Depends(get_db),
                       current_user: User = Depends(require_role(PRIVILEGED))):
    return PlainTextResponse(to_prometheus(compute_metrics(db, window)), media_type="text/plain; version=0.0.4")


@router.get("/explain/system", response_model=ApiResponse[Dict[str, Any]])
def explain_system(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """How the platform decides at each stage, with the live weights, thresholds and models."""
    return ApiResponse(data=system_explanation(db))


@router.delete("/traces", response_model=ApiResponse[Dict[str, Any]])
def delete_old_traces(request: Request, older_than_days: int = Query(30, ge=0, le=3650), db: Session = Depends(get_db),
                      current_user: User = Depends(require_role(["ADMIN"]))):
    """Retention: remove traces (and spans) older than N days. 0 removes everything."""
    removed = tracer.prune(older_than_days)
    audit_repo.record(db, action="TRACE_PRUNE", user_id=current_user.id, username=current_user.username, endpoint="/api/v1/observability/traces",
                      ip_address=request.client.host if request.client else None, details={"older_than_days": older_than_days, "removed": removed})
    return ApiResponse(data={"removed": removed, "older_than_days": older_than_days})
