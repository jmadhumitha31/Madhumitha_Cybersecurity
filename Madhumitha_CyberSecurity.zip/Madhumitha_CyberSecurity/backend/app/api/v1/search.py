from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.config import settings
from app.database.connection import get_db
from app.database.models import User
from app.database.repositories.audit_repo import audit_repo
from app.guardrails.relevance import relevance_guardrail
from app.guardrails.security import security_guardrail
from app.observability.tracing import tracer
from app.rag.embeddings import embedding_service
from app.rag.hybrid_search import hybrid_search_service
from app.rag.index import hybrid_index
from app.rag.retriever import NO_MATCH_MESSAGE
from app.schemas.common import ApiResponse
from app.schemas.search import SearchRequest, SearchResponseData, SearchResultItem
from app.services.auth_service import get_current_user, require_role
from app.services.incident_service import reindex_all

router = APIRouter(prefix="/search", tags=["Search"])


@router.post("", response_model=ApiResponse[SearchResponseData])
def search_incidents(search_req: SearchRequest, request: Request, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Hybrid search (sentence-embedding similarity + BM25) over historical incidents with SQL metadata filters."""
    query_str = (search_req.query or "").strip()
    filters = search_req.filters.model_dump(exclude_none=True) if search_req.filters else {}
    tracer.set_query(query_str or "(metadata filters only)")
    tracer.set_input(search_type=search_req.search_type, filters=filters, top_k=search_req.top_k, similarity_threshold=search_req.similarity_threshold)
    if not query_str and not filters:
        raise HTTPException(status_code=422, detail="Provide a text query, at least one metadata filter, or both")

    if query_str:
        ok, msg = security_guardrail.inspect_input(query_str)
        if not ok:
            raise HTTPException(status_code=400, detail=msg)
        ok, msg = relevance_guardrail.is_cybersecurity_relevant(query_str)
        if not ok:
            raise HTTPException(status_code=400, detail=msg)

    threshold = settings.TEXT_SEARCH_THRESHOLD if search_req.similarity_threshold is None else search_req.similarity_threshold
    if query_str:
        raw = hybrid_search_service.search(
            db=db, query=query_str, filters=filters, top_k=search_req.top_k, similarity_threshold=threshold, search_mode=search_req.search_type,
        )
        mode = search_req.search_type
    else:
        raw = hybrid_search_service.browse(db, filters, top_k=search_req.top_k)
        mode = "metadata"

    items = [SearchResultItem(**{k: r[k] for k in SearchResultItem.model_fields}) for r in raw]
    info = embedding_service.info()
    data = SearchResponseData(
        total_matches=len(items), results=items, query_applied=query_str or None, search_type_used=mode, filters_applied=filters,
        similarity_threshold_used=threshold if query_str else None,
        message=None if items else NO_MATCH_MESSAGE, trace_id=tracer.current_trace_id(),
        search_strategy={
            "semantic_search": mode in ("semantic", "hybrid"),
            "keyword_search": mode in ("keyword", "hybrid"),
            "metadata_filtering": bool(filters),
            "alpha": settings.HYBRID_ALPHA if mode == "hybrid" else None,
            "embedding_backend": info["backend"],
            "embedding_model": info["model"],
            "indexed_documents": hybrid_index.size(db),
        },
    )
    tracer.summarize(search_type=mode, n_results=len(items), empty=not items, n_filters=len(filters), threshold=threshold if query_str else None)
    tracer.set_output(n_results=len(items), results=[{"incident_id": i.incident_id, "attack_type": i.attack_type, "score": i.hybrid_score} for i in items[:10]],
                      message=None if items else NO_MATCH_MESSAGE)
    audit_repo.record(
        db, action="INCIDENT_SEARCH", user_id=current_user.id, username=current_user.username, endpoint="/api/v1/search",
        ip_address=request.client.host if request.client else None,
        details={"query": query_str[:200], "type": mode, "filters": list(filters.keys()), "matches": len(items)},
    )
    return ApiResponse(data=data)


@router.post("/reindex", response_model=ApiResponse[dict])
def reindex(db: Session = Depends(get_db), current_user: User = Depends(require_role(["ADMIN"]))):
    """Regenerate every embedding with the active embedding model (e.g. after changing EMBEDDING_MODEL)."""
    n = reindex_all(db)
    return ApiResponse(data={"reindexed": n, "embedding": embedding_service.info()})
