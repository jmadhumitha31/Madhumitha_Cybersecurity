import os
from typing import List, Optional

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PROJECT_DIR = os.path.abspath(os.path.join(BACKEND_DIR, ".."))

_DEFAULT_DB_FILE = os.path.join(BACKEND_DIR, "soc_assistant.db").replace("\\", "/")
DEFAULT_JWT_SECRET = "super-secret-soc-enterprise-jwt-key-change-in-prod-98234"


def _csv(value: Optional[str]) -> List[str]:
    return [v.strip() for v in (value or "").split(",") if v.strip()]


class Settings(BaseSettings):
    # Absolute env-file paths: behaviour no longer depends on the process working directory.
    # Later files win; real environment variables always win over both.
    model_config = SettingsConfigDict(
        env_file=(os.path.join(PROJECT_DIR, ".env"), os.path.join(BACKEND_DIR, ".env")),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    APP_NAME: str = "AI-Powered Cybersecurity Incident Response Assistant"
    APP_VERSION: str = "2.0.0"
    API_V1_PREFIX: str = "/api/v1"
    ENVIRONMENT: str = "development"
    DEBUG: bool = False

    # Database ---------------------------------------------------------------------------------
    DATABASE_URL: str = f"sqlite:///{_DEFAULT_DB_FILE}"

    # Retrieval --------------------------------------------------------------------------------
    EMBEDDING_BACKEND: str = "fastembed"  # "fastembed" (real ONNX sentence model) | "hashing" (explicit offline fallback)
    EMBEDDING_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"
    EMBEDDING_CACHE_DIR: str = os.path.join(BACKEND_DIR, "models", "embedding_cache")
    # Calibrated on real CIC-IDS2017 data with the retrieval evaluation (leave-one-out): flow-to-flow similarity scores
    # live in ~0.7-0.95 (0.75 keeps 97% of in-distribution queries at 98% precision@1); free-text queries score ~0.25-0.6.
    SIMILARITY_THRESHOLD: float = 0.75   # incident -> historical incident retrieval (analysis workflow)
    TEXT_SEARCH_THRESHOLD: float = 0.20  # analyst free-text search / chat
    HYBRID_ALPHA: float = 0.6  # weight of semantic similarity; (1 - alpha) goes to BM25
    TOP_K_DEFAULT: int = 5
    # Vector store: Qdrant in embedded (on-device) mode by default - persisted under QDRANT_PATH, no server process.
    # Set QDRANT_URL to use a Qdrant server instead (needed for several API workers: the embedded store is single-process).
    QDRANT_PATH: str = os.path.join(BACKEND_DIR, "data", "qdrant")  # ":memory:" keeps the index in RAM only (tests)
    QDRANT_URL: Optional[str] = None
    QDRANT_API_KEY: Optional[str] = None
    QDRANT_COLLECTION: str = "incident_index"
    QDRANT_CANDIDATES: int = 100  # dense/lexical candidate pool per query that is re-ranked with the exact hybrid score

    # Observability: a persisted trace for every analyst query -----------------------------------
    TRACING_ENABLED: bool = True
    TRACE_ALL_REQUESTS: bool = False       # False: trace analyst queries/operations only (search, chat, analyse, classify, feedback ...)
    TRACE_STORE_PAYLOADS: bool = True      # keep (secret-scrubbed, clipped) prompt/response previews for audit; False keeps only hashes and sizes
    TRACE_RETENTION_DAYS: int = 30
    TRACE_MAX_SPANS: int = 400             # per trace; further spans are counted, not stored
    TRACE_MAX_ATTR_CHARS: int = 2000       # clip for any string attribute
    TRACE_PAYLOAD_CHARS: int = 3000        # clip for prompt/response previews

    # AICredits (primary LLM) -----------------------------------------------------------------
    AICREDITS_API_KEY: Optional[str] = None
    AICREDITS_BASE_URL: str = "https://api.aicredits.in/v1"
    AICREDITS_MODEL: str = "gpt-4o-mini"
    AICREDITS_FALLBACK_MODELS: str = "openai/gpt-4o-mini,openai/gpt-4o"

    # NVIDIA NIM (fallback LLM) ----------------------------------------------------------------
    NVIDIA_API_KEY: Optional[str] = None
    NVIDIA_BASE_URL: str = "https://integrate.api.nvidia.com/v1"
    NVIDIA_MODEL: str = "meta/llama-3.2-11b-vision-instruct"
    NVIDIA_FALLBACK_MODELS: str = "openai/gpt-oss-20b"  # tried in order if the primary model is retired/unavailable
    # Independent judge model (must differ from the generator for LLM-as-Judge / DeepEval)
    JUDGE_MODEL: str = "nvidia/nemotron-3-super-120b-a12b"
    JUDGE_FALLBACK_MODELS: str = "openai/gpt-oss-20b"
    LLM_TIMEOUT_SECONDS: float = 60.0
    LLM_MAX_TOKENS: int = 1400
    LLM_JUDGE_MAX_TOKENS: int = 4500  # reasoning models spend tokens "thinking" before the JSON answer (2200 truncated some)
    LLM_MAX_RETRIES: int = 1

    # Ollama (local fallback) ------------------------------------------------------------------
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3.2:latest"

    # Auth & security --------------------------------------------------------------------------
    JWT_SECRET: str = DEFAULT_JWT_SECRET
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_MINUTES: int = 60 * 12
    CORS_ORIGINS: str = "http://localhost:5173,http://localhost:3000,http://127.0.0.1:5173"
    ALLOW_PUBLIC_REGISTRATION: bool = False  # when true, self-registration creates VIEWER accounts only
    LOGIN_MAX_ATTEMPTS: int = 5
    LOGIN_LOCK_SECONDS: int = 300

    # Paths ------------------------------------------------------------------------------------
    BASE_DIR: str = BACKEND_DIR
    MODEL_DIR: str = os.path.join(BACKEND_DIR, "models")
    DATA_DIR: str = os.path.join(BACKEND_DIR, "data")
    DATASET_DIR: str = os.path.join(BACKEND_DIR, "data", "cicids2017")

    @model_validator(mode="after")
    def _absolute_sqlite_path(self):
        """`sqlite:///./x.db` is relative to the *process working directory*: running uvicorn from the repo root vs
        backend/ silently created two different databases. Resolve relative SQLite paths against the backend dir."""
        prefix = "sqlite:///"
        if self.DATABASE_URL.startswith(prefix) and not self.DATABASE_URL.startswith("sqlite:////") and ":memory:" not in self.DATABASE_URL:
            path = self.DATABASE_URL[len(prefix):]
            if not os.path.isabs(path) and not (len(path) > 1 and path[1] == ":"):
                self.DATABASE_URL = prefix + os.path.abspath(os.path.join(BACKEND_DIR, path)).replace("\\", "/")
        if self.QDRANT_PATH != ":memory:" and not os.path.isabs(self.QDRANT_PATH):
            self.QDRANT_PATH = os.path.abspath(os.path.join(BACKEND_DIR, self.QDRANT_PATH))
        return self

    @model_validator(mode="after")
    def _check_secrets(self):
        if self.ENVIRONMENT.lower() == "production":
            if self.JWT_SECRET == DEFAULT_JWT_SECRET or len(self.JWT_SECRET) < 32:
                raise ValueError("JWT_SECRET must be set to a unique value of >= 32 characters in production")
        return self

    # Convenience accessors ---------------------------------------------------------------------
    @property
    def aicredits_models(self) -> List[str]:
        models = [self.AICREDITS_MODEL] + _csv(self.AICREDITS_FALLBACK_MODELS)
        return list(dict.fromkeys(m for m in models if m))

    @property
    def nvidia_models(self) -> List[str]:
        models = [self.NVIDIA_MODEL] + _csv(self.NVIDIA_FALLBACK_MODELS)
        return list(dict.fromkeys(m for m in models if m))

    @property
    def judge_models(self) -> List[str]:
        models = [self.JUDGE_MODEL] + _csv(self.JUDGE_FALLBACK_MODELS)
        return list(dict.fromkeys(m for m in models if m))

    @property
    def cors_origin_list(self) -> List[str]:
        return _csv(self.CORS_ORIGINS)

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT.lower() == "production"


settings = Settings()
