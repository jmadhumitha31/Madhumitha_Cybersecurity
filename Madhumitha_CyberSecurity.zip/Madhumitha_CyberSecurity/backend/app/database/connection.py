from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import Session, sessionmaker

from app.config import settings
from app.database.models import Base
from app.logging_config import logger

connect_args = {}
if settings.DATABASE_URL.startswith("sqlite"):
    connect_args = {"check_same_thread": False, "timeout": 30}

engine = create_engine(
    settings.DATABASE_URL,
    connect_args=connect_args,
    pool_pre_ping=True,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

from app.observability.tracing import instrument_engine  # noqa: E402  (after the engine exists; tracing imports this module lazily)

instrument_engine(engine)  # per-trace database query count and time


def get_db():
    db: Session = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def ensure_schema(bind=None) -> list:
    """Lightweight forward-only migration: add any column the models define but the database lacks.

    `Base.metadata.create_all` creates missing tables but never alters existing ones, so databases created
    by an earlier version would otherwise break at runtime. New columns are always added as nullable.
    """
    bind = bind or engine
    added = []
    insp = inspect(bind)
    existing_tables = set(insp.get_table_names())
    for table in Base.metadata.sorted_tables:
        if table.name not in existing_tables:
            continue
        have = {c["name"] for c in insp.get_columns(table.name)}
        for col in table.columns:
            if col.name in have:
                continue
            coltype = col.type.compile(dialect=bind.dialect)
            with bind.begin() as conn:
                conn.execute(text(f'ALTER TABLE {table.name} ADD COLUMN "{col.name}" {coltype}'))
            added.append(f"{table.name}.{col.name}")
    if added:
        logger.info(f"Schema migration added columns: {', '.join(added)}")
        _backfill(bind)
    return added


def _backfill(bind) -> None:
    """Give legacy rows sensible values for the columns introduced by the migration."""
    stmts = [
        "UPDATE incidents SET label_source = 'none' WHERE label_source IS NULL",
        "UPDATE incidents SET data_source = 'user' WHERE data_source IS NULL",
        "UPDATE evaluation_runs SET status = 'completed' WHERE status IS NULL",
    ]
    for s in stmts:
        try:
            with bind.begin() as conn:
                conn.execute(text(s))
        except Exception:  # column may not exist on a fresh schema; harmless
            pass


def init_db():
    try:
        Base.metadata.create_all(bind=engine)
        ensure_schema()
        logger.info("Database tables initialized successfully.")
    except Exception as e:
        logger.error(f"Database initialization error: {e}")
        raise
