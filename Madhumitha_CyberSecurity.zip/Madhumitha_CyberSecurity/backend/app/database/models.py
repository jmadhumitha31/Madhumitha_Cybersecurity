from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    String,
    Text,
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


def utcnow() -> datetime:
    """Naive UTC timestamp (all DateTime columns are stored as naive UTC)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(String(20), default="ANALYST", nullable=False)  # ADMIN, ANALYST, VIEWER
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=utcnow)

    audit_logs = relationship("AuditLog", back_populates="user")


class Incident(Base):
    __tablename__ = "incidents"

    id = Column(Integer, primary_key=True, index=True)
    flow_id = Column(String(160), unique=True, index=True, nullable=False)
    source_ip = Column(String(45), index=True, nullable=False)
    source_port = Column(Integer, index=True, nullable=False)
    destination_ip = Column(String(45), index=True, nullable=False)
    destination_port = Column(Integer, index=True, nullable=False)
    protocol = Column(Integer, index=True, nullable=False)  # 6=TCP, 17=UDP, 1=ICMP
    timestamp = Column(DateTime, default=utcnow, index=True)

    # CIC-IDS2017 flow metrics (names follow the project brief's key fields)
    flow_duration = Column(Float, default=0.0)
    total_fwd_packets = Column(Float, default=0.0)
    total_bwd_packets = Column(Float, default=0.0)
    total_length_fwd = Column(Float, default=0.0)
    total_length_bwd = Column(Float, default=0.0)
    flow_bytes_per_sec = Column(Float, default=0.0)
    flow_packets_per_sec = Column(Float, default=0.0)
    flow_iat_mean = Column(Float, default=0.0)
    packet_length_mean = Column(Float, default=0.0)
    syn_count = Column(Float, default=0.0)
    rst_count = Column(Float, default=0.0)
    ack_count = Column(Float, default=0.0)
    average_packet_size = Column(Float, default=0.0)
    active_mean = Column(Float, default=0.0)
    idle_mean = Column(Float, default=0.0)

    # Classification -------------------------------------------------------------------------
    # attack_type        : the classification currently in force (ground truth when known, else model prediction)
    # ground_truth_label : label from the dataset or confirmed by an analyst (NEVER overwritten by the model)
    # label_source       : dataset | analyst | model | none
    attack_type = Column(String(64), index=True, default="Unclassified")
    ground_truth_label = Column(String(64), index=True, nullable=True)
    original_label = Column(String(64), nullable=True)  # raw dataset label, e.g. "DoS Hulk"
    label_source = Column(String(16), index=True, default="none")
    data_source = Column(String(32), index=True, default="user")  # cicids2017 | synthetic-demo | user

    # Latest model outputs (None until the incident has been scored)
    predicted_attack_type = Column(String(64), nullable=True)
    prediction_confidence = Column(Float, nullable=True)
    intrusion_probability = Column(Float, nullable=True)
    anomaly_score = Column(Float, nullable=True)

    risk_score = Column(Float, nullable=True, index=True)
    risk_level = Column(String(16), index=True, default="Low")  # Critical, High, Medium, Low
    priority = Column(String(8), index=True, default="P4")      # P1, P2, P3, P4
    status = Column(String(32), default="NEW", index=True)      # NEW, INVESTIGATING, RESOLVED, FALSE_POSITIVE

    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)

    embedding = relationship("IncidentEmbedding", back_populates="incident", uselist=False, cascade="all, delete-orphan")
    analysis_results = relationship("AnalysisResult", back_populates="incident", cascade="all, delete-orphan")
    feedbacks = relationship("Feedback", back_populates="incident", cascade="all, delete-orphan")

    __table_args__ = (Index("ix_incidents_queue", "status", "risk_score"),)


class IncidentEmbedding(Base):
    __tablename__ = "incident_embeddings"

    id = Column(Integer, primary_key=True, index=True)
    incident_id = Column(Integer, ForeignKey("incidents.id", ondelete="CASCADE"), unique=True, index=True, nullable=False)
    # JSON array of floats: portable across SQLite/PostgreSQL. System of record for the vectors; searches run in the
    # Qdrant collection that app.rag.index diff-syncs from this table.
    embedding_vector = Column(JSON, nullable=False)
    text_representation = Column(Text, nullable=False)
    embedding_model = Column(String(96), nullable=True)
    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)

    incident = relationship("Incident", back_populates="embedding")


class AnalysisResult(Base):
    __tablename__ = "analysis_results"

    id = Column(Integer, primary_key=True, index=True)
    incident_id = Column(Integer, ForeignKey("incidents.id", ondelete="CASCADE"), index=True, nullable=False)
    workflow_trace = Column(JSON, nullable=True)
    attack_prediction = Column(JSON, nullable=True)
    risk_assessment = Column(JSON, nullable=True)
    historical_matches = Column(JSON, nullable=True)
    analysis = Column(Text, nullable=True)
    recommendations = Column(JSON, nullable=True)
    llm_provider = Column(String(32), default="none")
    llm_model = Column(String(96), nullable=True)
    fallback_used = Column(Boolean, default=False)
    llm_attempts = Column(JSON, nullable=True)
    quality_checks = Column(JSON, nullable=True)
    execution_time_ms = Column(Float, default=0.0)
    trace_id = Column(String(32), nullable=True)  # the observability trace that produced this analysis ("how was this written?")
    created_at = Column(DateTime, default=utcnow)

    incident = relationship("Incident", back_populates="analysis_results")


class Feedback(Base):
    __tablename__ = "feedback"

    id = Column(Integer, primary_key=True, index=True)
    incident_id = Column(Integer, ForeignKey("incidents.id", ondelete="CASCADE"), index=True, nullable=False)
    user_id = Column(Integer, nullable=True)
    username = Column(String(50), nullable=True)
    prediction = Column(String(64), nullable=False)
    actual_label = Column(String(64), nullable=False)
    analyst_feedback = Column(Text, nullable=True)
    feedback_type = Column(String(32), nullable=False)  # Correct, Incorrect, Partially Correct, Useful, Not Useful
    applied = Column(Boolean, default=False)            # label applied to the incident / knowledge base
    used_in_training_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=utcnow)

    incident = relationship("Incident", back_populates="feedbacks")


class EvaluationRun(Base):
    __tablename__ = "evaluation_runs"

    id = Column(Integer, primary_key=True, index=True)
    eval_type = Column(String(32), index=True, nullable=False)  # ML, RETRIEVAL, DEEPEVAL, LLM_JUDGE
    model_version = Column(String(64), default="1.0.0")
    dataset_version = Column(String(64), default="CIC-IDS2017")
    status = Column(String(24), default="completed")  # running | completed | failed | unavailable
    metrics = Column(JSON, nullable=False)
    report_location = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=utcnow)


class ModelVersion(Base):
    __tablename__ = "model_versions"

    id = Column(Integer, primary_key=True, index=True)
    version = Column(String(64), unique=True, index=True, nullable=False)
    path = Column(String(255), nullable=False)
    dataset_source = Column(String(64), nullable=True)
    metrics = Column(JSON, nullable=True)
    n_train = Column(Integer, nullable=True)
    n_feedback = Column(Integer, default=0)
    is_active = Column(Boolean, default=False, index=True)
    trigger = Column(String(32), default="manual")  # manual | feedback-retrain | bootstrap
    created_at = Column(DateTime, default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    username = Column(String(50), nullable=True)
    action = Column(String(100), nullable=False, index=True)
    incident_id = Column(Integer, nullable=True, index=True)
    endpoint = Column(String(255), nullable=True)
    model_provider = Column(String(32), nullable=True)
    fallback_used = Column(Boolean, default=False)
    status = Column(String(32), default="SUCCESS")
    ip_address = Column(String(45), nullable=True)
    details = Column(JSON, nullable=True)
    timestamp = Column(DateTime, default=utcnow, index=True)

    user = relationship("User", back_populates="audit_logs")


class Trace(Base):
    """One analyst query / operation (search, chat message, investigation, classification, feedback ...).

    The trace is the unit of auditability: who asked what, what each component did, how long it took and what came
    back. Its spans (``TraceSpan``) form a tree that the Observability page renders as a waterfall."""

    __tablename__ = "traces"

    id = Column(Integer, primary_key=True, index=True)
    trace_id = Column(String(32), unique=True, index=True, nullable=False)
    kind = Column(String(48), index=True, nullable=False)       # search | chat | incident.analyze | classify | ...
    name = Column(String(160), nullable=True)                   # e.g. "POST /api/v1/search"
    status = Column(String(16), index=True, default="ok")       # ok | degraded | rejected | error
    http_status = Column(Integer, nullable=True)
    user_id = Column(Integer, nullable=True)
    username = Column(String(50), index=True, nullable=True)
    role = Column(String(16), nullable=True)
    request_id = Column(String(64), nullable=True)
    incident_id = Column(Integer, index=True, nullable=True)
    query_text = Column(Text, nullable=True)                    # the analyst's query, secret-scrubbed and clipped
    input_data = Column(JSON, nullable=True)                    # sanitised request parameters
    output_data = Column(JSON, nullable=True)                   # compact outcome (counts, ids, verdicts)
    summary = Column(JSON, nullable=True)                       # facts used by the list view and the metrics
    error = Column(Text, nullable=True)
    started_at = Column(DateTime, default=utcnow, index=True)
    duration_ms = Column(Float, default=0.0)
    db_time_ms = Column(Float, default=0.0)
    db_queries = Column(Integer, default=0)
    n_spans = Column(Integer, default=0)
    dropped_spans = Column(Integer, default=0)

    spans = relationship("TraceSpan", back_populates="trace", cascade="all, delete-orphan", order_by="TraceSpan.start_offset_ms")

    __table_args__ = (Index("ix_traces_kind_started", "kind", "started_at"),)


class TraceSpan(Base):
    """A timed step inside a trace; ``component`` groups spans (api, guardrail, ml, retrieval, llm, agent, risk ...)."""

    __tablename__ = "trace_spans"

    id = Column(Integer, primary_key=True, index=True)
    trace_pk = Column(Integer, ForeignKey("traces.id", ondelete="CASCADE"), index=True, nullable=False)
    span_id = Column(String(16), nullable=False)
    parent_id = Column(String(16), nullable=True)
    name = Column(String(96), index=True, nullable=False)
    component = Column(String(24), index=True, nullable=False)
    status = Column(String(12), default="ok")                   # ok | error | rejected
    start_offset_ms = Column(Float, default=0.0)                # from the start of the trace
    duration_ms = Column(Float, default=0.0)
    self_ms = Column(Float, default=0.0)                        # duration minus child spans: where the time actually went
    attributes = Column(JSON, nullable=True)
    error = Column(Text, nullable=True)

    trace = relationship("Trace", back_populates="spans")
