from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import desc
from sqlalchemy.orm import Session

from app.database.models import AuditLog
from app.observability.context import current_trace_id


class AuditRepository:
    def record(
        self,
        db: Session,
        action: str,
        user_id: Optional[int] = None,
        username: Optional[str] = None,
        incident_id: Optional[int] = None,
        endpoint: Optional[str] = None,
        model_provider: Optional[str] = None,
        fallback_used: bool = False,
        status: str = "SUCCESS",
        ip_address: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> AuditLog:
        trace_id = current_trace_id()
        if trace_id:  # audit entry <-> trace: "what exactly happened during this audited action?"
            details = {**(details or {}), "trace_id": trace_id}
        log = AuditLog(
            action=action, user_id=user_id, username=username, incident_id=incident_id, endpoint=endpoint,
            model_provider=model_provider, fallback_used=fallback_used, status=status, ip_address=ip_address, details=details,
        )
        db.add(log)
        db.commit()
        db.refresh(log)
        return log

    def list_logs(
        self,
        db: Session,
        page: int = 1,
        page_size: int = 50,
        action: Optional[str] = None,
        username: Optional[str] = None,
        incident_id: Optional[int] = None,
    ) -> Tuple[List[AuditLog], int]:
        q = db.query(AuditLog)
        if action:
            q = q.filter(AuditLog.action == action)
        if username:
            q = q.filter(AuditLog.username == username)
        if incident_id is not None:
            q = q.filter(AuditLog.incident_id == incident_id)
        total = q.count()
        rows = q.order_by(desc(AuditLog.timestamp)).offset((page - 1) * page_size).limit(page_size).all()
        return rows, total


audit_repo = AuditRepository()
