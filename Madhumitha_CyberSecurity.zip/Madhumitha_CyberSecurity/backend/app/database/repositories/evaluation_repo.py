from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import desc
from sqlalchemy.orm import Session

from app.database.models import EvaluationRun, utcnow


class EvaluationRepository:
    def create(
        self,
        db: Session,
        eval_type: str,
        metrics: Dict[str, Any],
        status: str = "completed",
        model_version: str = "n/a",
        dataset_version: str = "n/a",
        report_location: Optional[str] = None,
    ) -> EvaluationRun:
        run = EvaluationRun(
            eval_type=eval_type, metrics=metrics, status=status, model_version=model_version,
            dataset_version=dataset_version, report_location=report_location, created_at=utcnow(),
        )
        db.add(run)
        db.commit()
        db.refresh(run)
        return run

    def update(self, db: Session, run_id: int, metrics: Dict[str, Any], status: str) -> Optional[EvaluationRun]:
        run = db.query(EvaluationRun).filter(EvaluationRun.id == run_id).first()
        if run:
            run.metrics = metrics
            run.status = status
            db.commit()
            db.refresh(run)
        return run

    def get_latest(self, db: Session, eval_type: str, only_completed: bool = False) -> Optional[EvaluationRun]:
        q = db.query(EvaluationRun).filter(EvaluationRun.eval_type == eval_type)
        if only_completed:
            q = q.filter(EvaluationRun.status == "completed")
        return q.order_by(desc(EvaluationRun.created_at), desc(EvaluationRun.id)).first()

    def list_all(self, db: Session, limit: int = 50) -> List[EvaluationRun]:
        return db.query(EvaluationRun).order_by(desc(EvaluationRun.created_at), desc(EvaluationRun.id)).limit(limit).all()


evaluation_repo = EvaluationRepository()
