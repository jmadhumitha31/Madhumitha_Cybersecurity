from typing import Any, Dict, List, Optional

from sqlalchemy import desc, func
from sqlalchemy.orm import Session

from app.database.models import Feedback


class FeedbackRepository:
    def list_by_incident(self, db: Session, incident_id: int) -> List[Feedback]:
        return db.query(Feedback).filter(Feedback.incident_id == incident_id).order_by(desc(Feedback.created_at)).all()

    def list_all(self, db: Session, limit: int = 100, offset: int = 0) -> List[Feedback]:
        return db.query(Feedback).order_by(desc(Feedback.created_at)).offset(offset).limit(limit).all()

    def stats(self, db: Session) -> Dict[str, Any]:
        total = db.query(func.count(Feedback.id)).scalar() or 0
        by_type = {t: n for t, n in db.query(Feedback.feedback_type, func.count(Feedback.id)).group_by(Feedback.feedback_type).all()}
        judged = (
            db.query(Feedback)
            .filter(Feedback.feedback_type.in_(["Correct", "Incorrect", "Partially Correct"]))
            .all()
        )
        correct = sum(1 for f in judged if f.prediction == f.actual_label)
        confusions: Dict[str, int] = {}
        for f in judged:
            if f.prediction != f.actual_label:
                key = f"{f.prediction} -> {f.actual_label}"
                confusions[key] = confusions.get(key, 0) + 1
        pending = db.query(func.count(Feedback.id)).filter(Feedback.applied.is_(True), Feedback.used_in_training_at.is_(None)).scalar() or 0
        return {
            "total": total,
            "by_type": by_type,
            "judged": len(judged),
            "analyst_agreement_rate": (correct / len(judged)) if judged else None,
            "top_corrections": sorted(({"correction": k, "count": v} for k, v in confusions.items()), key=lambda d: -d["count"])[:8],
            "pending_for_training": pending,
        }


feedback_repo = FeedbackRepository()
