from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import desc, func, or_
from sqlalchemy.orm import Session

from app.database.models import Incident

SORTS = {
    "created_at": lambda: desc(Incident.created_at),
    "timestamp": lambda: desc(Incident.timestamp),
    "risk": lambda: Incident.risk_score.desc().nullslast(),
    "priority": lambda: Incident.priority.asc(),
}


class IncidentRepository:
    def get_by_id(self, db: Session, incident_id: int) -> Optional[Incident]:
        return db.query(Incident).filter(Incident.id == incident_id).first()

    def get_by_flow_id(self, db: Session, flow_id: str) -> Optional[Incident]:
        return db.query(Incident).filter(Incident.flow_id == flow_id).first()

    def _filtered(
        self,
        db: Session,
        attack_type: Optional[str] = None,
        risk_level: Optional[str] = None,
        status: Optional[str] = None,
        search: Optional[str] = None,
        label_source: Optional[str] = None,
        data_source: Optional[str] = None,
        min_risk: Optional[float] = None,
    ):
        q = db.query(Incident)
        if attack_type:
            q = q.filter(func.lower(Incident.attack_type) == attack_type.strip().lower())
        if risk_level:
            q = q.filter(Incident.risk_level == risk_level)
        if status:
            q = q.filter(Incident.status == status)
        if label_source:
            q = q.filter(Incident.label_source == label_source)
        if data_source:
            q = q.filter(Incident.data_source == data_source)
        if min_risk is not None:
            q = q.filter(Incident.risk_score >= min_risk)
        if search:
            s = f"%{search.strip()}%"
            q = q.filter(
                or_(
                    Incident.flow_id.ilike(s), Incident.source_ip.ilike(s), Incident.destination_ip.ilike(s),
                    Incident.attack_type.ilike(s),
                )
            )
        return q

    def list_incidents(
        self,
        db: Session,
        page: int = 1,
        page_size: int = 20,
        sort: str = "created_at",
        **filters: Any,
    ) -> Tuple[List[Incident], int]:
        q = self._filtered(db, **filters)
        total = q.count()
        order = SORTS.get(sort, SORTS["created_at"])()
        items = q.order_by(order, desc(Incident.id)).offset((page - 1) * page_size).limit(page_size).all()
        return items, total

    def queue(self, db: Session, limit: int = 25, include_statuses: Optional[List[str]] = None) -> List[Incident]:
        """Triage queue: open incidents ordered by risk score (most urgent first)."""
        statuses = include_statuses or ["NEW", "INVESTIGATING"]
        return (
            db.query(Incident)
            .filter(Incident.status.in_(statuses), Incident.risk_score.isnot(None))
            .order_by(Incident.risk_score.desc(), Incident.timestamp.desc())
            .limit(limit)
            .all()
        )


incident_repo = IncidentRepository()
