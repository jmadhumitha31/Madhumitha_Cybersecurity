"""
Single source of truth for the cybersecurity taxonomy used by the dataset loader, the ML models,
the risk engine, the RAG text builder, the guardrails and the API schemas.
"""
import re
from typing import Dict, Optional

# Canonical attack families (CIC-IDS2017 families named in the project brief + Benign) ----------------
BENIGN = "Benign"
CLASSES = [
    "Benign",
    "DDoS",
    "DoS",
    "Port Scan",
    "FTP/SSH Brute Force",
    "Web Attack",
    "Botnet",
    "Infiltration",
    "Heartbleed",
]
ATTACK_CLASSES = [c for c in CLASSES if c != BENIGN]

# Marker for incidents that no model/analyst has classified yet
UNCLASSIFIED = "Unclassified"

# 0..1 intrinsic severity of each family (drives risk scoring)
SEVERITY_WEIGHT: Dict[str, float] = {
    "Benign": 0.0,
    "Port Scan": 0.45,
    "FTP/SSH Brute Force": 0.55,
    "Web Attack": 0.65,
    "DoS": 0.70,
    "DDoS": 0.80,
    "Botnet": 0.85,
    "Infiltration": 0.95,
    "Heartbleed": 0.95,
}
# Families that are escalated to at least High/Critical when the model is reasonably sure
CRITICAL_FLOOR = {"Heartbleed": "Critical", "Infiltration": "Critical", "Botnet": "High"}

RISK_LEVELS = ["Critical", "High", "Medium", "Low"]
PRIORITY_FOR_LEVEL = {"Critical": "P1", "High": "P2", "Medium": "P3", "Low": "P4"}
LEVEL_RANK = {"Critical": 3, "High": 2, "Medium": 1, "Low": 0}

ROLES = ["ADMIN", "ANALYST", "VIEWER"]
LABEL_SOURCES = ["dataset", "analyst", "model", "none"]
FEEDBACK_TYPES = ["Correct", "Incorrect", "Partially Correct", "Useful", "Not Useful"]
INCIDENT_STATUSES = ["NEW", "INVESTIGATING", "RESOLVED", "FALSE_POSITIVE"]

PROTOCOL_NAMES = {1: "ICMP", 6: "TCP", 17: "UDP"}

PORT_SERVICES = {
    20: "FTP-data", 21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 67: "DHCP", 80: "HTTP",
    110: "POP3", 123: "NTP", 135: "MS-RPC", 139: "NetBIOS", 143: "IMAP", 161: "SNMP", 389: "LDAP",
    443: "HTTPS", 445: "SMB", 993: "IMAPS", 1433: "MSSQL", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL",
    5900: "VNC", 6667: "IRC", 8080: "HTTP-alt", 8443: "HTTPS-alt", 4444: "Metasploit/backdoor",
    444: "non-standard port 444",
}
SENSITIVE_PORTS = {21, 22, 23, 135, 139, 445, 1433, 3306, 3389, 5432, 5900}
# 444 is used by the Metasploit sessions of the CIC-IDS2017 Infiltration/Heartbleed captures; 8080 by the ARES botnet
C2_LIKE_PORTS = {444, 4444, 6667, 1337, 31337, 8080}

# Natural-language aliases per family: used when indexing known incidents for semantic retrieval
CLASS_DESCRIPTIONS: Dict[str, str] = {
    "Benign": "legitimate normal baseline traffic, no malicious behaviour",
    "DDoS": "distributed denial of service, flooding attack from many sources overwhelming a service",
    "DoS": "denial of service attack exhausting a single server with slow or heavy requests (Hulk, GoldenEye, slowloris, slowhttptest)",
    "Port Scan": "port scanning reconnaissance probing many ports to discover listening services",
    "FTP/SSH Brute Force": "brute force credential guessing, password attack against FTP or SSH login services (Patator)",
    "Web Attack": "web application attack: brute force login, cross-site scripting XSS, SQL injection against HTTP server",
    "Botnet": "botnet command and control beaconing, compromised host communicating with C2 server (ARES)",
    "Infiltration": "infiltration, post-compromise lateral movement and data exfiltration from inside the network",
    "Heartbleed": "Heartbleed OpenSSL TLS heartbeat exploit leaking server memory (CVE-2014-0160)",
}

MITRE_ATTACK: Dict[str, str] = {
    "DDoS": "T1498 Network Denial of Service",
    "DoS": "T1499 Endpoint Denial of Service",
    "Port Scan": "T1046 Network Service Discovery",
    "FTP/SSH Brute Force": "T1110 Brute Force",
    "Web Attack": "T1190 Exploit Public-Facing Application",
    "Botnet": "T1071 Application Layer Protocol (C2) / T1568 Dynamic Resolution",
    "Infiltration": "T1041 Exfiltration Over C2 Channel / T1021 Remote Services (lateral movement)",
    "Heartbleed": "T1190 Exploit Public-Facing Application (CVE-2014-0160)",
}

# Raw CIC-IDS2017 labels -> canonical family. Matching is case-insensitive and ignores punctuation/encoding
# differences (the original CSVs contain a mangled en-dash in "Web Attack – Brute Force").
_RAW_LABEL_RULES = [
    (r"^benign$", "Benign"),
    (r"^ddos$", "DDoS"),
    (r"^dos\b.*", "DoS"),  # DoS Hulk / GoldenEye / slowloris / Slowhttptest
    (r"^port\s*scan$", "Port Scan"),
    (r"^(ftp|ssh)[\s_-]*patator$", "FTP/SSH Brute Force"),
    (r"^ftp/ssh brute force$", "FTP/SSH Brute Force"),
    (r"^web\s*attack.*", "Web Attack"),
    (r"^(bot|botnet|bot\s*net)$", "Botnet"),
    (r"^infiltrat(ion|eration)$", "Infiltration"),
    (r"^heartbleed$", "Heartbleed"),
]
_RAW_LABEL_RE = [(re.compile(p, re.IGNORECASE), c) for p, c in _RAW_LABEL_RULES]


def normalize_label(raw: object) -> Optional[str]:
    """Map a raw dataset label to a canonical family; None if the label is unknown."""
    if raw is None:
        return None
    text = re.sub(r"\s+", " ", str(raw).strip())
    if not text:
        return None
    for rx, canonical in _RAW_LABEL_RE:
        if rx.match(text):
            return canonical
    for canonical in CLASSES:  # already canonical (case-insensitive)
        if text.lower() == canonical.lower():
            return canonical
    return None


def risk_level_from_score(score: float) -> str:
    if score >= 75:
        return "Critical"
    if score >= 55:
        return "High"
    if score >= 35:
        return "Medium"
    return "Low"
