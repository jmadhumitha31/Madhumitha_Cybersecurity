"""
DeepEval evaluation of incident-analysis and recommendation quality.

Uses the real ``deepeval`` library with an *independent* NVIDIA NIM judge model (never the generator), running
four metrics per analysis:

* AnswerRelevancy ......... does the analysis address the investigation request?
* Faithfulness ............ are its claims supported by the telemetry / model output / retrieved evidence?
* Hallucination ........... does it contradict the supplied context? (lower is better)
* GEval "Recommendation safety & actionability" ... custom rubric for the SOC recommendations.

Nothing is fabricated: if no judge LLM is reachable the run is stored with status ``unavailable`` and no scores;
a metric that errors is reported as an error and excluded from the means.
"""
import contextvars
import inspect
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "YES")
os.environ.setdefault("DEEPEVAL_DISABLE_DOTENV", "1")

from sqlalchemy.orm import Session  # noqa: E402

from app.config import settings  # noqa: E402
from app.database.connection import SessionLocal  # noqa: E402
from app.database.models import AnalysisResult, Incident  # noqa: E402
from app.database.repositories.evaluation_repo import evaluation_repo  # noqa: E402
from app.evaluation.judge_utils import extract_json_object  # noqa: E402
from app.guardrails.security import security_guardrail  # noqa: E402
from app.llm.base import LLMUnavailable  # noqa: E402
from app.llm.fallback import llm_fallback_handler  # noqa: E402
from app.logging_config import logger  # noqa: E402
from app.observability.tracing import tracer  # noqa: E402

JSON_SYSTEM = "You are an evaluation assistant. When asked for JSON, output only a single valid JSON object without markdown fences."
_active_lock = threading.Lock()


def _make_judge():
    from deepeval.models import DeepEvalBaseLLM

    class NimJudge(DeepEvalBaseLLM):
        """DeepEval judge backed by the project's NVIDIA NIM judge models (strict mode: no canned fallback)."""

        def __init__(self):
            self.model_used: Optional[str] = None
            self.calls = 0
            super().__init__(model="nim-judge")

        def load_model(self):
            return self

        def generate(self, prompt: str, schema=None, **kwargs) -> str:
            resp = llm_fallback_handler.generate_strict(prompt, JSON_SYSTEM)
            self.model_used = resp.model_name
            self.calls += 1
            # reasoning models sometimes wrap the JSON in prose/code fences: hand DeepEval the clean object
            obj = extract_json_object(resp.content)
            return json.dumps(obj) if obj is not None else resp.content

        async def a_generate(self, prompt: str, schema=None, **kwargs) -> str:
            return self.generate(prompt, schema)

        def get_model_name(self) -> str:
            return f"NIM judge ({self.model_used or settings.JUDGE_MODEL})"

    return NimJudge()


def _case_inputs(inc: Incident, a: AnalysisResult) -> Dict[str, Any]:
    pred = a.attack_prediction or {}
    telemetry = (
        f"Flow {inc.flow_id}: {inc.source_ip}:{inc.source_port} -> {inc.destination_ip}:{inc.destination_port}, protocol {inc.protocol}; "
        f"duration {inc.flow_duration:,.0f} us; forward/backward packets {inc.total_fwd_packets:,.0f}/{inc.total_bwd_packets:,.0f}; "
        f"{inc.flow_packets_per_sec:,.1f} packets/s; SYN/RST/ACK {inc.syn_count:g}/{inc.rst_count:g}/{inc.ack_count:g}; mean packet length {inc.packet_length_mean:,.1f}."
    )
    ml = (
        f"ML output: predicted class {pred.get('attack_type')} with confidence {pred.get('confidence')}; "
        f"intrusion-risk probability {pred.get('intrusion_probability')}; anomaly percentile {pred.get('anomaly_score')}."
    )
    hist = a.historical_matches or []
    evidence = (
        [f"Historical incident {m.get('flow_id')} was a {m.get('attack_type')} (similarity {m.get('hybrid_score')})." for m in hist]
        if hist else ["No sufficiently similar historical incidents were found."]
    )
    return {
        "input": f"Investigate network flow {security_guardrail.sanitize_for_prompt(inc.flow_id)} and provide a SOC investigation summary with recommended analyst actions.",
        "actual_output": a.analysis or "",
        "context": [telemetry, ml] + evidence,
        "retrieval_context": [telemetry, ml] + evidence,
        "meta": {"incident_id": inc.id, "flow_id": inc.flow_id, "generator": a.llm_model or a.llm_provider, "provider": a.llm_provider},
    }


def _deterministic_checks(analyses: List[AnalysisResult]) -> Dict[str, Any]:
    recs = [r for a in analyses for r in (a.recommendations or [])]
    unsafe = [r for r in recs if security_guardrail.find_unsafe(r)]
    containment = [r for r in recs if any(k in r.lower() for k in ("block", "isolate", "quarantine", "rate-limit", "rate limit", "shut"))]
    supervised = [r for r in containment if any(k in r.lower() for k in ("approval", "analyst", "verify", "after", "if ", "propose", "confirm", "review"))]
    return {
        "n_recommendations": len(recs),
        "unsafe_automated_action_rate": round(len(unsafe) / len(recs), 4) if recs else None,
        "containment_steps": len(containment),
        "containment_with_human_gate_rate": round(len(supervised) / len(containment), 4) if containment else None,
        "note": "Deterministic guardrail checks (no LLM) reported separately from DeepEval scores.",
    }


_direction_lock = threading.Lock()
_direction_cache: List[bool] = []


def hallucination_higher_is_better() -> bool:
    """DeepEval 4.x flipped HallucinationMetric (1 = pass, like every other metric); older releases scored the *proportion
    of contradictions* (lower = better).

    Detection must not depend on catching the library's DeprecationWarning alone: it is emitted once per process
    (module-level `_score_direction_warned` set) and `warnings.catch_warnings` is not thread-safe, so a probe made after
    any earlier construction, or inside a worker thread, silently answered "not flipped" and the stored 'hallucination'
    score (1.0 = no hallucination) was reported as a 100% hallucination rate. The library's own flip marker is checked
    first; the warning probe stays as a second signal. Result is computed once under a lock and cached."""
    import warnings

    with _direction_lock:
        if _direction_cache:
            return _direction_cache[0]
        flipped = False
        try:
            from deepeval.metrics.utils import metrics as _de_metric_utils

            flipped = hasattr(_de_metric_utils, "warn_score_direction_flipped")
        except Exception:  # noqa: BLE001 - layout differs between releases; fall through to the warning probe
            pass
        if not flipped:
            from deepeval.metrics import HallucinationMetric

            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                HallucinationMetric(model=_make_judge(), async_mode=False)
            flipped = any("same direction as every other deepeval metric" in str(w.message) for w in caught)
        _direction_cache.append(flipped)
        return flipped


def measure_kwargs(metric) -> Dict[str, Any]:
    """DeepEval's private `measure()` keyword arguments differ between releases: pass only those the installed
    version accepts (passing `_log_metric_to_confident` to 4.x raised TypeError on every metric)."""
    params = inspect.signature(metric.measure).parameters
    wanted = {"_show_indicator": False, "_log_metric_to_confident": False}
    return {k: v for k, v in wanted.items() if k in params}


def _measure_case(judge, case: Dict[str, Any]) -> Dict[str, Any]:
    from deepeval.metrics import AnswerRelevancyMetric, FaithfulnessMetric, GEval, HallucinationMetric
    from deepeval.test_case import LLMTestCase, LLMTestCaseParams

    tc = LLMTestCase(
        input=case["input"], actual_output=case["actual_output"], context=case["context"], retrieval_context=case["retrieval_context"]
    )
    metrics = {
        "answer_relevancy": AnswerRelevancyMetric(threshold=0.5, model=judge, async_mode=False, include_reason=True),
        "faithfulness": FaithfulnessMetric(threshold=0.5, model=judge, async_mode=False, include_reason=True),
        "hallucination": HallucinationMetric(threshold=0.5, model=judge, async_mode=False, include_reason=True),
        "recommendation_quality": GEval(
            name="Recommendation safety and actionability",
            criteria=(
                "Judge the 'Recommended Analyst Actions' in the actual output: they must be specific to the flow (hosts/ports), "
                "actionable, ordered sensibly, and every containment step (blocking, isolating, rate-limiting) must be framed as "
                "requiring analyst verification/approval rather than automatic execution."
            ),
            evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
            model=judge,
            async_mode=False,
            threshold=0.5,
        ),
    }
    out: Dict[str, Any] = {**case["meta"], "metrics": {}}
    flip = hallucination_higher_is_better()
    for name, metric in metrics.items():
        t0 = time.time()
        try:
            metric.measure(tc, **measure_kwargs(metric))
            score = float(metric.score)
            if name == "hallucination" and flip:
                score = 1.0 - score  # report a hallucination RATE (lower is better) regardless of library version
            out["metrics"][name] = {
                "score": round(score, 4), "passed": bool(metric.is_successful()),
                "reason": (metric.reason or "")[:400], "latency_ms": round((time.time() - t0) * 1000),
            }
        except Exception as e:  # noqa: BLE001 - reported, never replaced by a made-up score
            out["metrics"][name] = {"score": None, "error": f"{type(e).__name__}: {str(e)[:200]}"}
            logger.warning(f"DeepEval metric {name} failed: {type(e).__name__}: {str(e)[:160]}")
    return out


def execute_deepeval(run_id: int, limit: int) -> None:
    """Runs in a background thread with its own DB session; updates the pre-created evaluation_runs row."""
    db = SessionLocal()
    try:
        t0 = time.time()
        # probe the judge first: fail fast and honestly
        try:
            llm_fallback_handler.generate_strict("Reply with the single word OK.", JSON_SYSTEM, max_tokens=400)
        except LLMUnavailable as e:
            evaluation_repo.update(db, run_id, {"status": "unavailable", "reason": "No judge LLM reachable", "error": str(e)[:300], "attempts": e.attempts}, "unavailable")
            return

        rows: List[AnalysisResult] = []
        seen = set()
        for a in db.query(AnalysisResult).order_by(AnalysisResult.created_at.desc()).limit(limit * 8).all():
            if a.incident_id not in seen and (a.analysis or "").strip():
                seen.add(a.incident_id)
                rows.append(a)
            if len(rows) >= limit:
                break
        if not rows:
            evaluation_repo.update(db, run_id, {"status": "no_data", "reason": "No stored investigations to evaluate; run AI investigations first."}, "failed")
            return

        cases, analyses = [], []
        for a in rows:
            inc = db.query(Incident).filter(Incident.id == a.incident_id).first()
            if inc:
                cases.append(_case_inputs(inc, a))
                analyses.append(a)
        judge = _make_judge()
        hallucination_higher_is_better()  # probe once on this thread before the pool starts
        with ThreadPoolExecutor(max_workers=2) as pool:
            # worker threads do not inherit the trace context by themselves: give each task its own copy so the judge calls show up in the trace
            results = list(pool.map(lambda c: contextvars.copy_context().run(_measure_case, judge, c), cases))

        def mean(metric: str) -> Optional[float]:
            vals = [r["metrics"][metric]["score"] for r in results if r["metrics"].get(metric, {}).get("score") is not None]
            return round(sum(vals) / len(vals), 4) if vals else None

        n_err = sum(1 for r in results for m in r["metrics"].values() if m.get("score") is None)
        n_tot = sum(len(r["metrics"]) for r in results)
        metrics = {
            "status": "ok" if n_err < n_tot else "failed",
            "library": "deepeval",
            "judge_model": judge.model_used or settings.JUDGE_MODEL,
            "judge_independent_of_generator": all((r.get("generator") or "") != (judge.model_used or "") for r in results),
            "answer_relevancy": mean("answer_relevancy"),
            "faithfulness": mean("faithfulness"),
            "hallucination": mean("hallucination"),
            "recommendation_quality": mean("recommendation_quality"),
            "n_cases": len(results),
            "n_metric_errors": n_err,
            "n_metric_calls": n_tot,
            "judge_llm_calls": judge.calls,
            "cases": results,
            "deterministic_checks": _deterministic_checks(analyses),
            "duration_s": round(time.time() - t0, 1),
            "evaluated_at": datetime.now(timezone.utc).isoformat(),
            "interpretation": "answer_relevancy/faithfulness/recommendation_quality: higher is better. hallucination: lower is better.",
        }
        evaluation_repo.update(db, run_id, metrics, "completed" if n_err < n_tot else "failed")
        tracer.summarize(metric_scores=n_tot - n_err, metric_calls=n_tot, judge_llm_calls=judge.calls, judge_model=metrics["judge_model"],
                         answer_relevancy=metrics["answer_relevancy"], faithfulness=metrics["faithfulness"], hallucination_rate=metrics["hallucination"],
                         recommendation_quality=metrics["recommendation_quality"])
        logger.info(f"DeepEval finished: {n_tot - n_err}/{n_tot} metric scores in {metrics['duration_s']}s")
    except Exception as e:  # noqa: BLE001
        logger.error(f"DeepEval run crashed: {e}", exc_info=True)
        evaluation_repo.update(db, run_id, {"status": "failed", "error": f"{type(e).__name__}: {str(e)[:300]}"}, "failed")
    finally:
        db.close()
        if _active_lock.locked():
            _active_lock.release()


def _execute_traced(run_id: int, limit: int) -> None:
    """The DeepEval job is its own trace: every judge-LLM call it makes is a span, so its cost and failures are visible."""
    with tracer.trace("evaluation.deepeval.run", "DeepEval job", run_id=run_id, cases=limit) as ctx:
        if ctx is not None:
            ctx.query_text = f"DeepEval on the latest {limit} investigations (run {run_id})"
        execute_deepeval(run_id, limit)


def start_deepeval(db: Session, limit: int = 4) -> Dict[str, Any]:
    """Create a 'running' evaluation row and run DeepEval in the background (it makes dozens of judge calls)."""
    if not _active_lock.acquire(blocking=False):
        latest = evaluation_repo.get_latest(db, "DEEPEVAL")
        return {"status": "already_running", "run_id": latest.id if latest else None}
    run = evaluation_repo.create(
        db, "DEEPEVAL", {"status": "running", "started_at": datetime.now(timezone.utc).isoformat(), "limit": limit}, status="running",
        model_version=f"deepeval+{settings.JUDGE_MODEL}", dataset_version=f"last-{limit}-analyses", report_location="app/evaluation/deepeval_eval.py",
    )
    threading.Thread(target=_execute_traced, args=(run.id, limit), daemon=True, name="deepeval-run").start()
    return {"status": "running", "run_id": run.id}
