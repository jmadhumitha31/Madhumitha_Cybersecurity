import json
import re
from typing import Any, Dict, Optional


def extract_json_object(text: str) -> Optional[Dict[str, Any]]:
    """Best-effort extraction of the first JSON object from model output (handles code fences and chatter)."""
    if not text:
        return None
    cleaned = re.sub(r"```(?:json)?", "", text)
    start = cleaned.find("{")
    if start == -1:
        return None
    depth, in_str, esc = 0, False, False
    for i in range(start, len(cleaned)):
        ch = cleaned[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                chunk = cleaned[start : i + 1]
                try:
                    return json.loads(chunk)
                except json.JSONDecodeError:
                    try:
                        return json.loads(re.sub(r",\s*([\]}])", r"\1", chunk))
                    except json.JSONDecodeError:
                        return None
    return None


def clamp01(v: Any) -> Optional[float]:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if f != f:  # NaN
        return None
    if f > 1.0 and f <= 10.0:  # some judges answer on a 0-10 scale
        f = f / 10.0
    return max(0.0, min(1.0, f))
