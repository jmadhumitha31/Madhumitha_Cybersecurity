"""
LLM-as-Judge: an *independent* model (different from the generator) grades each AI investigation against the
telemetry, the model outputs and the retrieved evidence.

Honesty rules (replacing the old behaviour that fabricated fixed scores when the LLM was unreachable):
* no reachable judge  -> status "unavailable" and NO scores;
* unparsable verdict  -> one repair attempt, then status "parse_failed" and NO scores;
* the result records which model judged, which model wrote the analysis, and whether they differ.
"""
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from app.config import settings
from app.database.models import AnalysisResult, Incident
from app.database.repositories.evaluation_repo import evaluation_repo
from app.evaluation.judge_utils import clamp01, extract_json_object
from app.guardrails.security import security_guardrail
from app.llm.base import LLMUnavailable
from app.llm.fallback import llm_fallback_handler
from app.logging_config import logger

DIMENSIONS = ["correctness", "relevance", "reasoning_quality", "recommendation_quality"]
VERDICTS = {"ACCEPTED", "NEEDS_REVIEW", "REJECTED"}

SYSTEM = "You are a strict, impartial cybersecurity evaluation judge. Output a single valid JSON object and nothing else."

PROMPT = """Grade the AI-generated SOC investigation below. Be critical: penalise claims the telemetry does not support, ignored contradictions between models, invented incidents, and unsafe recommendations.

## INCIDENT TELEMETRY
Flow {flow_id}: {source_ip}:{source_port} -> {destination_ip}:{destination_port}, protocol {protocol}
duration {duration} us, forward/backward packets {fwd}/{bwd}, {pps} packets/s, SYN/RST/ACK flags {syn}/{rst}/{ack} (0/1 per flow in CIC-IDS2017), mean packet length {plen}

## MACHINE-LEARNING OUTPUT
Predicted class: {attack_type} (confidence {confidence}); intrusion-risk model: {intrusion}; anomaly percentile: {anomaly}
Recorded ground-truth label (if any): {truth}

## RETRIEVED HISTORICAL EVIDENCE
{evidence}

## ANALYSIS UNDER REVIEW
{analysis}

## RECOMMENDED ACTIONS UNDER REVIEW
{recommendations}

EVALUATION GUIDANCE
- Judge the analysis against the EVIDENCE PROVIDED above (telemetry, ML output, retrieved incidents, ground truth if any), not against textbook defaults. Do not mark a classification wrong merely because a port differs from the textbook value.
- Dataset facts (CIC-IDS2017): SYN/RST/ACK are 0/1 flags per flow; the Heartbleed and Metasploit-Infiltration sessions both used TCP port 444; DDoS here is an HTTP flood of many slow, long-lived connections (low per-flow packet rate); Port Scan flows are 1-2 packets lasting microseconds.
- DO penalise: claims with no support in the evidence, invented incidents/IDs, ignoring a contradiction between the classifier and the intrusion/anomaly models, and unsafe or unattended containment advice.

Score each dimension from 0.00 to 1.00:
- correctness: is the analysis consistent with the telemetry and ML output (and the ground truth if given)?
- relevance: does it address this specific flow, hosts and ports?
- reasoning_quality: is the forensic reasoning logical, evidence-based and appropriately uncertain?
- recommendation_quality: are the steps specific, actionable, non-destructive and subject to analyst approval?

Return ONLY this JSON object:
{{"correctness": 0.0, "relevance": 0.0, "reasoning_quality": 0.0, "recommendation_quality": 0.0, "verdict": "ACCEPTED|NEEDS_REVIEW|REJECTED", "critique": "<=40 words", "unsupported_claims": ["..."]}}"""


def _fmt(v: Any, nd: int = 1) -> str:
    try:
        return f"{float(v):,.{nd}f}"
    except (TypeError, ValueError):
        return "n/a"


def build_judge_prompt(incident: Dict[str, Any], analysis: Dict[str, Any]) -> str:
    pred = analysis.get("attack_prediction") or {}
    hist = analysis.get("historical_matches") or []
    evidence = (
        "\n".join(f"- {m.get('flow_id')}: {m.get('attack_type')} (similarity {m.get('hybrid_score')})" for m in hist)
        if hist else "No similar historical incidents were retrieved."
    )
    recs = "\n".join(f"{i}. {r}" for i, r in enumerate(analysis.get("recommendations") or [], 1)) or "(none)"
    s = security_guardrail.sanitize_for_prompt
    return PROMPT.format(
        flow_id=s(incident.get("flow_id")), source_ip=incident.get("source_ip"), source_port=incident.get("source_port"),
        destination_ip=incident.get("destination_ip"), destination_port=incident.get("destination_port"), protocol=incident.get("protocol"),
        duration=_fmt(incident.get("flow_duration"), 0), fwd=_fmt(incident.get("total_fwd_packets"), 0), bwd=_fmt(incident.get("total_bwd_packets"), 0),
        pps=_fmt(incident.get("flow_packets_per_sec")), syn=incident.get("syn_count"), rst=incident.get("rst_count"), ack=incident.get("ack_count"),
        plen=_fmt(incident.get("packet_length_mean")), attack_type=pred.get("attack_type"), confidence=_fmt(pred.get("confidence"), 3),
        intrusion=_fmt(pred.get("intrusion_probability"), 3), anomaly=_fmt(pred.get("anomaly_score"), 3),
        truth=incident.get("ground_truth_label") or "not confirmed",
        evidence=evidence, analysis=(analysis.get("analysis") or "")[:6000], recommendations=recs,
    )


def _parse_scores(text: str) -> Optional[Dict[str, Any]]:
    data = extract_json_object(text)
    if not data:
        return None
    scores = {d: clamp01(data.get(d)) for d in DIMENSIONS}
    if any(v is None for v in scores.values()):
        return None
    verdict = str(data.get("verdict", "")).upper().replace(" ", "_")
    if verdict not in VERDICTS:
        verdict = "ACCEPTED" if min(scores.values()) >= 0.7 else "NEEDS_REVIEW" if min(scores.values()) >= 0.4 else "REJECTED"
    return {
        **{k: round(v, 3) for k, v in scores.items()},
        "verdict": verdict,
        "critique": str(data.get("critique", ""))[:600],
        "unsupported_claims": [str(c)[:200] for c in (data.get("unsupported_claims") or [])][:6],
    }


def judge_analysis(incident: Dict[str, Any], analysis: Dict[str, Any]) -> Dict[str, Any]:
    """Judge one analysis. Never fabricates: returns status unavailable / parse_failed without scores on failure."""
    generator = analysis.get("llm_model") or analysis.get("llm_provider") or "unknown"
    base = {"incident_id": incident.get("id", 0), "flow_id": incident.get("flow_id"), "generator_model": generator,
            "generator_provider": analysis.get("llm_provider"), "evaluated_at": datetime.now(timezone.utc).isoformat()}
    prompt = build_judge_prompt(incident, analysis)
    t0 = time.time()
    try:
        resp = llm_fallback_handler.generate_strict(prompt, SYSTEM)
        scores = _parse_scores(resp.content)
        if scores is None:  # one repair attempt
            resp = llm_fallback_handler.generate_strict(
                prompt + "\n\nYour previous answer was not valid JSON with all four numeric scores. Reply with ONLY the JSON object.", SYSTEM,
            )
            scores = _parse_scores(resp.content)
    except LLMUnavailable as e:
        return {**base, "status": "unavailable", "scores": None, "error": str(e)[:300], "attempts": e.attempts}
    if scores is None:
        return {**base, "status": "parse_failed", "scores": None, "judge_model": resp.model_name, "raw_output": resp.content[:400]}
    return {
        **base, "status": "ok", "scores": scores, "judge_model": resp.model_name, "judge_provider": resp.provider,
        "independent": resp.model_name != generator, "latency_ms": round((time.time() - t0) * 1000),
    }


def _incident_dict(inc: Incident) -> Dict[str, Any]:
    return {c.name: getattr(inc, c.name) for c in Incident.__table__.columns}


def _analysis_dict(a: AnalysisResult) -> Dict[str, Any]:
    return {
        "attack_prediction": a.attack_prediction or {}, "historical_matches": a.historical_matches or [], "analysis": a.analysis,
        "recommendations": a.recommendations or [], "llm_model": a.llm_model, "llm_provider": a.llm_provider,
    }


def run_llm_judge(incident_data: Dict[str, Any], analysis_data: Dict[str, Any], db: Optional[Session] = None) -> Dict[str, Any]:
    logger.info(f"LLM-as-Judge evaluating incident {incident_data.get('flow_id')}")
    result = judge_analysis(incident_data, analysis_data)
    if db is not None:
        status = "completed" if result["status"] == "ok" else result["status"]
        run = evaluation_repo.create(
            db, "LLM_JUDGE", result, status=status, model_version=f"judge:{result.get('judge_model', 'none')}",
            dataset_version="live-incident", report_location="app/evaluation/llm_judge.py",
        )
        result["run_id"] = run.id
    return result


def run_llm_judge_batch(db: Session, limit: int = 5) -> Dict[str, Any]:
    """Judge the most recent distinct-incident analyses and aggregate."""
    rows: List[AnalysisResult] = []
    seen = set()
    for a in db.query(AnalysisResult).order_by(AnalysisResult.created_at.desc()).limit(limit * 6).all():
        if a.incident_id not in seen:
            seen.add(a.incident_id)
            rows.append(a)
        if len(rows) >= limit:
            break
    cases = []
    for a in rows:
        inc = db.query(Incident).filter(Incident.id == a.incident_id).first()
        if inc:
            cases.append(judge_analysis(_incident_dict(inc), _analysis_dict(a)))
    ok = [c for c in cases if c["status"] == "ok"]
    summary: Dict[str, Any] = {"status": "ok" if ok else (cases[0]["status"] if cases else "no_data"), "n_cases": len(cases), "n_scored": len(ok), "cases": cases,
                               "evaluated_at": datetime.now(timezone.utc).isoformat()}
    if ok:
        for d in DIMENSIONS:
            summary[f"mean_{d}"] = round(sum(c["scores"][d] for c in ok) / len(ok), 3)
        summary["verdicts"] = {v: sum(1 for c in ok if c["scores"]["verdict"] == v) for v in VERDICTS}
        summary["judge_model"] = ok[0].get("judge_model")
    status = "completed" if ok else ("unavailable" if summary["status"] == "unavailable" else "failed")
    run = evaluation_repo.create(db, "LLM_JUDGE", summary, status=status, model_version=f"judge:{summary.get('judge_model', 'none')}",
                                 dataset_version=f"last-{len(cases)}-analyses", report_location="app/evaluation/llm_judge.py")
    summary["run_id"] = run.id
    return summary
