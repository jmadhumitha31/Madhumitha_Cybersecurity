"""
Retrieval-quality evaluation of the hybrid RAG index (replaces the previous mis-labelled "RAGAS" suite).

Protocol: leave-one-out over labelled historical incidents. For a sample of known incidents, build the query from
telemetry only (no label), remove the incident itself, retrieve the top-k from the *confirmed* knowledge base and
measure whether the retrieved incidents have the same attack family. Standard IR metrics: precision@k, hit@k, MRR,
nDCG@k. Semantic-only and keyword-only baselines run on the same queries, plus a "no IP addresses" variant that
measures generalisation beyond repeat offenders, and a similarity-threshold sweep used to set the cut-off.
"""
import math
from datetime import datetime, timezone
from typing import Any, Dict, List

import numpy as np
from sqlalchemy.orm import Session

from app.config import settings
from app.database.models import Incident
from app.database.repositories.evaluation_repo import evaluation_repo
from app.logging_config import logger
from app.observability.tracing import tracer
from app.rag.embeddings import embedding_service
from app.rag.index import hybrid_index
from app.rag.text import build_incident_text, build_semantic_text

K = 5


def _flow(inc: Incident) -> Dict[str, Any]:
    return {c.name: getattr(inc, c.name) for c in Incident.__table__.columns}


def _rank(scores: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Descending order with *unbiased* tie handling: scores are rounded to 6 decimals and documents with equal scores are
    shuffled with a fixed seed. Many flows share an identical behaviour description (identical vector, identical dense
    score), so ordering ties by index would favour whichever class happens to be stored first: the dense-only baseline
    measured 0.71 to 0.87 precision@5 depending purely on tie order."""
    s = np.round(scores.astype(np.float64), 6)
    return np.lexsort((rng.random(len(s)), -s))


def _metrics(rank_relevance: List[List[int]], top1_scores: List[float]) -> Dict[str, float]:
    n = len(rank_relevance)
    p1 = float(np.mean([r[0] for r in rank_relevance]))
    pk = float(np.mean([sum(r[:K]) / K for r in rank_relevance]))
    hit = float(np.mean([1.0 if sum(r[:K]) else 0.0 for r in rank_relevance]))
    mrr = float(np.mean([next((1.0 / (i + 1) for i, v in enumerate(r[:K]) if v), 0.0) for r in rank_relevance]))
    ndcg = float(np.mean([
        (sum(v / math.log2(i + 2) for i, v in enumerate(r[:K])) / sum(1.0 / math.log2(i + 2) for i in range(K))) for r in rank_relevance
    ]))
    return {"precision_at_1": round(p1, 4), f"precision_at_{K}": round(pk, 4), f"hit_at_{K}": round(hit, 4), "mrr": round(mrr, 4), f"ndcg_at_{K}": round(ndcg, 4), "n_queries": n}


def run_retrieval_evaluation(db: Session, per_class: int = 40, seed: int = 7) -> Dict[str, Any]:
    logger.info("Retrieval evaluation (leave-one-out) starting ...")
    hybrid_index.ensure(db)
    if len(hybrid_index.ids) < 20:
        res = {"status": "no_data", "reason": "Knowledge base has fewer than 20 indexed incidents"}
        run = evaluation_repo.create(db, "RETRIEVAL", res, status="failed", model_version=embedding_service.identifier)
        return {**res, "run_id": run.id}

    # confirmed (dataset/analyst) incidents that are in the index
    rows = db.query(Incident).filter(Incident.id.in_([int(i) for i in hybrid_index.ids]), Incident.label_source.in_(["dataset", "analyst"])).all()
    by_class: Dict[str, List[Incident]] = {}
    for r in rows:
        by_class.setdefault(r.attack_type, []).append(r)
    rng = np.random.default_rng(seed)
    sample: List[Incident] = []
    for cls, items in by_class.items():
        k = min(per_class, len(items))
        sample.extend(items[i] for i in rng.choice(len(items), size=k, replace=False))

    row_of = {int(i): n for n, i in enumerate(hybrid_index.ids)}
    labels = {r.id: r.attack_type for r in rows}
    confirmed_mask = np.array([int(i) in labels for i in hybrid_index.ids])
    doc_labels = np.array([labels.get(int(i), "") for i in hybrid_index.ids])
    alpha = settings.HYBRID_ALPHA

    def run_variant(include_endpoints: bool) -> Dict[str, Any]:
        rng = np.random.default_rng(seed + 1)   # tie-breaking stream: each variant is reproducible on its own
        texts =[build_incident_text(_flow(s), include_label=False, include_endpoints=include_endpoints) for s in sample]
        Q = embedding_service.embed_texts([build_semantic_text(_flow(s), include_label=False) for s in sample])
        rel = {"hybrid": [], "semantic": [], "keyword": []}
        top1 = {"hybrid": [], "semantic": [], "keyword": []}
        per_cls: Dict[str, List[float]] = {}
        sweep_scores, sweep_hits = [], []
        for qi, inc in enumerate(sample):
            # same code path as production search: dense candidates from Qdrant, BM25 from the index, exact blend
            mask = confirmed_mask.copy()
            mask[row_of[inc.id]] = False
            scores, _, _ = hybrid_index.score(texts[qi], Q[qi], mask, alpha, k=K)
            for mode in ("hybrid", "semantic", "keyword"):
                s = scores[mode]
                top = _rank(s, rng)[:K]
                rel[mode].append([int(doc_labels[t] == inc.attack_type) for t in top])
                top1[mode].append(float(s[top[0]]))
                if mode == "hybrid":
                    per_cls.setdefault(inc.attack_type, []).append(sum(rel["hybrid"][-1]) / K)
                    sweep_scores.append(float(s[top[0]]))
                    sweep_hits.append(rel["hybrid"][-1][0])
        thresholds = [round(t, 2) for t in np.arange(0.3, 0.96, 0.05)]
        sweep = []
        sc, hh = np.array(sweep_scores), np.array(sweep_hits)
        for t in thresholds:
            cov = float((sc >= t).mean())
            sweep.append({"threshold": t, "coverage": round(cov, 4), "precision_at_1_when_answered": round(float(hh[sc >= t].mean()), 4) if (sc >= t).any() else None})
        return {
            "hybrid": _metrics(rel["hybrid"], top1["hybrid"]),
            "semantic_only": _metrics(rel["semantic"], top1["semantic"]),
            "keyword_only": _metrics(rel["keyword"], top1["keyword"]),
            "per_class_precision_at_k": {c: round(float(np.mean(v)), 4) for c, v in sorted(per_cls.items())},
            "threshold_sweep": sweep,
        }

    with tracer.span("evaluation.retrieval.benchmark", "evaluation", method="leave-one-out over confirmed incidents", queries=len(sample),
                     k=K, alpha=alpha, variants=["with endpoints", "without IP addresses"]) as bsp:
        with tracer.suppress():  # ~600 identical queries: one summary span, not one trace entry each
            with_ip = run_variant(True)
            without_ip = run_variant(False)
        bsp.set(hybrid=with_ip["hybrid"], semantic_only=with_ip["semantic_only"], keyword_only=with_ip["keyword_only"],
                hybrid_without_ips=without_ip["hybrid"])
    prior = float(sum((len(v) / len(rows)) ** 2 for v in by_class.values()))
    thr = settings.SIMILARITY_THRESHOLD
    cur = next((s for s in with_ip["threshold_sweep"] if abs(s["threshold"] - round(thr / 0.05) * 0.05) < 1e-6), None)
    metrics = {
        "status": "ok",
        "method": "leave-one-out over confirmed incidents; query built from telemetry only (no label)",
        "k": K,
        "embedding_model": embedding_service.identifier,
        "vector_store": hybrid_index.store.info() | {"collection": hybrid_index.collection},
        "hybrid_alpha": alpha,
        "similarity_threshold": thr,
        "knowledge_base_size": int(confirmed_mask.sum()),
        "queries": len(sample),
        "random_retrieval_precision": round(prior, 4),
        "with_endpoints": with_ip,
        "without_ip_addresses": without_ip,
        "operating_point": cur,
        "evaluated_at": datetime.now(timezone.utc).isoformat(),
        "note": "precision = share of retrieved incidents with the same attack family as the query's ground truth.",
    }
    run = evaluation_repo.create(
        db, "RETRIEVAL", metrics, status="completed", model_version=embedding_service.identifier, dataset_version=f"kb-{int(confirmed_mask.sum())}",
        report_location="app/evaluation/retrieval_eval.py",
    )
    metrics["run_id"] = run.id
    return metrics
