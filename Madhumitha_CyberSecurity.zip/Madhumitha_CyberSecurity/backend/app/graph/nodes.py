import re
import time
from datetime import datetime, timezone
from typing import Any, Dict, List

from sqlalchemy.orm import Session

from app.agents.analysis_agent import analysis_agent
from app.agents.detection_agent import detection_agent
from app.agents.response_agent import response_agent
from app.agents.risk_agent import risk_agent
from app.domain import PRIORITY_FOR_LEVEL, RISK_LEVELS
from app.graph.state import IncidentState
from app.guardrails.input_validation import validate_network_incident
from app.guardrails.security import security_guardrail
from app.llm.offline import offline_recommendations

# flow-id shaped tokens, e.g. "192.168.10.5-104.16.207.165-54865-443-6@07051715" or "TEST-INT-AB12CD"
_FLOW_ID_LIKE = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}-\d{1,3}(?:\.\d{1,3}){3}-\d+-\d+-\d+(?:@\d+)?(?:#\d+)?")


def _append_trace(state: IncidentState, step: str, status: str, details: str, duration_ms: float = 0.0) -> None:
    state["execution_trace"].append(
        {
            "step": step,
            "status": status,
            "timestamp": datetime.now(timezone.utc).strftime("%H:%M:%S"),
            "duration_ms": round(duration_ms, 2),
            "details": details,
        }
    )


def validate_input_node(state: IncidentState) -> IncidentState:
    t0 = time.time()
    ok, errors = validate_network_incident(state["incident"])
    dur = (time.time() - t0) * 1000
    state["validation_result"] = {"valid": ok, "errors": errors}
    if not ok:
        state["errors"].extend(errors)
        _append_trace(state, "Input Validation", "FAILED", f"Validation errors: {'; '.join(errors)}", dur)
    else:
        _append_trace(state, "Input Validation", "PASSED", "Flow schema, RFC address/port rules and physical bounds verified", dur)
    return state


def detection_node(state: IncidentState) -> IncidentState:
    if state["errors"]:
        return state
    t0 = time.time()
    out = detection_agent.run(state["incident"])
    state["attack_prediction"] = out
    state["prediction_confidence"] = float(out.get("confidence", 0.0))
    if out.get("status") == "ok":
        details = (
            f"Classified '{out['attack_type']}' ({out['confidence'] * 100:.1f}%); intrusion probability "
            f"{(out.get('intrusion_probability') or 0) * 100:.1f}%, anomaly {(out.get('anomaly_score') or 0):.2f}"
            f"{'; LOW CONFIDENCE' if out.get('low_confidence') else ''}"
        )
        _append_trace(state, "Detection Agent", "COMPLETED", details, (time.time() - t0) * 1000)
    else:
        _append_trace(state, "Detection Agent", "DEGRADED", "ML model unavailable: " + "; ".join(out.get("indicators", [])), (time.time() - t0) * 1000)
    return state


def analysis_node(state: IncidentState, db: Session = None) -> IncidentState:
    if state["errors"]:
        return state
    t0 = time.time()
    out = analysis_agent.run(db=db, incident_data=state["incident"], exclude_id=state["incident"].get("id"))
    state["retrieved_incidents"] = out["retrieved_incidents"]
    state["retrieval_scores"] = {m["flow_id"]: m["hybrid_score"] for m in out["retrieved_incidents"]}
    state["evidence_context"] = out["evidence_context"]
    state["class_votes"] = out["class_votes"]
    n = len(out["retrieved_incidents"])
    if n:
        votes = ", ".join(f"{k} {v * 100:.0f}%" for k, v in list(out["class_votes"].items())[:3])
        msg = f"Retrieved {n} similar labelled incident(s); class vote: {votes}"
    else:
        msg = "No sufficiently similar historical incidents were found"
    _append_trace(state, "Analysis & RAG Retrieval", "COMPLETED", msg, (time.time() - t0) * 1000)
    return state


def risk_node(state: IncidentState) -> IncidentState:
    if state["errors"]:
        return state
    t0 = time.time()
    analysis_out = {
        "found_similar": len(state["retrieved_incidents"]) > 0,
        "retrieved_incidents": state["retrieved_incidents"],
        "class_votes": state["class_votes"],
    }
    risk = risk_agent.run(state["incident"], state["attack_prediction"], analysis_out)
    state["risk_assessment"] = risk
    state["risk_confidence"] = float(risk.get("confidence", 0.0))
    _append_trace(
        state, "Risk Assessment Agent", "COMPLETED",
        f"Severity {risk['risk_level']} ({risk['priority']}), risk score {risk['risk_score']}/100", (time.time() - t0) * 1000,
    )
    return state


def recommendation_node(state: IncidentState) -> IncidentState:
    if state["errors"]:
        return state
    t0 = time.time()
    resp = response_agent.run(
        state["incident"],
        state["attack_prediction"],
        {"evidence_context": state["evidence_context"], "found_similar": bool(state["retrieved_incidents"])},
        state["risk_assessment"],
    )
    state["analysis"] = resp["analysis"]
    state["recommendations"] = resp["recommendations"]
    state["llm_provider"] = resp["llm_provider"]
    state["llm_model"] = resp["model_name"]
    state["llm_attempts"] = resp["llm_attempts"]
    state["fallback_used"] = resp["fallback_used"]
    info = f"Provider: {state['llm_provider']} / {state['llm_model']} (fallback: {'YES' if state['fallback_used'] else 'NO'})"
    failed = [a for a in state["llm_attempts"] if not a.get("ok")]
    if failed:
        info += f"; {len(failed)} failed attempt(s): " + "; ".join(f"{a.get('model') or a.get('provider')}: {str(a.get('error'))[:60]}" for a in failed[:3])
    _append_trace(state, "Response Recommendation Agent", "COMPLETED", info, (time.time() - t0) * 1000)
    return state


def final_validation_node(state: IncidentState) -> IncidentState:
    """Output validation: checks the generated analysis before it reaches an analyst, repairs what can be repaired."""
    t0 = time.time()
    checks: List[Dict[str, Any]] = []

    def add(name: str, passed: bool, detail: str) -> None:
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    if not state["errors"]:
        analysis = state.get("analysis", "")
        attack = state["attack_prediction"].get("attack_type", "")
        risk = state["risk_assessment"]

        add("analysis_non_empty", len(analysis.strip()) >= 80, f"{len(analysis)} characters")
        add("mentions_predicted_class", attack.lower() in analysis.lower() or attack in ("Unclassified", ""),
            f"analysis refers to '{attack}'")

        recs = state.get("recommendations", [])
        unsafe = [r for r in recs if security_guardrail.find_unsafe(r)]
        if unsafe:  # defence in depth: sanitisation already ran, so this should never trigger
            state["recommendations"] = security_guardrail.sanitize_recommendations(recs)
        add("recommendations_safe", not unsafe, "no unattended destructive action" if not unsafe else f"{len(unsafe)} rewritten")
        if not recs:
            state["recommendations"] = offline_recommendations(attack, state["incident"])
        add("recommendations_present", bool(recs), f"{len(recs)} step(s)" if recs else "none generated; class playbook inserted")

        ok_risk = (
            risk.get("risk_level") in RISK_LEVELS
            and PRIORITY_FOR_LEVEL.get(risk.get("risk_level")) == risk.get("priority")
            and 0 <= float(risk.get("risk_score", -1)) <= 100
        )
        add("risk_fields_consistent", ok_risk, f"{risk.get('risk_level')} / {risk.get('priority')} / {risk.get('risk_score')}")

        allowed = {m["flow_id"] for m in state["retrieved_incidents"]} | {str(state["incident"].get("flow_id"))}
        cited = {t for t in _FLOW_ID_LIKE.findall(analysis)}
        invented = sorted(c for c in cited if not any(c in a or a in c for a in allowed))
        add("no_uncited_incidents", not invented,
            "every incident id in the analysis was retrieved" if not invented else f"analysis cites unretrieved id(s): {', '.join(invented[:3])}")

        failed = [c for c in checks if not c["passed"]]
        if invented:
            state["analysis"] += (
                "\n\n> ⚠️ Guardrail notice: this text references incident identifiers that were not retrieved from the knowledge base; "
                "treat those references as unverified."
            )
        state["requires_analyst_review"] = True  # human-in-the-loop is mandatory for containment
        _append_trace(
            state, "Final Validation & Package", "COMPLETED" if not failed else "WARNING",
            f"{len(checks) - len(failed)}/{len(checks)} output checks passed" + (f"; failed: {', '.join(c['check'] for c in failed)}" if failed else ""),
            (time.time() - t0) * 1000,
        )
    else:
        _append_trace(state, "Final Validation & Package", "FAILED", "Workflow stopped on input validation errors", (time.time() - t0) * 1000)

    state["quality_checks"] = checks
    state["final_response"] = {
        "incident_id": state["incident"].get("id", 0),
        "attack_prediction": state["attack_prediction"],
        "risk": state["risk_assessment"],
        "historical_matches": state["retrieved_incidents"],
        "analysis": state["analysis"],
        "recommendations": state["recommendations"],
        "llm_provider": state["llm_provider"],
        "llm_model": state["llm_model"],
        "llm_attempts": state["llm_attempts"],
        "fallback_used": state["fallback_used"],
        "quality_checks": checks,
        "requires_analyst_review": state["requires_analyst_review"],
        "execution_trace": state["execution_trace"],
        "errors": state["errors"],
    }
    return state
