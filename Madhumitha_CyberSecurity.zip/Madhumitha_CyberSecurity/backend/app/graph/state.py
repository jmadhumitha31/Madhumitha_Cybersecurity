from typing import Any, Dict, List, TypedDict


class IncidentState(TypedDict):
    incident: Dict[str, Any]
    validation_result: Dict[str, Any]
    attack_prediction: Dict[str, Any]
    prediction_confidence: float
    retrieved_incidents: List[Dict[str, Any]]
    retrieval_scores: Dict[str, Any]
    evidence_context: str
    class_votes: Dict[str, float]
    risk_assessment: Dict[str, Any]
    risk_confidence: float
    analysis: str
    recommendations: List[str]
    llm_provider: str
    llm_model: str
    llm_attempts: List[Dict[str, Any]]
    fallback_used: bool
    quality_checks: List[Dict[str, Any]]
    requires_analyst_review: bool
    errors: List[str]
    execution_trace: List[Dict[str, Any]]
    final_response: Dict[str, Any]
