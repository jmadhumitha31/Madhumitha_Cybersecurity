import time
from typing import Any, Dict

from langgraph.graph import END, START, StateGraph
from sqlalchemy.orm import Session

from app.graph.nodes import (
    analysis_node,
    detection_node,
    final_validation_node,
    recommendation_node,
    risk_node,
    validate_input_node,
)
from app.graph.state import IncidentState
from app.logging_config import logger
from app.observability.tracing import tracer


def _describe_node(name: str, before: int, state: IncidentState, sp) -> None:
    """Record what a workflow node decided (read from the state it produced) on its trace span."""
    trace = state.get("execution_trace", [])
    if len(trace) <= before:
        sp.set(skipped=True, reason="workflow already stopped on an input validation error")
        return
    entry = trace[-1]
    sp.set(step=entry["step"], outcome=entry["status"], details=entry["details"])
    if name == "validate_input":
        sp.set(valid=bool(state["validation_result"].get("valid")), errors=state["validation_result"].get("errors", []))
    elif name == "detection":
        p = state.get("attack_prediction", {})
        sp.set(attack_type=p.get("attack_type"), confidence=p.get("confidence"), intrusion_probability=p.get("intrusion_probability"),
               anomaly_score=p.get("anomaly_score"), low_confidence=p.get("low_confidence"), model_version=p.get("model_version"))
    elif name == "analysis":
        sp.set(n_retrieved=len(state.get("retrieved_incidents", [])), class_votes=state.get("class_votes", {}),
               retrieved=[{"incident_id": m.get("incident_id"), "flow_id": m.get("flow_id"), "attack_type": m.get("attack_type"),
                           "score": m.get("hybrid_score")} for m in state.get("retrieved_incidents", [])])
    elif name == "risk_assessment":
        r = state.get("risk_assessment", {})
        sp.set(risk_level=r.get("risk_level"), risk_score=r.get("risk_score"), priority=r.get("priority"), components=r.get("components"))
    elif name == "recommendation":
        sp.set(llm_provider=state.get("llm_provider"), llm_model=state.get("llm_model"), fallback_used=state.get("fallback_used"),
               degraded=bool(state.get("fallback_used")), n_recommendations=len(state.get("recommendations", [])))
    elif name == "final_validation":
        checks = state.get("quality_checks", [])
        sp.set(checks=checks, n_checks=len(checks), n_passed=sum(1 for c in checks if c.get("passed")),
               failed=[c["check"] for c in checks if not c.get("passed")], requires_analyst_review=state.get("requires_analyst_review"))
        tracer.count("output_checks.total", len(checks))
        tracer.count("output_checks.failed", sum(1 for c in checks if not c.get("passed")))


def _traced(name: str, fn):
    def run(state: IncidentState) -> IncidentState:
        with tracer.span(f"agent.{name}", "agent", node=name) as sp:
            before = len(state.get("execution_trace", []))
            out = fn(state)
            _describe_node(name, before, out, sp)
            return out

    return run


def build_investigation_graph(db: Session = None):
    builder = StateGraph(IncidentState)

    def wrapped_analysis_node(state: IncidentState) -> IncidentState:
        return analysis_node(state, db=db)

    builder.add_node("validate_input", _traced("validate_input", validate_input_node))
    builder.add_node("detection", _traced("detection", detection_node))
    builder.add_node("analysis", _traced("analysis", wrapped_analysis_node))
    builder.add_node("risk_assessment", _traced("risk_assessment", risk_node))
    builder.add_node("recommendation", _traced("recommendation", recommendation_node))
    builder.add_node("final_validation", _traced("final_validation", final_validation_node))

    def route_after_validation(state: IncidentState) -> str:
        return "final_validation" if state.get("errors") else "detection"

    builder.add_edge(START, "validate_input")
    builder.add_conditional_edges(
        "validate_input", route_after_validation, {"detection": "detection", "final_validation": "final_validation"}
    )
    builder.add_edge("detection", "analysis")
    builder.add_edge("analysis", "risk_assessment")
    builder.add_edge("risk_assessment", "recommendation")
    builder.add_edge("recommendation", "final_validation")
    builder.add_edge("final_validation", END)
    return builder.compile()


def initial_state(incident_data: Dict[str, Any]) -> IncidentState:
    return {
        "incident": incident_data,
        "validation_result": {},
        "attack_prediction": {},
        "prediction_confidence": 0.0,
        "retrieved_incidents": [],
        "retrieval_scores": {},
        "evidence_context": "",
        "class_votes": {},
        "risk_assessment": {},
        "risk_confidence": 0.0,
        "analysis": "",
        "recommendations": [],
        "llm_provider": "none",
        "llm_model": "",
        "llm_attempts": [],
        "fallback_used": False,
        "quality_checks": [],
        "requires_analyst_review": True,
        "errors": [],
        "execution_trace": [],
        "final_response": {},
    }


def run_investigation_workflow(incident_data: Dict[str, Any], db: Session) -> IncidentState:
    """Execute Detection -> Analysis (RAG) -> Risk -> Response -> Output validation as a LangGraph workflow."""
    graph = build_investigation_graph(db=db)
    start = time.time()
    logger.info(f"Initiating LangGraph incident investigation for {incident_data.get('flow_id')}")
    with tracer.span("workflow.investigation", "agent", flow_id=incident_data.get("flow_id"), incident_id=incident_data.get("id"),
                     graph="validate_input -> detection -> analysis -> risk_assessment -> recommendation -> final_validation") as sp:
        final_state = graph.invoke(initial_state(incident_data))
        total_ms = (time.time() - start) * 1000
        if isinstance(final_state.get("final_response"), dict):
            final_state["final_response"]["execution_time_ms"] = round(total_ms, 2)
        sp.set(total_ms=round(total_ms, 2), errors=final_state.get("errors", []), n_steps=len(final_state.get("execution_trace", [])))
    logger.info(f"LangGraph investigation completed in {total_ms:.2f}ms")
    return final_state
