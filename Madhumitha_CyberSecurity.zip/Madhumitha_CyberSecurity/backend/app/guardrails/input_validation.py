"""Input validation guardrail for network-flow telemetry (RFC address/port rules + sane physical bounds)."""
import ipaddress
import math
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Tuple

from app.observability.tracing import tracer

FLOW_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:@#|/\-]{0,159}$")

# field -> inclusive upper bound. Values are physically meaningful ceilings (CIC-IDS2017 flows are capped at 120 s).
NUMERIC_LIMITS: Dict[str, float] = {
    "flow_duration": 1.2e10,        # microseconds
    "total_fwd_packets": 1e8,
    "total_bwd_packets": 1e8,
    "total_length_fwd": 1e12,
    "total_length_bwd": 1e12,
    "flow_bytes_per_sec": 1e11,
    "flow_packets_per_sec": 1e9,
    "flow_iat_mean": 1.2e10,
    "packet_length_mean": 65535.0,
    "syn_count": 1e8,
    "rst_count": 1e8,
    "ack_count": 1e8,
    "average_packet_size": 65535.0,
    "active_mean": 1.2e10,
    "idle_mean": 1.2e10,
}
MIN_TIMESTAMP = datetime(1990, 1, 1)


def _is_number(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _validate(data: Dict[str, Any]) -> Tuple[bool, List[str]]:
    errors: List[str] = []

    flow_id = data.get("flow_id")
    if flow_id not in (None, "") and not FLOW_ID_RE.match(str(flow_id)):
        errors.append("flow_id may only contain letters, digits and . _ : @ # | / - (max 160 chars)")

    for ip_field in ("source_ip", "destination_ip"):
        ip_val = data.get(ip_field)
        if not ip_val:
            errors.append(f"Missing required field: {ip_field}")
            continue
        try:
            ipaddress.ip_address(str(ip_val).strip())
        except ValueError:
            errors.append(f"Invalid IP address format for {ip_field}: '{ip_val}'")

    for port_field in ("source_port", "destination_port"):
        port_val = data.get(port_field)
        if port_val is None:
            errors.append(f"Missing required field: {port_field}")
            continue
        try:
            port_num = int(port_val)
            if port_num < 0 or port_num > 65535:
                errors.append(f"{port_field} must be between 0 and 65535 (got {port_num})")
        except (ValueError, TypeError):
            errors.append(f"{port_field} must be an integer (got {port_val})")

    proto_val = data.get("protocol")
    if proto_val is None:
        errors.append("Missing required field: protocol")
    else:
        try:
            proto_num = int(proto_val)
            if proto_num < 0 or proto_num > 255:
                errors.append(f"Protocol must be between 0 and 255 (got {proto_num})")
        except (ValueError, TypeError):
            errors.append(f"Protocol must be an integer (got {proto_val})")

    for field, upper in NUMERIC_LIMITS.items():
        raw = data.get(field)
        if raw is None:
            continue
        try:
            val = float(raw)
        except (TypeError, ValueError):
            errors.append(f"{field} must be a valid number (got {raw})")
            continue
        if not math.isfinite(val):
            errors.append(f"{field} must be a finite number (got {raw})")
        elif val < 0:
            errors.append(f"{field} cannot be negative (got {val})")
        elif val > upper:
            errors.append(f"{field} exceeds the physically plausible maximum of {upper:g} (got {val:g})")

    ts = data.get("timestamp")
    if ts not in (None, ""):
        try:
            if isinstance(ts, str):
                ts = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            if ts.tzinfo is not None:
                ts = ts.astimezone(timezone.utc).replace(tzinfo=None)
            now = datetime.now(timezone.utc).replace(tzinfo=None)
            if ts < MIN_TIMESTAMP:
                errors.append("timestamp is before 1990-01-01")
            elif ts > now + timedelta(days=1):
                errors.append("timestamp lies in the future")
        except (ValueError, TypeError, AttributeError):
            errors.append(f"timestamp is not a valid ISO-8601 datetime (got {ts})")

    return len(errors) == 0, errors


def validate_network_incident(data: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """Validate a flow record (addresses, ports, protocol, physical bounds, timestamp). Recorded as a trace span."""
    with tracer.span("guardrail.input_validation", "guardrail", fields_checked=len(NUMERIC_LIMITS) + 6) as sp:
        ok, errors = _validate(data)
        sp.set(valid=ok, n_errors=len(errors), errors=errors[:6])
        if not ok:
            tracer.count("guardrail.validation_failed")
        return ok, errors
