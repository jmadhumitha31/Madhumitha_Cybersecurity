"""Relevance guardrail: keep the assistant on cybersecurity incident investigation.

Matching is stem/prefix based, so natural phrasings such as "attacks on web servers", "any scans against our
hosts?", "many SYNs" or "credential guessing against a remote shell" are recognised. Only clearly off-topic
requests are refused.
"""
import re
from typing import Tuple

from app.observability.tracing import tracer

# long stems: prefix match
STRONG_STEMS = (
    "cyber", "secur", "incident", "attack", "ddos", "malware", "botnet", "infiltrat", "heartbleed", "packet", "network",
    "traffic", "protocol", "firewall", "threat", "vulnerab", "exploit", "payload", "analyst", "investigat", "mitre",
    "alert", "anomal", "suspici", "honeypot", "beacon", "exfiltrat", "phish", "ransom", "trojan", "backdoor", "rootkit",
    "zero-day", "intrusion", "malicious", "adversar", "credential", "password", "authent", "denial", "flood", "brute",
    "scan", "probe", "endpoint", "subnet", "iptables", "siem", "forensic", "playbook", "mitigat", "remediat", "triage",
    "contain", "lateral", "c2", "command-and-control", "hijack", "spoof", "sniff", "inject", "xss", "csrf", "ioc",
    "indicator", "cic-ids", "cicids", "nist", "owasp", "pentest", "penetration", "compromis", "breach", "intrus",
)
# short tokens: exact (or plural) match only
SHORT_TOKENS = {
    "dos", "ids", "ips", "syn", "rst", "ack", "fin", "tcp", "udp", "icmp", "dns", "ssh", "ftp", "tls", "ssl", "http",
    "https", "smb", "rdp", "cve", "soc", "ip", "acl", "vlan", "vpn", "nat", "flow", "port", "host", "server", "log",
    "login", "attacker", "bot", "worm", "rule", "iat", "pcap",
}
# generic words that count only as a weak hint
WEAK_STEMS = ("detect", "classif", "severity", "priorit", "risk", "benign", "label", "feedback", "explain", "similar", "historical", "recommend", "predict", "model")

OFF_TOPIC_PATTERNS = [
    r"capital of [a-z ]+", r"recipe for", r"write (me )?a (poem|song|story|joke|essay)", r"who won the [a-z ]+",
    r"movie|film recommendation|tv show", r"translate (this )?(to|into) [a-z]+", r"weather (in|for|today)", r"\bhoroscope\b",
    r"stock price|bitcoin price|crypto price", r"lottery|casino|football score|cricket score",
    r"\b(tell me a joke|sing a song)\b", r"how (do|to) (i )?(cook|bake|lose weight)", r"homework|math problem|solve for x",
]
_OFF = [re.compile(p, re.I) for p in OFF_TOPIC_PATTERNS]
_MSG = "I can assist with cybersecurity incident investigation and related cybersecurity questions."
_WORD = re.compile(r"[a-z0-9][a-z0-9&/_-]*")


def _strong_hit(tok: str) -> bool:
    if tok in SHORT_TOKENS or (tok.endswith("s") and tok[:-1] in SHORT_TOKENS):
        return True
    return any(tok.startswith(s) for s in STRONG_STEMS)


class RelevanceGuardrail:
    @staticmethod
    def is_cybersecurity_relevant(query: str) -> Tuple[bool, str]:
        if not query or not query.strip():
            return True, ""
        text = query.lower().strip()
        words = _WORD.findall(text)

        has_ip = bool(re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text))
        has_port = bool(re.search(r"\bport\s*\d+\b", text))
        has_incident_ref = bool(re.search(r"(incident|flow|#)\s*#?\s*[\w-]*\d", text))
        strong_words = [w for w in words if _strong_hit(w)]
        strong = len(strong_words)
        weak = sum(1 for w in words if any(w.startswith(s) for s in WEAK_STEMS))
        off_topic = any(p.search(text) for p in _OFF)

        if strong or has_ip or has_port or has_incident_ref:
            ok, why = True, "security vocabulary" if strong else "IP address, port or incident reference"
        elif off_topic:
            ok, why = False, "matches an off-topic pattern and has no security vocabulary"
        elif weak and len(words) <= 12:
            ok, why = True, "weak security hint in a short query"
        elif len(words) <= 3:  # short follow-ups like "why?" or "and port 22?"
            ok, why = True, "very short follow-up"
        else:
            ok, why = False, "no security vocabulary, IP, port or incident reference"
        with tracer.span("guardrail.relevance", "guardrail") as sp:
            sp.set(relevant=ok, reason=why, n_words=len(words), strong_terms=strong_words[:8], weak_hits=weak, has_ip=has_ip,
                   has_port=has_port, has_incident_ref=has_incident_ref, off_topic=off_topic)
            if not ok:
                tracer.count("guardrail.blocked.relevance")
        return (True, "") if ok else (False, _MSG)


relevance_guardrail = RelevanceGuardrail()
