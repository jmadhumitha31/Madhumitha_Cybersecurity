"""Security guardrails: prompt-injection screening, prompt hygiene for untrusted fields, and human-in-the-loop
enforcement on generated recommendations."""
import re
from typing import List, Tuple

from app.observability.tracing import tracer

PROMPT_INJECTION_PATTERNS = [
    re.compile(r"(ignore|forget|override)\s+(?:(?:all|any|the|your|my|these|those)\s+)*(previous|prior|above|earlier|original)\s+(instruction|prompt|rule|direction|guideline)s?", re.I),
    re.compile(r"disregard\s+(?:(?:all|any|the|your|my|these|those)\s+)*(previous|prior|above|earlier|original)?\s*(instruction|prompt|rule|guideline)s?", re.I),
    re.compile(r"(reveal|show|print|leak|dump|repeat|output)\s+(me\s+)?(your|the)\s+(system|hidden|initial)\s+(prompt|instruction)s?", re.I),
    re.compile(r"system\s+prompt\s+(reveal|leak|show|dump)", re.I),
    re.compile(r"you\s+are\s+now\s+(an?\s+)?(unrestricted|unfiltered|jailbroken|dan\b|developer mode)", re.I),
    re.compile(r"\b(jailbreak|developer\s+mode|do\s+anything\s+now)\b", re.I),
    re.compile(r"bypass\s+(all\s+|the\s+|any\s+)?(guardrail|safety|filter|restriction)s?", re.I),
    re.compile(r"(pretend|act)\s+(that\s+)?(you\s+(are|have)\s+no|without)\s+(restriction|rule|guardrail|limit)s?", re.I),
    re.compile(r"\bdrop\s+table\b", re.I),
    re.compile(r"\bdelete\s+from\b", re.I),
    re.compile(r";\s*--"),
    re.compile(r"<\s*script\b", re.I),
    re.compile(r"\bunion\s+select\b", re.I),
]

# Phrases that turn an investigation step into an unattended destructive action
_AUTOMATIC = r"automatic(?:ally)?\s+"
UNSAFE_ACTION_PATTERNS = [
    re.compile(_AUTOMATIC + r"(block|isolate|quarantine|shut\s*down|disable|delete|wipe|terminate|kill|reset)", re.I),
    re.compile(r"\brm\s+-rf\b", re.I),
    re.compile(r"\bformat\s+(c:|the\s+disk|the\s+drive)\b", re.I),
    re.compile(r"immediately\s+shut\s*down\s+(the\s+)?production", re.I),
    re.compile(r"without\s+(analyst\s+)?(approval|review|verification)", re.I),
]

_CONTROL = re.compile(r"[\x00-\x1f\x7f`]")


class SecurityGuardrail:
    @staticmethod
    def inspect_input(text: str) -> Tuple[bool, str]:
        with tracer.span("guardrail.security_screen", "guardrail", text_chars=len(text or ""), n_rules=len(PROMPT_INJECTION_PATTERNS)) as sp:
            if not text:
                sp.set(blocked=False)
                return True, ""
            for i, pattern in enumerate(PROMPT_INJECTION_PATTERNS):
                if pattern.search(text):
                    sp.set(blocked=True, matched_rule=i, rule=pattern.pattern[:90])
                    tracer.count("guardrail.blocked.security")
                    return False, "Input rejected by security guardrail: Malicious payload or prompt injection signature detected."
            sp.set(blocked=False)
            return True, ""

    @staticmethod
    def sanitize_for_prompt(value: object, max_len: int = 160) -> str:
        """Neutralise an untrusted field (flow id, feedback text ...) before it is interpolated into an LLM prompt."""
        text = _CONTROL.sub(" ", str(value if value is not None else ""))
        text = re.sub(r"\s+", " ", text).strip()[:max_len]
        for pattern in PROMPT_INJECTION_PATTERNS:
            text = pattern.sub("[filtered]", text)
        return text

    @staticmethod
    def find_unsafe(text: str) -> List[str]:
        return [p.pattern for p in UNSAFE_ACTION_PATTERNS if p.search(text or "")]

    @staticmethod
    def sanitize_text(text: str) -> str:
        """Rewrite unattended-destructive phrasing into analyst-supervised wording."""
        out = text
        out = UNSAFE_ACTION_PATTERNS[0].sub(lambda m: "Analyst review: evaluate whether to " + m.group(1), out)
        out = UNSAFE_ACTION_PATTERNS[1].sub("[command removed by guardrail]", out)
        out = UNSAFE_ACTION_PATTERNS[2].sub("[command removed by guardrail]", out)
        out = UNSAFE_ACTION_PATTERNS[3].sub("consider, after change-control approval, restricting the affected production service", out)
        out = UNSAFE_ACTION_PATTERNS[4].sub("after analyst approval", out)
        return out

    @classmethod
    def sanitize_recommendations(cls, recommendations: List[str]) -> List[str]:
        return [cls.sanitize_text(r) for r in recommendations if r and r.strip()]


security_guardrail = SecurityGuardrail()
