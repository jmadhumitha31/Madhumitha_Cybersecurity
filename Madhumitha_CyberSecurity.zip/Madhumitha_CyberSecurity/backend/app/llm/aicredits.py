import threading
import time
from typing import Any, Dict, List, Optional

import httpx

from app.config import settings
from app.llm.base import BaseLLMProvider, LLMResponse, LLMUnavailable
from app.logging_config import logger
from app.net import enable_system_trust_store, http_verify

_RETRYABLE = {408, 409, 425, 429, 500, 502, 503, 504}
_MODEL_GONE = {400, 404, 410, 422}


class AICreditsProvider(BaseLLMProvider):
    """AICredits (OpenAI-compatible) gateway client.

    * Primary LLM provider routing through https://api.aicredits.in/v1
    * Walks candidate models (e.g. gpt-4o-mini -> openai/gpt-4o)
    * Records every attempt for observability and tracing.
    """

    def __init__(self):
        enable_system_trust_store()
        self._client: Optional[httpx.Client] = None
        self._lock = threading.Lock()
        self._health: Dict[str, Any] = {}
        self._health_at = 0.0

    # ------------------------------------------------------------------ config
    @property
    def api_key(self) -> str:
        return (settings.AICREDITS_API_KEY or "").strip()

    @property
    def base_url(self) -> str:
        return settings.AICREDITS_BASE_URL.rstrip("/")

    def is_available(self) -> bool:
        return bool(self.api_key)

    def _http(self) -> httpx.Client:
        with self._lock:
            if self._client is None:
                self._client = httpx.Client(timeout=settings.LLM_TIMEOUT_SECONDS, verify=http_verify())
            return self._client

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    # ------------------------------------------------------------------ inference
    def _call(self, model: str, messages: List[Dict[str, str]], max_tokens: int, temperature: float) -> Dict[str, Any]:
        payload = {"model": model, "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
        resp = self._http().post(f"{self.base_url}/chat/completions", headers=self._headers(), json=payload)
        if resp.status_code != 200:
            detail = resp.text[:200].replace("\n", " ")
            err = RuntimeError(f"HTTP {resp.status_code}: {detail}")
            err.status_code = resp.status_code  # type: ignore[attr-defined]
            raise err
        return resp.json()

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        models: Optional[List[str]] = None,
        max_tokens: Optional[int] = None,
        temperature: float = 0.2,
        **_: Any,
    ) -> LLMResponse:
        if not self.is_available():
            raise LLMUnavailable("AICREDITS_API_KEY is not configured")
        messages: List[Dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        candidates = models or settings.aicredits_models
        budget = max_tokens or settings.LLM_MAX_TOKENS
        attempts: List[Dict[str, Any]] = []
        started = time.time()

        for model in candidates:
            for retry in range(settings.LLM_MAX_RETRIES + 1):
                t0 = time.time()
                try:
                    data = self._call(model, messages, budget, temperature)
                    choice = data["choices"][0]
                    content = (choice["message"].get("content") or "").strip()
                    if not content and choice.get("finish_reason") == "length":
                        data = self._call(model, messages, min(budget * 2, 8000), temperature)
                        choice = data["choices"][0]
                        content = (choice["message"].get("content") or "").strip()
                    if not content:
                        raise RuntimeError(f"empty content (finish_reason={choice.get('finish_reason')})")
                    attempts.append({"provider": "aicredits", "model": model, "ok": True, "latency_ms": round((time.time() - t0) * 1000)})
                    logger.info(f"AICredits LLM ok: {model} in {(time.time() - t0):.1f}s")
                    return LLMResponse(
                        content=content,
                        provider="aicredits",
                        model_name=model,
                        fallback_used=False,
                        raw_response={"usage": data.get("usage"), "finish_reason": choice.get("finish_reason"), "model_index": candidates.index(model)},
                        attempts=attempts,
                        latency_ms=round((time.time() - started) * 1000),
                    )
                except Exception as e:  # noqa: BLE001
                    status = getattr(e, "status_code", None)
                    attempts.append(
                        {
                            "provider": "aicredits",
                            "model": model,
                            "ok": False,
                            "status": status,
                            "error": f"{type(e).__name__}: {str(e)[:180]}",
                            "latency_ms": round((time.time() - t0) * 1000),
                        }
                    )
                    logger.warning(f"AICredits call failed for {model} (try {retry + 1}): {type(e).__name__}: {str(e)[:150]}")
                    if status in _MODEL_GONE:
                        break
                    retryable = status in _RETRYABLE or isinstance(e, (httpx.TimeoutException, httpx.TransportError))
                    if not retryable or retry >= settings.LLM_MAX_RETRIES:
                        break
                    time.sleep(1.0 * (retry + 1))
        raise LLMUnavailable(
            "All AICredits models failed: " + "; ".join(f"{a['model']}: {a.get('error') or a.get('status')}" for a in attempts if not a["ok"]),
            attempts,
        )

    # ------------------------------------------------------------------ health
    def check(self, force: bool = False, ttl: float = 300.0) -> Dict[str, Any]:
        """Live probe (cached): key accepted? configured model callable?"""
        if not force and self._health and time.time() - self._health_at < ttl:
            return self._health
        info: Dict[str, Any] = {"configured": self.is_available(), "model": settings.AICREDITS_MODEL, "checked_at": time.time()}
        if not info["configured"]:
            info.update(reachable=False, key_valid=False, error="AICREDITS_API_KEY not set")
        else:
            t0 = time.time()
            try:
                r = self._http().get(f"{self.base_url}/models", headers=self._headers(), timeout=15)
                info["reachable"] = True
                info["key_valid"] = r.status_code == 200
                if r.status_code != 200:
                    info["error"] = f"HTTP {r.status_code}"
                else:
                    try:
                        self._call(settings.AICREDITS_MODEL, [{"role": "user", "content": "ping"}], 4, 0.0)
                        info["model_callable"] = True
                    except Exception as e:  # noqa: BLE001
                        info["model_callable"] = False
                        info["error"] = f"{type(e).__name__}: {str(e)[:160]}"
            except Exception as e:  # noqa: BLE001
                info.update(reachable=False, key_valid=False, error=f"{type(e).__name__}: {str(e)[:160]}")
            info["latency_ms"] = round((time.time() - t0) * 1000)
        self._health, self._health_at = info, time.time()
        return info
