from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class LLMError(Exception):
    """A provider call failed."""


class LLMUnavailable(LLMError):
    """No real LLM could serve the request (all providers/models failed). ``attempts`` explains why."""

    def __init__(self, message: str, attempts: Optional[List[Dict[str, Any]]] = None):
        super().__init__(message)
        self.attempts = attempts or []


class LLMResponse:
    def __init__(
        self,
        content: str,
        provider: str,
        model_name: str,
        fallback_used: bool = False,
        raw_response: Optional[Dict[str, Any]] = None,
        attempts: Optional[List[Dict[str, Any]]] = None,
        latency_ms: float = 0.0,
    ):
        self.content = content
        self.provider = provider
        self.model_name = model_name
        self.fallback_used = fallback_used
        self.raw_response = raw_response or {}
        self.attempts = attempts or []
        self.latency_ms = latency_ms

    def to_dict(self) -> Dict[str, Any]:
        return {
            "content": self.content,
            "provider": self.provider,
            "model_name": self.model_name,
            "fallback_used": self.fallback_used,
            "attempts": self.attempts,
            "latency_ms": self.latency_ms,
        }


class BaseLLMProvider(ABC):
    @abstractmethod
    def generate(self, prompt: str, system_prompt: Optional[str] = None, **kwargs) -> LLMResponse:
        pass

    @abstractmethod
    def is_available(self) -> bool:
        pass
