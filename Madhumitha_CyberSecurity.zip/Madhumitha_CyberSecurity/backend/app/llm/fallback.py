import hashlib
from typing import Any, Dict, List, Optional

from app.config import settings
from app.llm.aicredits import AICreditsProvider
from app.llm.base import LLMResponse, LLMUnavailable
from app.llm.nvidia import NVIDIAProvider
from app.llm.offline import build_offline_analysis, build_offline_chat_reply
from app.llm.ollama import OllamaProvider
from app.logging_config import logger
from app.observability.tracing import payload, tracer


class LLMFallbackHandler:
    """AICredits (primary) -> NVIDIA NIM (fallback) -> Ollama (local) -> deterministic offline playbooks.

    ``generate`` never raises and always reports which tier answered plus every failed attempt.
    ``generate_strict`` is for evaluation (LLM-as-Judge, DeepEval): it never degrades to canned text and raises
    ``LLMUnavailable`` instead, so a missing judge is reported as missing - not as a fabricated score.
    """

    def __init__(self):
        self.aicredits = AICreditsProvider()
        self.nvidia = NVIDIAProvider()
        self.ollama = OllamaProvider()

    # ------------------------------------------------------------------ tracing
    @staticmethod
    def _describe(sp, resp: LLMResponse) -> None:
        raw = resp.raw_response or {}
        sp.set(
            provider=resp.provider, model=resp.model_name, fallback_used=resp.fallback_used, degraded=bool(resp.fallback_used),
            attempts=resp.attempts, latency_ms=resp.latency_ms, response_chars=len(resp.content or ""),
            usage=raw.get("usage"), finish_reason=raw.get("finish_reason"), response_preview=payload(resp.content),
        )
        key = f"{resp.provider}/{resp.model_name}"
        tracer.count("llm.calls")
        tracer.count(f"llm.calls.{key}")
        tracer.count(f"llm.latency_ms.{key}", resp.latency_ms or 0)
        tracer.count("llm.failed_attempts", sum(1 for a in resp.attempts if not a.get("ok")))
        if resp.fallback_used:
            tracer.count("llm.fallbacks")
        usage = raw.get("usage") or {}
        for field in ("prompt_tokens", "completion_tokens"):
            if isinstance(usage.get(field), (int, float)):
                tracer.count(f"llm.{field}", usage[field])

    @staticmethod
    def _request_attrs(prompt: str, system_prompt: Optional[str], mode: str, temperature: float, max_tokens: Optional[int]) -> Dict[str, Any]:
        return dict(
            mode=mode, prompt_chars=len(prompt or ""), system_chars=len(system_prompt or ""),
            prompt_sha256=hashlib.sha256((prompt or "").encode("utf-8")).hexdigest()[:16], temperature=temperature,
            max_tokens=max_tokens, prompt_preview=payload(prompt), system_preview=payload(system_prompt),
            chain=[f"aicredits:{m}" for m in settings.aicredits_models] + [f"nvidia:{m}" for m in settings.nvidia_models] + [f"ollama:{settings.OLLAMA_MODEL}", "offline playbooks"],
        )

    # ------------------------------------------------------------------ generation for the workflow / chat
    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        context_metadata: Optional[Dict[str, Any]] = None,
        max_tokens: Optional[int] = None,
        temperature: float = 0.2,
    ) -> LLMResponse:
        mode = (context_metadata or {}).get("mode", "analysis")
        with tracer.span("llm.generate", "llm", **self._request_attrs(prompt, system_prompt, mode, temperature, max_tokens or settings.LLM_MAX_TOKENS)) as sp:
            resp = self._generate(prompt, system_prompt, context_metadata, max_tokens, temperature)
            self._describe(sp, resp)
            return resp

    def _generate(
        self,
        prompt: str,
        system_prompt: Optional[str],
        context_metadata: Optional[Dict[str, Any]],
        max_tokens: Optional[int],
        temperature: float,
    ) -> LLMResponse:
        attempts: List[Dict[str, Any]] = []

        # 1. Primary: AICredits
        if self.aicredits.is_available():
            try:
                resp = self.aicredits.generate(prompt, system_prompt, max_tokens=max_tokens, temperature=temperature)
                return resp
            except LLMUnavailable as e:
                attempts.extend(e.attempts)
                logger.warning(f"Primary LLM (AICredits) unavailable: {e}. Falling back to NVIDIA NIM...")
        else:
            attempts.append({"provider": "aicredits", "ok": False, "error": "AICREDITS_API_KEY not configured"})

        # 2. Secondary fallback: NVIDIA NIM
        if self.nvidia.is_available():
            try:
                resp = self.nvidia.generate(prompt, system_prompt, max_tokens=max_tokens, temperature=temperature)
                resp.attempts = attempts + resp.attempts
                resp.fallback_used = True
                return resp
            except LLMUnavailable as e:
                attempts.extend(e.attempts)
                logger.warning(f"Secondary LLM (NVIDIA) unavailable: {e}. Falling back to Ollama...")
        else:
            attempts.append({"provider": "nvidia", "ok": False, "error": "NVIDIA_API_KEY not configured"})

        # 3. Local fallback: Ollama
        if self.ollama.is_available():
            try:
                resp = self.ollama.generate(prompt, system_prompt, max_tokens=max_tokens, temperature=temperature)
                resp.attempts = attempts + resp.attempts
                resp.fallback_used = True
                return resp
            except LLMUnavailable as e:
                attempts.extend(e.attempts)
        else:
            attempts.append({"provider": "ollama", "ok": False, "error": f"not reachable at {settings.OLLAMA_BASE_URL}"})

        logger.info("No LLM reachable; using the offline SOC rule engine.")
        meta = context_metadata or {}
        if meta.get("mode") == "chat":
            content = build_offline_chat_reply(meta.get("message", ""), meta.get("incident"), meta.get("citations", []))
        else:
            content = build_offline_analysis(
                attack_type=meta.get("attack_type", "Unclassified"),
                risk_level=meta.get("risk_level", "Medium"),
                priority=meta.get("priority", "P3"),
                flow=meta.get("flow", {}),
                indicators=meta.get("indicators", []),
                risk_factors=meta.get("risk_factors", []),
                evidence_text=meta.get("evidence_text", ""),
            )
        return LLMResponse(
            content=content,
            provider="heuristic_rule_engine",
            model_name="soc-playbooks-v2",
            fallback_used=True,
            raw_response={"status": "offline_rule_engine"},
            attempts=attempts,
        )

    # ------------------------------------------------------------------ strict generation for evaluators
    def generate_strict(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        models: Optional[List[str]] = None,
        max_tokens: Optional[int] = None,
        temperature: float = 0.0,
    ) -> LLMResponse:
        with tracer.span("llm.generate", "llm", **self._request_attrs(prompt, system_prompt, "strict-judge", temperature, max_tokens or settings.LLM_JUDGE_MAX_TOKENS)) as sp:
            try:
                resp = self._generate_strict(prompt, system_prompt, models, max_tokens, temperature)
            except LLMUnavailable as e:
                sp.set(provider="none", attempts=e.attempts, degraded=True)
                raise
            self._describe(sp, resp)
            return resp

    def _generate_strict(
        self,
        prompt: str,
        system_prompt: Optional[str],
        models: Optional[List[str]],
        max_tokens: Optional[int],
        temperature: float,
    ) -> LLMResponse:
        attempts: List[Dict[str, Any]] = []
        if self.aicredits.is_available():
            try:
                return self.aicredits.generate(
                    prompt, system_prompt, models=models or settings.aicredits_models,
                    max_tokens=max_tokens or settings.LLM_JUDGE_MAX_TOKENS, temperature=temperature,
                )
            except LLMUnavailable as e:
                attempts.extend(e.attempts)
        else:
            attempts.append({"provider": "aicredits", "ok": False, "error": "AICREDITS_API_KEY not configured"})

        if self.nvidia.is_available():
            try:
                return self.nvidia.generate(
                    prompt, system_prompt, models=models or settings.judge_models,
                    max_tokens=max_tokens or settings.LLM_JUDGE_MAX_TOKENS, temperature=temperature,
                )
            except LLMUnavailable as e:
                attempts.extend(e.attempts)
        else:
            attempts.append({"provider": "nvidia", "ok": False, "error": "NVIDIA_API_KEY not configured"})
        if self.ollama.is_available():
            try:
                resp = self.ollama.generate(prompt, system_prompt, max_tokens=max_tokens or settings.LLM_JUDGE_MAX_TOKENS, temperature=temperature)
                resp.attempts = attempts + resp.attempts
                return resp
            except LLMUnavailable as e:
                attempts.extend(e.attempts)
        else:
            attempts.append({"provider": "ollama", "ok": False, "error": "not reachable"})
        raise LLMUnavailable("No LLM provider could serve the evaluation request", attempts)

    def status(self, force: bool = False) -> Dict[str, Any]:
        return {
            "aicredits": self.aicredits.check(force=force),
            "nvidia": self.nvidia.check(force=force),
            "ollama": self.ollama.check(),
        }


llm_fallback_handler = LLMFallbackHandler()
