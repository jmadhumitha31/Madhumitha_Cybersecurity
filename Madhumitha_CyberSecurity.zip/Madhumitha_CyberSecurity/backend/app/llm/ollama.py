import time
from typing import Any, Dict, Optional

import httpx

from app.config import settings
from app.llm.base import BaseLLMProvider, LLMResponse, LLMUnavailable
from app.logging_config import logger


class OllamaProvider(BaseLLMProvider):
    """Local Ollama daemon (secondary LLM)."""

    @property
    def base_url(self) -> str:
        return settings.OLLAMA_BASE_URL.rstrip("/")

    @property
    def model(self) -> str:
        return settings.OLLAMA_MODEL

    def is_available(self) -> bool:
        try:
            with httpx.Client(timeout=2.0) as client:
                res = client.get(f"{self.base_url}/api/tags")
                return res.status_code == 200
        except Exception:
            return False

    def check(self) -> Dict[str, Any]:
        try:
            with httpx.Client(timeout=2.0) as client:
                res = client.get(f"{self.base_url}/api/tags")
            if res.status_code != 200:
                return {"reachable": True, "model": self.model, "model_installed": False, "error": f"HTTP {res.status_code}"}
            names = [m.get("name") for m in res.json().get("models", [])]
            return {"reachable": True, "model": self.model, "model_installed": self.model in names, "installed_models": names[:10]}
        except Exception as e:  # noqa: BLE001
            return {"reachable": False, "model": self.model, "error": f"{type(e).__name__}"}

    def generate(self, prompt: str, system_prompt: Optional[str] = None, max_tokens: Optional[int] = None, temperature: float = 0.2, **_: Any) -> LLMResponse:
        url = f"{self.base_url}/api/generate"
        payload = {
            "model": self.model,
            "prompt": prompt,
            "system": system_prompt or "",
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens or settings.LLM_MAX_TOKENS},
        }
        t0 = time.time()
        try:
            with httpx.Client(timeout=settings.LLM_TIMEOUT_SECONDS) as client:
                resp = client.post(url, json=payload)
            if resp.status_code != 200:
                raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:160]}")
            data = resp.json()
            content = (data.get("response") or "").strip()
            if not content:
                raise RuntimeError("empty response")
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Ollama call failed: {type(e).__name__}: {str(e)[:150]}")
            raise LLMUnavailable(
                f"Ollama failed: {e}",
                [{"provider": "ollama", "model": self.model, "ok": False, "error": f"{type(e).__name__}: {str(e)[:160]}", "latency_ms": round((time.time() - t0) * 1000)}],
            )
        return LLMResponse(
            content=content,
            provider="ollama",
            model_name=self.model,
            fallback_used=True,
            raw_response={"eval_count": data.get("eval_count")},
            attempts=[{"provider": "ollama", "model": self.model, "ok": True, "latency_ms": round((time.time() - t0) * 1000)}],
            latency_ms=round((time.time() - t0) * 1000),
        )
