import logging
import sys
import json
import re
from datetime import datetime, timezone
from typing import Any, Dict

from app.observability.context import current_trace_id  # dependency-free module: no import cycle

SECRET_PATTERNS = [
    re.compile(r"(api[_-]?key|secret|password|token)[\"']?\s*[:=]\s*[\"']?([^\"'\s&]+)", re.IGNORECASE),
    re.compile(r"Bearer\s+([A-Za-z0-9\-_=]+\.[A-Za-z0-9\-_=]+\.?[A-Za-z0-9\-_.+/=]*)", re.IGNORECASE),
]


def scrub_secrets(text: str) -> str:
    if not isinstance(text, str):
        return text
    sanitized = text
    for pattern in SECRET_PATTERNS:
        sanitized = pattern.sub(r"\1: [REDACTED]", sanitized)
    return sanitized


class StructuredJsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_entry: Dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": scrub_secrets(record.getMessage()),
            "module": record.module,
            "line": record.lineno,
        }
        trace_id = current_trace_id()
        if trace_id:
            log_entry["trace_id"] = trace_id  # joins log lines to the trace shown on the Observability page
        if hasattr(record, "request_id"):
            log_entry["request_id"] = record.request_id
        if hasattr(record, "user_id"):
            log_entry["user_id"] = record.user_id
        if hasattr(record, "incident_id"):
            log_entry["incident_id"] = record.incident_id
        if hasattr(record, "duration_ms"):
            log_entry["duration_ms"] = record.duration_ms
        if hasattr(record, "llm_provider"):
            log_entry["llm_provider"] = record.llm_provider

        if record.exc_info:
            log_entry["exception"] = scrub_secrets(self.formatException(record.exc_info))

        return json.dumps(log_entry)


def setup_logger(name: str = "soc_assistant") -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(StructuredJsonFormatter())
        logger.addHandler(handler)

    logger.propagate = False
    return logger


logger = setup_logger()
