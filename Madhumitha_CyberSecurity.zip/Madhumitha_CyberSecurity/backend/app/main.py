import threading
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.config import DEFAULT_JWT_SECRET, settings
from app.database.connection import init_db
from app.logging_config import logger
from app.net import enable_system_trust_store
from app.observability.tracing import route_kind, tracer

enable_system_trust_store()  # before any outbound HTTP client is created (corporate TLS inspection)

from app.api.v1.analytics import router as analytics_router  # noqa: E402
from app.api.v1.audit import router as audit_router  # noqa: E402
from app.api.v1.auth import router as auth_router  # noqa: E402
from app.api.v1.chat import router as chat_router  # noqa: E402
from app.api.v1.evaluation import router as evaluation_router  # noqa: E402
from app.api.v1.feedback import router as feedback_router  # noqa: E402
from app.api.v1.health import router as health_router  # noqa: E402
from app.api.v1.incidents import router as incidents_router  # noqa: E402
from app.api.v1.ml import router as ml_router  # noqa: E402
from app.api.v1.observability import router as observability_router  # noqa: E402
from app.api.v1.search import router as search_router  # noqa: E402


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting AI-Powered Cybersecurity Incident Response Assistant backend...")
    init_db()
    if settings.JWT_SECRET == DEFAULT_JWT_SECRET:
        logger.warning("JWT_SECRET is the public default: set a unique value before exposing this service.")
    from app.database.connection import SessionLocal
    from app.rag.embeddings import embedding_service
    from app.rag.index import hybrid_index

    def warm_up() -> None:
        with tracer.trace("system.startup", "Startup warm-up") as ctx:
            if ctx is not None:
                ctx.query_text = "load the embedding model and sync the Qdrant index with the database"
            with tracer.span("embedding.warm_up", "embedding"):
                embedding_service.warm_up()
            try:  # open the on-device Qdrant store and make it mirror the database before the first search
                with SessionLocal() as db:
                    hybrid_index.ensure(db)
            except Exception as e:  # noqa: BLE001 - search retries on demand; /health reports the state
                logger.warning(f"Vector index warm-up failed: {type(e).__name__}: {str(e)[:200]}")

    threading.Thread(target=warm_up, daemon=True, name="index-warmup").start()
    yield
    logger.info("Shutting down backend services.")
    hybrid_index.close()  # release the embedded Qdrant storage lock


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="SOC AI incident-response assistant: hybrid RAG, multi-agent LangGraph investigation, intrusion-risk and anomaly models, explainability, feedback loop and evaluation suite over CIC-IDS2017.",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list or ["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
)


@app.middleware("http")
async def request_context_middleware(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))[:64]
    start = time.time()
    prefix = settings.API_V1_PREFIX
    path = request.url.path
    kind = route_kind(request.method, path[len(prefix):]) if path.startswith(prefix) else None
    ctx = tracer.begin(kind, f"{request.method} {path}", request_id) if kind else None
    try:
        response = await call_next(request)
    except BaseException as exc:  # noqa: BLE001 - the unhandled-error handler answers; the trace still records what failed
        tracer.end(ctx, http_status=500, error=exc)
        raise
    trace_id = tracer.end(ctx, http_status=response.status_code)
    if trace_id:
        response.headers["X-Trace-ID"] = trace_id
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Response-Time-Ms"] = f"{(time.time() - start) * 1000:.2f}"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cache-Control"] = "no-store"
    return response


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    detail = exc.detail
    message = detail if isinstance(detail, str) else (detail.get("message") if isinstance(detail, dict) and detail.get("message") else "An HTTP error occurred")
    return JSONResponse(
        status_code=exc.status_code,
        headers=getattr(exc, "headers", None),
        content={"success": False, "error": {"code": f"HTTP_{exc.status_code}", "message": message, "details": detail if not isinstance(detail, str) else None}},
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    errors = [f"{' -> '.join(str(x) for x in err.get('loc', []))}: {err.get('msg')}" for err in exc.errors()]
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"success": False, "error": {"code": "INPUT_VALIDATION_ERROR", "message": "Input validation guardrail failed.", "details": errors}},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled server error: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"success": False, "error": {"code": "INTERNAL_SERVER_ERROR", "message": "An internal server error occurred. Please contact the SOC systems administrator."}},
    )


for r in (auth_router, incidents_router, search_router, analytics_router, evaluation_router, health_router, chat_router, ml_router, feedback_router, audit_router, observability_router):
    app.include_router(r, prefix=settings.API_V1_PREFIX)


@app.get("/", tags=["Root"])
def root():
    return {"name": settings.APP_NAME, "version": settings.APP_VERSION, "status": "OPERATIONAL", "docs": "/docs"}
