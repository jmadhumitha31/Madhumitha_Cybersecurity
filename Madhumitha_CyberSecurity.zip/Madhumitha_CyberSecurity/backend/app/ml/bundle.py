"""Versioned model artifacts: classifier + intrusion-risk model + anomaly detector + explainability statistics."""
import json
import os
import threading
from typing import Any, Dict, List, Optional

import joblib
import numpy as np

from app.ml.preprocessing import log_transform

ACTIVE_POINTER = "active_model.json"
VERSIONS_DIR = "versions"


class ModelBundle:
    def __init__(self, data: Dict[str, Any]):
        self.version: str = data["version"]
        self.classifier = data["classifier"]
        self.label_encoder = data["label_encoder"]
        self.intrusion_model = data["intrusion_model"]
        self.anomaly_model = data["anomaly_model"]
        self.anomaly_ref: np.ndarray = np.asarray(data["anomaly_ref"])  # sorted benign anomaly raw scores
        self.baselines: Dict[str, Dict[str, float]] = data["baselines"]
        self.class_profiles: Dict[str, Any] = data["class_profiles"]
        self.global_shap: Dict[str, Dict[str, float]] = data.get("global_shap", {})
        self.global_importance: Dict[str, float] = data.get("global_importance", {})
        self.metrics: Dict[str, Any] = data.get("metrics", {})
        self.metadata: Dict[str, Any] = data.get("metadata", {})
        self._explainer = None
        self._lock = threading.Lock()

    # --------------------------------------------------------------------------------------
    @property
    def classes(self) -> List[str]:
        return [str(c) for c in self.label_encoder.classes_]

    def explainer(self):
        with self._lock:
            if self._explainer is None:
                import shap

                self._explainer = shap.TreeExplainer(self.classifier)
            return self._explainer

    def class_proba(self, x: np.ndarray) -> np.ndarray:
        return self.classifier.predict_proba(x)

    def intrusion_proba(self, x: np.ndarray) -> np.ndarray:
        return self.intrusion_model.predict_proba(x)[:, 1]

    def anomaly(self, x: np.ndarray) -> np.ndarray:
        """Empirical-CDF calibrated anomaly score in [0, 1]: share of benign training flows that look *less* odd."""
        raw = -self.anomaly_model.score_samples(log_transform(x))
        return np.searchsorted(self.anomaly_ref, raw, side="right") / float(len(self.anomaly_ref))

    def to_info(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "classes": self.classes,
            "metadata": self.metadata,
            "metrics": self.metrics,
        }


def _versions_root(model_dir: str) -> str:
    return os.path.join(model_dir, VERSIONS_DIR)


def save_bundle(data: Dict[str, Any], model_dir: str, activate: bool = True) -> str:
    version = data["version"]
    vdir = os.path.join(_versions_root(model_dir), version)
    os.makedirs(vdir, exist_ok=True)
    joblib.dump(data, os.path.join(vdir, "bundle.joblib"), compress=3)
    with open(os.path.join(vdir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump({"version": version, "metadata": data.get("metadata", {}), "metrics": data.get("metrics", {})}, f, indent=2, default=str)
    if activate:
        set_active(model_dir, version)
    return vdir


def set_active(model_dir: str, version: str) -> None:
    os.makedirs(model_dir, exist_ok=True)
    with open(os.path.join(model_dir, ACTIVE_POINTER), "w", encoding="utf-8") as f:
        json.dump({"version": version}, f)


def active_version(model_dir: str) -> Optional[str]:
    p = os.path.join(model_dir, ACTIVE_POINTER)
    if not os.path.exists(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f).get("version")
    except Exception:
        return None


def load_bundle(model_dir: str, version: str) -> Optional[ModelBundle]:
    path = os.path.join(_versions_root(model_dir), version, "bundle.joblib")
    if not os.path.exists(path):
        return None
    return ModelBundle(joblib.load(path))


def load_active_bundle(model_dir: str) -> Optional[ModelBundle]:
    v = active_version(model_dir)
    return load_bundle(model_dir, v) if v else None


def list_versions(model_dir: str) -> List[Dict[str, Any]]:
    root = _versions_root(model_dir)
    out = []
    if not os.path.isdir(root):
        return out
    active = active_version(model_dir)
    for v in sorted(os.listdir(root)):
        mp = os.path.join(root, v, "metrics.json")
        if os.path.exists(mp):
            with open(mp, "r", encoding="utf-8") as f:
                info = json.load(f)
            m = info.get("metrics", {}).get("classification", {})
            out.append(
                {
                    "version": v,
                    "active": v == active,
                    "trained_at": info.get("metadata", {}).get("trained_at"),
                    "dataset_source": info.get("metadata", {}).get("dataset_source"),
                    "trigger": info.get("metadata", {}).get("trigger"),
                    "macro_f1": m.get("f1_macro"),
                    "accuracy": m.get("accuracy"),
                }
            )
    return out
