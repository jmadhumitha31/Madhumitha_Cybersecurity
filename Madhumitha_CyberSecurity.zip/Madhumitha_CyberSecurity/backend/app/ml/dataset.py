"""
CIC-IDS2017 dataset loader.

Accepts the official TrafficLabelling CSVs, the Hugging Face / Kaggle Parquet conversions, and the project's
synthetic demo CSV. Handles the real dataset's quirks:

* header spelling/whitespace differences (``" Destination Port"``, ``"Total Length of Fwd Packets"``,
  ``"SYN Flag Count"`` ...) via an alias table - every column in the project brief is recognised;
* raw labels (``BENIGN``, ``DoS Hulk``, ``PortScan``, ``FTP-Patator``, ``Web Attack – XSS`` ...) mapped to the
  canonical families in :mod:`app.domain`;
* ``inf`` / ``NaN`` rates, exact duplicate rows, mixed timestamp formats;
* very large files: only the needed columns are read and classes are sampled with per-class caps.
"""
import glob
import hashlib
import os
import re
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

from app.domain import CLASSES, normalize_label
from app.logging_config import logger
from app.ml.preprocessing import FEATURE_COLUMNS

META_COLUMNS = ["flow_id", "source_ip", "source_port", "destination_ip", "destination_port", "protocol", "timestamp"]

# normalised header (lower-case, single spaces) -> canonical column name
_ALIASES: Dict[str, str] = {
    "flow id": "flow_id",
    "source ip": "source_ip", "src ip": "source_ip",
    "source port": "source_port", "src port": "source_port",
    "destination ip": "destination_ip", "dst ip": "destination_ip",
    "destination port": "destination_port", "dst port": "destination_port",
    "protocol": "protocol",
    "timestamp": "timestamp",
    "flow duration": "flow_duration",
    "total fwd packets": "total_fwd_packets", "total forward packets": "total_fwd_packets", "tot fwd pkts": "total_fwd_packets",
    "total backward packets": "total_bwd_packets", "total bwd packets": "total_bwd_packets", "tot bwd pkts": "total_bwd_packets",
    "total length of fwd packets": "total_length_fwd", "total length forward": "total_length_fwd", "totlen fwd pkts": "total_length_fwd",
    "total length of bwd packets": "total_length_bwd", "total length backward": "total_length_bwd", "totlen bwd pkts": "total_length_bwd",
    "flow bytes/s": "flow_bytes_per_sec", "flow byts/s": "flow_bytes_per_sec",
    "flow packets/s": "flow_packets_per_sec", "flow pkts/s": "flow_packets_per_sec",
    "flow iat mean": "flow_iat_mean",
    "packet length mean": "packet_length_mean", "pkt len mean": "packet_length_mean",
    "syn flag count": "syn_count", "syn count": "syn_count", "syn flag cnt": "syn_count",
    "rst flag count": "rst_count", "rst count": "rst_count", "rst flag cnt": "rst_count",
    "ack flag count": "ack_count", "ack count": "ack_count", "ack flag cnt": "ack_count",
    "average packet size": "average_packet_size", "pkt size avg": "average_packet_size",
    "active mean": "active_mean",
    "idle mean": "idle_mean",
    "label": "label",
}


def _norm(col: object) -> str:
    return re.sub(r"\s+", " ", str(col).strip().lower())


@dataclass
class LoadReport:
    source: str = ""
    files: List[str] = field(default_factory=list)
    rows_read: int = 0
    rows_dropped_invalid: int = 0
    rows_dropped_unknown_label: int = 0
    rows_dropped_duplicates: int = 0
    unknown_labels: Dict[str, int] = field(default_factory=dict)
    class_counts_before_sampling: Dict[str, int] = field(default_factory=dict)
    class_counts: Dict[str, int] = field(default_factory=dict)
    placeholders_used: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return self.__dict__.copy()


def rename_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Rename recognised headers to canonical names, keeping the first occurrence of each."""
    mapping, seen = {}, set()
    for col in df.columns:
        canon = _ALIASES.get(_norm(col))
        if canon and canon not in seen:
            mapping[col] = canon
            seen.add(canon)
    return df[list(mapping.keys())].rename(columns=mapping)


def usable_columns(all_columns: Iterable[str]) -> List[str]:
    """Original header names that map to a canonical column (used to limit what is read from big files)."""
    seen, keep = set(), []
    for col in all_columns:
        canon = _ALIASES.get(_norm(col))
        if canon and canon not in seen:
            seen.add(canon)
            keep.append(col)
    return keep


def normalize_frame(
    raw: pd.DataFrame,
    source: str = "cicids2017",
    allow_missing_metadata: bool = False,
    report: Optional[LoadReport] = None,
) -> pd.DataFrame:
    """Raw frame -> canonical frame with META + FEATURE columns, ``original_label`` and ``attack_type``."""
    report = report or LoadReport(source=source)
    df = rename_columns(raw)
    report.rows_read += len(df)

    if "label" not in df.columns:
        raise ValueError("Dataset has no 'Label' column")
    missing_features = [c for c in FEATURE_COLUMNS if c not in df.columns]
    if missing_features:
        raise ValueError(f"Dataset is missing required feature columns: {missing_features}")

    missing_meta = [c for c in META_COLUMNS if c not in df.columns]
    if missing_meta and not allow_missing_metadata:
        raise ValueError(
            f"Dataset lacks flow metadata columns {missing_meta}. Use the TrafficLabelling variant "
            "(Flow ID / IPs / ports / Timestamp), or pass allow_missing_metadata=True to use placeholders."
        )
    for c in missing_meta:
        report.placeholders_used.append(c)
        if c == "flow_id":
            df[c] = [f"{source}-{i}" for i in range(len(df))]
        elif c in ("source_ip", "destination_ip"):
            df[c] = "0.0.0.0"
        elif c == "source_port":
            df[c] = 0
        elif c == "timestamp":
            df[c] = pd.NaT

    # numeric coercion; inf -> NaN; drop rows whose features are not finite
    for col in FEATURE_COLUMNS + ["source_port"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    feat = df[FEATURE_COLUMNS].to_numpy(dtype=np.float64, na_value=np.nan)
    ok = np.isfinite(feat).all(axis=1) & (np.nan_to_num(feat, nan=-1.0) >= 0).all(axis=1)
    ok &= df["source_port"].between(0, 65535).to_numpy(na_value=False) & df["destination_port"].between(0, 65535).to_numpy(na_value=False)
    report.rows_dropped_invalid += int((~ok).sum())
    df = df.loc[ok].copy()

    # labels
    df["original_label"] = df["label"].astype(str).str.strip()
    df["attack_type"] = df["original_label"].map(normalize_label)
    unknown = df["attack_type"].isna()
    if unknown.any():
        for lab, n in df.loc[unknown, "original_label"].value_counts().items():
            report.unknown_labels[lab] = report.unknown_labels.get(lab, 0) + int(n)
        report.rows_dropped_unknown_label += int(unknown.sum())
        df = df.loc[~unknown].copy()

    # timestamps -> naive UTC (the Hugging Face conversion is already UTC; the CSVs use M/D/YYYY H:MM local)
    ts = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
    df["timestamp"] = ts.dt.tz_convert("UTC").dt.tz_localize(None)

    for c in ("flow_id", "source_ip", "destination_ip"):
        df[c] = df[c].astype(str).str.strip()
    df["source_port"] = df["source_port"].astype(int)
    df["destination_port"] = df["destination_port"].astype(int)
    df["protocol"] = df["protocol"].astype(int)

    keep = META_COLUMNS + [c for c in FEATURE_COLUMNS if c not in META_COLUMNS] + ["original_label", "attack_type"]
    return df[keep].reset_index(drop=True)


def _read_one(path: str) -> pd.DataFrame:
    lower = path.lower()
    if lower.endswith(".parquet"):
        import pyarrow.parquet as pq

        names = pq.ParquetFile(path).schema.names
        return pd.read_parquet(path, columns=usable_columns(names))
    header = pd.read_csv(path, nrows=0, encoding="latin-1")
    return pd.read_csv(path, usecols=usable_columns(header.columns), encoding="latin-1", low_memory=False)


def discover_files(path: str) -> List[str]:
    if os.path.isdir(path):
        files = sorted(glob.glob(os.path.join(path, "*.parquet")) + glob.glob(os.path.join(path, "*.csv")))
    elif os.path.exists(path):
        files = [path]
    else:
        files = []
    return files


def _stable_hash(df: pd.DataFrame) -> np.ndarray:
    cols = ["flow_id", "timestamp", "flow_duration", "total_fwd_packets", "total_bwd_packets", "flow_bytes_per_sec"]
    return pd.util.hash_pandas_object(df[cols].astype(str), index=False).to_numpy(dtype=np.uint64)


def load_dataset(
    path: str,
    max_per_label: Optional[Dict[str, int]] = None,
    default_cap: Optional[int] = None,
    seed: int = 42,
    source: str = "cicids2017",
    allow_missing_metadata: bool = False,
) -> Tuple[pd.DataFrame, LoadReport]:
    """Load a file or directory, clean it, de-duplicate and sample each *raw* label up to its cap.

    ``max_per_label`` caps individual raw labels (e.g. ``{"DoS Hulk": 10000}``); ``default_cap`` applies to every
    other raw label. Rare classes (Heartbleed, Infiltration, ...) are always kept in full.
    """
    files = discover_files(path)
    if not files:
        raise FileNotFoundError(f"No dataset files found at {path}")
    report = LoadReport(source=source, files=[os.path.basename(f) for f in files])
    rng = np.random.default_rng(seed)
    pieces: List[pd.DataFrame] = []
    caps = max_per_label or {}

    for f in files:
        logger.info(f"Loading {os.path.basename(f)} ...")
        raw = _read_one(f)
        df = normalize_frame(raw, source=source, allow_missing_metadata=allow_missing_metadata, report=report)
        del raw
        before = len(df)
        df = df.drop_duplicates(subset=FEATURE_COLUMNS + ["original_label"])
        report.rows_dropped_duplicates += before - len(df)
        for lab, n in df["original_label"].value_counts().items():
            report.class_counts_before_sampling[lab] = report.class_counts_before_sampling.get(lab, 0) + int(n)
        # per-file down-sampling bounds memory: keep up to 2x the global cap per raw label per file
        for lab, grp in df.groupby("original_label", sort=False):
            cap = caps.get(lab, default_cap)
            if cap is not None and len(grp) > cap * 2:
                grp = grp.iloc[rng.choice(len(grp), size=cap * 2, replace=False)]
            pieces.append(grp)

    full = pd.concat(pieces, ignore_index=True)
    # global de-dup across files, then the final per-label cap
    n0 = len(full)
    full = full.drop_duplicates(subset=FEATURE_COLUMNS + ["original_label"])
    report.rows_dropped_duplicates += n0 - len(full)
    sampled = []
    for lab, grp in full.groupby("original_label", sort=False):
        cap = caps.get(lab, default_cap)
        if cap is not None and len(grp) > cap:
            grp = grp.iloc[rng.choice(len(grp), size=cap, replace=False)]
        sampled.append(grp)
    out = pd.concat(sampled, ignore_index=True)
    out = _ensure_unique_flow_ids(out)
    report.class_counts = {k: int(v) for k, v in out["attack_type"].value_counts().items()}
    logger.info(f"Dataset loaded: {len(out)} flows, classes={report.class_counts}")
    return out, report


def _ensure_unique_flow_ids(df: pd.DataFrame) -> pd.DataFrame:
    """Real Flow IDs repeat (the same 5-tuple reappears over time); the database needs unique ids."""
    df = df.copy()
    ts = df["timestamp"].dt.strftime("%m%d%H%M").fillna("NA")
    df["flow_id"] = (df["flow_id"].str.slice(0, 110) + "@" + ts).astype(str)
    dup = df.duplicated("flow_id", keep=False)
    if dup.any():
        order = df.groupby("flow_id").cumcount()
        df.loc[dup, "flow_id"] = df.loc[dup, "flow_id"] + "#" + order[dup].astype(str)
    return df


def split_train_test(df: pd.DataFrame, test_fraction: float = 0.25) -> pd.Series:
    """Deterministic, row-identity-based split (stable across runs and re-sampling).

    Returns a boolean Series: True = test row. Every class with >= 2 rows contributes at least one test row,
    and rows of single-sample classes stay in training.
    """
    h = _stable_hash(df)
    is_test = pd.Series((h % 1000) < int(test_fraction * 1000), index=df.index)
    for cls, idx in df.groupby("attack_type").groups.items():
        idx = list(idx)
        if len(idx) < 2:
            is_test.loc[idx] = False
            continue
        n_test = int(is_test.loc[idx].sum())
        if n_test == 0:
            order = np.argsort(h[df.index.get_indexer(idx)])
            is_test.loc[idx[int(order[0])]] = True
        elif n_test == len(idx):
            order = np.argsort(-h[df.index.get_indexer(idx)])
            is_test.loc[idx[int(order[0])]] = False
    return is_test


def class_distribution(df: pd.DataFrame) -> Dict[str, int]:
    return {c: int((df["attack_type"] == c).sum()) for c in CLASSES if (df["attack_type"] == c).any()}


def dataset_fingerprint(files: List[str]) -> str:
    h = hashlib.sha256()
    for f in files:
        h.update(os.path.basename(f).encode())
        try:
            h.update(str(os.path.getsize(f)).encode())
        except OSError:
            pass
    return h.hexdigest()[:12]
