import os
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from app.config import settings
from app.database.repositories.evaluation_repo import evaluation_repo
from app.logging_config import logger
from app.ml.predictor import ml_predictor


def stored_ml_metrics() -> Optional[Dict[str, Any]]:
    """Metrics measured at training time on the held-out split, together with model/data provenance."""
    b = ml_predictor.bundle
    if not b:
        return None
    c = b.metrics.get("classification", {})
    return {
        "model_version": b.version,
        "dataset_source": b.metadata.get("dataset_source"),
        "trained_at": b.metadata.get("trained_at"),
        "n_train": b.metadata.get("n_train"),
        "n_test": b.metadata.get("n_test"),
        "n_feedback_rows": b.metadata.get("n_feedback_rows", 0),
        "train_distribution": b.metadata.get("train_distribution"),
        "test_distribution": b.metadata.get("test_distribution"),
        "accuracy": c.get("accuracy"),
        "precision_macro": c.get("precision_macro"),
        "recall_macro": c.get("recall_macro"),
        "f1_macro": c.get("f1_macro"),
        "f1_weighted": c.get("f1_weighted"),
        "per_class_metrics": c.get("per_class"),
        "confusion_matrix": c.get("confusion_matrix"),
        "top_confusions": c.get("top_confusions"),
        "cv": c.get("cv"),
        "samples_evaluated": c.get("samples_evaluated"),
        "intrusion_model": b.metrics.get("intrusion"),
        "anomaly_model": b.metrics.get("anomaly"),
        "feature_importances": b.global_importance,
        "caveat": b.metadata.get("caveat"),
        "synthetic": b.metadata.get("dataset_source") in ("synthetic-demo",),
        "evaluated_at": b.metadata.get("trained_at"),
    }


def run_ml_evaluation(db: Optional[Session] = None, recompute: bool = True) -> Dict[str, Any]:
    """Re-evaluate the active model on the deterministic held-out split (when the dataset is available)."""
    base = stored_ml_metrics()
    if base is None:
        return {"status": "unavailable", "reason": "No trained model is loaded. Run `python -m app.ml.training`."}
    result = dict(base)
    result["status"] = "ok"
    result["recomputed"] = False
    path = settings.DATASET_DIR
    if recompute and ml_predictor.bundle.metadata.get("dataset_source") == "cicids2017" and os.path.isdir(path):
        try:
            from app.ml.dataset import load_dataset, split_train_test
            from app.ml.training import DEFAULT_CAPS, evaluate_bundle

            df, _ = load_dataset(path, max_per_label=DEFAULT_CAPS)
            test = df[split_train_test(df)]
            fresh = evaluate_bundle(ml_predictor.bundle, test)
            c = fresh["classification"]
            result.update(
                accuracy=c["accuracy"], precision_macro=c["precision_macro"], recall_macro=c["recall_macro"], f1_macro=c["f1_macro"],
                per_class_metrics=c["per_class"], confusion_matrix=c["confusion_matrix"], samples_evaluated=c["samples_evaluated"],
                intrusion_model=fresh.get("intrusion", result.get("intrusion_model")), anomaly_model=fresh.get("anomaly", result.get("anomaly_model")),
                recomputed=True, evaluated_at=datetime.now(timezone.utc).isoformat(),
            )
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Re-evaluation fell back to stored training metrics: {e}")
            result["recompute_error"] = f"{type(e).__name__}: {str(e)[:160]}"
    if db is not None:
        run = evaluation_repo.create(
            db, "ML", result, status="completed", model_version=result["model_version"],
            dataset_version=str(result.get("dataset_source")), report_location=os.path.join(settings.MODEL_DIR, "versions", result["model_version"], "metrics.json"),
        )
        result["run_id"] = run.id
    return result
