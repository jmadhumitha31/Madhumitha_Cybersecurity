"""
Explainable analysis of network-traffic features and their relationship to attack types.

Three complementary views:
1. **Local (per flow)** - SHAP TreeExplainer attributions for the predicted class (falls back to occlusion
   against the benign median if SHAP is unavailable). Answers "why did the model call *this* flow a SYN flood?".
2. **Global (per attack type)** - mean |SHAP| per class computed at training time, and robust feature profiles
   (median / IQR) of every class versus the benign baseline. Answers "what does traffic of attack type X look like?".
3. **Human-readable indicators** - data-driven sentences (ratios against the benign baseline) plus protocol/port
   semantics that analysts can act on.
"""
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from app.domain import C2_LIKE_PORTS, PORT_SERVICES, SENSITIVE_PORTS
from app.logging_config import logger
from app.ml.preprocessing import FEATURE_COLUMNS, FEATURE_DISPLAY_NAMES


def fmt_num(v: float) -> str:
    v = float(v)
    if abs(v) >= 1e9:
        return f"{v / 1e9:.2f}G"
    if abs(v) >= 1e6:
        return f"{v / 1e6:.2f}M"
    if abs(v) >= 1e4:
        return f"{v / 1e3:.1f}k"
    if abs(v) >= 100 or float(v).is_integer():
        return f"{v:,.0f}"
    return f"{v:.2f}"


# --------------------------------------------------------------------------------------------------
# Training-time statistics
# --------------------------------------------------------------------------------------------------
def compute_baselines(benign: pd.DataFrame) -> Dict[str, Dict[str, float]]:
    out = {}
    for col in FEATURE_COLUMNS:
        s = benign[col].astype(float)
        out[col] = {
            "p05": float(s.quantile(0.05)),
            "p50": float(s.quantile(0.50)),
            "p95": float(s.quantile(0.95)),
            "mean": float(s.mean()),
        }
    return out


def compute_class_profiles(df: pd.DataFrame, classes: List[str]) -> Dict[str, Dict[str, Dict[str, float]]]:
    """Per class, per feature: robust location/spread and a separation score against the benign baseline."""
    benign = df[df["attack_type"] == "Benign"]
    ben_med = benign[FEATURE_COLUMNS].median()
    ben_iqr = benign[FEATURE_COLUMNS].quantile(0.75) - benign[FEATURE_COLUMNS].quantile(0.25)
    profiles: Dict[str, Dict[str, Dict[str, float]]] = {}
    for cls in classes:
        sub = df[df["attack_type"] == cls]
        if sub.empty:
            continue
        med = sub[FEATURE_COLUMNS].median()
        q1, q3 = sub[FEATURE_COLUMNS].quantile(0.25), sub[FEATURE_COLUMNS].quantile(0.75)
        prof = {}
        for col in FEATURE_COLUMNS:
            denom = float((q3[col] - q1[col]) + ben_iqr[col]) + 1e-9
            prof[col] = {
                "median": float(med[col]),
                "p25": float(q1[col]),
                "p75": float(q3[col]),
                "mean": float(sub[col].mean()),
                "benign_median": float(ben_med[col]),
                # robust standardised difference to benign: >0 means the attack class is higher than benign
                "separation": float((med[col] - ben_med[col]) / denom) if denom > 1e-9 else 0.0,
                "ratio_to_benign": float((med[col] + 1.0) / (ben_med[col] + 1.0)),
            }
        profiles[cls] = prof
    return profiles


def compute_global_shap(clf, x_by_class: Dict[str, np.ndarray], classes: List[str], max_per_class: int = 80) -> Dict[str, Dict[str, float]]:
    """Mean |SHAP| of each feature for the class's own output, averaged over that class's flows."""
    try:
        import shap

        expl = shap.TreeExplainer(clf)
    except Exception as e:  # pragma: no cover - shap missing
        logger.warning(f"Global SHAP unavailable: {e}")
        return {}
    result: Dict[str, Dict[str, float]] = {}
    for ci, cls in enumerate(classes):
        x = x_by_class.get(cls)
        if x is None or len(x) == 0:
            continue
        x = x[:max_per_class]
        try:
            sv = expl.shap_values(x, check_additivity=False)
            arr = sv[ci] if isinstance(sv, list) else sv[:, :, ci]
            mean_abs = np.abs(arr).mean(axis=0)
            result[cls] = {f: float(mean_abs[i]) for i, f in enumerate(FEATURE_COLUMNS)}
        except Exception as e:  # pragma: no cover
            logger.warning(f"Global SHAP failed for {cls}: {e}")
    return result


# --------------------------------------------------------------------------------------------------
# Inference-time explanation
# --------------------------------------------------------------------------------------------------
def local_explanation(bundle, x: np.ndarray, class_idx: int, top_n: int = 8) -> Dict[str, Any]:
    """Per-feature contribution to the predicted class probability for one flow."""
    classes = list(bundle.classes)
    method = "shap-tree"
    base_value = None
    try:
        expl = bundle.explainer()
        sv = expl.shap_values(x, check_additivity=False)
        vals = sv[class_idx][0] if isinstance(sv, list) else sv[0, :, class_idx]
        ev = expl.expected_value
        base_value = float(ev[class_idx]) if hasattr(ev, "__len__") else float(ev)
    except Exception as e:
        logger.warning(f"SHAP failed ({e}); using occlusion attribution")
        method = "occlusion"
        p0 = float(bundle.classifier.predict_proba(x)[0, class_idx])
        vals = np.zeros(len(FEATURE_COLUMNS))
        for i, col in enumerate(FEATURE_COLUMNS):
            x2 = x.copy()
            x2[0, i] = bundle.baselines[col]["p50"]
            vals[i] = p0 - float(bundle.classifier.predict_proba(x2)[0, class_idx])

    contribs = []
    for i, col in enumerate(FEATURE_COLUMNS):
        b = bundle.baselines[col]
        v = float(x[0, i])
        contribs.append(
            {
                "feature": col,
                "label": FEATURE_DISPLAY_NAMES[col],
                "value": v,
                "contribution": float(vals[i]),
                "benign_median": b["p50"],
                "benign_p95": b["p95"],
                "ratio_to_benign": float((v + 1.0) / (b["p50"] + 1.0)),
                "direction": "supports" if vals[i] > 0 else "opposes",
            }
        )
    contribs.sort(key=lambda c: abs(c["contribution"]), reverse=True)
    return {
        "method": method,
        "target_class": classes[class_idx],
        "base_value": base_value,
        "contributions": contribs[:top_n],
        "all_contributions_sum": float(np.sum(vals)),
    }


def flow_indicators(flow: Dict[str, Any], bundle, attack_type: str, explanation: Optional[Dict[str, Any]]) -> List[str]:
    """Analyst-readable evidence statements for one flow."""
    out: List[str] = []
    syn = float(flow.get("syn_count") or 0)
    rst = float(flow.get("rst_count") or 0)
    fwd = float(flow.get("total_fwd_packets") or 0)
    bwd = float(flow.get("total_bwd_packets") or flow.get("total_backward_packets") or 0)
    pps = float(flow.get("flow_packets_per_sec") or 0)
    dport = int(flow.get("destination_port") or 0)
    idle = float(flow.get("idle_mean") or 0)
    plen = float(flow.get("packet_length_mean") or 0)

    if explanation and attack_type != "Benign" and bundle is not None:
        for c in explanation["contributions"][:4]:
            if c["contribution"] <= 0:
                continue
            ratio = c["ratio_to_benign"]
            if ratio >= 3 or ratio <= 0.33:
                rel = f"{ratio:,.1f}x" if ratio >= 1 else f"{1 / max(ratio, 1e-9):,.1f}x lower than"
                out.append(
                    f"{c['label']} = {fmt_num(c['value'])} is {rel} the benign median ({fmt_num(c['benign_median'])}) "
                    f"and drives the {attack_type} classification"
                )
            else:
                out.append(f"{c['label']} = {fmt_num(c['value'])} contributes to the {attack_type} classification")
    if syn >= 100 and bwd <= 2:
        out.append(f"{int(syn)} SYN flags with {int(bwd)} backward packet(s): half-open connection flood pattern")
    elif syn >= 3 and bwd == 0:
        out.append("Unanswered SYN requests with no reverse handshake (probing)")
    if rst >= 5:
        out.append(f"{int(rst)} RST flags: many aborted/refused connections")
    if fwd >= 100 and bwd <= 2:
        out.append(f"Extreme asymmetry: {int(fwd)} forward vs {int(bwd)} backward packets (one-way flood)")
    if pps >= 20000:
        out.append(f"Packet rate of {fmt_num(pps)} pkts/s is characteristic of automated flooding")
    if dport in (21, 22) and fwd >= 5:
        out.append(f"Repeated session activity against administrative service {PORT_SERVICES[dport]} (port {dport})")
    elif dport == 444:
        out.append("Destination port 444 is a non-standard service port; the CIC-IDS2017 Heartbleed and Metasploit-Infiltration sessions used it")
    elif dport in C2_LIKE_PORTS and dport != 8080:
        out.append(f"Destination port {dport} is a non-standard port often associated with backdoor/command-and-control tooling")
    elif dport in SENSITIVE_PORTS:
        out.append(f"Destination port {dport} ({PORT_SERVICES.get(dport, 'service')}) exposes a sensitive service")
    if idle >= 5e6 and fwd + bwd <= 40:
        out.append("Long idle gaps between short bursts: possible beaconing behaviour")
    if plen >= 1000 and dport in (80, 443, 8080):
        out.append(f"Large mean payload ({fmt_num(plen)} B) towards a web port: possible exploit/injection transfer")
    if not out:
        if attack_type == "Benign":
            out.append("All monitored features fall within the benign baseline range")
        else:
            out.append(f"Feature pattern statistically matches the {attack_type} class profile")
    # keep order, drop duplicates, cap
    seen, uniq = set(), []
    for s in out:
        if s not in seen:
            seen.add(s)
            uniq.append(s)
    return uniq[:7]


def attack_type_profiles(bundle, top_n: int = 6) -> Dict[str, Any]:
    """Global view: for each attack family, the traffic features that characterise it."""
    result = {}
    for cls, prof in bundle.class_profiles.items():
        ranked = sorted(prof.items(), key=lambda kv: abs(kv[1]["separation"]), reverse=True)[:top_n]
        shap_rank = {}
        if cls in (bundle.global_shap or {}):
            shap_rank = dict(sorted(bundle.global_shap[cls].items(), key=lambda kv: kv[1], reverse=True)[:top_n])
        result[cls] = {
            "n_train": int(bundle.metadata.get("train_distribution", {}).get(cls, 0)),
            "top_features": [
                {
                    "feature": f,
                    "label": FEATURE_DISPLAY_NAMES[f],
                    "median": s["median"],
                    "benign_median": s["benign_median"],
                    "ratio_to_benign": s["ratio_to_benign"],
                    "separation": s["separation"],
                    "direction": "higher" if s["separation"] > 0 else "lower",
                }
                for f, s in ranked
            ],
            "shap_importance": [
                {"feature": f, "label": FEATURE_DISPLAY_NAMES[f], "mean_abs_shap": v} for f, v in shap_rank.items()
            ],
        }
    return result
