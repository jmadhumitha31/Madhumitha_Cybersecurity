import threading
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from app.config import settings
from app.domain import BENIGN, UNCLASSIFIED
from app.logging_config import logger
from app.ml.bundle import ModelBundle, load_active_bundle
from app.ml.explainability import attack_type_profiles, flow_indicators, local_explanation
from app.ml.preprocessing import FEATURE_COLUMNS, frame_to_matrix, row_to_vector
from app.ml.risk import assess_risk
from app.observability.tracing import tracer

LOW_CONFIDENCE = 0.60


class MLPredictor:
    """Serves the active model bundle (classifier + intrusion-risk model + anomaly detector + explanations)."""

    def __init__(self, model_dir: Optional[str] = None):
        self.model_dir = model_dir or settings.MODEL_DIR
        self.bundle: Optional[ModelBundle] = None
        self._lock = threading.Lock()
        self.reload()

    # ---------------------------------------------------------------- lifecycle
    def reload(self, model_dir: Optional[str] = None) -> bool:
        with self._lock:
            if model_dir:
                self.model_dir = model_dir
            try:
                self.bundle = load_active_bundle(self.model_dir)
            except Exception as e:  # corrupt artefact must not take the API down
                logger.error(f"Could not load ML bundle from {self.model_dir}: {e}")
                self.bundle = None
            if self.bundle:
                logger.info(f"ML predictor ready: model {self.bundle.version} ({self.bundle.metadata.get('dataset_source')})")
            else:
                logger.warning(f"No trained model in {self.model_dir}; classification unavailable until training runs.")
            return self.bundle is not None

    @property
    def is_loaded(self) -> bool:
        return self.bundle is not None

    def info(self) -> Dict[str, Any]:
        if not self.bundle:
            return {"loaded": False}
        md = self.bundle.metadata
        return {
            "loaded": True,
            "version": self.bundle.version,
            "dataset_source": md.get("dataset_source"),
            "trained_at": md.get("trained_at"),
            "trigger": md.get("trigger"),
            "n_train": md.get("n_train"),
            "n_test": md.get("n_test"),
            "n_feedback_rows": md.get("n_feedback_rows", 0),
            "classes": self.bundle.classes,
        }

    # ---------------------------------------------------------------- inference
    def unavailable(self) -> Dict[str, Any]:
        return {
            "status": "unavailable",
            "attack_type": UNCLASSIFIED,
            "confidence": 0.0,
            "suspicious": False,
            "intrusion_probability": None,
            "anomaly_score": None,
            "top_classes": [],
            "indicators": ["The ML classification model is not trained/loaded; run `python -m app.ml.training`"],
            "feature_importance": {},
            "explanation": None,
            "low_confidence": True,
            "model_version": None,
        }

    def predict_attack(self, flow: Dict[str, Any], explain: bool = True) -> Dict[str, Any]:
        b = self.bundle
        if b is None:
            return self.unavailable()
        try:
            with tracer.span("ml.predict", "ml", model_version=b.version, explain=explain) as top:
                x = row_to_vector(flow)
                with tracer.span("ml.classifier", "ml", model="RandomForest", n_classes=len(b.classes)) as s1:
                    proba = b.class_proba(x)[0]
                    idx = int(np.argmax(proba))
                    attack = b.classes[idx]
                    conf = float(proba[idx])
                    order = np.argsort(proba)[::-1][:4]
                    top_classes = [{"attack_type": b.classes[i], "probability": round(float(proba[i]), 4)} for i in order]
                    s1.set(attack_type=attack, confidence=round(conf, 4), top_classes=top_classes, low_confidence=conf < LOW_CONFIDENCE)
                with tracer.span("ml.intrusion_model", "ml", model="calibrated gradient boosting") as s2:
                    intrusion = float(b.intrusion_proba(x)[0])
                    s2.set(intrusion_probability=round(intrusion, 4))
                with tracer.span("ml.anomaly_detector", "ml", model="Isolation Forest (benign-only, ECDF-calibrated)") as s3:
                    anomaly = float(b.anomaly(x)[0])
                    s3.set(anomaly_score=round(anomaly, 4))

                explanation = None
                if explain:
                    with tracer.span("ml.explain", "ml") as s4:
                        explanation = local_explanation(b, x, idx)
                        if explanation:
                            s4.set(
                                method=explanation.get("method"), target_class=explanation.get("target_class"),
                                base_value=explanation.get("base_value"),
                                top_contributions=[
                                    {"feature": c["feature"], "label": c["label"], "value": c["value"], "contribution": c["contribution"],
                                     "benign_median": c["benign_median"]}
                                    for c in explanation["contributions"][:8]
                                ],
                            )
                indicators = flow_indicators(flow, b, attack, explanation)
                importance = {}
                if explanation:
                    importance = {c["feature"]: round(abs(c["contribution"]), 5) for c in explanation["contributions"][:6]}
                top.set(attack_type=attack, confidence=round(conf, 4), intrusion_probability=round(intrusion, 4),
                        anomaly_score=round(anomaly, 4), n_indicators=len(indicators))
                tracer.count("ml.predictions")
                if conf < LOW_CONFIDENCE:
                    tracer.count("ml.low_confidence")
            return {
                "status": "ok",
                "attack_type": attack,
                "confidence": round(conf, 4),
                "suspicious": bool(attack != BENIGN or intrusion >= 0.5 or anomaly >= 0.995),
                "intrusion_probability": round(intrusion, 4),
                "anomaly_score": round(anomaly, 4),
                "top_classes": top_classes,
                "indicators": indicators,
                "feature_importance": importance,
                "explanation": explanation,
                "low_confidence": bool(conf < LOW_CONFIDENCE),
                "model_version": b.version,
            }
        except Exception as e:
            logger.error(f"Prediction failed: {e}", exc_info=True)
            out = self.unavailable()
            out["status"] = "error"
            out["indicators"] = [f"Inference error: {e}"]
            return out

    def predict_batch(self, df: pd.DataFrame) -> Optional[pd.DataFrame]:
        """Vectorised scoring (no explanations) for ingestion. Returns None if no model is loaded."""
        b = self.bundle
        if b is None or df.empty:
            return None
        x = frame_to_matrix(df)
        proba = b.class_proba(x)
        idx = proba.argmax(axis=1)
        out = pd.DataFrame(
            {
                "predicted_attack_type": [b.classes[i] for i in idx],
                "prediction_confidence": proba[np.arange(len(idx)), idx],
                "intrusion_probability": b.intrusion_proba(x),
                "anomaly_score": b.anomaly(x),
            },
            index=df.index,
        )
        return out

    def profiles(self) -> Dict[str, Any]:
        if not self.bundle:
            return {}
        return attack_type_profiles(self.bundle)

    # ---------------------------------------------------------------- risk (kept for the agents)
    def predict_risk(
        self,
        flow: Dict[str, Any],
        attack_type: str,
        confidence: float,
        intrusion_probability: Optional[float] = None,
        anomaly_score: Optional[float] = None,
        neighbor_agreement: Optional[float] = None,
    ) -> Dict[str, Any]:
        return assess_risk(flow, attack_type, confidence, intrusion_probability, anomaly_score, neighbor_agreement)


ml_predictor = MLPredictor()
