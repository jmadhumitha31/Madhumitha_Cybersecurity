from typing import Any, Dict, List

import numpy as np
import pandas as pd

# The 17 model inputs: the flow features named in the project brief plus destination port and protocol.
FEATURE_COLUMNS: List[str] = [
    "flow_duration",
    "total_fwd_packets",
    "total_bwd_packets",
    "total_length_fwd",
    "total_length_bwd",
    "flow_bytes_per_sec",
    "flow_packets_per_sec",
    "flow_iat_mean",
    "packet_length_mean",
    "syn_count",
    "rst_count",
    "ack_count",
    "average_packet_size",
    "active_mean",
    "idle_mean",
    "destination_port",
    "protocol",
]

FEATURE_DISPLAY_NAMES: Dict[str, str] = {
    "flow_duration": "Flow Duration (µs)",
    "total_fwd_packets": "Total Forward Packets",
    "total_bwd_packets": "Total Backward Packets",
    "total_length_fwd": "Forward Bytes",
    "total_length_bwd": "Backward Bytes",
    "flow_bytes_per_sec": "Throughput (bytes/s)",
    "flow_packets_per_sec": "Packet Rate (pkts/s)",
    "flow_iat_mean": "Mean Inter-Arrival Time (µs)",
    "packet_length_mean": "Mean Packet Length",
    "syn_count": "SYN Flag Count",
    "rst_count": "RST Flag Count",
    "ack_count": "ACK Flag Count",
    "average_packet_size": "Average Packet Size",
    "active_mean": "Active Time Mean (µs)",
    "idle_mean": "Idle Time Mean (µs)",
    "destination_port": "Destination Port",
    "protocol": "Protocol",
}


def row_to_vector(flow: Dict[str, Any]) -> np.ndarray:
    """One flow dict -> 1xN float array (missing/invalid values become 0.0)."""
    values = []
    for col in FEATURE_COLUMNS:
        raw = flow.get(col)
        if raw is None and col == "total_bwd_packets":
            raw = flow.get("total_backward_packets")
        try:
            val = float(raw) if raw is not None else 0.0
            if not np.isfinite(val):
                val = 0.0
        except (TypeError, ValueError):
            val = 0.0
        values.append(val)
    return np.array(values, dtype=np.float64).reshape(1, -1)


def frame_to_matrix(df: pd.DataFrame) -> np.ndarray:
    """DataFrame (canonical column names) -> float matrix, with non-finite values zeroed."""
    mat = df.reindex(columns=FEATURE_COLUMNS).to_numpy(dtype=np.float64, na_value=0.0)
    mat[~np.isfinite(mat)] = 0.0
    return mat


def log_transform(mat: np.ndarray) -> np.ndarray:
    """Variance-stabilising transform for the heavy-tailed traffic features (used by the anomaly model)."""
    return np.log1p(np.clip(mat, 0.0, None))
