"""
Continuous-improvement loop: analyst-confirmed labels are folded back into the model.

1. Every "Correct/Incorrect/Partially Correct" feedback relabels the incident (label_source = analyst).
2. ``POST /ml/retrain`` trains a *candidate* model on the base dataset + all analyst-confirmed incidents
   (feedback rows only ever enter the training side of the split, weighted x5).
3. The candidate and the current model are scored on the **same** held-out test split. The candidate is promoted
   (hot-reloaded into the predictor) unless macro-F1 regresses by more than 1 point; either way the decision, the
   numbers and the new ModelVersion are recorded.
"""
import os
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict

import pandas as pd

from app.config import settings
from app.database.connection import SessionLocal
from app.database.models import Feedback, Incident, ModelVersion, utcnow
from app.database.repositories.evaluation_repo import evaluation_repo
from app.logging_config import logger
from app.ml.bundle import set_active
from app.ml.dataset import load_dataset, split_train_test
from app.ml.predictor import ml_predictor
from app.ml.preprocessing import FEATURE_COLUMNS
from app.ml.training import DEFAULT_CAPS, evaluate_bundle, train_bundle
from app.observability.tracing import tracer

MAX_REGRESSION = 0.01
_lock = threading.Lock()
_state: Dict[str, Any] = {"status": "idle"}


def status() -> Dict[str, Any]:
    return dict(_state)


def _incidents_frame(rows) -> pd.DataFrame:
    recs = []
    for i in rows:
        rec = {c: getattr(i, c) for c in FEATURE_COLUMNS}
        rec.update(flow_id=i.flow_id, source_ip=i.source_ip, source_port=i.source_port, destination_ip=i.destination_ip,
                   timestamp=i.timestamp, original_label=i.original_label or i.ground_truth_label, attack_type=i.ground_truth_label)
        recs.append(rec)
    return pd.DataFrame(recs)


def _set(**kw) -> None:
    _state.update(kw)


def _run(triggered_by: str) -> None:
    db = SessionLocal()
    t0 = time.time()
    try:
        _set(status="running", step="collecting analyst-confirmed labels", started_at=datetime.now(timezone.utc).isoformat(), triggered_by=triggered_by, result=None)
        fb_rows = db.query(Incident).filter(Incident.label_source == "analyst", Incident.ground_truth_label.isnot(None)).all()
        if not fb_rows:
            _set(status="failed", step="done", result={"decision": "skipped", "reason": "No analyst-confirmed labels exist yet. Submit feedback on incidents first."})
            return
        extra = _incidents_frame(fb_rows)

        _set(step="loading base training data")
        if os.path.isdir(settings.DATASET_DIR) and any(f.endswith((".parquet", ".csv")) for f in os.listdir(settings.DATASET_DIR)):
            base, _ = load_dataset(settings.DATASET_DIR, max_per_label=DEFAULT_CAPS)
            source = "cicids2017"
        else:
            rows = db.query(Incident).filter(Incident.label_source == "dataset").all()
            base = _incidents_frame([r for r in rows if r.ground_truth_label])
            source = (rows[0].data_source if rows else "database")
            if base.empty:
                _set(status="failed", step="done", result={"decision": "skipped", "reason": "No base dataset available for retraining."})
                return
        base = base.reset_index(drop=True)
        mask = split_train_test(base)

        _set(step=f"training candidate on {int((~mask).sum())} base + {len(extra)} analyst-confirmed flows")
        with tracer.span("ml.train_candidate", "ml", n_base=int((~mask).sum()), n_feedback=len(extra), feedback_weight=5.0, dataset_source=source) as tsp:
            cand = train_bundle(
                base, test_mask=mask, extra_train=extra, extra_weight=5.0, dataset_source=source, trigger="feedback-retrain",
                activate=False, cv_folds=0, global_shap_per_class=40, progress=lambda m: _set(step=m),
            )
            tsp.set(candidate_version=cand["version"], accuracy=cand["metrics"]["classification"]["accuracy"],
                    f1_macro=cand["metrics"]["classification"]["f1_macro"])

        _set(step="comparing candidate with the active model on the same held-out split")
        old = ml_predictor.bundle
        test_df = base[mask]
        new_f1 = cand["metrics"]["classification"]["f1_macro"]
        new_acc = cand["metrics"]["classification"]["accuracy"]
        old_eval = evaluate_bundle(old, test_df)["classification"] if old else None
        old_f1 = old_eval["f1_macro"] if old_eval else None
        promote = old_f1 is None or new_f1 >= old_f1 - MAX_REGRESSION
        with tracer.span("ml.promotion_decision", "ml", candidate_f1=new_f1, previous_f1=old_f1, max_regression=MAX_REGRESSION,
                         rule="promote unless macro-F1 drops by more than the allowed margin on the same held-out split", promote=bool(promote)):
            pass
        if promote:
            set_active(settings.MODEL_DIR, cand["version"])
            ml_predictor.reload()

        now = utcnow()
        for fb in db.query(Feedback).filter(Feedback.applied.is_(True), Feedback.used_in_training_at.is_(None)).all():
            fb.used_in_training_at = now
        db.add(ModelVersion(
            version=cand["version"], path=os.path.join("versions", cand["version"]), dataset_source=source,
            metrics=cand["metrics"]["classification"], n_train=cand["metadata"]["n_train"], n_feedback=len(extra),
            is_active=bool(promote), trigger="feedback-retrain",
        ))
        if promote and old:
            db.query(ModelVersion).filter(ModelVersion.version == old.version).update({"is_active": False})
        db.commit()

        result = {
            "decision": "promoted" if promote else "rejected",
            "candidate_version": cand["version"],
            "previous_version": old.version if old else None,
            "feedback_incidents_used": len(extra),
            "feedback_class_counts": extra["attack_type"].value_counts().to_dict(),
            "candidate": {"accuracy": round(new_acc, 4), "f1_macro": round(new_f1, 4)},
            "previous": {"accuracy": round(old_eval["accuracy"], 4), "f1_macro": round(old_f1, 4)} if old_eval else None,
            "rule": f"promote unless macro-F1 drops by more than {MAX_REGRESSION:.2f} on the same held-out split",
            "duration_s": round(time.time() - t0, 1),
        }
        evaluation_repo.create(
            db, "ML", {**result, "model_version": cand["version"], "status": "ok", "retrain": True,
                       **{k: cand["metrics"]["classification"][k] for k in ("accuracy", "f1_macro", "precision_macro", "recall_macro")}},
            status="completed", model_version=cand["version"], dataset_version=str(source),
        )
        _set(status="completed", step="done", result=result, finished_at=datetime.now(timezone.utc).isoformat())
        logger.info(f"Retrain finished: {result['decision']} {cand['version']}")
    except Exception as e:  # noqa: BLE001
        logger.error(f"Retrain failed: {e}", exc_info=True)
        _set(status="failed", step="error", result={"decision": "error", "reason": f"{type(e).__name__}: {str(e)[:300]}"})
    finally:
        db.close()
        if _lock.locked():
            _lock.release()


def _run_traced(triggered_by: str) -> None:
    """The retraining job is its own trace (the request that started it returned long ago)."""
    with tracer.trace("model.retrain.run", "Retrain job", requested_by=triggered_by) as ctx:
        if ctx is not None:
            ctx.username = triggered_by
            ctx.query_text = "retrain the models on the base dataset + analyst-confirmed labels"
        _run(triggered_by)
        res = status().get("result") or {}
        tracer.summarize(decision=res.get("decision"), candidate_version=res.get("candidate_version"), previous_version=res.get("previous_version"),
                         feedback_incidents_used=res.get("feedback_incidents_used"), candidate=res.get("candidate"), previous=res.get("previous"))
        tracer.set_output(**{k: res.get(k) for k in ("decision", "candidate_version", "reason", "duration_s")})
        if ctx is not None and res.get("decision") == "error":
            ctx.status = "error"


def start_retrain(triggered_by: str) -> Dict[str, Any]:
    if not _lock.acquire(blocking=False):
        return {"started": False, **status()}
    _set(status="running", step="queued", result=None)
    threading.Thread(target=_run_traced, args=(triggered_by,), daemon=True, name="ml-retrain").start()
    return {"started": True, **status()}
