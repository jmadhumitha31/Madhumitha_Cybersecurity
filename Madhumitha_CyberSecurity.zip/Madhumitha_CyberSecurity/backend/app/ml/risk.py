"""
Incident prioritisation: combines model outputs with traffic indicators into a transparent 0-100 risk score,
a severity level (Critical/High/Medium/Low) and a SOC priority (P1-P4).

    score = 100 * ( 0.40 * severity(class) * class_confidence      -> "how bad is this attack family, and how sure are we"
                  + 0.25 * intrusion_probability                    -> calibrated binary intrusion-risk model
                  + 0.15 * anomaly_score                            -> Isolation-Forest deviation from benign traffic
                  + 0.20 * traffic_indicators )                     -> rate/SYN/asymmetry/sensitive-port evidence

plus explicit policy floors (e.g. a confident Heartbleed/Infiltration detection is always Critical) and a
"classifier says Benign but the intrusion model disagrees" escalation for suspicious unknowns.
"""
from typing import Any, Dict, List, Optional

from app.observability.tracing import tracer
from app.domain import (
    BENIGN,
    C2_LIKE_PORTS,
    CRITICAL_FLOOR,
    LEVEL_RANK,
    PORT_SERVICES,
    PRIORITY_FOR_LEVEL,
    SENSITIVE_PORTS,
    SEVERITY_WEIGHT,
    risk_level_from_score,
)

W_SEVERITY, W_INTRUSION, W_ANOMALY, W_TRAFFIC = 0.40, 0.25, 0.15, 0.20


def traffic_indicator_score(flow: Dict[str, Any]) -> (float, List[str]):
    pps = float(flow.get("flow_packets_per_sec") or 0)
    syn = float(flow.get("syn_count") or 0)
    rst = float(flow.get("rst_count") or 0)
    fwd = float(flow.get("total_fwd_packets") or 0)
    bwd = float(flow.get("total_bwd_packets") or flow.get("total_backward_packets") or 0)
    dport = int(flow.get("destination_port") or 0)
    bps = float(flow.get("flow_bytes_per_sec") or 0)

    dur = float(flow.get("flow_duration") or 0)
    idle = float(flow.get("idle_mean") or 0)
    pkts = fwd + bwd

    score, notes = 0.0, []
    # packet rate is only a red flag away from DNS (benign DNS legitimately bursts at 10^5 pkts/s)
    if pps >= 50000 and dport != 53 and pkts > 2:
        score += 0.25
        notes.append(f"Extreme packet velocity ({pps:,.0f} pkts/s)")
    elif pps >= 5000 and dport != 53 and pkts > 2:
        score += 0.12
        notes.append(f"Elevated packet velocity ({pps:,.0f} pkts/s)")
    # reconnaissance probe: 1-2 packets lasting microseconds towards a non-DNS port
    if 0 < pkts <= 4 and dur and dur < 1000 and dport not in (53, 123):
        score += 0.20
        notes.append("Single-packet probe lasting microseconds (port-scan signature)")
    if syn >= 100 and bwd <= 2:
        score += 0.30
        notes.append(f"SYN flood pattern ({int(syn)} SYN, {int(bwd)} reply packets)")
    elif syn >= 1 and bwd == 0:
        score += 0.12
        notes.append("Unanswered SYN probe")
    if fwd >= 100 and bwd <= 2:
        score += 0.15
        notes.append("Severe forward/backward asymmetry")
    if pkts >= 1000 and dport not in (80, 443, 8080, 8443, 445):
        score += 0.18
        notes.append(f"Bulk transfer ({int(pkts):,} packets) on non-web port {dport}: possible exfiltration/memory leak")
    if idle >= 5e6:
        score += 0.10
        notes.append("Long idle gaps between bursts (slow-and-low / beaconing pattern)")
    if rst >= 5:
        score += 0.08
        notes.append(f"{int(rst)} connection resets")
    if dport in SENSITIVE_PORTS or dport in C2_LIKE_PORTS - {8080}:
        score += 0.15
        notes.append(f"Sensitive/suspicious service targeted: {PORT_SERVICES.get(dport) or 'service'} (port {dport})")
    if bps >= 5e6:
        score += 0.10
        notes.append(f"High throughput ({bps / 1e6:,.1f} MB/s)")
    return min(score, 1.0), notes


def assess_confirmed_risk(
    flow: Dict[str, Any],
    label: str,
    intrusion_probability: Optional[float] = None,
    anomaly_score: Optional[float] = None,
) -> Dict[str, Any]:
    """Risk for an incident whose class is *known* (dataset ground truth or analyst-confirmed).

    A confirmed Benign flow is always Low/P4: a human or the dataset has overridden any model suspicion.
    A confirmed attack is scored with class confidence 1.0 plus whatever model signals exist.
    """
    if label == BENIGN:
        risk = assess_risk(flow, BENIGN, 1.0, 0.0, 0.0)
        risk["risk_score"] = min(risk["risk_score"], 10.0)
        risk["factors"] = ["Confirmed Benign (dataset label or analyst verdict): model suspicion overridden"]
        return risk
    return assess_risk(flow, label, 1.0, intrusion_probability, anomaly_score)


def _assess_risk(
    flow: Dict[str, Any],
    attack_type: str,
    class_confidence: float,
    intrusion_probability: Optional[float] = None,
    anomaly_score: Optional[float] = None,
    neighbor_agreement: Optional[float] = None,
) -> Dict[str, Any]:
    """Return risk_score (0-100), risk_level, priority and the explicit factors behind them."""
    attack_type = attack_type or BENIGN
    is_attack = attack_type != BENIGN
    sev = SEVERITY_WEIGHT.get(attack_type, 0.5)
    conf = max(0.0, min(1.0, float(class_confidence or 0.0)))
    m = intrusion_probability if intrusion_probability is not None else (conf if is_attack else 0.0)
    a = anomaly_score if anomaly_score is not None else (0.5 if is_attack else 0.0)
    t, traffic_notes = traffic_indicator_score(flow)

    class_term = sev * conf if is_attack else 0.0
    raw = W_SEVERITY * class_term + W_INTRUSION * m + W_ANOMALY * a + W_TRAFFIC * t
    # retrieval corroboration: historical neighbours agreeing/disagreeing with the prediction nudges the score
    adj = 0.0
    if neighbor_agreement is not None and is_attack:
        adj = 0.06 * (neighbor_agreement - 0.5) * 2  # -0.06 .. +0.06
    score = max(0.0, min(100.0, 100.0 * (raw + adj)))
    if not is_attack:
        score = min(score, 54.0)  # a Benign classification can reach "Medium" via the intrusion model, never High

    factors: List[str] = []
    if is_attack:
        factors.append(
            f"Attack family '{attack_type}' (intrinsic severity {sev:.2f}) predicted with {conf * 100:.1f}% confidence"
        )
    else:
        factors.append(f"Classified Benign with {conf * 100:.1f}% confidence")
    if intrusion_probability is not None:
        factors.append(f"Calibrated intrusion-risk model: {intrusion_probability * 100:.1f}% probability the flow is malicious")
    if anomaly_score is not None:
        factors.append(f"Anomaly score {anomaly_score:.2f} (more atypical than {anomaly_score * 100:.1f}% of benign training flows)")
    factors.extend(traffic_notes)
    if neighbor_agreement is not None and is_attack:
        factors.append(
            f"Historical retrieval {'corroborates' if neighbor_agreement >= 0.5 else 'does not corroborate'} the prediction "
            f"({neighbor_agreement * 100:.0f}% of similar past incidents share this class)"
        )

    level = risk_level_from_score(score)
    # Policy floors
    floor = CRITICAL_FLOOR.get(attack_type)
    if floor and conf >= 0.5 and LEVEL_RANK[level] < LEVEL_RANK[floor]:
        level = floor
        score = max(score, {"Critical": 75.0, "High": 55.0}[floor])
        factors.append(f"Policy floor: confident '{attack_type}' detections are never rated below {floor}")
    if not is_attack and m >= 0.5:
        if LEVEL_RANK[level] < LEVEL_RANK["Medium"]:
            level = "Medium"
            score = max(score, 35.0)
        factors.append(
            "Classifier output is Benign but the independent intrusion model flags this flow as likely malicious: "
            "possible novel/unknown attack, analyst review recommended"
        )

    return {
        "risk_score": round(score, 1),
        "risk_level": level,
        "priority": PRIORITY_FOR_LEVEL[level],
        "confidence": round(conf, 4),
        "anomaly_score": None if anomaly_score is None else round(float(anomaly_score), 4),
        "intrusion_probability": None if intrusion_probability is None else round(float(intrusion_probability), 4),
        "factors": factors,
        "components": {
            "severity_x_confidence": round(class_term, 4),
            "intrusion_probability": round(float(m), 4),
            "anomaly": round(float(a), 4),
            "traffic_indicators": round(t, 4),
            "retrieval_adjustment": round(adj, 4),
        },
    }


def assess_risk(
    flow: Dict[str, Any],
    attack_type: str,
    class_confidence: float,
    intrusion_probability: Optional[float] = None,
    anomaly_score: Optional[float] = None,
    neighbor_agreement: Optional[float] = None,
) -> Dict[str, Any]:
    """Transparent 0-100 risk score (see module docstring). The span records inputs, weighted components and policy floors."""
    with tracer.span("risk.assess", "risk", attack_type=attack_type, class_confidence=class_confidence,
                     intrusion_probability=intrusion_probability, anomaly_score=anomaly_score, neighbor_agreement=neighbor_agreement,
                     weights={"severity_x_confidence": W_SEVERITY, "intrusion_probability": W_INTRUSION, "anomaly": W_ANOMALY,
                              "traffic_indicators": W_TRAFFIC}) as sp:
        out = _assess_risk(flow, attack_type, class_confidence, intrusion_probability, anomaly_score, neighbor_agreement)
        sp.set(
            risk_score=out["risk_score"], risk_level=out["risk_level"], priority=out["priority"], components=out["components"],
            policy_floor_applied=any(f.startswith("Policy floor") for f in out["factors"]),
            factors=out["factors"],
        )
        return out
