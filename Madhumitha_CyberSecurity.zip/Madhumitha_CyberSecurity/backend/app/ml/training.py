"""
Model training and *honest* evaluation.

Trains three models from labelled flows and evaluates each on a held-out split that is never used for fitting:

1. attack-type classifier ............ RandomForest, 9 CIC-IDS2017 families (class-balanced)
2. intrusion-risk model .............. calibrated gradient boosting, P(flow is malicious)
3. anomaly detector .................. Isolation Forest fitted on benign traffic only, calibrated to a 0-1 score

Analyst feedback can be mixed into the training portion (never the test portion) for continuous improvement.
"""
import argparse
import os
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import HistGradientBoostingClassifier, IsolationForest, RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    brier_score_loss,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.preprocessing import LabelEncoder

from app.config import settings
from app.domain import BENIGN, CLASSES
from app.logging_config import logger
from app.ml.bundle import save_bundle
from app.ml.dataset import class_distribution, load_dataset, split_train_test
from app.ml.explainability import compute_baselines, compute_class_profiles, compute_global_shap
from app.ml.preprocessing import FEATURE_COLUMNS, frame_to_matrix, log_transform

LOW_SUPPORT = 30  # test classes with fewer samples than this are flagged as statistically unreliable

# Per-raw-label caps for the training sample (keeps training to ~minutes while preserving every rare class)
DEFAULT_CAPS = {
    "BENIGN": 60000,
    "DoS Hulk": 10000,
    "DoS GoldenEye": 6000,
    "PortScan": 15000,
    "DDoS": 15000,
}


def _bundle_version(trigger: str) -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S") + f"-{trigger}"


def train_bundle(
    df: pd.DataFrame,
    test_mask: Optional[pd.Series] = None,
    extra_train: Optional[pd.DataFrame] = None,
    extra_weight: float = 5.0,
    dataset_source: str = "cicids2017",
    trigger: str = "manual",
    n_estimators: int = 150,
    max_depth: Optional[int] = 22,
    save_dir: Optional[str] = None,
    activate: bool = True,
    cv_folds: int = 3,
    global_shap_per_class: int = 60,
    random_state: int = 42,
    progress: Optional[Callable[[str], None]] = None,
    metadata_extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Train + evaluate. Returns the bundle dict (also persisted when ``save_dir`` is given)."""
    say = progress or (lambda m: logger.info(m))
    t0 = time.time()
    save_dir = save_dir or settings.MODEL_DIR

    df = df.reset_index(drop=True)
    if test_mask is None:
        test_mask = split_train_test(df)
    test_mask = test_mask.reset_index(drop=True)
    train_df, test_df = df[~test_mask], df[test_mask]
    if extra_train is not None and len(extra_train):
        w = np.concatenate([np.ones(len(train_df)), np.full(len(extra_train), extra_weight)])
        train_df = pd.concat([train_df, extra_train[train_df.columns.intersection(extra_train.columns)]], ignore_index=True)
    else:
        w = np.ones(len(train_df))

    classes_present = [c for c in CLASSES if (train_df["attack_type"] == c).any()]
    le = LabelEncoder().fit(classes_present)
    X_tr, X_te = frame_to_matrix(train_df), frame_to_matrix(test_df)
    y_tr = le.transform(train_df["attack_type"])
    test_known = test_df["attack_type"].isin(classes_present).to_numpy()
    X_te, test_df = X_te[test_known], test_df[test_known]
    y_te = le.transform(test_df["attack_type"])
    say(f"Training on {len(train_df)} flows, evaluating on {len(test_df)} held-out flows ({len(classes_present)} classes)")

    # 1. attack-type classifier -----------------------------------------------------------------
    clf = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_leaf=1,
        class_weight="balanced_subsample",
        n_jobs=-1,
        random_state=random_state,
    )
    clf.fit(X_tr, y_tr, sample_weight=w)
    y_pred = clf.predict(X_te)
    labels_idx = list(range(len(le.classes_)))
    cr = classification_report(y_te, y_pred, labels=labels_idx, target_names=list(le.classes_), output_dict=True, zero_division=0)
    cm = confusion_matrix(y_te, y_pred, labels=labels_idx)
    present = [i for i in labels_idx if (y_te == i).any()]
    per_class = {
        c: {
            "precision": float(cr[c]["precision"]),
            "recall": float(cr[c]["recall"]),
            "f1": float(cr[c]["f1-score"]),
            "support": int(cr[c]["support"]),
            "low_support": bool(cr[c]["support"] < LOW_SUPPORT),
        }
        for c in le.classes_
    }
    confusions = []
    for i, ci in enumerate(le.classes_):
        for j, cj in enumerate(le.classes_):
            if i != j and cm[i, j] > 0:
                confusions.append({"true": ci, "predicted": cj, "count": int(cm[i, j])})
    confusions.sort(key=lambda d: d["count"], reverse=True)
    classification = {
        "accuracy": float(accuracy_score(y_te, y_pred)),
        "precision_macro": float(precision_score(y_te, y_pred, labels=present, average="macro", zero_division=0)),
        "recall_macro": float(recall_score(y_te, y_pred, labels=present, average="macro", zero_division=0)),
        "f1_macro": float(f1_score(y_te, y_pred, labels=present, average="macro", zero_division=0)),
        "f1_weighted": float(f1_score(y_te, y_pred, labels=present, average="weighted", zero_division=0)),
        "per_class": per_class,
        "confusion_matrix": {"labels": list(le.classes_), "matrix": cm.tolist()},
        "top_confusions": confusions[:8],
        "samples_evaluated": int(len(y_te)),
    }
    say(f"Classifier: acc={classification['accuracy']:.4f} macro-F1={classification['f1_macro']:.4f}")

    # cross-validated stability estimate on a capped subsample of the training portion
    if cv_folds and cv_folds > 1:
        rng = np.random.default_rng(random_state)
        idx = rng.choice(len(X_tr), size=min(30000, len(X_tr)), replace=False)
        ysub = y_tr[idx]
        min_count = np.bincount(ysub).min() if len(ysub) else 0
        folds = int(min(cv_folds, max(2, min_count))) if min_count >= 2 else 0
        if folds >= 2:
            cv_clf = RandomForestClassifier(n_estimators=60, max_depth=max_depth, class_weight="balanced_subsample", n_jobs=-1, random_state=random_state)
            pred_cv = cross_val_predict(cv_clf, X_tr[idx], ysub, cv=StratifiedKFold(folds, shuffle=True, random_state=random_state))
            classification["cv"] = {
                "folds": folds,
                "subsample": int(len(idx)),
                "accuracy": float(accuracy_score(ysub, pred_cv)),
                "f1_macro": float(f1_score(ysub, pred_cv, average="macro", zero_division=0)),
            }

    # 2. intrusion-risk model (binary) ------------------------------------------------------------
    yb_tr = (train_df["attack_type"] != BENIGN).to_numpy().astype(int)
    yb_te = (test_df["attack_type"] != BENIGN).to_numpy().astype(int)
    hgb = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.1, max_depth=8, random_state=random_state)
    intrusion = CalibratedClassifierCV(hgb, method="sigmoid", cv=3)
    intrusion.fit(X_tr, yb_tr, sample_weight=w)
    p_mal = intrusion.predict_proba(X_te)[:, 1]
    intrusion_metrics: Dict[str, Any] = {"n_test": int(len(yb_te))}
    if yb_te.min() != yb_te.max():
        fpr, tpr, _ = roc_curve(yb_te, p_mal)
        intrusion_metrics.update(
            {
                "roc_auc": float(roc_auc_score(yb_te, p_mal)),
                "average_precision": float(average_precision_score(yb_te, p_mal)),
                "brier": float(brier_score_loss(yb_te, p_mal)),
                "tpr_at_1pct_fpr": float(np.interp(0.01, fpr, tpr)),
                "accuracy_at_0.5": float(accuracy_score(yb_te, p_mal >= 0.5)),
                "recall_at_0.5": float(recall_score(yb_te, p_mal >= 0.5, zero_division=0)),
                "precision_at_0.5": float(precision_score(yb_te, p_mal >= 0.5, zero_division=0)),
            }
        )
    say(f"Intrusion-risk model: {intrusion_metrics.get('roc_auc')}")

    # 3. anomaly detector (benign-only) -------------------------------------------------------------
    benign_tr = X_tr[train_df["attack_type"].to_numpy() == BENIGN]
    iso = IsolationForest(
        n_estimators=200,
        max_samples=min(10000, len(benign_tr)),
        contamination="auto",
        random_state=random_state,
        n_jobs=-1,
    ).fit(log_transform(benign_tr))
    ref_idx = np.random.default_rng(random_state).choice(len(benign_tr), size=min(20000, len(benign_tr)), replace=False)
    anomaly_ref = np.sort(-iso.score_samples(log_transform(benign_tr[ref_idx])))
    raw_te = -iso.score_samples(log_transform(X_te))
    anomaly_scores = np.searchsorted(anomaly_ref, raw_te, side="right") / float(len(anomaly_ref))
    anomaly_metrics: Dict[str, Any] = {"trained_on_benign_flows": int(len(benign_tr))}
    if yb_te.min() != yb_te.max():
        anomaly_metrics.update(
            {
                "roc_auc_attack_vs_benign": float(roc_auc_score(yb_te, anomaly_scores)),
                "median_score_benign": float(np.median(anomaly_scores[yb_te == 0])),
                "median_score_attack": float(np.median(anomaly_scores[yb_te == 1])),
                "note": "Unsupervised: fitted without any attack examples; AUC measures how well it separates unseen attacks.",
            }
        )
    say(f"Anomaly detector AUC: {anomaly_metrics.get('roc_auc_attack_vs_benign')}")

    # explainability statistics --------------------------------------------------------------------
    labelled_all = pd.concat([train_df, test_df], ignore_index=True)
    baselines = compute_baselines(train_df[train_df["attack_type"] == BENIGN])
    profiles = compute_class_profiles(train_df, list(le.classes_))
    x_by_class = {}
    for c in le.classes_:
        sel = X_te[test_df["attack_type"].to_numpy() == c]
        if len(sel) < 5:  # rare classes: fall back to training rows so every family gets an explanation
            sel = X_tr[train_df["attack_type"].to_numpy() == c]
        x_by_class[c] = sel
    global_shap = compute_global_shap(clf, x_by_class, list(le.classes_), max_per_class=global_shap_per_class) if global_shap_per_class else {}
    importance = {f: float(v) for f, v in sorted(zip(FEATURE_COLUMNS, clf.feature_importances_), key=lambda kv: kv[1], reverse=True)}

    version = _bundle_version(trigger)
    metadata = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "trigger": trigger,
        "dataset_source": dataset_source,
        "n_train": int(len(train_df)),
        "n_test": int(len(test_df)),
        "n_feedback_rows": int(len(extra_train)) if extra_train is not None else 0,
        "train_distribution": class_distribution(train_df),
        "test_distribution": class_distribution(test_df),
        "feature_columns": FEATURE_COLUMNS,
        "random_state": random_state,
        "training_seconds": round(time.time() - t0, 1),
        "caveat": (
            "Evaluated on a random held-out split of one dataset; flows from the same attack campaign share patterns, "
            "so real-world performance on unseen networks will be lower. Classes with fewer than "
            f"{LOW_SUPPORT} test flows are statistically unreliable."
        ),
    }
    metadata.update(metadata_extra or {})
    data = {
        "version": version,
        "classifier": clf,
        "label_encoder": le,
        "intrusion_model": intrusion,
        "anomaly_model": iso,
        "anomaly_ref": anomaly_ref,
        "baselines": baselines,
        "class_profiles": profiles,
        "global_shap": global_shap,
        "global_importance": importance,
        "metrics": {"classification": classification, "intrusion": intrusion_metrics, "anomaly": anomaly_metrics},
        "metadata": metadata,
    }
    if save_dir:
        save_bundle(data, save_dir, activate=activate)
        say(f"Saved model {version} to {save_dir} (active={activate}) in {metadata['training_seconds']}s")
    return data


def evaluate_bundle(bundle, test_df: pd.DataFrame) -> Dict[str, Any]:
    """Score any model bundle on a labelled held-out frame (used to compare an old and a retrained model fairly)."""
    known = test_df["attack_type"].isin(bundle.classes).to_numpy()
    test_df = test_df[known]
    X = frame_to_matrix(test_df)
    le = bundle.label_encoder
    y = le.transform(test_df["attack_type"])
    pred = bundle.classifier.predict(X)
    present = sorted(set(y.tolist()))
    labels_idx = list(range(len(le.classes_)))
    cr = classification_report(y, pred, labels=labels_idx, target_names=list(le.classes_), output_dict=True, zero_division=0)
    out = {
        "classification": {
            "accuracy": float(accuracy_score(y, pred)),
            "f1_macro": float(f1_score(y, pred, labels=present, average="macro", zero_division=0)),
            "precision_macro": float(precision_score(y, pred, labels=present, average="macro", zero_division=0)),
            "recall_macro": float(recall_score(y, pred, labels=present, average="macro", zero_division=0)),
            "per_class": {
                c: {"precision": float(cr[c]["precision"]), "recall": float(cr[c]["recall"]), "f1": float(cr[c]["f1-score"]),
                    "support": int(cr[c]["support"]), "low_support": bool(cr[c]["support"] < LOW_SUPPORT)}
                for c in le.classes_
            },
            "confusion_matrix": {"labels": list(le.classes_), "matrix": confusion_matrix(y, pred, labels=labels_idx).tolist()},
            "samples_evaluated": int(len(y)),
        }
    }
    yb = (test_df["attack_type"] != BENIGN).to_numpy().astype(int)
    if yb.min() != yb.max():
        p_mal = bundle.intrusion_proba(X)
        out["intrusion"] = {
            "roc_auc": float(roc_auc_score(yb, p_mal)),
            "average_precision": float(average_precision_score(yb, p_mal)),
            "brier": float(brier_score_loss(yb, p_mal)),
        }
        out["anomaly"] = {"roc_auc_attack_vs_benign": float(roc_auc_score(yb, bundle.anomaly(X)))}
    return out


def main() -> None:
    p = argparse.ArgumentParser(description="Train the SOC assistant models on CIC-IDS2017 flows")
    p.add_argument("--data", default=None, help="file or directory (CSV/Parquet); default: backend/data/cicids2017")
    p.add_argument("--source", default=None, help="dataset_source tag, e.g. synthetic-demo")
    p.add_argument("--trees", type=int, default=150)
    p.add_argument("--no-shap", action="store_true")
    a = p.parse_args()
    data_path = a.data or settings.DATASET_DIR
    if not os.path.exists(data_path):
        raise SystemExit(f"{data_path} not found. Run scripts/download_cicids2017.py or pass --data")
    df, report = load_dataset(data_path, max_per_label=DEFAULT_CAPS, source=a.source or "cicids2017")
    out = train_bundle(
        df,
        dataset_source=a.source or "cicids2017",
        n_estimators=a.trees,
        global_shap_per_class=0 if a.no_shap else 60,
        trigger="manual",
        metadata_extra={"load_report": report.to_dict()},
    )
    c = out["metrics"]["classification"]
    print(f"version={out['version']} accuracy={c['accuracy']:.4f} macro_f1={c['f1_macro']:.4f}")


if __name__ == "__main__":
    main()
