"""
Network helpers shared by every outbound HTTP client (NVIDIA NIM, Ollama, Hugging Face downloads, DeepEval).

Many corporate networks perform TLS inspection with a private root CA that is installed in the
operating-system trust store but is NOT in Python's bundled `certifi` list. Without this, every
HTTPS call fails with `CERTIFICATE_VERIFY_FAILED: self-signed certificate in certificate chain`
and the LLM layer silently degrades to the offline rule engine.

We never disable verification: we make Python use the OS trust store via `truststore`.
"""
import os
import ssl
from functools import lru_cache
from typing import Union

_injected = False


def enable_system_trust_store() -> bool:
    """Patch `ssl` so every library (httpx, requests, urllib3, huggingface_hub, openai) trusts the OS store."""
    global _injected
    if _injected:
        return True
    if os.getenv("LLM_USE_SYSTEM_TRUST_STORE", "true").lower() in ("0", "false", "no"):
        return False
    try:
        import truststore

        truststore.inject_into_ssl()
        _injected = True
        return True
    except Exception:  # truststore missing or unsupported platform: fall back to certifi silently
        return False


@lru_cache(maxsize=1)
def http_verify() -> Union[bool, str, ssl.SSLContext]:
    """Value for httpx's `verify=` argument.

    Precedence: explicit CA bundle (SSL_CERT_FILE / LLM_CA_BUNDLE) > OS trust store > default certifi.
    """
    bundle = os.getenv("LLM_CA_BUNDLE") or os.getenv("SSL_CERT_FILE")
    if bundle and os.path.exists(bundle):
        return bundle
    if os.getenv("LLM_USE_SYSTEM_TRUST_STORE", "true").lower() not in ("0", "false", "no"):
        try:
            import truststore

            return truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        except Exception:
            pass
    return True
