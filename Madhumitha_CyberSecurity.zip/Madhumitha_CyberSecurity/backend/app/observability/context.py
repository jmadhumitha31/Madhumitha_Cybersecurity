"""Correlation context shared by tracing, logging and the API schemas.

Kept free of imports from the rest of the application so that ``logging_config`` and ``schemas`` can use it
without creating import cycles. The context variables propagate into worker threads started by Starlette/anyio
(they copy the context), so a trace begun in the HTTP middleware is visible inside synchronous endpoints."""
import contextvars
from typing import Any, Optional

trace_var: contextvars.ContextVar[Optional[Any]] = contextvars.ContextVar("soc_trace", default=None)
span_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar("soc_span", default=None)


def current_trace_id() -> Optional[str]:
    ctx = trace_var.get()
    return ctx.trace_id if ctx is not None else None
