"""Plain-language explanations built from recorded facts - never from an LLM.

``explain_trace`` turns the spans of one trace into an ordered narrative ("what happened and why") plus the structured
evidence behind it (retrieval scores and matched terms, SHAP drivers, risk components, LLM attempts, output checks).
Because every sentence is derived from span attributes, an explanation cannot assert anything the system did not do.

``system_explanation`` describes the decision logic of the whole platform with its *live* parameters (weights,
thresholds, models), so the documentation shown to analysts cannot drift away from the running configuration.
"""
from typing import Any, Callable, Dict, List, Optional, Tuple

Span = Dict[str, Any]


# ---------------------------------------------------------------------------------------------------------
# formatting helpers
# ---------------------------------------------------------------------------------------------------------
def _pct(x: Any) -> str:
    try:
        return f"{float(x) * 100:.1f}%"
    except (TypeError, ValueError):
        return "n/a"


def _ms(x: Any) -> str:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "n/a"
    return f"{v:,.0f} ms" if v >= 100 else f"{v:.1f} ms"


def _num(x: Any, nd: int = 3) -> str:
    try:
        return f"{float(x):.{nd}f}"
    except (TypeError, ValueError):
        return "n/a"


def _a(s: Optional[Span]) -> Dict[str, Any]:
    return (s or {}).get("attributes") or {}


# ---------------------------------------------------------------------------------------------------------
# per-span narrative: (sentence, verdict) with verdict in ok | blocked | warn | info
# ---------------------------------------------------------------------------------------------------------
def _f_validation(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    if a.get("valid"):
        return "The flow passed input validation: IP addresses, ports, protocol, physical bounds and timestamp are all acceptable.", "ok"
    return f"The flow was rejected by the input guardrail: {'; '.join(a.get('errors') or [])[:300]}", "blocked"


def _f_security(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    if a.get("blocked"):
        return f"Blocked by the security guardrail: the text matched prompt-injection rule #{a.get('matched_rule')} ({a.get('rule')}).", "blocked"
    return f"The text passed the prompt-injection screen ({a.get('n_rules')} rules checked, none matched).", "ok"


def _f_relevance(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    terms = ", ".join(a.get("strong_terms") or [])
    if a.get("relevant"):
        return f"Judged on-topic ({a.get('reason')}{': ' + terms if terms else ''}).", "ok"
    return f"Refused as outside the SOC domain: {a.get('reason')}.", "blocked"


def _f_embed(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    return f"Embedded {a.get('n_texts')} text(s) with {a.get('model')} ({a.get('dimension')}-d, {a.get('backend')}) in {_ms(s['duration_ms'])}.", "info"


def _f_filters(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    f = a.get("filters") or {}
    scope = ", ".join(f"{k}={v}" for k, v in f.items()) or "none"
    return f"Metadata filters ({scope}) left {a.get('n_candidates')} eligible incident(s); {a.get('n_filtered_out')} were excluded.", "info"


def _f_dense(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    tie = ""
    if a.get("docs_tied_with_best", 0) and a["docs_tied_with_best"] > 1:
        tie = f" {a['docs_tied_with_best']} incidents tie at the top similarity (identical behaviour descriptions)."
    ext = " The pool was extended to include every incident tied at its boundary." if a.get("tie_inclusive_expansion") else ""
    return (f"Dense search in Qdrant ({a.get('store_mode')}): examined a pool of {a.get('pool')} and returned {a.get('returned')}; "
            f"best cosine similarity {_num(a.get('best_similarity'))}.{tie}{ext}"), "info"


def _f_bm25(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    if a.get("skipped"):
        return "Keyword (BM25) scoring was not used for this search mode.", "info"
    unknown = f" Terms not in the index: {', '.join(a['unknown_terms'])}." if a.get("unknown_terms") else ""
    return f"BM25 keyword scoring over {a.get('n_query_terms')} query term(s); {a.get('n_docs_matching')} incident(s) contain at least one.{unknown}", "info"


def _f_score(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    widen = f" The candidate pool was widened {a['widenings']} time(s) until the ranking was provably exact." if a.get("widenings") else ""
    exact = "The top results are exact (no unseen incident can outscore them)." if a.get("exact_top_k") else ""
    return (f"Blended the channels (alpha={a.get('alpha')}): scored {a.get('candidates_scored', 'all')} candidate(s) out of "
            f"{a.get('n_candidates_after_filters')}.{widen} {exact}").strip(), "info"


def _f_search(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    if a.get("empty"):
        return (f"No incident cleared the similarity threshold of {a.get('threshold')}: the system answers "
                "'No sufficiently similar historical incidents were found' instead of guessing."), "warn"
    top = (a.get("top_results") or [{}])[0]
    terms = ", ".join(t["term"] for t in (top.get("matched_terms") or [])[:4])
    return (f"{a.get('n_results')} incident(s) cleared the threshold of {a.get('threshold')}. Best: #{top.get('incident_id')} "
            f"({top.get('attack_type')}) with score {_num(top.get('score'))} = dense {_num(top.get('dense'))} + BM25 {_num(top.get('bm25'))}"
            f"{'; matched terms: ' + terms if terms else ''}."), "ok"


def _f_classifier(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    runners = ", ".join(f"{c['attack_type']} {_pct(c['probability'])}" for c in (a.get("top_classes") or [])[1:3])
    low = " Confidence is below the review threshold, so this is a hypothesis rather than a verdict." if a.get("low_confidence") else ""
    return (f"Random-forest classifier: {a.get('attack_type')} with {_pct(a.get('confidence'))} confidence"
            f"{' (next: ' + runners + ')' if runners else ''}.{low}"), "warn" if a.get("low_confidence") else "ok"


def _f_intrusion(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    return f"Independent intrusion-risk model: {_pct(a.get('intrusion_probability'))} probability that the flow is malicious.", "info"


def _f_anomaly(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    return (f"Anomaly detector (trained on benign traffic only): score {_num(a.get('anomaly_score'))}, i.e. more atypical than "
            f"{_pct(a.get('anomaly_score'))} of benign training flows."), "info"


def _f_shap(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    drivers = a.get("top_contributions") or []
    txt = "; ".join(f"{d['label']} ({'+' if d['contribution'] >= 0 else ''}{d['contribution']:.3f})" for d in drivers[:3])
    return f"{'SHAP' if a.get('method') == 'shap-tree' else 'Occlusion'} attribution for '{a.get('target_class')}': strongest drivers are {txt}.", "info"


def _f_risk(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    c = a.get("components") or {}
    w = a.get("weights") or {}
    parts = ", ".join(f"{k.replace('_', ' ')} {_num(c.get(k), 2)} x {w.get(k)}" for k in w if k in c)
    floor = " A policy floor raised the level." if a.get("policy_floor_applied") else ""
    return f"Risk score {a.get('risk_score')}/100 -> {a.get('risk_level')} ({a.get('priority')}): {parts}.{floor}", "ok"


def _f_llm(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    attempts = a.get("attempts") or []
    failed = [x for x in attempts if not x.get("ok")]
    tail = f" {len(failed)} earlier attempt(s) failed ({'; '.join((str(x.get('error') or x.get('status')))[:50] for x in failed[:2])})." if failed else ""
    if a.get("fallback_used"):
        return (f"No LLM was reachable: answered by {a.get('provider')} ({a.get('model')}), a deterministic rule engine.{tail}"), "warn"
    usage = a.get("usage") or {}
    tok = f", {usage.get('prompt_tokens')} prompt / {usage.get('completion_tokens')} completion tokens" if usage else ""
    return f"LLM answer from {a.get('provider')}/{a.get('model')} in {_ms(a.get('latency_ms') or s['duration_ms'])}{tok}.{tail}", "ok"


def _f_post(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    bits = []
    if a.get("used_playbook"):
        bits.append("no steps could be parsed from the LLM text, so the class playbook was used")
    if a.get("n_rewritten_unsafe"):
        bits.append(f"{a['n_rewritten_unsafe']} step(s) containing unattended destructive phrasing were rewritten as analyst-approved proposals")
    return f"Output guardrail: {a.get('n_recommendations')} recommendation(s); " + ("; ".join(bits) if bits else "none needed rewriting") + ".", "warn" if bits else "ok"


def _f_checks(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    if a.get("skipped"):
        return "Output checks were skipped because the input was invalid.", "info"
    failed = a.get("failed") or []
    return (f"{a.get('n_passed')}/{a.get('n_checks')} output checks passed" + (f"; failed: {', '.join(failed)}." if failed else "."),
            "warn" if failed else "ok")


def _f_node(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    return f"Workflow node '{a.get('node')}': {a.get('details') or a.get('reason') or a.get('outcome') or 'done'}.", "info"


def _f_chat_retrieve(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    if a.get("failed"):
        return f"Retrieval for the copilot failed ({a.get('error')}); the answer continues without evidence.", "warn"
    return f"Copilot retrieval ({a.get('mode')}): {a.get('n_citations', 0)} cited incident(s) at threshold {a.get('threshold')}.", "ok" if a.get("n_citations") else "info"


def _f_find(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    return (f"The message refers to incident #{a.get('incident_id')}, which was loaded as context." if a.get("found")
            else "No specific incident was referenced; answering from general knowledge and retrieval."), "info"


def _f_chat_post(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    return ("Unsafe action phrasing in the reply was rewritten to analyst-supervised wording." if a.get("rewritten_unsafe_phrasing")
            else "The reply needed no guardrail rewriting."), "warn" if a.get("rewritten_unsafe_phrasing") else "ok"


def _f_relabel(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    b, af = a.get("before") or {}, a.get("after") or {}
    return (f"Analyst verdict '{a.get('feedback_type')}': label {b.get('attack_type')} -> {af.get('attack_type')} (source {b.get('label_source')} -> "
            f"{af.get('label_source')}), risk {b.get('risk_level')} -> {af.get('risk_level')}. The incident is now confirmed evidence for retrieval and retraining."), "ok"


def _f_sync(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    sy = a.get("sync") or {}
    return (f"Vector index synchronised with the database: {sy.get('upserted', 0)} point(s) written, {sy.get('deleted', 0)} removed, "
            f"{sy.get('unchanged', 0)} unchanged ({a.get('documents')} documents)."), "info"


def _f_upsert(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    return f"Embedded and stored {a.get('n_incidents')} incident(s) for retrieval ({a.get('embedding_model')}).", "info"


def _f_triage(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    return f"Automatic triage: {a.get('attack_type')} ({a.get('label_source')}), risk {a.get('risk_level')} / {a.get('priority')}.", "ok"


def _f_benchmark(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    h = a.get("hybrid") or {}
    return f"Retrieval benchmark over {a.get('queries')} leave-one-out queries: hybrid P@1 {h.get('precision_at_1')}, P@5 {h.get('precision_at_5')}, MRR {h.get('mrr')}.", "ok"


def _f_promotion(a: Dict[str, Any], s: Span) -> Tuple[str, str]:
    return (f"Promotion rule ({a.get('rule')}): candidate macro-F1 {_num(a.get('candidate_f1'), 4)} vs current {_num(a.get('previous_f1'), 4)} -> "
            f"{'promoted' if a.get('promote') else 'rejected'}."), "ok" if a.get("promote") else "warn"


_FORMATTERS: Dict[str, Callable[[Dict[str, Any], Span], Tuple[str, str]]] = {
    "guardrail.input_validation": _f_validation,
    "guardrail.security_screen": _f_security,
    "guardrail.relevance": _f_relevance,
    "embedding.embed": _f_embed,
    "retrieval.sql_filters": _f_filters,
    "retrieval.dense_qdrant": _f_dense,
    "retrieval.bm25": _f_bm25,
    "retrieval.score": _f_score,
    "retrieval.search": _f_search,
    "ml.classifier": _f_classifier,
    "ml.intrusion_model": _f_intrusion,
    "ml.anomaly_detector": _f_anomaly,
    "ml.explain": _f_shap,
    "risk.assess": _f_risk,
    "llm.generate": _f_llm,
    "response.postprocess": _f_post,
    "chat.retrieve": _f_chat_retrieve,
    "chat.find_incident": _f_find,
    "chat.postprocess": _f_chat_post,
    "feedback.relabel": _f_relabel,
    "index.sync": _f_sync,
    "index.upsert_embeddings": _f_upsert,
    "incident.triage": _f_triage,
    "evaluation.retrieval.benchmark": _f_benchmark,
    "ml.promotion_decision": _f_promotion,
}


def _node_step(s: Span) -> Optional[Tuple[str, str]]:
    a = _a(s)
    if s["name"] == "agent.final_validation":
        return _f_checks(a, s)
    return _f_node(a, s)


# ---------------------------------------------------------------------------------------------------------
# headline per kind
# ---------------------------------------------------------------------------------------------------------
def _headline(trace: Dict[str, Any], spans: List[Span]) -> str:
    kind, summ, q = trace["kind"], trace.get("summary") or {}, (trace.get("query_text") or "").strip()
    q = q if len(q) <= 90 else q[:89] + "…"
    sec = next((s for s in spans if s["name"] == "guardrail.security_screen" and _a(s).get("blocked")), None)
    rel = next((s for s in spans if s["name"] == "guardrail.relevance" and not _a(s).get("relevant", True)), None)
    val = next((s for s in spans if s["name"] == "guardrail.input_validation" and not _a(s).get("valid", True)), None)
    if sec:
        return f"“{q}” was blocked by the security guardrail before any retrieval or model call."
    if rel:
        return f"“{q}” was refused as outside the SOC domain; nothing was retrieved or generated."
    if val:
        return "The flow was rejected by input validation; no model was run."
    if kind == "search":
        n = summ.get("n_results")
        if summ.get("empty"):
            return f"Search “{q}” found no incident above the similarity threshold."
        return f"Search “{q}” returned {n} incident(s) ({summ.get('search_type', 'hybrid')} ranking)."
    if kind.startswith("chat"):
        if summ.get("route") and str(summ["route"]).startswith("canned"):
            return f"Copilot message “{q}” was answered with a canned reply (no model call)."
        n = summ.get("n_citations", 0)
        fb = " via the offline rule engine" if summ.get("fallback_used") else f" by {summ.get('llm_provider')}/{summ.get('model')}"
        return f"Copilot answered “{q}”{fb} with {n} cited incident(s)."
    if kind == "incident.analyze":
        return (f"Investigation of incident #{trace.get('incident_id')}: {summ.get('attack_type')} ({_pct(summ.get('confidence'))}), "
                f"{summ.get('risk_level')} risk, {summ.get('n_matches', 0)} similar past incident(s), written by {summ.get('llm_provider')}/{summ.get('model')}; "
                f"{summ.get('checks_passed')}/{summ.get('n_checks')} output checks passed.")
    if kind == "classify":
        return f"Classified the submitted flow as {summ.get('attack_type')} ({_pct(summ.get('confidence'))}), risk {summ.get('risk_level')} ({summ.get('risk_score')}/100)."
    if kind == "incident.explain":
        return f"SHAP explanation for incident #{trace.get('incident_id')}: {summ.get('attack_type')} ({_pct(summ.get('confidence'))})."
    if kind == "incident.create":
        return f"Created incident #{trace.get('incident_id')} and triaged it as {summ.get('attack_type')} ({summ.get('risk_level')} risk)."
    if kind == "feedback":
        return f"Analyst feedback '{summ.get('feedback_type')}' on incident #{trace.get('incident_id')} (label {summ.get('predicted')} -> {summ.get('actual')}, applied={summ.get('applied')})."
    if kind.startswith("model.retrain"):
        return f"Retraining job: decision {summ.get('decision') or 'requested'}."
    if kind.startswith("evaluation"):
        return f"{kind.replace('.', ' ')} finished with status {summ.get('status') or trace['status']}."
    if kind == "system.startup":
        return "Startup warm-up: embedding model loaded and the vector index synchronised."
    return f"{kind} completed in {_ms(trace.get('duration_ms'))} ({trace['status']})."


# ---------------------------------------------------------------------------------------------------------
# public: explain one trace
# ---------------------------------------------------------------------------------------------------------
def explain_trace(trace: Dict[str, Any]) -> Dict[str, Any]:
    spans: List[Span] = sorted(trace.get("spans") or [], key=lambda s: s["start_offset_ms"])
    steps: List[Dict[str, Any]] = []
    for s in spans:
        res: Optional[Tuple[str, str]] = None
        if s["name"].startswith("agent.") and s["name"] != "agent.final_validation":
            res = None  # the specific spans below already narrate each stage; node spans stay in the waterfall
        elif s["name"] == "agent.final_validation":
            res = _node_step(s)
        else:
            fmt = _FORMATTERS.get(s["name"])
            if fmt:
                res = fmt(_a(s), s)
        if res:
            detail, verdict = res
            if s.get("status") == "error":
                verdict, detail = "warn", f"{detail} (the step raised an error: {s.get('error')})"
            steps.append({"order": len(steps) + 1, "title": s["name"], "component": s["component"], "verdict": verdict, "detail": detail,
                          "span_id": s["span_id"], "duration_ms": s["duration_ms"]})

    def last(name: str) -> Optional[Span]:
        found = [s for s in spans if s["name"] == name]
        return found[-1] if found else None

    # ---- structured evidence for the UI
    evidence: Dict[str, Any] = {}
    rs, sc = last("retrieval.search"), last("retrieval.score")
    if rs:
        a = _a(rs)
        evidence["retrieval"] = {
            "query": a.get("query"), "mode": a.get("mode"), "alpha": a.get("alpha"), "threshold": a.get("threshold"), "filters": a.get("filters"),
            "n_indexed": a.get("n_indexed"), "n_candidates": a.get("n_candidates"), "n_results": a.get("n_results"), "empty": a.get("empty"),
            "results": a.get("top_results") or [], "stats": _a(sc),
            "formula": f"score = {a.get('alpha')} x dense (Qdrant cosine) + {round(1 - float(a.get('alpha') or 0), 2)} x BM25 (normalised)" if a.get("mode") == "hybrid" else f"{a.get('mode')} ranking",
        }
    pr = last("ml.predict")
    if pr:
        cl, ex = _a(last("ml.classifier")), _a(last("ml.explain"))
        evidence["model"] = {
            "attack_type": _a(pr).get("attack_type"), "confidence": _a(pr).get("confidence"), "model_version": _a(pr).get("model_version"),
            "top_classes": cl.get("top_classes") or [], "low_confidence": cl.get("low_confidence"),
            "intrusion_probability": _a(pr).get("intrusion_probability"), "anomaly_score": _a(pr).get("anomaly_score"),
            "explanation_method": ex.get("method"), "target_class": ex.get("target_class"), "contributions": ex.get("top_contributions") or [],
        }
    rk = last("risk.assess")
    if rk:
        a = _a(rk)
        evidence["risk"] = {"risk_score": a.get("risk_score"), "risk_level": a.get("risk_level"), "priority": a.get("priority"),
                            "components": a.get("components") or {}, "weights": a.get("weights") or {}, "factors": a.get("factors") or [],
                            "policy_floor_applied": a.get("policy_floor_applied")}
    llms = [s for s in spans if s["name"] == "llm.generate"]
    if llms:
        evidence["llm"] = [{
            "span_id": s["span_id"], "mode": _a(s).get("mode"), "provider": _a(s).get("provider"), "model": _a(s).get("model"),
            "fallback_used": _a(s).get("fallback_used"), "latency_ms": _a(s).get("latency_ms") or s["duration_ms"], "usage": _a(s).get("usage"),
            "finish_reason": _a(s).get("finish_reason"), "attempts": _a(s).get("attempts") or [], "chain": _a(s).get("chain") or [],
            "prompt_chars": _a(s).get("prompt_chars"), "prompt_sha256": _a(s).get("prompt_sha256"), "temperature": _a(s).get("temperature"),
            "prompt_preview": _a(s).get("prompt_preview"), "system_preview": _a(s).get("system_preview"), "response_preview": _a(s).get("response_preview"),
            "status": s["status"], "error": s.get("error"),
        } for s in llms]
    fv = last("agent.final_validation")
    if fv and _a(fv).get("checks"):
        evidence["checks"] = _a(fv)["checks"]
    guards = [{"name": s["name"], "verdict": next((st["verdict"] for st in steps if st["span_id"] == s["span_id"]), "info"),
               "detail": next((st["detail"] for st in steps if st["span_id"] == s["span_id"]), "")} for s in spans if s["component"] == "guardrail"]
    if guards:
        evidence["guardrails"] = guards

    # ---- where did the time go
    by_component: Dict[str, float] = {}
    for s in spans:
        by_component[s["component"]] = by_component.get(s["component"], 0.0) + float(s.get("self_ms") or 0.0)
    slowest = sorted(spans, key=lambda s: s.get("self_ms") or 0.0, reverse=True)[:5]
    return {
        "headline": _headline(trace, spans),
        "steps": steps,
        "evidence": evidence,
        "time_breakdown": {
            "total_ms": trace.get("duration_ms"), "db_ms": trace.get("db_time_ms"), "db_queries": trace.get("db_queries"),
            "by_component": {k: round(v, 2) for k, v in sorted(by_component.items(), key=lambda kv: kv[1], reverse=True)},
            "slowest": [{"name": s["name"], "component": s["component"], "self_ms": s.get("self_ms"), "duration_ms": s["duration_ms"]} for s in slowest],
        },
    }


# ---------------------------------------------------------------------------------------------------------
# public: how the whole system decides (live parameters)
# ---------------------------------------------------------------------------------------------------------
def system_explanation(db=None) -> Dict[str, Any]:
    from app.config import settings
    from app.domain import CRITICAL_FLOOR, PRIORITY_FOR_LEVEL, SEVERITY_WEIGHT
    from app.guardrails.input_validation import NUMERIC_LIMITS
    from app.guardrails.security import PROMPT_INJECTION_PATTERNS, UNSAFE_ACTION_PATTERNS
    from app.ml.predictor import LOW_CONFIDENCE, ml_predictor
    from app.ml.retrain import MAX_REGRESSION
    from app.ml.risk import W_ANOMALY, W_INTRUSION, W_SEVERITY, W_TRAFFIC
    from app.rag.bm25 import BM25Index
    from app.rag.embeddings import embedding_service
    from app.rag.index import hybrid_index

    ml = ml_predictor.info()
    emb = embedding_service.info()
    n_traces = None
    if db is not None:
        from app.database.models import Trace

        n_traces = db.query(Trace).count()
    bm = BM25Index()
    return {
        "pipeline": [
            {"id": "guardrails_in", "title": "1. Input guardrails", "component": "guardrail",
             "what": "Every analyst query and flow is screened before anything runs.",
             "how": f"Flows: addresses, ports, protocol, {len(NUMERIC_LIMITS)} physical bounds and the timestamp. Text: {len(PROMPT_INJECTION_PATTERNS)} "
                    "prompt-injection signatures, then a relevance check that keeps the assistant on cybersecurity investigation.",
             "parameters": {"injection_rules": len(PROMPT_INJECTION_PATTERNS), "numeric_bounds": len(NUMERIC_LIMITS)},
             "spans": ["guardrail.input_validation", "guardrail.security_screen", "guardrail.relevance"]},
            {"id": "classification", "title": "2. Classification and anomaly detection", "component": "ml",
             "what": "Three independent models look at the same 15 flow features.",
             "how": "A random forest names the attack family; a calibrated gradient-boosting model gives P(malicious); an Isolation Forest trained on benign "
                    "traffic only scores how atypical the flow is. SHAP explains which features pushed the classifier.",
             "parameters": {"model_version": ml.get("version"), "classes": ml.get("classes"), "low_confidence_below": LOW_CONFIDENCE,
                            "trained_on": ml.get("n_train"), "dataset": ml.get("dataset_source")},
             "spans": ["ml.classifier", "ml.intrusion_model", "ml.anomaly_detector", "ml.explain"]},
            {"id": "retrieval", "title": "3. Evidence retrieval (RAG)", "component": "retrieval",
             "what": "Similar *confirmed* historical incidents are retrieved; the query never contains the label being predicted.",
             "how": f"Dense similarity in Qdrant ({hybrid_index.store.mode}) blended with BM25: score = {settings.HYBRID_ALPHA} x dense + "
                    f"{round(1 - settings.HYBRID_ALPHA, 2)} x BM25. The top-k is exact (tie-inclusive candidate pools plus a threshold bound). Metadata filters run in SQL.",
             "parameters": {"alpha": settings.HYBRID_ALPHA, "incident_threshold": settings.SIMILARITY_THRESHOLD, "free_text_threshold": settings.TEXT_SEARCH_THRESHOLD,
                            "embedding_model": emb.get("model"), "dimension": emb.get("dimension"), "bm25": {"k1": bm.k1, "b": bm.b},
                            "candidate_pool": settings.QDRANT_CANDIDATES, "store": hybrid_index.store.info()},
             "spans": ["retrieval.search", "retrieval.sql_filters", "retrieval.dense_qdrant", "retrieval.bm25", "retrieval.score"]},
            {"id": "risk", "title": "4. Risk and priority", "component": "risk",
             "what": "A transparent 0-100 score decides the triage order.",
             "how": "score = 100 x (w1 x severity x confidence + w2 x intrusion probability + w3 x anomaly + w4 x traffic indicators) plus a small retrieval "
                    "agreement adjustment, then policy floors (e.g. a confident Heartbleed is never below Critical).",
             "parameters": {"weights": {"severity_x_confidence": W_SEVERITY, "intrusion_probability": W_INTRUSION, "anomaly": W_ANOMALY, "traffic_indicators": W_TRAFFIC},
                            "levels": {"Critical": ">= 75", "High": ">= 55", "Medium": ">= 35", "Low": "< 35"}, "priorities": PRIORITY_FOR_LEVEL,
                            "class_severity": SEVERITY_WEIGHT, "policy_floors": CRITICAL_FLOOR},
             "spans": ["risk.assess"]},
            {"id": "llm", "title": "5. Analysis and recommendations (LLM)", "component": "llm",
             "what": "An LLM writes the analyst-facing assessment from the evidence above; it never decides the classification or risk.",
             "how": "NVIDIA NIM is tried first (model list walk on retired/unavailable models), then local Ollama, then deterministic attack-specific playbooks, "
                    "which are always labelled as such. Judges use a separate model and never fall back to canned text.",
             "parameters": {"nvidia_models": settings.nvidia_models, "ollama_model": settings.OLLAMA_MODEL, "judge_models": settings.judge_models,
                            "max_tokens": settings.LLM_MAX_TOKENS},
             "spans": ["llm.generate"]},
            {"id": "guardrails_out", "title": "6. Output guardrails", "component": "guardrail",
             "what": "What the LLM wrote is checked before an analyst sees it.",
             "how": f"{len(UNSAFE_ACTION_PATTERNS)} unattended-destructive-action patterns are rewritten into analyst-approved proposals; six output checks verify "
                    "non-empty analysis, mention of the predicted class, safe recommendations, risk-field consistency and that every cited incident was actually retrieved.",
             "parameters": {"unsafe_action_rules": len(UNSAFE_ACTION_PATTERNS), "checks": ["analysis_non_empty", "mentions_predicted_class", "recommendations_safe",
                                                                                              "recommendations_present", "risk_fields_consistent", "no_uncited_incidents"],
                            "human_in_the_loop": "always required for containment"},
             "spans": ["response.postprocess", "agent.final_validation"]},
            {"id": "feedback", "title": "7. Feedback and learning", "component": "ml",
             "what": "Analyst verdicts become confirmed evidence and training data.",
             "how": "A judged verdict relabels the incident (label source = analyst) and re-indexes it. A retraining candidate is promoted only if macro-F1 on the "
                    "same held-out split drops by no more than the allowed margin.",
             "parameters": {"max_macro_f1_regression": MAX_REGRESSION, "feedback_weight": 5.0}, "spans": ["feedback.relabel", "ml.promotion_decision"]},
        ],
        "observability": {
            "tracing_enabled": settings.TRACING_ENABLED, "trace_all_requests": settings.TRACE_ALL_REQUESTS, "retention_days": settings.TRACE_RETENTION_DAYS,
            "store_payloads": settings.TRACE_STORE_PAYLOADS, "max_spans_per_trace": settings.TRACE_MAX_SPANS, "traces_stored": n_traces,
            "traced_operations": ["search", "chat", "classify", "incident.create", "incident.analyze", "incident.explain", "feedback", "model.retrain",
                                  "evaluation.*", "index.reindex"],
            "note": "Every traced query records who asked, the query, each component's decision with its parameters, timings and the outcome.",
        },
        "data": {"classes": ml.get("classes"), "dataset_source": ml.get("dataset_source"), "model_version": ml.get("version")},
    }
