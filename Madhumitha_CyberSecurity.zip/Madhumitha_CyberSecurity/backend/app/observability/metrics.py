"""Aggregations over the stored traces: volume, outcomes, latency, where time goes, LLM / retrieval / guardrail health.

Everything is computed from the ``traces`` table (plus SQL aggregates over ``trace_spans``) so the numbers on the
Observability page are the same facts an auditor can open trace by trace. Per-trace counters
(``summary.counters``, see ``Tracer.count``) mean no span payload ever has to be loaded to build a metric.
"""
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import numpy as np
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database.models import Trace, TraceSpan

WINDOWS: Dict[str, Dict[str, timedelta]] = {
    "1h": {"span": timedelta(hours=1), "bucket": timedelta(minutes=5)},
    "6h": {"span": timedelta(hours=6), "bucket": timedelta(minutes=15)},
    "24h": {"span": timedelta(hours=24), "bucket": timedelta(hours=1)},
    "7d": {"span": timedelta(days=7), "bucket": timedelta(hours=6)},
    "30d": {"span": timedelta(days=30), "bucket": timedelta(days=1)},
}
INTERACTIVE = {"search", "chat", "chat.incident", "classify", "incident.create", "incident.analyze", "incident.explain", "feedback"}
STATUSES = ("ok", "degraded", "rejected", "error")


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _pcts(values: List[float]) -> Dict[str, Optional[float]]:
    if not values:
        return {"p50": None, "p95": None, "p99": None, "max": None, "avg": None}
    a = np.asarray(values, dtype=float)
    return {"p50": round(float(np.percentile(a, 50)), 1), "p95": round(float(np.percentile(a, 95)), 1),
            "p99": round(float(np.percentile(a, 99)), 1), "max": round(float(a.max()), 1), "avg": round(float(a.mean()), 1)}


def _rate(num: float, den: float) -> Optional[float]:
    return round(num / den, 4) if den else None


def compute_metrics(db: Session, window: str = "24h") -> Dict[str, Any]:
    cfg = WINDOWS.get(window) or WINDOWS["24h"]
    window = window if window in WINDOWS else "24h"
    now = _utcnow()
    since = now - cfg["span"]
    rows = (
        db.query(Trace.id, Trace.trace_id, Trace.kind, Trace.status, Trace.started_at, Trace.duration_ms, Trace.db_time_ms, Trace.db_queries,
                 Trace.username, Trace.query_text, Trace.error, Trace.summary)
        .filter(Trace.started_at >= since)
        .all()
    )
    queries = [r for r in rows if not r.kind.startswith("system.")]
    interactive = [r for r in queries if r.kind in INTERACTIVE]

    by_status = Counter(r.status for r in queries)
    total = len(queries)

    # ---- per kind
    per_kind: Dict[str, Dict[str, Any]] = {}
    grouped: Dict[str, List[Any]] = defaultdict(list)
    for r in queries:
        grouped[r.kind].append(r)
    for kind, items in sorted(grouped.items(), key=lambda kv: len(kv[1]), reverse=True):
        st = Counter(i.status for i in items)
        per_kind[kind] = {"count": len(items), **{s: st.get(s, 0) for s in STATUSES}, **_pcts([i.duration_ms or 0.0 for i in items]),
                          "avg_db_ms": round(float(np.mean([i.db_time_ms or 0.0 for i in items])), 1),
                          "avg_db_queries": round(float(np.mean([i.db_queries or 0 for i in items])), 1)}

    # ---- time series
    bucket = cfg["bucket"]
    n_buckets = int(cfg["span"] / bucket)
    epoch = datetime(1970, 1, 1)
    size = bucket.total_seconds()
    start = epoch + timedelta(seconds=(since - epoch).total_seconds() // size * size)   # align to bucket boundaries (clean axis labels)
    series: List[Dict[str, Any]] = []
    index: Dict[int, Dict[str, Any]] = {}
    for i in range(n_buckets + 1):
        t = start + i * bucket
        row = {"t": t.isoformat(), "total": 0, **{s: 0 for s in STATUSES}, "avg_ms": None, "_sum": 0.0}
        series.append(row)
        index[i] = row
    for r in queries:
        i = min(max(int((r.started_at - start) / bucket), 0), n_buckets)
        b = index[i]
        b["total"] += 1
        b[r.status if r.status in STATUSES else "ok"] += 1
        b["_sum"] += r.duration_ms or 0.0
    for b in series:
        b["avg_ms"] = round(b["_sum"] / b["total"], 1) if b["total"] else None
        del b["_sum"]

    # ---- counters recorded inside traces
    counters: Dict[str, float] = defaultdict(float)
    for r in queries:
        for k, v in ((r.summary or {}).get("counters") or {}).items():
            counters[k] += float(v)
    llm_models: Dict[str, Dict[str, Any]] = {}
    for k, v in counters.items():
        if k.startswith("llm.calls."):
            model = k[len("llm.calls."):]
            lat = counters.get(f"llm.latency_ms.{model}", 0.0)
            llm_models[model] = {"calls": int(v), "avg_latency_ms": round(lat / v, 1) if v else None}
    searches = counters.get("retrieval.searches", 0.0)
    llm_calls = counters.get("llm.calls", 0.0)

    # ---- span aggregates (SQL): where the time goes
    in_window = db.query(TraceSpan).join(Trace, Trace.id == TraceSpan.trace_pk).filter(Trace.started_at >= since, ~Trace.kind.like("system.%"))
    comp_rows = (
        db.query(TraceSpan.component, func.sum(TraceSpan.self_ms), func.count(TraceSpan.id))
        .join(Trace, Trace.id == TraceSpan.trace_pk)
        .filter(Trace.started_at >= since, ~Trace.kind.like("system.%"))
        .group_by(TraceSpan.component)
        .all()
    )
    by_component = {c: {"self_ms": round(float(s or 0.0), 1), "spans": int(n)} for c, s, n in sorted(comp_rows, key=lambda x: x[1] or 0.0, reverse=True)}
    name_rows = (
        db.query(TraceSpan.name, TraceSpan.component, func.count(TraceSpan.id), func.avg(TraceSpan.duration_ms), func.max(TraceSpan.duration_ms),
                 func.sum(TraceSpan.self_ms))
        .join(Trace, Trace.id == TraceSpan.trace_pk)
        .filter(Trace.started_at >= since, ~Trace.kind.like("system.%"))
        .group_by(TraceSpan.name, TraceSpan.component)
        .all()
    )
    err_rows = dict(
        db.query(TraceSpan.name, func.count(TraceSpan.id))
        .join(Trace, Trace.id == TraceSpan.trace_pk)
        .filter(Trace.started_at >= since, TraceSpan.status != "ok", ~Trace.kind.like("system.%"))
        .group_by(TraceSpan.name)
        .all()
    )
    top_spans = sorted(
        ({"name": n, "component": c, "count": int(cnt), "avg_ms": round(float(avg or 0), 1), "max_ms": round(float(mx or 0), 1),
          "self_ms_total": round(float(selfm or 0), 1), "errors": int(err_rows.get(n, 0))} for n, c, cnt, avg, mx, selfm in name_rows),
        key=lambda d: d["self_ms_total"], reverse=True,
    )[:12]
    llm_lat = [float(d[0] or 0.0) for d in in_window.filter(TraceSpan.name == "llm.generate").with_entities(TraceSpan.duration_ms).all()]

    slowest = sorted(interactive, key=lambda r: r.duration_ms or 0.0, reverse=True)[:5]
    problems = [r for r in sorted(queries, key=lambda r: r.started_at, reverse=True) if r.status in ("error", "degraded")][:6]
    users = Counter(r.username or "system" for r in queries).most_common(8)

    return {
        "window": window, "since": since.isoformat(), "until": now.isoformat(),
        "totals": {
            "traces": total, "by_status": {s: by_status.get(s, 0) for s in STATUSES},
            "error_rate": _rate(by_status.get("error", 0), total), "degraded_rate": _rate(by_status.get("degraded", 0), total),
            "rejected_rate": _rate(by_status.get("rejected", 0), total),
            "interactive_latency_ms": _pcts([r.duration_ms or 0.0 for r in interactive]),
            "avg_db_ms": round(float(np.mean([r.db_time_ms or 0.0 for r in interactive])), 1) if interactive else None,
            "avg_db_queries": round(float(np.mean([r.db_queries or 0 for r in interactive])), 1) if interactive else None,
        },
        "per_kind": per_kind,
        "timeseries": series,
        "llm": {
            "calls": int(llm_calls), "fallbacks": int(counters.get("llm.fallbacks", 0)), "fallback_rate": _rate(counters.get("llm.fallbacks", 0), llm_calls),
            "failed_attempts": int(counters.get("llm.failed_attempts", 0)), "prompt_tokens": int(counters.get("llm.prompt_tokens", 0)),
            "completion_tokens": int(counters.get("llm.completion_tokens", 0)), "latency_ms": _pcts(llm_lat), "models": llm_models,
        },
        "retrieval": {
            "searches": int(searches), "empty": int(counters.get("retrieval.empty", 0)), "empty_rate": _rate(counters.get("retrieval.empty", 0), searches),
            "pool_widenings": int(counters.get("retrieval.widenings", 0)),
            "avg_candidates_scored": round(counters.get("retrieval.candidates_scored", 0) / searches, 1) if searches else None,
            "avg_dense_ties_at_top": round(counters.get("retrieval.dense_top_ties", 0) / searches, 1) if searches else None,
        },
        "guardrails": {
            "blocked_security": int(counters.get("guardrail.blocked.security", 0)), "blocked_relevance": int(counters.get("guardrail.blocked.relevance", 0)),
            "validation_failed": int(counters.get("guardrail.validation_failed", 0)),
            "output_checks": int(counters.get("output_checks.total", 0)), "output_checks_failed": int(counters.get("output_checks.failed", 0)),
            "output_check_pass_rate": _rate(counters.get("output_checks.total", 0) - counters.get("output_checks.failed", 0), counters.get("output_checks.total", 0)),
        },
        "ml": {"predictions": int(counters.get("ml.predictions", 0)), "low_confidence": int(counters.get("ml.low_confidence", 0)),
               "low_confidence_rate": _rate(counters.get("ml.low_confidence", 0), counters.get("ml.predictions", 0))},
        "time_by_component": by_component,
        "top_spans": top_spans,
        "slowest_traces": [{"trace_id": r.trace_id, "kind": r.kind, "duration_ms": r.duration_ms, "query": (r.query_text or "")[:100], "status": r.status} for r in slowest],
        "recent_problems": [{"trace_id": r.trace_id, "kind": r.kind, "status": r.status, "started_at": r.started_at.isoformat(), "query": (r.query_text or "")[:100],
                             "error": (r.error or "")[:160]} for r in problems],
        "top_users": [{"username": u, "traces": n} for u, n in users],
    }


def to_prometheus(m: Dict[str, Any]) -> str:
    """Prometheus text exposition of the headline numbers (scrape with a bearer token)."""
    out: List[str] = []

    def metric(name: str, help_: str, kind: str, samples: List[str]) -> None:
        out.append(f"# HELP {name} {help_}")
        out.append(f"# TYPE {name} {kind}")
        out.extend(samples)

    w = m["window"]
    metric("soc_traces", f"Analyst queries traced in the last {w}, by kind and outcome", "gauge",
           [f'soc_traces{{kind="{k}",status="{s}"}} {v[s]}' for k, v in m["per_kind"].items() for s in STATUSES])
    lat = m["totals"]["interactive_latency_ms"]
    metric("soc_interactive_latency_ms", "Latency of interactive queries", "gauge",
           [f'soc_interactive_latency_ms{{quantile="{q}"}} {lat[p]}' for q, p in (("0.5", "p50"), ("0.95", "p95"), ("0.99", "p99")) if lat[p] is not None])
    metric("soc_llm_calls", "LLM calls", "gauge", [f"soc_llm_calls {m['llm']['calls']}"])
    metric("soc_llm_fallbacks", "LLM calls answered by the offline rule engine", "gauge", [f"soc_llm_fallbacks {m['llm']['fallbacks']}"])
    metric("soc_retrieval_empty_rate", "Share of searches with no result above the threshold", "gauge",
           [f"soc_retrieval_empty_rate {m['retrieval']['empty_rate'] if m['retrieval']['empty_rate'] is not None else 0}"])
    metric("soc_guardrail_blocked", "Queries blocked by a guardrail", "gauge",
           [f'soc_guardrail_blocked{{guardrail="security"}} {m["guardrails"]["blocked_security"]}',
            f'soc_guardrail_blocked{{guardrail="relevance"}} {m["guardrails"]["blocked_relevance"]}',
            f'soc_guardrail_blocked{{guardrail="input_validation"}} {m["guardrails"]["validation_failed"]}'])
    metric("soc_time_ms_by_component", "Self time by component", "gauge",
           [f'soc_time_ms_by_component{{component="{c}"}} {v["self_ms"]}' for c, v in m["time_by_component"].items()])
    return "\n".join(out) + "\n"
