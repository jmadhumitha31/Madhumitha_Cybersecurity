"""Tracing: a persisted, structured record of every analyst query.

Usage
-----
* The HTTP middleware (``app.main``) opens a trace for each analyst operation (see ``route_kind``); background jobs open
  one with ``tracer.trace(...)``.
* Components describe what they did with ``with tracer.span("retrieval.search", "retrieval", mode=...) as sp: ...``
  and ``sp.set(n_results=5)``. Outside a trace the span is a no-op, so instrumented code costs nothing in scripts/tests.
* When the trace ends it is written to ``traces`` / ``trace_spans`` (one transaction). A failure to write a trace is
  logged and never affects the request.

Everything stored is passed through ``clean``: secrets are scrubbed, strings are clipped, collections are capped and
numpy / datetime values become plain JSON, so a trace can neither leak a credential nor grow without bound.
"""
import math
import re
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterator, List, Optional

from app.config import settings
from app.logging_config import logger, scrub_secrets
from app.observability.context import current_trace_id, span_var, trace_var

# Keys whose *value* is a credential. "token" must be the whole word (access_token, api_token, token): usage counters such as
# prompt_tokens / completion_tokens / max_tokens are numbers, not secrets, and must stay visible.
_SECRET_KEY = re.compile(r"(api[_-]?key|authorization|passw|secret|bearer|credential|(^|[_-])token$|private[_-]?key|session[_-]?id|cookie)", re.I)
_MAX_ITEMS = 50
_MAX_KEYS = 60


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def clip(text: str, n: int) -> str:
    return text if len(text) <= n else text[: n - 1] + "…"


def clean(value: Any, depth: int = 0) -> Any:
    """JSON-safe, secret-free, size-bounded copy of ``value``."""
    if value is None or isinstance(value, (bool, int)):
        return value
    if isinstance(value, float):
        return None if (math.isnan(value) or math.isinf(value)) else round(value, 6)
    if isinstance(value, str):
        return clip(scrub_secrets(value), settings.TRACE_MAX_ATTR_CHARS)
    if isinstance(value, (bytes, bytearray)):
        return f"<{len(value)} bytes>"
    if isinstance(value, datetime):
        return value.isoformat()
    if depth >= 5:
        return clip(str(value), 200)
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for i, (k, v) in enumerate(value.items()):
            if i >= _MAX_KEYS:
                out["…"] = f"+{len(value) - _MAX_KEYS} more keys"
                break
            key = str(k)[:80]
            out[key] = "[REDACTED]" if _SECRET_KEY.search(key) else clean(v, depth + 1)
        return out
    if isinstance(value, (list, tuple, set, frozenset)):
        items = list(value)
        out_list = [clean(x, depth + 1) for x in items[:_MAX_ITEMS]]
        if len(items) > _MAX_ITEMS:
            out_list.append(f"…+{len(items) - _MAX_ITEMS} more")
        return out_list
    if hasattr(value, "tolist"):  # numpy scalars / arrays
        try:
            return clean(value.tolist(), depth + 1)
        except Exception:  # noqa: BLE001
            pass
    if hasattr(value, "model_dump"):  # pydantic
        try:
            return clean(value.model_dump(), depth + 1)
        except Exception:  # noqa: BLE001
            pass
    return clip(str(value), 200)


def payload(text: Optional[str]) -> Optional[str]:
    """Prompt/response preview for audit: clipped and scrubbed, or None when payload storage is switched off."""
    if text is None or not settings.TRACE_STORE_PAYLOADS:
        return None
    return clip(scrub_secrets(str(text)), settings.TRACE_PAYLOAD_CHARS)


# ---------------------------------------------------------------------------------------------------------
class Span:
    __slots__ = ("span_id", "parent_id", "name", "component", "start_offset_ms", "duration_ms", "status", "attributes", "error", "_t0")

    def __init__(self, name: str, component: str, parent_id: Optional[str], start_offset_ms: float):
        self.span_id = uuid.uuid4().hex[:16]
        self.parent_id = parent_id
        self.name = name
        self.component = component
        self.start_offset_ms = start_offset_ms
        self.duration_ms = 0.0
        self.status = "ok"
        self.attributes: Dict[str, Any] = {}
        self.error: Optional[str] = None
        self._t0 = time.perf_counter()

    def set(self, **attrs: Any) -> "Span":
        for k, v in attrs.items():
            self.attributes[k] = clean(v)
        return self

    def fail(self, exc: BaseException) -> None:
        code = getattr(exc, "status_code", None)
        self.status = "rejected" if isinstance(code, int) and 400 <= code < 500 else "error"
        self.error = clip(scrub_secrets(f"{type(exc).__name__}: {exc}"), 500)


class _NullSpan:
    """Returned when no trace is active: accepts everything, records nothing."""

    attributes: Dict[str, Any] = {}
    span_id = None

    def set(self, **_: Any) -> "_NullSpan":
        return self

    def fail(self, _exc: BaseException) -> None:
        return None


_NULL = _NullSpan()


class TraceContext:
    def __init__(self, kind: str, name: str, request_id: Optional[str] = None):
        self.trace_id = uuid.uuid4().hex
        self.kind, self.name, self.request_id = kind, name, request_id
        self.t0 = time.perf_counter()
        self.started_at = _utcnow()
        self.spans: List[Span] = []
        self.dropped_spans = 0
        self.lock = threading.Lock()
        self.user_id: Optional[int] = None
        self.username: Optional[str] = None
        self.role: Optional[str] = None
        self.incident_id: Optional[int] = None
        self.query_text: Optional[str] = None
        self.input: Dict[str, Any] = {}
        self.output: Dict[str, Any] = {}
        self.summary: Dict[str, Any] = {}
        self.status = "ok"
        self.http_status: Optional[int] = None
        self.error: Optional[str] = None
        self.db_time_ms = 0.0
        self.db_queries = 0
        self.counters: Dict[str, float] = {}
        self._token = None

    # -- spans
    def open_span(self, name: str, component: str, parent_id: Optional[str]) -> Optional[Span]:
        sp = Span(name, component, parent_id, (time.perf_counter() - self.t0) * 1000)
        with self.lock:
            if len(self.spans) >= settings.TRACE_MAX_SPANS:
                self.dropped_spans += 1
                return None
            self.spans.append(sp)
        return sp

    def add_db(self, seconds: float) -> None:
        with self.lock:
            self.db_time_ms += seconds * 1000
            self.db_queries += 1


class Tracer:
    # ------------------------------------------------------------------ lifecycle
    @staticmethod
    def enabled() -> bool:
        return bool(settings.TRACING_ENABLED)

    def begin(self, kind: str, name: str, request_id: Optional[str] = None) -> Optional[TraceContext]:
        if not self.enabled():
            return None
        ctx = TraceContext(kind, name, request_id)
        ctx._token = trace_var.set(ctx)
        return ctx

    def end(self, ctx: Optional[TraceContext], http_status: Optional[int] = None, error: Optional[BaseException] = None) -> Optional[str]:
        """Finish and persist the trace; returns its id. Never raises."""
        if ctx is None:
            return None
        try:
            if ctx._token is not None:
                try:
                    trace_var.reset(ctx._token)
                except ValueError:  # ended from a different context than it began in
                    trace_var.set(None)
                ctx._token = None
            ctx.http_status = http_status
            if error is not None:
                ctx.error = clip(scrub_secrets(f"{type(error).__name__}: {error}"), 800)
                code = getattr(error, "status_code", None)
                ctx.status = "rejected" if isinstance(code, int) and 400 <= code < 500 else "error"
            elif http_status is not None and http_status >= 500:
                ctx.status = "error"
            elif http_status is not None and http_status >= 400:
                ctx.status = "rejected"
            elif ctx.status == "ok" and any(s.status == "error" or s.attributes.get("degraded") for s in ctx.spans):
                ctx.status = "degraded"  # answered, but a component failed or fell back (e.g. LLM -> offline playbooks)
            self._persist(ctx)
            self._maybe_prune()
        except Exception as e:  # noqa: BLE001 - observability must never break the request
            logger.warning(f"Could not persist trace {ctx.trace_id}: {type(e).__name__}: {e}")
        return ctx.trace_id

    @contextmanager
    def trace(self, kind: str, name: Optional[str] = None, user: Optional[Any] = None, **input_data: Any) -> Iterator[Optional[TraceContext]]:
        """Root trace for non-HTTP work (background jobs). Inside an active trace it degrades to a child span."""
        if trace_var.get() is not None:
            with self.span(name or kind, "app", **input_data):
                yield trace_var.get()
            return
        ctx = self.begin(kind, name or kind)
        if ctx is None:
            yield None
            return
        if user is not None:
            self.set_user(user)
        ctx.input.update(clean(input_data))
        err: Optional[BaseException] = None
        try:
            yield ctx
        except BaseException as e:  # noqa: BLE001
            err = e
            raise
        finally:
            self.end(ctx, error=err)

    @contextmanager
    def span(self, name: str, component: str = "app", **attrs: Any) -> Iterator[Any]:
        ctx = trace_var.get()
        if ctx is None:
            yield _NULL
            return
        sp = ctx.open_span(name, component, span_var.get())
        if sp is None:
            yield _NULL
            return
        sp.set(**attrs)
        token = span_var.set(sp.span_id)
        try:
            yield sp
        except BaseException as e:  # noqa: BLE001
            sp.fail(e)
            raise
        finally:
            sp.duration_ms = (time.perf_counter() - sp._t0) * 1000
            span_var.reset(token)

    @contextmanager
    def suppress(self) -> Iterator[None]:
        """Temporarily stop recording (e.g. a benchmark that would issue hundreds of identical queries); the caller
        records one summary span around it instead."""
        token = trace_var.set(None)
        try:
            yield
        finally:
            trace_var.reset(token)

    # ------------------------------------------------------------------ annotation helpers
    @staticmethod
    def current() -> Optional[TraceContext]:
        return trace_var.get()

    @staticmethod
    def current_span() -> Any:
        ctx = trace_var.get()
        sid = span_var.get()
        if ctx is None or sid is None:
            return _NULL
        for sp in reversed(ctx.spans):
            if sp.span_id == sid:
                return sp
        return _NULL

    @staticmethod
    def current_trace_id() -> Optional[str]:
        return current_trace_id()

    @staticmethod
    def set_user(user: Any) -> None:
        ctx = trace_var.get()
        if ctx is not None and user is not None:
            ctx.user_id = getattr(user, "id", None)
            ctx.username = getattr(user, "username", None)
            ctx.role = getattr(user, "role", None)

    @staticmethod
    def set_query(text: Optional[str]) -> None:
        ctx = trace_var.get()
        if ctx is not None and text:
            ctx.query_text = clean(str(text))

    @staticmethod
    def set_incident(incident_id: Optional[int]) -> None:
        ctx = trace_var.get()
        if ctx is not None and incident_id is not None:
            ctx.incident_id = int(incident_id)

    @staticmethod
    def set_input(**kw: Any) -> None:
        ctx = trace_var.get()
        if ctx is not None:
            ctx.input.update(clean(kw))

    @staticmethod
    def set_output(**kw: Any) -> None:
        ctx = trace_var.get()
        if ctx is not None:
            ctx.output.update(clean(kw))

    @staticmethod
    def summarize(**kw: Any) -> None:
        ctx = trace_var.get()
        if ctx is not None:
            ctx.summary.update(clean(kw))

    @staticmethod
    def count(name: str, value: float = 1.0) -> None:
        """Add to a per-trace counter (persisted in ``summary.counters``; the metrics endpoint aggregates these cheaply)."""
        ctx = trace_var.get()
        if ctx is not None:
            with ctx.lock:
                ctx.counters[name] = round(ctx.counters.get(name, 0.0) + float(value), 4)

    # ------------------------------------------------------------------ persistence
    @staticmethod
    def _persist(ctx: TraceContext) -> None:
        from app.database.connection import SessionLocal
        from app.database.models import Trace, TraceSpan

        total_ms = (time.perf_counter() - ctx.t0) * 1000
        spans = sorted(ctx.spans, key=lambda s: s.start_offset_ms)
        child_ms: Dict[str, float] = {}
        for s in spans:
            if s.parent_id:
                child_ms[s.parent_id] = child_ms.get(s.parent_id, 0.0) + s.duration_ms
        summary = {**ctx.summary, **({"counters": dict(ctx.counters)} if ctx.counters else {})}
        row = Trace(
            trace_id=ctx.trace_id, kind=ctx.kind, name=ctx.name, status=ctx.status, http_status=ctx.http_status,
            user_id=ctx.user_id, username=ctx.username, role=ctx.role, request_id=ctx.request_id, incident_id=ctx.incident_id,
            query_text=ctx.query_text, input_data=ctx.input or None, output_data=ctx.output or None, summary=summary or None,
            error=ctx.error, started_at=ctx.started_at, duration_ms=round(total_ms, 2), db_time_ms=round(ctx.db_time_ms, 2),
            db_queries=ctx.db_queries, n_spans=len(spans), dropped_spans=ctx.dropped_spans,
        )
        row.spans = [
            TraceSpan(
                span_id=s.span_id, parent_id=s.parent_id, name=s.name, component=s.component, status=s.status,
                start_offset_ms=round(s.start_offset_ms, 2), duration_ms=round(s.duration_ms, 2),
                self_ms=round(max(s.duration_ms - child_ms.get(s.span_id, 0.0), 0.0), 2), attributes=s.attributes or None, error=s.error,
            )
            for s in spans
        ]
        db = SessionLocal()
        try:
            db.add(row)
            db.commit()
        finally:
            db.close()

    # ------------------------------------------------------------------ retention
    _last_prune = 0.0

    def _maybe_prune(self) -> None:
        if time.time() - Tracer._last_prune < 3600:
            return
        Tracer._last_prune = time.time()
        threading.Thread(target=self.prune, kwargs={"older_than_days": settings.TRACE_RETENTION_DAYS}, daemon=True, name="trace-prune").start()

    @staticmethod
    def prune(older_than_days: Optional[int] = None) -> int:
        """Delete traces (and their spans) older than the retention window. Returns the number of traces removed."""
        from app.database.connection import SessionLocal
        from app.database.models import Trace, TraceSpan

        days = settings.TRACE_RETENTION_DAYS if older_than_days is None else int(older_than_days)
        cutoff = _utcnow() - timedelta(days=days)
        db = SessionLocal()
        try:
            old = [r[0] for r in db.query(Trace.id).filter(Trace.started_at < cutoff).all()]
            for i in range(0, len(old), 500):
                chunk = old[i : i + 500]
                db.query(TraceSpan).filter(TraceSpan.trace_pk.in_(chunk)).delete(synchronize_session=False)
                db.query(Trace).filter(Trace.id.in_(chunk)).delete(synchronize_session=False)
            db.commit()
            if old:
                logger.info(f"Pruned {len(old)} trace(s) older than {days} day(s)")
            return len(old)
        except Exception as e:  # noqa: BLE001
            db.rollback()
            logger.warning(f"Trace pruning failed: {e}")
            return 0
        finally:
            db.close()


tracer = Tracer()


# ---------------------------------------------------------------------------------------------------------
# Which HTTP requests are analyst queries/operations worth a trace
# ---------------------------------------------------------------------------------------------------------
_ROUTES = [
    ("POST", re.compile(r"^/search$"), "search"),
    ("POST", re.compile(r"^/search/reindex$"), "index.reindex"),
    ("POST", re.compile(r"^/chat/message$"), "chat"),
    ("POST", re.compile(r"^/chat/incident/\d+$"), "chat.incident"),
    ("POST", re.compile(r"^/incidents$"), "incident.create"),
    ("POST", re.compile(r"^/incidents/classify$"), "classify"),
    ("POST", re.compile(r"^/incidents/\d+/analyze$"), "incident.analyze"),
    ("GET", re.compile(r"^/incidents/\d+/explain$"), "incident.explain"),
    ("POST", re.compile(r"^/incidents/\d+/feedback$"), "feedback"),
    ("POST", re.compile(r"^/ml/retrain$"), "model.retrain"),
    ("POST", re.compile(r"^/evaluation/(ml|retrieval|deepeval|judge|judge/batch)$"), "evaluation"),
]
_UNTRACED_PREFIXES = ("/observability", "/health", "/auth", "/audit")


def route_kind(method: str, path: str) -> Optional[str]:
    """Trace kind for an API request, or None when the request is not traced. ``path`` excludes the API prefix."""
    for m, pattern, kind in _ROUTES:
        if method == m and pattern.match(path):
            if kind == "evaluation":
                return "evaluation." + pattern.match(path).group(1).replace("/", ".")
            return kind
    if settings.TRACE_ALL_REQUESTS and not path.startswith(_UNTRACED_PREFIXES):
        return "request"
    return None


def instrument_engine(engine) -> None:
    """Count database queries and time per trace (cheap: two perf_counter calls per statement)."""
    from sqlalchemy import event

    if getattr(engine, "_soc_instrumented", False):
        return

    @event.listens_for(engine, "before_cursor_execute")
    def _before(conn, cursor, statement, parameters, context, executemany):  # noqa: ANN001
        conn.info.setdefault("_soc_q", []).append(time.perf_counter())

    @event.listens_for(engine, "after_cursor_execute")
    def _after(conn, cursor, statement, parameters, context, executemany):  # noqa: ANN001
        stack = conn.info.get("_soc_q")
        if not stack:
            return
        elapsed = time.perf_counter() - stack.pop()
        ctx = trace_var.get()
        if ctx is not None:
            ctx.add_db(elapsed)

    engine._soc_instrumented = True
