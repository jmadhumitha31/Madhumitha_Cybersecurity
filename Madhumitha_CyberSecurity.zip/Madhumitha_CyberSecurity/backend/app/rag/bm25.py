"""Okapi BM25 with corpus statistics (IDF, average document length) over the incident texts."""
import math
import re
from collections import Counter
from typing import Dict, List, Tuple

import numpy as np

_TOKEN = re.compile(r"[a-z0-9]+(?:[._:/-][a-z0-9]+)*")
STOPWORDS = frozenset(
    "a an and are as at be by for from has have in is it of on or that the this to was were with into than then "
    "which who what when where how any all can show find me our us we i you your their there been being".split()
)


def _stem(t: str) -> str:
    if t.isdigit() or "." in t or len(t) <= 4:
        return t
    for suf in ("ing", "ed", "es", "s"):
        if t.endswith(suf) and len(t) - len(suf) >= 4:
            return t[: -len(suf)]
    return t


def tokenize(text: str) -> List[str]:
    if not text:
        return []
    return [_stem(t) for t in _TOKEN.findall(text.lower()) if t not in STOPWORDS]


class BM25Index:
    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self.n_docs = 0
        self.avgdl = 1.0
        self.doc_len = np.zeros(0, dtype=np.float32)
        self.postings: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
        self.idf: Dict[str, float] = {}

    def build(self, docs: List[List[str]]) -> "BM25Index":
        self.n_docs = len(docs)
        self.doc_len = np.array([len(d) for d in docs], dtype=np.float32)
        self.avgdl = float(self.doc_len.mean()) if self.n_docs else 1.0
        post: Dict[str, Tuple[List[int], List[int]]] = {}
        for i, toks in enumerate(docs):
            for t, tf in Counter(toks).items():
                ids, tfs = post.setdefault(t, ([], []))
                ids.append(i)
                tfs.append(tf)
        self.postings = {t: (np.array(ids, dtype=np.int32), np.array(tfs, dtype=np.float32)) for t, (ids, tfs) in post.items()}
        n = max(self.n_docs, 1)
        self.idf = {t: math.log(1.0 + (n - len(ids) + 0.5) / (len(ids) + 0.5)) for t, (ids, _) in self.postings.items()}
        return self

    def _idf(self, term: str) -> float:
        # unseen terms are treated as maximally rare (df = 0)
        return self.idf.get(term, math.log(1.0 + (max(self.n_docs, 1) + 0.5) / 0.5))

    def scores(self, query_tokens: List[str]) -> np.ndarray:
        out = np.zeros(self.n_docs, dtype=np.float32)
        norm = self.k1 * (1.0 - self.b + self.b * self.doc_len / self.avgdl)
        for term, qtf in Counter(query_tokens).items():
            p = self.postings.get(term)
            if p is None:
                continue
            ids, tfs = p
            out[ids] += self._idf(term) * (tfs * (self.k1 + 1.0)) / (tfs + norm[ids])
        return out

    def self_score(self, query_tokens: List[str]) -> float:
        """Score of the query against a document identical to itself: the normaliser that makes scores comparable."""
        if not query_tokens:
            return 0.0
        total = 0.0
        ln = len(query_tokens)
        denom_norm = self.k1 * (1.0 - self.b + self.b * ln / self.avgdl)
        for term, tf in Counter(query_tokens).items():
            total += self._idf(term) * (tf * (self.k1 + 1.0)) / (tf + denom_norm)
        return total

    def explain(self, query_tokens: List[str], row: int, top: int = 6) -> List[Dict[str, float]]:
        """Which query terms put document ``row`` where it is: per-term share of its normalised BM25 score.

        Mirrors ``scores`` (one contribution per distinct query term), divided by the same self-match normaliser as
        ``normalized_scores``, so the contributions add up to that document's keyword score (before clipping)."""
        ref = self.self_score(query_tokens)
        if ref <= 0 or not (0 <= row < self.n_docs):
            return []
        norm = self.k1 * (1.0 - self.b + self.b * float(self.doc_len[row]) / self.avgdl)
        out = []
        for term in dict.fromkeys(query_tokens):
            p = self.postings.get(term)
            if p is None:
                continue
            ids, tfs = p
            pos = int(np.searchsorted(ids, row))
            if pos < len(ids) and int(ids[pos]) == row:
                tf = float(tfs[pos])
                c = self._idf(term) * (tf * (self.k1 + 1.0)) / (tf + norm)
                out.append({"term": term, "tf": int(tf), "idf": round(self._idf(term), 3), "contribution": round(c / ref, 4)})
        out.sort(key=lambda d: d["contribution"], reverse=True)
        return out[:top]

    def normalized_scores(self, query_tokens: List[str]) -> np.ndarray:
        s = self.scores(query_tokens)
        ref = self.self_score(query_tokens)
        return np.clip(s / ref, 0.0, 1.0) if ref > 0 else s
