"""
Dense text embeddings.

Primary backend: ``fastembed`` running the ONNX build of ``sentence-transformers/all-MiniLM-L6-v2`` (384-d) -
a real sentence-embedding model, so "credential guessing against a remote shell" lands next to SSH brute-force
incidents even with no shared words.

If the model cannot be loaded (offline first run, missing package) the service degrades to a clearly-labelled
hashing fallback. The active backend is exposed via ``info()`` / the health endpoint and stored per row
(``IncidentEmbedding.embedding_model``) so vectors from different backends are never mixed.
"""
import hashlib
import re
import threading
from typing import Any, Dict, List, Optional

import numpy as np

from app.config import settings
from app.logging_config import logger
from app.net import enable_system_trust_store
from app.observability.tracing import tracer

HASH_DIM = 384
_TOKEN = re.compile(r"[a-z0-9]+")


def _normalise_model_name(name: str) -> str:
    return name if "/" in name else f"sentence-transformers/{name}"


class EmbeddingService:
    def __init__(self):
        self.requested_backend = settings.EMBEDDING_BACKEND.lower()
        self.model_name = _normalise_model_name(settings.EMBEDDING_MODEL)
        self._model = None
        self._lock = threading.Lock()
        self.active_backend: Optional[str] = None  # "fastembed" | "hashing-fallback"
        self.dimension: int = 384
        self.error: Optional[str] = None
        self._loaded = False

    # ------------------------------------------------------------------ loading
    def _load(self) -> None:
        with self._lock:
            if self._loaded:
                return
            if self.requested_backend == "fastembed":
                try:
                    enable_system_trust_store()
                    from fastembed import TextEmbedding

                    self._model = TextEmbedding(self.model_name, cache_dir=settings.EMBEDDING_CACHE_DIR)
                    probe = list(self._model.embed(["dimension probe"]))[0]
                    self.dimension = int(len(probe))
                    self.active_backend = "fastembed"
                    logger.info(f"Embedding model loaded: {self.model_name} ({self.dimension}-d)")
                except Exception as e:
                    self.error = f"{type(e).__name__}: {e}"
                    logger.error(f"fastembed unavailable ({self.error}); using hashing fallback")
            if self.active_backend is None:
                self.active_backend = "hashing-fallback"
                self.dimension = HASH_DIM
            self._loaded = True

    def warm_up(self) -> None:
        self._load()
        self.embed_texts(["warm up"])

    @property
    def identifier(self) -> str:
        """Stored with every vector; only vectors with the same identifier are ever compared."""
        from app.rag.text import TEXT_VERSION

        self._load()
        if self.active_backend == "fastembed":
            return f"fastembed:{self.model_name}|{TEXT_VERSION}"
        return f"hashing-fallback:v2|{TEXT_VERSION}"

    def info(self) -> Dict[str, Any]:
        self._load()
        return {
            "backend": self.active_backend,
            "model": self.model_name if self.active_backend == "fastembed" else "feature-hashing (n-gram, 384-d)",
            "dimension": self.dimension,
            "semantic": self.active_backend == "fastembed",
            "error": self.error,
        }

    # ------------------------------------------------------------------ embedding
    @staticmethod
    def _hash_embed(text: str) -> np.ndarray:
        vec = np.zeros(HASH_DIM, dtype=np.float32)
        toks = _TOKEN.findall(text.lower())
        feats = toks + [f"{a}_{b}" for a, b in zip(toks, toks[1:])]
        for f in feats:
            h = int.from_bytes(hashlib.blake2b(f.encode(), digest_size=8).digest(), "little")
            vec[h % HASH_DIM] += 1.0 if (h >> 63) & 1 else -1.0
        n = np.linalg.norm(vec)
        return vec / n if n > 0 else vec

    def embed_texts(self, texts: List[str], batch_size: int = 64) -> np.ndarray:
        """-> (n, d) float32 matrix of L2-normalised vectors."""
        self._load()
        if not texts:
            return np.zeros((0, self.dimension), dtype=np.float32)
        with tracer.span("embedding.embed", "embedding", n_texts=len(texts), chars=sum(len(t) for t in texts),
                         backend=self.active_backend, model=self.model_name if self.active_backend == "fastembed" else "feature-hashing",
                         dimension=self.dimension):
            if self.active_backend == "fastembed":
                with self._lock:
                    vecs = np.asarray(list(self._model.embed(texts, batch_size=batch_size)), dtype=np.float32)
                norms = np.linalg.norm(vecs, axis=1, keepdims=True)
                return vecs / np.where(norms == 0, 1.0, norms)
            return np.vstack([self._hash_embed(t) for t in texts])

    def embed_text(self, text: str) -> List[float]:
        return [float(x) for x in self.embed_texts([text or ""])[0]]

    @staticmethod
    def cosine_similarity(a: List[float], b: List[float]) -> float:
        """Cosine similarity clipped to [0, 1] (no re-mapping, so a threshold means what it says)."""
        va, vb = np.asarray(a, dtype=np.float32), np.asarray(b, dtype=np.float32)
        na, nb = np.linalg.norm(va), np.linalg.norm(vb)
        if na == 0 or nb == 0:
            return 0.0
        return float(max(0.0, min(1.0, float(va @ vb) / (na * nb))))


embedding_service = EmbeddingService()
