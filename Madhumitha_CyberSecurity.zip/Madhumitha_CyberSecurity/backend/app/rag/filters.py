"""Metadata filters (attack type, protocol, source/destination IP and port, timestamp range, confidence ...).

Filters are compiled into SQL, so only matching rows are ever scored - the database does the narrowing, not a
Python loop over the whole corpus. Timestamps are normalised to naive UTC, which fixes the
"can't compare offset-naive and offset-aware datetimes" failure for ISO-8601 strings with a ``Z`` suffix.
"""
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from sqlalchemy import func

from app.database.models import Incident

FILTER_KEYS = {
    "attack_type", "protocol", "source_ip", "destination_ip", "source_port", "destination_port",
    "start_time", "end_time", "min_confidence", "label_sources", "risk_level", "status", "data_source",
}


def to_naive_utc(value: Any) -> Optional[datetime]:
    if value is None or value == "":
        return None
    if isinstance(value, str):
        value = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    if value.tzinfo is not None:
        value = value.astimezone(timezone.utc).replace(tzinfo=None)
    return value


def apply_filters(query, filters: Optional[Dict[str, Any]]):
    """Add WHERE clauses for every recognised filter key; unknown/empty keys are ignored."""
    if not filters:
        return query
    f = {k: v for k, v in filters.items() if k in FILTER_KEYS and v is not None and v != ""}

    if "attack_type" in f:
        query = query.filter(func.lower(Incident.attack_type) == str(f["attack_type"]).strip().lower())
    if "protocol" in f:
        query = query.filter(Incident.protocol == int(f["protocol"]))
    if "source_ip" in f:
        query = query.filter(Incident.source_ip == str(f["source_ip"]).strip())
    if "destination_ip" in f:
        query = query.filter(Incident.destination_ip == str(f["destination_ip"]).strip())
    if "source_port" in f:
        query = query.filter(Incident.source_port == int(f["source_port"]))
    if "destination_port" in f:
        query = query.filter(Incident.destination_port == int(f["destination_port"]))
    if "start_time" in f:
        query = query.filter(Incident.timestamp >= to_naive_utc(f["start_time"]))
    if "end_time" in f:
        query = query.filter(Incident.timestamp <= to_naive_utc(f["end_time"]))
    if "min_confidence" in f:
        query = query.filter(Incident.prediction_confidence >= float(f["min_confidence"]))
    if "label_sources" in f:
        query = query.filter(Incident.label_source.in_(list(f["label_sources"])))
    if "risk_level" in f:
        query = query.filter(Incident.risk_level == f["risk_level"])
    if "status" in f:
        query = query.filter(Incident.status == f["status"])
    if "data_source" in f:
        query = query.filter(Incident.data_source == f["data_source"])
    return query
