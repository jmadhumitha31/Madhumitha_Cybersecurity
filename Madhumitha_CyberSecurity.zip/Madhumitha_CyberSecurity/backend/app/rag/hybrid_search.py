from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from app.config import settings
from app.observability.tracing import tracer
from app.rag.index import hybrid_index


class HybridSearchService:
    """Hybrid retrieval: alpha * semantic (sentence embeddings) + (1 - alpha) * lexical (BM25), with SQL metadata filters."""

    def __init__(self, alpha: Optional[float] = None):
        self.alpha = alpha

    def search(
        self,
        db: Session,
        query: str,
        filters: Optional[Dict[str, Any]] = None,
        top_k: int = 5,
        similarity_threshold: Optional[float] = None,
        search_mode: str = "hybrid",  # "hybrid" | "semantic" | "keyword"
        exclude_id: Optional[int] = None,
        query_flow: Optional[Dict[str, Any]] = None,
        semantic_query: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        threshold = settings.TEXT_SEARCH_THRESHOLD if similarity_threshold is None else similarity_threshold
        return hybrid_index.search(
            db,
            (query or "").strip(),
            filters=filters,
            top_k=top_k,
            threshold=threshold,
            mode=search_mode,
            alpha=self.alpha,
            exclude_id=exclude_id,
            query_flow=query_flow,
            semantic_query=semantic_query,
        )

    def browse(self, db: Session, filters: Dict[str, Any], top_k: int = 10) -> List[Dict[str, Any]]:
        """Metadata-only listing (no text query): highest-risk matching incidents first."""
        from app.database.models import Incident
        from app.rag.filters import apply_filters

        with tracer.span("retrieval.browse", "retrieval", filters=filters, top_k=top_k, ordering="risk score desc, newest first") as sp:
            rows = (
                apply_filters(db.query(Incident), filters)
                .order_by(Incident.risk_score.desc().nullslast(), Incident.timestamp.desc())
                .limit(top_k)
                .all()
            )
            sp.set(n_results=len(rows), empty=not rows, top_results=[{"incident_id": r.id, "attack_type": r.attack_type, "risk_score": r.risk_score} for r in rows[:5]])
        return [
            {
                "incident_id": r.id, "flow_id": r.flow_id, "attack_type": r.attack_type, "label_source": r.label_source,
                "data_source": r.data_source, "risk_level": r.risk_level, "priority": r.priority,
                "source_ip": r.source_ip, "destination_ip": r.destination_ip, "source_port": r.source_port,
                "destination_port": r.destination_port, "protocol": r.protocol,
                "timestamp": r.timestamp.isoformat() if r.timestamp else None,
                "hybrid_score": 0.0, "similarity_score": 0.0, "semantic_score": 0.0, "keyword_score": 0.0,
                "shared_characteristics": ["Metadata filter match"],
                "explanation": {"mode": "metadata", "formula": "no text query: ranked by risk score among incidents matching the filters",
                                "matched_terms": [], "dense": 0.0, "bm25": 0.0, "score": 0.0, "alpha": None},
                "matched_features": {
                    "flow_duration": r.flow_duration, "flow_packets_per_sec": r.flow_packets_per_sec,
                    "syn_count": r.syn_count, "packet_length_mean": r.packet_length_mean,
                },
            }
            for r in rows
        ]


hybrid_search_service = HybridSearchService()
