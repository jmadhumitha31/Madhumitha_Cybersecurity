"""Hybrid retrieval index: dense vectors in Qdrant (on-device) + BM25 postings, kept in sync with ``incident_embeddings``.

* **Dense channel** - Qdrant (embedded, persisted under ``QDRANT_PATH``): cosine search, restricted by incident id.
* **Lexical channel** - BM25 over the incident texts (IPs, ports, attack-family descriptions). Its postings are a small
  derived structure rebuilt from the SQL texts whenever the table changes (~0.3 s for 10^4 incidents); they are not
  persisted because they would only duplicate what the texts already contain.
* **Metadata filters** - compiled to SQL (the database is the source of truth for mutable fields such as the attack
  type, status and risk) and handed to Qdrant as an id restriction.
* **Hybrid score** - ``alpha * dense + (1 - alpha) * BM25``. Qdrant returns the dense candidates; the lexical candidates
  the dense pool missed get their exact dense score from Qdrant too, so the blend is exact for every candidate (the pool
  is ``QDRANT_CANDIDATES`` per channel, far deeper than the handful of results ever returned).

The SQL embedding rows stay the system of record: the collection is diff-synced from them (see ``vector_store.sync``),
so deleting the Qdrant folder only costs one rebuild at the next start - no re-embedding.
"""
import threading
import zlib
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.config import settings
from app.database.models import Incident, IncidentEmbedding
from app.logging_config import logger, scrub_secrets
from app.rag.bm25 import BM25Index, tokenize
from app.rag.embeddings import embedding_service
from app.observability.tracing import tracer
from app.rag.filters import apply_filters
from app.rag.text import flow_behaviors
from app.rag.vector_store import QdrantVectorStore, collection_name_for, vector_store

MODES = ("hybrid", "semantic", "keyword")


def _revision(updated_at: Any, text: str) -> str:
    """Fingerprint of an embedding row: changes when the row is re-embedded or its text changes."""
    return f"{updated_at.isoformat() if updated_at else '-'}|{zlib.crc32((text or '').encode('utf-8')):08x}"


class HybridIndex:
    def __init__(self, store: Optional[QdrantVectorStore] = None):
        self.store = store or vector_store
        self._lock = threading.RLock()
        self._signature = None
        self.collection: Optional[str] = None
        self.ids = np.zeros(0, dtype=np.int64)
        self.texts: List[str] = []
        self.bm25 = BM25Index()
        self._row_of: Dict[int, int] = {}
        self.last_sync: Dict[str, int] = {}

    # ------------------------------------------------------------------ maintenance
    def _signature_now(self, db: Session):
        model = embedding_service.identifier
        row = (
            db.query(func.count(IncidentEmbedding.id), func.max(IncidentEmbedding.id), func.max(IncidentEmbedding.updated_at))
            .filter(IncidentEmbedding.embedding_model == model)
            .one()
        )
        return (model, row[0], row[1], str(row[2]), self.store.mode, self.store.url or self.store.path)

    def invalidate(self) -> None:
        with self._lock:
            self._signature = None

    def ensure(self, db: Session) -> None:
        sig = self._signature_now(db)
        if sig == self._signature:
            return
        with self._lock, tracer.span("index.sync", "retrieval", reason="table signature changed") as span:
            if sig == self._signature:
                return
            model = embedding_service.identifier
            rows = (
                db.query(IncidentEmbedding.incident_id, IncidentEmbedding.updated_at, IncidentEmbedding.text_representation)
                .filter(IncidentEmbedding.embedding_model == model)
                .order_by(IncidentEmbedding.incident_id)
                .all()
            )
            self.ids = np.array([r[0] for r in rows], dtype=np.int64)
            self.texts = [r[2] for r in rows]
            self._row_of = {int(i): n for n, i in enumerate(self.ids)}
            dim = embedding_service.dimension
            self.collection = collection_name_for(model, dim)

            def load_vectors(chunk: List[int]) -> Dict[int, Sequence[float]]:
                got = (
                    db.query(IncidentEmbedding.incident_id, IncidentEmbedding.embedding_vector)
                    .filter(IncidentEmbedding.embedding_model == model, IncidentEmbedding.incident_id.in_(chunk))
                    .all()
                )
                return {int(i): v for i, v in got}

            wanted = {int(r[0]): _revision(r[1], r[2]) for r in rows}
            self.last_sync = self.store.sync(self.collection, dim, wanted, load_vectors)
            self.bm25 = BM25Index().build([tokenize(t) for t in self.texts])
            self._signature = sig
            stale = db.query(func.count(IncidentEmbedding.id)).filter(IncidentEmbedding.embedding_model != model).scalar() or 0
            span.set(documents=int(len(self.ids)), embedding_model=model, store_mode=self.store.mode, collection=self.collection,
                     sync=self.last_sync, stale_vectors=stale)
            logger.info(
                f"Hybrid index ready: {len(self.ids)} documents ({model}); Qdrant {self.store.mode} collection {self.collection} "
                f"synced {self.last_sync}; {stale} stale vectors need re-indexing"
            )

    def size(self, db: Session) -> int:
        self.ensure(db)
        return int(len(self.ids))

    def stats(self) -> Dict[str, Any]:
        """Index/store facts for the health endpoint (no database access)."""
        out: Dict[str, Any] = {**self.store.info(), "collection": self.collection, "documents": int(len(self.ids))}
        if self.collection:
            out["points"] = self.store.count(self.collection)
        out["last_sync"] = self.last_sync
        return out

    def close(self) -> None:
        self.store.close()

    # ------------------------------------------------------------------ scoring
    def _id_restriction(self, mask: np.ndarray) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        """Cheapest way to express the candidate mask to Qdrant: list the allowed ids if few, else list the excluded ones."""
        n = len(mask)
        kept = int(mask.sum())
        if kept == n:
            return None, None
        if kept <= n // 2:
            return self.ids[mask], None
        return None, self.ids[~mask]

    def score(
        self,
        query_text: str,
        query_vec: Optional[np.ndarray],
        mask: np.ndarray,
        alpha: float,
        modes: Sequence[str] = MODES,
        pool: Optional[int] = None,
        k: int = 10,
    ) -> Tuple[Dict[str, np.ndarray], np.ndarray, np.ndarray]:
        """Score the index for one query (see ``_score``); the work is recorded as a ``retrieval.score`` trace span."""
        with tracer.span("retrieval.score", "retrieval", modes=list(modes), alpha=alpha, k=k, n_indexed=int(len(self.ids)),
                         n_candidates_after_filters=int(mask.sum())) as sp:
            stats: Dict[str, Any] = {}
            out = self._score(query_text, query_vec, mask, alpha, modes, pool, k, stats)
            sp.set(**stats)
            tracer.count("retrieval.widenings", stats.get("widenings", 0))
            tracer.count("retrieval.candidates_scored", stats.get("candidates_scored", 0))
            tracer.count("retrieval.dense_top_ties", stats.get("dense_docs_tied_with_best", 0))
            return out

    def _score(
        self,
        query_text: str,
        query_vec: Optional[np.ndarray],
        mask: np.ndarray,
        alpha: float,
        modes: Sequence[str],
        pool: Optional[int],
        k: int,
        stats: Dict[str, Any],
    ) -> Tuple[Dict[str, np.ndarray], np.ndarray, np.ndarray]:
        """Score the index for one query. Returns ({mode: scores}, dense_scores, bm25_scores).

        Score arrays have one entry per indexed document and ``-1`` for documents that are masked out or outside the
        candidate pool of the channel(s) the mode uses. The top ``k`` of every mode is **exact**:

        * Candidate pools are tie-inclusive. The flow descriptions are bucketed, so many documents share an identical
          vector (a median of ~100 and up to ~500 documents tie with the best dense score on CIC-IDS2017); a pool that
          cut through such a group would pick its members arbitrarily.
        * The hybrid ranking is checked with a threshold-algorithm bound: an unseen document scores below
          ``alpha * dense_boundary + (1 - alpha) * bm25_boundary``. If the k-th best candidate does not clear that bound,
          the pool is widened and the query repeated, so the blend never depends on where a pool happened to end."""
        n = len(self.ids)
        n_mask = int(mask.sum())
        pool = max(int(pool or settings.QDRANT_CANDIDATES), k, 1)
        use_store = query_vec is not None and bool(self.collection)
        want_dense = use_store and ("hybrid" in modes or "semantic" in modes)
        want_kw = "hybrid" in modes or "keyword" in modes

        q_tokens = tokenize(query_text)
        # Terms shown in the trace come from the *scrubbed* text: tokenising splits "api_key=sk-..." into pieces that no
        # longer look like a secret, so they must never be derived from the raw query.
        shown = tokenize(scrub_secrets(query_text))
        with tracer.span("retrieval.bm25", "retrieval", n_query_terms=len(q_tokens), query_terms=sorted(set(shown))[:20]) as bsp:
            kw = self.bm25.normalized_scores(q_tokens) if want_kw else np.zeros(n, dtype=np.float32)
            bsp.set(skipped=not want_kw, n_docs_matching=int((kw > 0).sum()) if want_kw else 0,
                    unknown_terms=[t for t in dict.fromkeys(shown) if t not in self.bm25.postings][:10] if want_kw else [])
        kw_masked = np.where(mask, kw, -1.0)
        must, must_not = self._id_restriction(mask) if want_dense else (None, None)
        rows_all = np.arange(n)
        stats.update(pool_initial=pool, widenings=0, dense_enabled=bool(want_dense), lexical_enabled=bool(want_kw))

        while True:
            sem = np.full(n, -1.0, dtype=np.float32)
            sem_bound = 0.0                      # no unseen document when the dense pool was not filled
            if want_dense:
                with tracer.span("retrieval.dense_qdrant", "retrieval", pool=pool, store_mode=self.store.mode, collection=self.collection,
                                 restriction="allow-list" if must is not None else ("deny-list" if must_not is not None else "none")) as dsp:
                    hits = self.store.search(self.collection, query_vec, pool, must_ids=must, must_not_ids=must_not)
                    expanded = False
                    if len(hits) >= pool and n_mask > pool:
                        sem_bound = max(hits[-1][1], 0.0)   # pool is full: take every document tied with its last member too
                        hits = self.store.search(self.collection, query_vec, n_mask, must_ids=must, must_not_ids=must_not, score_threshold=hits[-1][1] - 1e-7)
                        expanded = True
                    for inc_id, s in hits:
                        row = self._row_of.get(inc_id)
                        if row is not None and mask[row]:
                            sem[row] = min(max(s, 0.0), 1.0)
                    best = max((s for _, s in hits), default=0.0)
                    dsp.set(returned=len(hits), tie_inclusive_expansion=expanded, best_similarity=best,
                            docs_tied_with_best=sum(1 for _, s in hits if s >= best - 1e-6), boundary_similarity=sem_bound)
                    stats.update(dense_returned=len(hits), dense_docs_tied_with_best=sum(1 for _, s in hits if s >= best - 1e-6))

            out: Dict[str, np.ndarray] = {}
            if "semantic" in modes:
                out["semantic"] = sem.copy()
            if "keyword" in modes:
                out["keyword"] = kw_masked
            if "hybrid" not in modes:
                break

            positive = np.nonzero(kw_masked > 0)[0]
            if len(positive) <= pool:
                lex_rows, kw_bound = positive, 0.0
            else:
                kw_bound = float(np.sort(kw_masked[positive])[-pool])
                lex_rows = positive[kw_masked[positive] >= kw_bound]          # tie-inclusive
            if want_dense:
                # Lexical candidates the dense pool missed need an exact dense score - but only those that could still reach the
                # top-k. Such a document scores at most alpha * dense_boundary + (1 - alpha) * its own BM25, so any whose bound
                # is below the current k-th best (computed from the exactly scored dense candidates) can be skipped: the result
                # stays exact while the exact-score lookup (slow for hundreds of ids in embedded Qdrant) shrinks to a handful.
                known = (sem >= 0) & mask
                blend0 = alpha * np.clip(sem, 0.0, 1.0) + (1.0 - alpha) * kw
                kth0 = float(np.sort(blend0[known])[-k]) if int(known.sum()) >= k else -1.0
                lex_only = lex_rows[sem[lex_rows] < 0]
                need = lex_only[alpha * sem_bound + (1.0 - alpha) * kw[lex_only] >= kth0 - 1e-9]
                stats.update(lexical_only_candidates=int(len(lex_only)), exact_fill=int(len(need)))
                if len(need):
                    with tracer.span("retrieval.dense_exact_fill", "retrieval", n_candidates=int(len(need)), skipped_by_bound=int(len(lex_only) - len(need)),
                                     reason="lexical candidates outside the dense pool that could still reach the top-k") as xsp:
                        exact = self.store.scores_for(self.collection, query_vec, [int(self.ids[r]) for r in need])
                        for r in need:
                            sem[r] = min(max(exact.get(int(self.ids[r]), 0.0), 0.0), 1.0)
                        xsp.set(scored=len(exact))
                candidate = (sem >= 0) & mask
            else:
                candidate = np.isin(rows_all, lex_rows) & mask
            blend = alpha * np.clip(sem, 0.0, 1.0) + (1.0 - alpha) * kw
            hybrid = np.where(candidate, blend, -1.0).astype(np.float32)

            seen = int(candidate.sum())
            kth = float(np.sort(hybrid[candidate])[-k]) if seen >= k else -1.0
            bound = alpha * sem_bound + (1.0 - alpha) * kw_bound
            stats.update(pool_final=pool, candidates_scored=seen, kth_best_score=round(kth, 4), unseen_upper_bound=round(bound, 4),
                         lexical_candidates=int(len(lex_rows)))
            if seen >= n_mask or (seen >= k and kth >= bound - 1e-9):
                out["hybrid"] = hybrid
                stats["exact_top_k"] = True
                break
            pool *= 4                                                          # bound not cleared: widen both pools
            stats["widenings"] += 1

        stats.setdefault("exact_top_k", True)  # semantic / keyword modes: tie-inclusive pools are exact by construction
        return out, np.clip(sem, 0.0, 1.0), kw

    # ------------------------------------------------------------------ search
    def search(
        self,
        db: Session,
        query_text: str,
        filters: Optional[Dict[str, Any]] = None,
        top_k: int = 5,
        threshold: float = 0.0,
        mode: str = "hybrid",
        alpha: Optional[float] = None,
        exclude_id: Optional[int] = None,
        query_flow: Optional[Dict[str, Any]] = None,
        semantic_query: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """``query_text`` drives BM25; ``semantic_query`` (default: the same text) drives the dense channel.

        Every call is a ``retrieval.search`` trace span carrying the query, filters, candidate counts and the ranked
        results with their dense / BM25 breakdown, so any answer can be audited after the fact."""
        alpha = settings.HYBRID_ALPHA if alpha is None else alpha
        with tracer.span("retrieval.search", "retrieval", mode=mode, top_k=top_k, threshold=threshold, alpha=alpha,
                         filters=filters or {}, exclude_id=exclude_id, query=(query_text or "")[:600],
                         semantic_query=(semantic_query or "")[:300] or None, flow_query=query_flow is not None) as sp:
            results = self._search(db, query_text, filters, top_k, threshold, mode, alpha, exclude_id, query_flow, semantic_query, sp)
            tracer.count("retrieval.searches")
            if not results:
                tracer.count("retrieval.empty")
            sp.set(
                n_results=len(results), empty=not results,
                top_results=[
                    {"incident_id": r["incident_id"], "flow_id": r["flow_id"], "attack_type": r["attack_type"], "score": r["hybrid_score"],
                     "dense": r["semantic_score"], "bm25": r["keyword_score"], "matched_terms": r["explanation"]["matched_terms"][:5]}
                    for r in results[:5]
                ],
            )
            return results

    def _search(self, db, query_text, filters, top_k, threshold, mode, alpha, exclude_id, query_flow, semantic_query, sp) -> List[Dict[str, Any]]:
        with tracer.span("index.ensure", "retrieval", note="checks the embedding table signature; loads the embedding model on first use, syncs Qdrant if rows changed"):
            self.ensure(db)
        n = len(self.ids)
        sp.set(n_indexed=int(n))
        if n == 0 or not query_text.strip():
            return []

        # 1. candidate mask from SQL metadata filters
        mask = np.ones(n, dtype=bool)
        with tracer.span("retrieval.sql_filters", "db", filters=filters or {}, exclude_id=exclude_id) as fsp:
            if filters:
                allowed = {int(r[0]) for r in apply_filters(db.query(Incident.id), filters).all()}
                mask = np.fromiter((int(i) in allowed for i in self.ids), dtype=bool, count=n)
            if exclude_id is not None and exclude_id in self._row_of:
                mask[self._row_of[exclude_id]] = False
            fsp.set(n_candidates=int(mask.sum()), n_filtered_out=int(n - mask.sum()))
        sp.set(n_candidates=int(mask.sum()))
        if not mask.any():
            return []

        # 2. scores: dense from Qdrant, lexical from BM25, blended exactly over the candidate pool
        q = embedding_service.embed_texts([semantic_query or query_text])[0] if mode in ("semantic", "hybrid") else None
        scores, sem, kw = self.score(query_text, q, mask, alpha, modes=(mode,), pool=max(settings.QDRANT_CANDIDATES, top_k * 10), k=top_k)
        final = scores[mode]

        # equal scores (identical flow descriptions) are listed in a fixed order: lowest incident id first
        order = np.argsort(-final, kind="stable")[: max(top_k * 3, top_k)]
        picked = [int(i) for i in order if final[i] >= threshold and final[i] >= 0][:top_k]
        if not picked:
            return []

        # 3. materialise results
        inc_ids = [int(self.ids[i]) for i in picked]
        with tracer.span("retrieval.materialize", "db", n_rows=len(inc_ids)):
            incs = {i.id: i for i in db.query(Incident).filter(Incident.id.in_(inc_ids)).all()}
        q_list = tokenize(query_text)
        q_tokens = set(q_list)
        results = []
        for row in picked:
            inc = incs.get(int(self.ids[row]))
            if inc is None:
                continue
            d_score, k_score = float(sem[row]), float(kw[row])
            results.append(
                {
                    "incident_id": inc.id,
                    "flow_id": inc.flow_id,
                    "attack_type": inc.attack_type,
                    "label_source": inc.label_source,
                    "data_source": inc.data_source,
                    "risk_level": inc.risk_level,
                    "priority": inc.priority,
                    "source_ip": inc.source_ip,
                    "destination_ip": inc.destination_ip,
                    "source_port": inc.source_port,
                    "destination_port": inc.destination_port,
                    "protocol": inc.protocol,
                    "timestamp": inc.timestamp.isoformat() if inc.timestamp else None,
                    "hybrid_score": round(float(final[row]), 4),
                    "similarity_score": round(float(final[row]), 4),
                    "semantic_score": round(float(sem[row]), 4),
                    "keyword_score": round(float(kw[row]), 4),
                    "shared_characteristics": _shared(inc, q_tokens, query_text, query_flow),
                    "matched_features": {
                        "flow_duration": inc.flow_duration,
                        "flow_packets_per_sec": inc.flow_packets_per_sec,
                        "syn_count": inc.syn_count,
                        "packet_length_mean": inc.packet_length_mean,
                    },
                    # why this document: channel breakdown and the query terms that earned its BM25 score
                    "explanation": {
                        "mode": mode, "alpha": alpha, "dense": round(d_score, 4), "bm25": round(k_score, 4), "score": round(float(final[row]), 4),
                        "formula": (f"{alpha:.2f} x {d_score:.3f} (dense) + {1 - alpha:.2f} x {k_score:.3f} (BM25) = {float(final[row]):.3f}"
                                    if mode == "hybrid" else f"{mode} score {float(final[row]):.3f}"),
                        "matched_terms": self.bm25.explain(q_list, int(row)) if mode != "semantic" else [],
                    },
                }
            )
        return results


def _shared(inc: Incident, q_tokens: set, query_text: str, query_flow: Optional[Dict[str, Any]]) -> List[str]:
    shared: List[str] = []
    doc_flow = {c.name: getattr(inc, c.name) for c in Incident.__table__.columns}
    doc_tags = flow_behaviors(doc_flow)
    if query_flow:
        if int(query_flow.get("destination_port") or -1) == inc.destination_port:
            shared.append(f"Same destination port ({inc.destination_port})")
        if int(query_flow.get("protocol") or -1) == inc.protocol:
            shared.append("Same transport protocol")
        if query_flow.get("source_ip") == inc.source_ip:
            shared.append("Same source IP (repeat offender)")
        q_tags = set(flow_behaviors(query_flow))
        shared.extend(f"Both show: {t}" for t in doc_tags if t in q_tags)
    else:
        low = query_text.lower()
        if inc.attack_type and inc.attack_type.lower() in low:
            shared.append(f"Matching attack type: {inc.attack_type}")
        if str(inc.destination_port) in q_tokens:
            shared.append(f"Target port match ({inc.destination_port})")
        if inc.source_ip in query_text or inc.destination_ip in query_text:
            shared.append("IP address overlap")
        for t in doc_tags:
            words = {w for w in tokenize(t) if len(w) > 3}
            if len(words & q_tokens) >= 2:
                shared.append(t)
    return shared[:5] or [f"Flow profile resembles historical {inc.attack_type}"]


hybrid_index = HybridIndex()
