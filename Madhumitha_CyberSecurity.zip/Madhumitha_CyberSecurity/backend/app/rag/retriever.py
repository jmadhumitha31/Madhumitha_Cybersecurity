from collections import defaultdict
from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from app.config import settings
from app.observability.tracing import tracer
from app.rag.hybrid_search import hybrid_search_service
from app.rag.text import build_incident_text, build_semantic_text

NO_MATCH_MESSAGE = "No sufficiently similar historical incidents were found."
CONFIRMED_SOURCES = ["dataset", "analyst"]  # only labels a human/dataset vouches for count as historical evidence


class RAGRetriever:
    def retrieve_similar_incidents(
        self,
        db: Session,
        incident_dict: Dict[str, Any],
        top_k: int = 4,
        threshold: Optional[float] = None,
        exclude_id: Optional[int] = None,
        confirmed_only: bool = True,
        include_endpoints: bool = True,
    ) -> Dict[str, Any]:
        """Top-K similar *labelled* historical incidents for a flow.

        The query is built from telemetry only (``include_label=False``): neither the stored label nor the model's
        prediction can leak into retrieval. If nothing clears the similarity threshold the result is the explicit
        empty state "No sufficiently similar historical incidents were found."
        """
        effective_threshold = settings.SIMILARITY_THRESHOLD if threshold is None else threshold
        with tracer.span("rag.retrieve_similar", "retrieval", flow_id=incident_dict.get("flow_id"), threshold=effective_threshold, top_k=top_k,
                         confirmed_only=confirmed_only, label_free_query=True, exclude_id=exclude_id) as rsp:
            result = self._retrieve(db, incident_dict, top_k, effective_threshold, exclude_id, confirmed_only, include_endpoints)
            rsp.set(found=result["found"], n_matches=len(result["matches"]), class_votes=result["class_votes"], message=result["message"])
            return result

    def _retrieve(self, db, incident_dict, top_k, effective_threshold, exclude_id, confirmed_only, include_endpoints) -> Dict[str, Any]:
        query_text = build_incident_text(incident_dict, include_label=False, include_endpoints=include_endpoints)
        filters = {"label_sources": CONFIRMED_SOURCES} if confirmed_only else None

        matches = hybrid_search_service.search(
            db=db,
            query=query_text,
            filters=filters,
            top_k=top_k,
            similarity_threshold=effective_threshold,
            search_mode="hybrid",
            exclude_id=exclude_id,
            query_flow=incident_dict,
            semantic_query=build_semantic_text(incident_dict, include_label=False),
        )
        if not matches:
            return {
                "found": False,
                "matches": [],
                "class_votes": {},
                "message": NO_MATCH_MESSAGE,
                "evidence_context": f"{NO_MATCH_MESSAGE} (similarity threshold {effective_threshold:.2f}; the knowledge base holds no comparable incident.)",
                "query_text": query_text,
            }

        votes: Dict[str, float] = defaultdict(float)
        for m in matches:
            votes[m["attack_type"]] += m["hybrid_score"]
        total = sum(votes.values()) or 1.0
        class_votes = {k: round(v / total, 4) for k, v in sorted(votes.items(), key=lambda kv: kv[1], reverse=True)}

        lines = [f"Retrieved {len(matches)} similar labelled historical incident(s) from the CIC-IDS2017 knowledge base:"]
        for idx, m in enumerate(matches, 1):
            lines.append(
                f"{idx}. Incident {m['flow_id']}: attack type={m['attack_type']}, hybrid similarity={m['hybrid_score']:.2f} "
                f"(semantic={m['semantic_score']:.2f}, keyword={m['keyword_score']:.2f}), "
                f"target={m['destination_ip']}:{m['destination_port']}, shared: {'; '.join(m['shared_characteristics'])}"
            )
        lines.append("Similarity-weighted class vote: " + ", ".join(f"{k} {v * 100:.0f}%" for k, v in class_votes.items()))
        return {
            "found": True,
            "matches": matches,
            "class_votes": class_votes,
            "message": f"Retrieved {len(matches)} similar historical incident(s).",
            "evidence_context": "\n".join(lines),
            "query_text": query_text,
        }


rag_retriever = RAGRetriever()
