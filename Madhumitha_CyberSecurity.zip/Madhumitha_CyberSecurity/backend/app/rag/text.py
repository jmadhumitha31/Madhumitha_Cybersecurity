"""
Textual representations of a network-flow incident.

Two views are built from the same telemetry:

* ``build_incident_text``  - full text with identifiers (IPs, ports) and exact metrics. Used for **BM25**, so an analyst
  can find "port 445" or a repeat-offender IP lexically.
* ``build_semantic_text``  - compact *behavioural* description (service, duration class, packet volume, direction,
  payload size, rate, attack family). Used for the **sentence embedding**: a transformer cannot compare raw
  numbers or IPs, but it can tell "a handful of packets, sub-millisecond, one-directional probe of an SMB service"
  from "long-lived bidirectional bulk transfer".

``include_label=False`` is used for the *query* side when investigating an alert, so a stored label can never leak
into retrieval.
"""
from typing import Any, Dict, List, Optional

from app.domain import (
    C2_LIKE_PORTS,
    CLASS_DESCRIPTIONS,
    PORT_SERVICES,
    PROTOCOL_NAMES,
    SENSITIVE_PORTS,
    UNCLASSIFIED,
)

TEXT_VERSION = "sem3"  # bump when the representation changes: stored vectors are then re-indexed automatically


def _f(d: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for k in keys:
        v = d.get(k)
        if v is not None:
            try:
                return float(v)
            except (TypeError, ValueError):
                pass
    return default


def fmt_duration(us: float) -> str:
    if us >= 1e6:
        return f"{us / 1e6:.1f} s"
    if us >= 1e3:
        return f"{us / 1e3:.1f} ms"
    return f"{us:.0f} us"


def flow_behaviors(d: Dict[str, Any]) -> List[str]:
    """Qualitative behaviour descriptors computed from the numeric telemetry (bucketed, label-free)."""
    dur = _f(d, "flow_duration")
    fwd = _f(d, "total_fwd_packets")
    bwd = _f(d, "total_bwd_packets", "total_backward_packets")
    pps = _f(d, "flow_packets_per_sec")
    bps = _f(d, "flow_bytes_per_sec")
    syn, rst = _f(d, "syn_count"), _f(d, "rst_count")
    plen = _f(d, "packet_length_mean")
    idle = _f(d, "idle_mean")
    dport = int(_f(d, "destination_port"))
    pkts = fwd + bwd
    tags: List[str] = []

    # --- duration
    if dur < 1e3:
        tags.append("sub-millisecond flow duration, lasting microseconds")
    elif dur < 1e5:
        tags.append("very short flow under 100 milliseconds")
    elif dur < 1e6:
        tags.append("short flow under one second")
    elif dur < 1e7:
        tags.append("flow lasting several seconds")
    elif dur < 6e7:
        tags.append("flow lasting tens of seconds")
    else:
        tags.append("long-lived persistent connection lasting over a minute")

    # --- packet volume and direction
    if pkts <= 2:
        tags.append("only one or two packets exchanged, single-packet probe of a port, reconnaissance port scanning")
    elif pkts <= 10:
        tags.append("a handful of packets exchanged")
    elif pkts <= 50:
        tags.append("dozens of packets exchanged")
    elif pkts <= 500:
        tags.append("hundreds of packets exchanged")
    else:
        tags.append("thousands of packets exchanged, bulk transfer, possible data leak or exfiltration")
    if bwd == 0 and fwd > 0:
        tags.append("no reply packets, one-directional traffic")
    elif fwd >= 5 * max(bwd, 1) and fwd >= 5:
        tags.append("mostly forward traffic, highly asymmetric")
    elif bwd >= 5 * max(fwd, 1) and bwd >= 5:
        tags.append("mostly backward traffic from the server")
    else:
        tags.append("balanced bidirectional exchange")

    # --- payload size
    if pkts > 2:
        if plen == 0:
            tags.append("no application payload bytes")
        elif plen < 15:
            tags.append("near-empty keep-alive style packets, possible bot beaconing")
        elif plen < 100:
            tags.append("small packets")
        elif plen < 500:
            tags.append("medium sized packets")
        elif plen < 1000:
            tags.append("large packets")
        else:
            tags.append("jumbo payload packets, large payloads")

    # --- rates
    if pps >= 50000:
        tags.append("extreme packet rate burst")
    elif pps >= 5000:
        tags.append("very high packet rate")
    elif pps >= 1000:
        tags.append("elevated packet rate")
    elif 0 < pps < 5:
        tags.append("very slow low-rate traffic")
    if bps >= 5e6:
        tags.append("very high bandwidth consumption")

    # --- flags and timing
    if syn >= 100 and bwd <= 2:
        tags.append("SYN flood pattern with unanswered half-open connections")
    elif syn >= 1 and bwd == 0:
        tags.append("unanswered SYN probe")
    if rst >= 3:
        tags.append("many connection resets refused connections")
    if idle >= 5e6:
        tags.append("long idle gaps between bursts, slow-and-low or periodic beaconing behaviour")

    # --- service semantics
    svc = PORT_SERVICES.get(dport)
    if dport in (21, 22):
        tags.append(f"{svc} authentication service targeted, repeated login attempts credential guessing")
    elif dport in (80, 443, 8443):
        tags.append(f"{svc} web service targeted")
    elif dport == 53:
        tags.append("DNS traffic")
    elif dport in C2_LIKE_PORTS:
        tags.append(f"backdoor or command-and-control style port {dport}")
    elif dport in SENSITIVE_PORTS:
        tags.append(f"{svc} sensitive internal service targeted")
    elif dport >= 1024:
        tags.append("high ephemeral destination port")
    return tags


def _label_sentence(d: Dict[str, Any], include_label: bool) -> Optional[str]:
    label: Optional[str] = d.get("attack_type")
    if include_label and label and label != UNCLASSIFIED:
        return f"Attack type {label}: {CLASS_DESCRIPTIONS.get(label, label)}."
    return None


def _proto(d: Dict[str, Any]) -> str:
    return PROTOCOL_NAMES.get(int(_f(d, "protocol")), f"protocol {int(_f(d, 'protocol'))}")


def build_semantic_text(d: Dict[str, Any], include_label: bool = True) -> str:
    """Compact behavioural description for the sentence-embedding model (no IPs, no raw numbers)."""
    dport = int(_f(d, "destination_port"))
    svc = PORT_SERVICES.get(dport)
    parts: List[str] = []
    lab = _label_sentence(d, include_label)
    if lab:
        parts.append(lab)
    parts.append(f"{_proto(d)} network flow towards {svc + ' service' if svc else 'an unlisted port'}.")
    parts.append("Behaviour: " + "; ".join(flow_behaviors(d)) + ".")
    return " ".join(parts)


def build_incident_text(d: Dict[str, Any], include_label: bool = True, include_endpoints: bool = True) -> str:
    """Full lexical text (identifiers + exact metrics + behaviours) for BM25 and for display."""
    dport = int(_f(d, "destination_port"))
    sport = int(_f(d, "source_port"))
    svc = PORT_SERVICES.get(dport)
    parts: List[str] = []
    lab = _label_sentence(d, include_label)
    if lab:
        parts.append(lab)
    if include_endpoints:
        path = f"{_proto(d)} flow from {d.get('source_ip', '?')} port {sport} to {d.get('destination_ip', '?')} port {dport}"
    else:
        path = f"{_proto(d)} flow to port {dport}"
    parts.append(path + (f" ({svc} service)." if svc else "."))
    parts.append("Behaviour: " + "; ".join(flow_behaviors(d)) + ".")
    parts.append(
        "Metrics: duration {dur}, {fwd:.0f} forward and {bwd:.0f} backward packets, {pps:.0f} packets per second, "
        "{bps:.0f} bytes per second, SYN {syn:.0f} RST {rst:.0f} ACK {ack:.0f}, mean packet length {plen:.0f}.".format(
            dur=fmt_duration(_f(d, "flow_duration")),
            fwd=_f(d, "total_fwd_packets"),
            bwd=_f(d, "total_bwd_packets", "total_backward_packets"),
            pps=_f(d, "flow_packets_per_sec"),
            bps=_f(d, "flow_bytes_per_sec"),
            syn=_f(d, "syn_count"),
            rst=_f(d, "rst_count"),
            ack=_f(d, "ack_count"),
            plen=_f(d, "packet_length_mean"),
        )
    )
    return " ".join(parts)
