"""Qdrant vector store for the incident index.

By default Qdrant runs *embedded* (on-device): ``QdrantClient(path=...)`` persists the collection under
``settings.QDRANT_PATH`` and needs no server process. Set ``QDRANT_URL`` to talk to a Qdrant server instead (required
for several API workers, because the embedded store is locked to one process). ``QDRANT_PATH=:memory:`` keeps the
index in RAM only.

Qdrant holds, per incident, the dense embedding (cosine distance) and a small payload (``rev``, a fingerprint of the
source row). The SQL ``incident_embeddings`` table stays the system of record, so the index can always be rebuilt
without re-embedding: :meth:`QdrantVectorStore.sync` diffs the two and upserts/deletes only what changed.

One collection per embedding model (name includes a hash of the model identifier), so vectors from different
models or backends are never mixed.
"""
import hashlib
import os
import re
import threading
from contextlib import nullcontext
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from app.config import settings
from app.logging_config import logger

_BATCH = 256
_SCROLL = 1000


def collection_name_for(model_id: str, dim: int, prefix: Optional[str] = None) -> str:
    """One collection per (embedding model, dimension). The dimension is part of the name on purpose: embedded Qdrant
    cannot be relied on to recreate a collection under a name it has just deleted (on Windows the old storage file can
    survive ``delete_collection`` and is silently reloaded), so a collection is never deleted and recreated."""
    slug = re.sub(r"[^a-z0-9]+", "_", model_id.lower()).strip("_")[:40]
    digest = hashlib.sha1(model_id.encode("utf-8")).hexdigest()[:8]
    return f"{prefix or settings.QDRANT_COLLECTION}__{slug}_{digest}_{dim}d"


class QdrantVectorStore:
    def __init__(self, path: Optional[str] = None, url: Optional[str] = None, api_key: Optional[str] = None):
        self._path, self._url, self._api_key = path, url, api_key
        self._client = None
        self._lock = threading.RLock()  # guards client creation and (embedded mode) every call

    # ------------------------------------------------------------------ connection
    @property
    def url(self) -> Optional[str]:
        return self._url if self._url is not None else settings.QDRANT_URL

    @property
    def path(self) -> str:
        return self._path if self._path is not None else settings.QDRANT_PATH

    @property
    def mode(self) -> str:
        if self.url:
            return "server"
        return "memory" if self.path == ":memory:" else "local"

    def _io(self):
        """Embedded Qdrant is not safe for concurrent calls from several threads; a server handles that itself."""
        return nullcontext() if self.mode == "server" else self._lock

    def client(self):
        with self._lock:
            if self._client is None:
                from qdrant_client import QdrantClient

                if self.url:
                    self._client = QdrantClient(url=self.url, api_key=self._api_key or settings.QDRANT_API_KEY, timeout=30)
                elif self.path == ":memory:":
                    self._client = QdrantClient(":memory:")
                else:
                    os.makedirs(self.path, exist_ok=True)
                    self._client = QdrantClient(path=self.path)
                logger.info(f"Qdrant vector store opened ({self.mode}: {self.url or self.path})")
            return self._client

    def close(self) -> None:
        with self._lock:
            if self._client is not None:
                try:
                    self._client.close()
                except Exception as e:  # noqa: BLE001 - shutting down
                    logger.warning(f"Qdrant close failed: {e}")
                self._client = None

    def info(self) -> Dict[str, object]:
        return {"engine": "qdrant", "mode": self.mode, "location": self.url or self.path}

    # ------------------------------------------------------------------ collections
    def has_collection(self, name: str) -> bool:
        with self._io():
            return bool(self.client().collection_exists(name))

    def ensure_collection(self, name: str, dim: int) -> None:
        from qdrant_client import models

        with self._io():
            c = self.client()
            if c.collection_exists(name):
                size = c.get_collection(name).config.params.vectors.size
                if size != dim:  # cannot happen for names built by collection_name_for(); fail loudly rather than corrupt the index
                    raise RuntimeError(f"Qdrant collection {name} holds {size}-dimensional vectors, expected {dim}")
                return
            c.create_collection(name, vectors_config=models.VectorParams(size=dim, distance=models.Distance.COSINE))

    def count(self, name: str) -> int:
        with self._io():
            c = self.client()
            return int(c.count(name, exact=True).count) if c.collection_exists(name) else 0

    def list_collections(self) -> List[str]:
        with self._io():
            return [c.name for c in self.client().get_collections().collections]

    # ------------------------------------------------------------------ maintenance
    def revisions(self, name: str) -> Dict[int, str]:
        """Point id -> stored revision fingerprint (payload only: vectors are not transferred)."""
        out: Dict[int, str] = {}
        offset = None
        with self._io():
            c = self.client()
            while True:
                points, offset = c.scroll(name, limit=_SCROLL, offset=offset, with_payload=["rev"], with_vectors=False)
                out.update({int(p.id): str((p.payload or {}).get("rev", "")) for p in points})
                if offset is None:
                    return out

    def upsert(self, name: str, ids: Sequence[int], vectors: Sequence[Sequence[float]], revs: Sequence[str]) -> None:
        from qdrant_client import models

        with self._io():
            c = self.client()
            for i in range(0, len(ids), _BATCH):
                c.upsert(
                    name,
                    points=[
                        models.PointStruct(id=int(pid), vector=[float(x) for x in vec], payload={"rev": rev})
                        for pid, vec, rev in zip(ids[i : i + _BATCH], vectors[i : i + _BATCH], revs[i : i + _BATCH])
                    ],
                    wait=True,
                )

    def delete(self, name: str, ids: Sequence[int]) -> None:
        from qdrant_client import models

        with self._io():
            c = self.client()
            for i in range(0, len(ids), _BATCH * 4):
                c.delete(name, points_selector=models.PointIdsList(points=[int(x) for x in ids[i : i + _BATCH * 4]]), wait=True)

    def sync(
        self,
        name: str,
        dim: int,
        wanted: Dict[int, str],
        load_vectors: Callable[[List[int]], Dict[int, Sequence[float]]],
    ) -> Dict[str, int]:
        """Make the collection mirror ``wanted`` (point id -> revision): delete extras, upsert missing or changed points.

        ``load_vectors`` is only called for the ids that need (re)writing, so a restart over an unchanged, persisted
        collection transfers no vectors at all."""
        self.ensure_collection(name, dim)
        have = self.revisions(name)
        extra = [i for i in have if i not in wanted]
        todo = [i for i, rev in wanted.items() if have.get(i) != rev]
        if extra:
            self.delete(name, extra)
        upserted = skipped = 0
        for i in range(0, len(todo), _BATCH):
            chunk = todo[i : i + _BATCH]
            vecs = load_vectors(chunk)
            ok = [pid for pid in chunk if len(vecs.get(pid) or ()) == dim]
            skipped += len(chunk) - len(ok)
            if ok:
                self.upsert(name, ok, [vecs[pid] for pid in ok], [wanted[pid] for pid in ok])
                upserted += len(ok)
        return {"upserted": upserted, "deleted": len(extra), "unchanged": len(wanted) - len(todo), "skipped_invalid": skipped}

    # ------------------------------------------------------------------ search
    @staticmethod
    def _filter(must_ids: Optional[Sequence[int]] = None, must_not_ids: Optional[Sequence[int]] = None):
        from qdrant_client import models

        must = [models.HasIdCondition(has_id=[int(i) for i in must_ids])] if must_ids is not None else None
        must_not = [models.HasIdCondition(has_id=[int(i) for i in must_not_ids])] if must_not_ids is not None and len(must_not_ids) else None
        return models.Filter(must=must, must_not=must_not) if (must or must_not) else None

    def search(
        self,
        name: str,
        vector: Sequence[float],
        limit: int,
        must_ids: Optional[Sequence[int]] = None,
        must_not_ids: Optional[Sequence[int]] = None,
        score_threshold: Optional[float] = None,
    ) -> List[Tuple[int, float]]:
        """Top ``limit`` (point id, cosine similarity), optionally restricted to / excluding given ids and to scores
        of at least ``score_threshold``."""
        if limit <= 0 or (must_ids is not None and len(must_ids) == 0):
            return []
        with self._io():
            res = self.client().query_points(
                name, query=[float(x) for x in vector], limit=int(limit), query_filter=self._filter(must_ids, must_not_ids),
                score_threshold=score_threshold, with_payload=False, with_vectors=False,
            )
        return [(int(p.id), float(p.score)) for p in res.points]

    def scores_for(self, name: str, vector: Sequence[float], ids: Sequence[int]) -> Dict[int, float]:
        """Exact cosine similarity of the query to specific points (candidates found by another channel).

        Fetches the points' vectors by id and takes the cosine locally. The obvious alternative, a search restricted
        with a ``has_id`` filter, costs O(points x ids) in embedded Qdrant (about 0.4 ms per id on 4k points), which
        dominated query latency when a few hundred lexical candidates needed a dense score."""
        if not len(ids):
            return {}
        import numpy as np

        q = np.asarray(vector, dtype=np.float32)
        qn = float(np.linalg.norm(q))
        out: Dict[int, float] = {}
        with self._io():
            c = self.client()
            for i in range(0, len(ids), 1000):
                pts = c.retrieve(name, ids=[int(x) for x in ids[i : i + 1000]], with_vectors=True, with_payload=False)
                if not pts:
                    continue
                v = np.asarray([p.vector for p in pts], dtype=np.float32)
                denom = np.linalg.norm(v, axis=1) * qn
                sims = (v @ q) / np.where(denom == 0, 1.0, denom)
                out.update({int(p.id): float(s) for p, s in zip(pts, sims)})
        return out


vector_store = QdrantVectorStore()
