from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    role: str = Field(..., description="Role: 'user', 'assistant', or 'system'")
    content: str = Field(..., max_length=6000, description="Message text")
    timestamp: Optional[str] = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class ChatQueryRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000, description="The user's query or instruction")
    history: List[ChatMessage] = Field(default=[], max_length=20, description="Recent conversation turns")
    incident_id: Optional[int] = Field(default=None, description="Optional incident ID for focused investigation")
    use_rag: bool = Field(default=True, description="Whether to query the CIC-IDS2017 knowledge base")
    filters: Optional[Dict[str, Any]] = Field(default=None, description="Optional metadata filters for RAG")


class ChatCitation(BaseModel):
    incident_id: int
    flow_id: str
    attack_type: str
    similarity_score: float
    source_ip: str
    destination_ip: str
    destination_port: int
    protocol: int


class ChatQueryResponse(BaseModel):
    reply: str
    citations: List[ChatCitation] = []
    incident_context: Optional[Dict[str, Any]] = None
    llm_provider: str = "none"  # nothing was generated unless a provider actually answered
    model_name: str = ""
    fallback_used: bool = False
    llm_attempts: List[Dict[str, Any]] = []
    guardrails: Dict[str, Any] = {}
    execution_time_ms: float = 0.0
    trace_id: Optional[str] = None  # the trace recorded for this message (Observability page)
