from typing import Generic, TypeVar, Optional, List, Any
from pydantic import BaseModel, Field

from app.observability.context import current_trace_id

T = TypeVar("T")


class ErrorDetail(BaseModel):
    code: str
    message: str
    details: Optional[Any] = None


class ApiResponse(BaseModel, Generic[T]):
    success: bool = True
    data: Optional[T] = None
    error: Optional[ErrorDetail] = None
    trace_id: Optional[str] = Field(default_factory=current_trace_id, description="Id of the trace recorded for this query (Observability page)")


class PaginationMeta(BaseModel):
    page: int
    page_size: int
    total: int
    total_pages: int


class PaginatedResponse(BaseModel, Generic[T]):
    success: bool = True
    data: List[T]
    pagination: PaginationMeta
