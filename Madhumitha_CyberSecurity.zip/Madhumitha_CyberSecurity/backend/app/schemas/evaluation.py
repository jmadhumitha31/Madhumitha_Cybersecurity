from datetime import datetime
from typing import Any, Dict

from pydantic import BaseModel, ConfigDict


class EvaluationRunResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    eval_type: str
    model_version: str
    dataset_version: str
    status: str = "completed"
    metrics: Dict[str, Any]
    created_at: datetime
