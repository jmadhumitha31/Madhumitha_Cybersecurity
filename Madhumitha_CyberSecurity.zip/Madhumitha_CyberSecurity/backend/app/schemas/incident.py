import ipaddress
from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.guardrails.input_validation import FLOW_ID_RE, NUMERIC_LIMITS


def _metric(field: str, desc: str):
    return Field(default=0.0, ge=0.0, le=NUMERIC_LIMITS[field], allow_inf_nan=False, description=desc)


class IncidentBase(BaseModel):
    flow_id: Optional[str] = Field(None, max_length=160, description="Unique flow identifier (generated if omitted)")
    source_ip: str = Field(..., description="Source IPv4/IPv6 address", json_schema_extra={"example": "172.16.0.1"})
    source_port: int = Field(..., ge=0, le=65535, description="Source port (0-65535)")
    destination_ip: str = Field(..., description="Destination IPv4/IPv6 address", json_schema_extra={"example": "192.168.10.50"})
    destination_port: int = Field(..., ge=0, le=65535, description="Destination port (0-65535)", json_schema_extra={"example": 80})
    protocol: int = Field(..., ge=0, le=255, description="IP protocol number (6=TCP, 17=UDP, 1=ICMP)")
    timestamp: Optional[datetime] = None

    # CIC-IDS2017 flow features
    flow_duration: float = _metric("flow_duration", "Flow duration in microseconds")
    total_fwd_packets: float = _metric("total_fwd_packets", "Total forward packets")
    total_bwd_packets: float = _metric("total_bwd_packets", "Total backward packets")
    total_length_fwd: float = _metric("total_length_fwd", "Total length of forward packets (bytes)")
    total_length_bwd: float = _metric("total_length_bwd", "Total length of backward packets (bytes)")
    flow_bytes_per_sec: float = _metric("flow_bytes_per_sec", "Flow bytes per second")
    flow_packets_per_sec: float = _metric("flow_packets_per_sec", "Flow packets per second")
    flow_iat_mean: float = _metric("flow_iat_mean", "Mean inter-arrival time (microseconds)")
    packet_length_mean: float = _metric("packet_length_mean", "Mean packet length")
    syn_count: float = _metric("syn_count", "SYN flag count")
    rst_count: float = _metric("rst_count", "RST flag count")
    ack_count: float = _metric("ack_count", "ACK flag count")
    average_packet_size: float = _metric("average_packet_size", "Average packet size")
    active_mean: float = _metric("active_mean", "Active time mean (microseconds)")
    idle_mean: float = _metric("idle_mean", "Idle time mean (microseconds)")

    @field_validator("flow_id")
    @classmethod
    def validate_flow_id(cls, v):
        if v in (None, ""):
            return None
        if not FLOW_ID_RE.match(v):
            raise ValueError("flow_id may only contain letters, digits and . _ : @ # | / -")
        return v

    @field_validator("source_ip", "destination_ip")
    @classmethod
    def validate_ip(cls, v: str) -> str:
        try:
            ipaddress.ip_address(v.strip())
            return v.strip()
        except ValueError:
            raise ValueError(f"Invalid IP address format: {v}")


class IncidentCreate(IncidentBase):
    pass


class ClassifyRequest(IncidentBase):
    """Classify-only: nothing is stored."""


class IncidentResponse(IncidentBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    flow_id: str
    attack_type: str
    ground_truth_label: Optional[str] = None
    original_label: Optional[str] = None
    label_source: str = "none"
    data_source: str = "user"
    predicted_attack_type: Optional[str] = None
    prediction_confidence: Optional[float] = None
    intrusion_probability: Optional[float] = None
    anomaly_score: Optional[float] = None
    risk_score: Optional[float] = None
    risk_level: str
    priority: str
    status: str
    created_at: datetime
    updated_at: datetime


class AttackPrediction(BaseModel):
    status: str = "ok"
    attack_type: str
    confidence: float
    suspicious: bool = False
    intrusion_probability: Optional[float] = None
    anomaly_score: Optional[float] = None
    low_confidence: bool = False
    top_classes: List[Dict[str, Any]] = []
    indicators: List[str] = []
    feature_importance: Optional[Dict[str, float]] = None
    explanation: Optional[Dict[str, Any]] = None
    model_version: Optional[str] = None


class RiskAssessment(BaseModel):
    risk_level: str
    priority: str
    risk_score: float = 0.0
    confidence: float = 0.0
    factors: List[str] = []
    anomaly_score: Optional[float] = None
    intrusion_probability: Optional[float] = None
    components: Dict[str, float] = {}


class HistoricalMatch(BaseModel):
    incident_id: int
    flow_id: str
    attack_type: str
    label_source: Optional[str] = None
    risk_level: Optional[str] = None
    similarity_score: Optional[float] = None
    hybrid_score: Optional[float] = None
    semantic_score: Optional[float] = None
    keyword_score: Optional[float] = None
    protocol: int
    destination_port: int
    destination_ip: Optional[str] = None
    source_ip: Optional[str] = None
    shared_characteristics: List[str] = []
    timestamp: Optional[str] = None


class AnalysisResponse(BaseModel):
    incident_id: int
    attack_prediction: AttackPrediction
    risk_assessment: RiskAssessment
    historical_matches: List[HistoricalMatch]
    analysis: str
    recommendations: List[str]
    llm_provider: str
    llm_model: Optional[str] = None
    llm_attempts: List[Dict[str, Any]] = []
    fallback_used: bool
    quality_checks: List[Dict[str, Any]] = []
    requires_analyst_review: bool = True
    ground_truth_label: Optional[str] = None
    label_mismatch: bool = False
    execution_trace: List[Dict[str, Any]]
    execution_time_ms: float
    trace_id: Optional[str] = None  # the observability trace of this investigation


class FeedbackCreate(BaseModel):
    feedback_type: str = Field(..., description="Correct | Incorrect | Partially Correct | Useful | Not Useful")
    actual_label: Optional[str] = Field(None, description="Analyst-confirmed attack family (required for Correct/Incorrect/Partially Correct)")
    analyst_feedback: Optional[str] = Field(None, max_length=2000)
    prediction: Optional[str] = Field(None, description="Ignored: the server records the model's actual prediction")


class FeedbackResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    incident_id: int
    username: Optional[str] = None
    prediction: str
    actual_label: str
    feedback_type: str
    analyst_feedback: Optional[str] = None
    applied: bool = False
    created_at: datetime


class StatusUpdate(BaseModel):
    status: str
