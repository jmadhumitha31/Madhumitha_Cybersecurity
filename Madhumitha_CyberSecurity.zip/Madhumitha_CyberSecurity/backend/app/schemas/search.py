from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field


class SearchFilters(BaseModel):
    attack_type: Optional[str] = None
    protocol: Optional[int] = Field(None, ge=0, le=255)
    source_ip: Optional[str] = None
    destination_ip: Optional[str] = None
    source_port: Optional[int] = Field(None, ge=0, le=65535)
    destination_port: Optional[int] = Field(None, ge=0, le=65535)
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    min_confidence: Optional[float] = Field(None, ge=0.0, le=1.0)


class SearchRequest(BaseModel):
    query: Optional[str] = Field(None, max_length=1000, description="Natural-language query or keywords")
    search_type: Literal["hybrid", "semantic", "keyword"] = "hybrid"
    filters: Optional[SearchFilters] = None
    top_k: int = Field(5, ge=1, le=50)
    similarity_threshold: Optional[float] = Field(None, ge=0.0, le=1.0, description="Minimum score; server default if omitted")


class SearchResultItem(BaseModel):
    incident_id: int
    flow_id: str
    attack_type: str
    label_source: Optional[str] = None
    risk_level: str
    priority: str
    source_ip: str
    destination_ip: str
    destination_port: int
    protocol: int
    timestamp: Optional[datetime] = None
    hybrid_score: float
    semantic_score: float
    keyword_score: float
    shared_characteristics: List[str]
    matched_features: Dict[str, Any]
    explanation: Optional[Dict[str, Any]] = None  # why this result: dense / BM25 breakdown and the query terms that matched


class SearchResponseData(BaseModel):
    total_matches: int
    results: List[SearchResultItem]
    query_applied: Optional[str]
    search_type_used: str
    filters_applied: Dict[str, Any]
    search_strategy: Dict[str, Any]
    similarity_threshold_used: Optional[float] = None
    message: Optional[str] = None
    trace_id: Optional[str] = None  # the trace recorded for this query (Observability page)
