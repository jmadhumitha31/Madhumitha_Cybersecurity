import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple

import bcrypt
import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.config import settings
from app.database.connection import get_db
from app.database.models import User
from app.observability.tracing import tracer

oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_PREFIX}/auth/login", auto_error=False)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    try:
        return bcrypt.checkpw(plain_password.encode("utf-8"), hashed_password.encode("utf-8"))
    except Exception:
        return False


def get_password_hash(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (expires_delta or timedelta(minutes=settings.JWT_EXPIRATION_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)


def get_current_user(token: Optional[str] = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    """Authenticated user or 401. There is deliberately no anonymous/default-user fallback."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    if not token:
        raise credentials_exception
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
        username = payload.get("sub")
        if not username:
            raise credentials_exception
    except jwt.PyJWTError:
        raise credentials_exception

    user = db.query(User).filter(User.username == username).first()
    if user is None:
        raise credentials_exception
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Account is disabled")
    tracer.set_user(user)  # attribute the current trace (if any) to the authenticated account
    return user  # role is always read from the database, never trusted from the token


def require_role(allowed_roles: List[str]):
    def role_checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Operation not permitted. Requires role in {allowed_roles}",
            )
        return current_user

    return role_checker


class LoginThrottle:
    """Per (username, client-ip) failed-login lockout to blunt password guessing against the API itself."""

    def __init__(self):
        self._fails: Dict[Tuple[str, str], List[float]] = {}
        self._lock = threading.Lock()

    def _recent(self, key: Tuple[str, str]) -> List[float]:
        cutoff = time.time() - settings.LOGIN_LOCK_SECONDS
        self._fails[key] = [t for t in self._fails.get(key, []) if t > cutoff]
        return self._fails[key]

    def blocked_for(self, username: str, ip: str) -> int:
        with self._lock:
            recent = self._recent((username.lower(), ip))
            if len(recent) >= settings.LOGIN_MAX_ATTEMPTS:
                return int(recent[0] + settings.LOGIN_LOCK_SECONDS - time.time()) + 1
            return 0

    def fail(self, username: str, ip: str) -> None:
        with self._lock:
            self._recent((username.lower(), ip)).append(time.time())

    def reset(self, username: str, ip: str) -> None:
        with self._lock:
            self._fails.pop((username.lower(), ip), None)


login_throttle = LoginThrottle()
