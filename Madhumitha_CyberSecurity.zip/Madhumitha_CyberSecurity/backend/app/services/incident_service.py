"""
Incident lifecycle: creation + automatic ML triage, analysis results, analyst feedback, and vector-index upkeep.

Key invariants (these fix the label-corruption bug of the previous version):
* ``ground_truth_label`` (dataset / analyst) is never overwritten by a model prediction;
* model outputs live in ``predicted_attack_type`` / ``prediction_confidence`` / ``intrusion_probability`` / ``anomaly_score``;
* ``attack_type`` is the classification in force: ground truth if known, otherwise the latest prediction;
* whenever ``attack_type`` changes the incident's embedding is regenerated so search never sees stale text.
"""
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional

from sqlalchemy.orm import Session

from app.database.models import Feedback, Incident, IncidentEmbedding, User, utcnow
from app.domain import CLASSES, FEEDBACK_TYPES, UNCLASSIFIED, normalize_label
from app.logging_config import logger
from app.ml.predictor import ml_predictor
from app.ml.risk import assess_confirmed_risk, assess_risk
from app.observability.tracing import tracer
from app.rag.embeddings import embedding_service
from app.rag.index import hybrid_index
from app.rag.text import build_incident_text, build_semantic_text

JUDGED_TYPES = {"Correct", "Incorrect", "Partially Correct"}
FLOW_COLUMNS = [c.name for c in Incident.__table__.columns]


def incident_to_flow(inc: Incident) -> Dict[str, Any]:
    d = {c: getattr(inc, c) for c in FLOW_COLUMNS}
    d["timestamp"] = inc.timestamp.isoformat() if inc.timestamp else None
    return d


# ---------------------------------------------------------------------------------------------------------
# embeddings
# ---------------------------------------------------------------------------------------------------------
def upsert_embeddings(db: Session, incidents: Iterable[Incident], batch_size: int = 128, commit: bool = True) -> int:
    incidents = list(incidents)
    model_id = embedding_service.identifier
    with tracer.span("index.upsert_embeddings", "retrieval", n_incidents=len(incidents), embedding_model=model_id,
                     text_version="behaviour-only dense text; full text for BM25"):
        return _upsert_embeddings(db, incidents, model_id, batch_size, commit)


def _upsert_embeddings(db: Session, incidents: List[Incident], model_id: str, batch_size: int, commit: bool) -> int:
    n = 0
    for i in range(0, len(incidents), batch_size):
        chunk = incidents[i : i + batch_size]
        flows = [incident_to_flow(inc) for inc in chunk]
        texts = [build_incident_text(f, include_label=True) for f in flows]          # full text: BM25 + display
        # Dense channel: behaviour only. Measured on CIC-IDS2017: adding the long attack-family sentence to documents (absent
        # from queries) dominated the embedding and cut dense-only precision@5 from 0.86 to 0.27. Labels stay in the BM25 text.
        vecs = embedding_service.embed_texts([build_semantic_text(f, include_label=False) for f in flows])
        existing = {
            e.incident_id: e
            for e in db.query(IncidentEmbedding).filter(IncidentEmbedding.incident_id.in_([c.id for c in chunk])).all()
        }
        for inc, text, vec in zip(chunk, texts, vecs):
            payload = [round(float(x), 6) for x in vec]
            emb = existing.get(inc.id)
            if emb:
                emb.embedding_vector, emb.text_representation = payload, text
                emb.embedding_model, emb.updated_at = model_id, utcnow()
            else:
                db.add(IncidentEmbedding(incident_id=inc.id, embedding_vector=payload, text_representation=text, embedding_model=model_id))
            n += 1
        db.flush()
    if commit:
        db.commit()
    hybrid_index.invalidate()
    return n


def reindex_all(db: Session) -> int:
    """Regenerate every embedding with the active embedding backend (after switching models/backends)."""
    total = 0
    last = 0
    while True:
        chunk = db.query(Incident).filter(Incident.id > last).order_by(Incident.id).limit(1000).all()
        if not chunk:
            break
        total += upsert_embeddings(db, chunk)
        last = chunk[-1].id
    logger.info(f"Re-indexed {total} incidents with {embedding_service.identifier}")
    return total


# ---------------------------------------------------------------------------------------------------------
# risk helpers
# ---------------------------------------------------------------------------------------------------------
def apply_risk(inc: Incident, risk: Dict[str, Any]) -> None:
    inc.risk_score = risk["risk_score"]
    inc.risk_level = risk["risk_level"]
    inc.priority = risk["priority"]


def recompute_risk_for_label(inc: Incident) -> None:
    """Risk for an incident whose class is known (ground truth): confidence 1.0 plus whatever model signals exist."""
    apply_risk(inc, assess_confirmed_risk(incident_to_flow(inc), inc.attack_type, inc.intrusion_probability, inc.anomaly_score))


# ---------------------------------------------------------------------------------------------------------
# creation + triage
# ---------------------------------------------------------------------------------------------------------
def triage_new_incident(inc: Incident) -> Dict[str, Any]:
    """Fast ML triage (no LLM/RAG): classification, intrusion probability, anomaly, risk and priority."""
    det = ml_predictor.predict_attack(incident_to_flow(inc), explain=False)
    if det.get("status") != "ok":
        inc.attack_type, inc.label_source = UNCLASSIFIED, "none"
        return det
    inc.predicted_attack_type = det["attack_type"]
    inc.prediction_confidence = det["confidence"]
    inc.intrusion_probability = det["intrusion_probability"]
    inc.anomaly_score = det["anomaly_score"]
    if not inc.ground_truth_label:
        inc.attack_type, inc.label_source = det["attack_type"], "model"
    risk = assess_risk(incident_to_flow(inc), det["attack_type"], det["confidence"], det["intrusion_probability"], det["anomaly_score"])
    apply_risk(inc, risk)
    return det


def create_incident(db: Session, data: Dict[str, Any], data_source: str = "user") -> Incident:
    allowed = {k: v for k, v in data.items() if k in FLOW_COLUMNS and k not in ("id", "attack_type", "ground_truth_label", "label_source")}
    if not allowed.get("flow_id"):
        allowed["flow_id"] = f"INC-{int(datetime.utcnow().timestamp() * 1000)}"
    allowed.setdefault("timestamp", utcnow())
    inc = Incident(**allowed, attack_type=UNCLASSIFIED, label_source="none", data_source=data_source, status="NEW")
    with tracer.span("incident.create", "db", flow_id=allowed["flow_id"], data_source=data_source):
        db.add(inc)
        db.flush()
    with tracer.span("incident.triage", "agent", note="classification, intrusion probability, anomaly score, risk and priority (no LLM)") as sp:
        triage_new_incident(inc)
        sp.set(attack_type=inc.attack_type, label_source=inc.label_source, risk_level=inc.risk_level, priority=inc.priority)
    db.flush()
    upsert_embeddings(db, [inc], commit=False)
    db.commit()
    db.refresh(inc)
    return inc


# ---------------------------------------------------------------------------------------------------------
# analysis results
# ---------------------------------------------------------------------------------------------------------
def apply_analysis(db: Session, inc: Incident, detection: Dict[str, Any], risk: Dict[str, Any]) -> None:
    """Store the latest model outputs. Ground truth is preserved; the classification only follows the model when
    nobody has confirmed a label."""
    relabelled = False
    if detection.get("status") == "ok":
        inc.predicted_attack_type = detection["attack_type"]
        inc.prediction_confidence = detection["confidence"]
        inc.intrusion_probability = detection.get("intrusion_probability")
        inc.anomaly_score = detection.get("anomaly_score")
        if not inc.ground_truth_label and inc.attack_type != detection["attack_type"]:
            inc.attack_type, inc.label_source = detection["attack_type"], "model"
            relabelled = True
    apply_risk(inc, risk)
    if inc.status == "NEW":
        inc.status = "INVESTIGATING"
    if relabelled:
        upsert_embeddings(db, [inc], commit=False)
    db.commit()


# ---------------------------------------------------------------------------------------------------------
# analyst feedback (the continuous-improvement loop)
# ---------------------------------------------------------------------------------------------------------
class FeedbackError(ValueError):
    pass


def apply_feedback(
    db: Session,
    inc: Incident,
    feedback_type: str,
    actual_label: Optional[str],
    analyst_feedback: Optional[str],
    user: User,
) -> Feedback:
    if feedback_type not in FEEDBACK_TYPES:
        raise FeedbackError(f"feedback_type must be one of {FEEDBACK_TYPES}")
    canonical = normalize_label(actual_label) if actual_label else None
    if feedback_type in JUDGED_TYPES and canonical is None:
        raise FeedbackError(f"actual_label must be one of {CLASSES} for '{feedback_type}' feedback")

    predicted = inc.predicted_attack_type or inc.attack_type
    fb = Feedback(
        incident_id=inc.id,
        user_id=user.id,
        username=user.username,
        prediction=predicted or UNCLASSIFIED,
        actual_label=canonical or inc.attack_type,
        analyst_feedback=(analyst_feedback or "")[:2000] or None,
        feedback_type=feedback_type,
        applied=False,
    )
    if feedback_type in JUDGED_TYPES:
        with tracer.span("feedback.relabel", "agent", feedback_type=feedback_type, predicted=predicted, analyst_label=canonical,
                         before={"attack_type": inc.attack_type, "label_source": inc.label_source, "risk_level": inc.risk_level, "status": inc.status}) as sp:
            inc.ground_truth_label = canonical
            inc.attack_type = canonical
            inc.label_source = "analyst"
            if canonical == "Benign" and predicted != "Benign":
                inc.status = "FALSE_POSITIVE"
            elif inc.status in ("NEW", "INVESTIGATING"):
                inc.status = "RESOLVED" if feedback_type == "Correct" else inc.status
            recompute_risk_for_label(inc)
            fb.applied = True
            sp.set(after={"attack_type": inc.attack_type, "label_source": inc.label_source, "risk_level": inc.risk_level, "status": inc.status},
                   agreed_with_model=canonical == predicted, becomes_retraining_evidence=True)
        db.add(fb)
        db.flush()
        # the label is now analyst-confirmed: re-embed so it becomes retrievable historical evidence
        upsert_embeddings(db, [inc], commit=False)
    else:
        db.add(fb)
    db.commit()
    db.refresh(fb)
    return fb
