#!/bin/sh
# Container entrypoint: wait for the database, bootstrap (users, models, incidents, index) once, then serve.
set -e

echo "[entrypoint] waiting for the database ..."
python - <<'PY'
import os, sys, time
from sqlalchemy import create_engine, text
url = os.environ.get("DATABASE_URL", "")
if url.startswith("sqlite"):
    sys.exit(0)
for i in range(60):
    try:
        with create_engine(url).connect() as c:
            c.execute(text("SELECT 1"))
        print("[entrypoint] database is reachable")
        sys.exit(0)
    except Exception as e:
        time.sleep(2)
print("[entrypoint] database never became reachable", file=sys.stderr)
sys.exit(1)
PY

ARGS=""
if [ "${BOOTSTRAP_DOWNLOAD:-false}" = "true" ]; then ARGS="--download"; fi
echo "[entrypoint] bootstrap ${ARGS}"
python scripts/bootstrap.py ${ARGS}

if [ "${UVICORN_WORKERS:-1}" != "1" ] && [ -z "${QDRANT_URL:-}" ]; then
    echo "[entrypoint] ERROR: the embedded (on-device) Qdrant store is locked to one process." >&2
    echo "[entrypoint]        Use UVICORN_WORKERS=1, or set QDRANT_URL to a Qdrant server." >&2
    exit 1
fi

echo "[entrypoint] starting API"
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers "${UVICORN_WORKERS:-1}"
