"""
One-command setup used by the Docker entrypoint and for local first runs.

    python scripts/bootstrap.py                # use whatever data is present
    python scripts/bootstrap.py --download     # fetch real CIC-IDS2017 (~240 MB) if no dataset is present

Steps (each idempotent): create tables -> seed users -> obtain data -> train models -> ingest incidents -> (re)index.
If no real dataset is available and --download is not given, a clearly-labelled *synthetic demo* dataset is generated
so the system still starts; every metric and UI banner then says "synthetic demo data".
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.config import settings  # noqa: E402
from app.database.connection import SessionLocal, init_db  # noqa: E402
from app.database.models import Incident, IncidentEmbedding  # noqa: E402
from app.logging_config import logger  # noqa: E402
from app.ml.dataset import discover_files, load_dataset  # noqa: E402
from app.ml.predictor import ml_predictor  # noqa: E402
from app.ml.training import DEFAULT_CAPS, train_bundle  # noqa: E402

HERE = os.path.dirname(__file__)


def _real_data_present() -> bool:
    return bool(discover_files(settings.DATASET_DIR))


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--download", action="store_true", help="download real CIC-IDS2017 if missing")
    p.add_argument("--no-ingest", action="store_true")
    args = p.parse_args()

    init_db()
    from seed_users import seed_default_users  # noqa: E402

    seed_default_users()

    source, data_path = "cicids2017", settings.DATASET_DIR
    if not _real_data_present():
        if args.download:
            logger.info("Downloading CIC-IDS2017 ...")
            from download_cicids2017 import main as download  # noqa: E402

            sys.argv = ["download_cicids2017.py"]
            download()
        if not _real_data_present():
            source = "synthetic-demo"
            data_path = os.path.join(settings.DATA_DIR, "synthetic_demo_sample.csv")
            if not os.path.exists(data_path):
                from generate_sample_dataset import generate_cicids_dataset  # noqa: E402

                generate_cicids_dataset(data_path, num_records=3000)
            logger.warning("=" * 78)
            logger.warning("NO REAL CIC-IDS2017 DATA FOUND - running on SYNTHETIC DEMO DATA. Metrics are NOT representative.")
            logger.warning("Run `python scripts/download_cicids2017.py` and re-run bootstrap with a fresh database for real data.")
            logger.warning("=" * 78)

    if not ml_predictor.is_loaded:
        logger.info(f"Training models on {source} data ...")
        df, report = load_dataset(data_path, max_per_label=DEFAULT_CAPS if source == "cicids2017" else None, source=source)
        train_bundle(df, dataset_source=source, trigger="bootstrap", metadata_extra={"load_report": report.to_dict()})
        ml_predictor.reload()

    db = SessionLocal()
    try:
        n = db.query(Incident).count()
    finally:
        db.close()
    if n == 0 and not args.no_ingest:
        from ingest_cicids2017 import ingest  # noqa: E402

        ingest(data_path, source=source)
    else:
        logger.info(f"{n} incidents already present; skipping ingestion")

    from app.services.incident_service import reindex_all  # noqa: E402
    from app.rag.embeddings import embedding_service  # noqa: E402

    db = SessionLocal()
    try:
        stale = db.query(IncidentEmbedding).filter(IncidentEmbedding.embedding_model != embedding_service.identifier).count()
        if stale:
            logger.info(f"Re-indexing {stale} stale embeddings ...")
            reindex_all(db)
    finally:
        db.close()
    logger.info("Bootstrap complete.")


if __name__ == "__main__":
    main()
