"""
Build (or repair) the retrieval index so the first search is instant.

    python scripts/build_index.py          # human-readable
    python scripts/build_index.py --json   # last line is a JSON summary (used by the setup script)

1. every incident gets an embedding with the active embedding model (the database rows are the system of record);
2. the on-device Qdrant collection is synchronised from those rows (only changed points are written);
3. a probe query proves the index answers.

If the sentence-embedding model cannot be downloaded (offline first run) the service degrades to the hashing fallback;
this script then reports ``semantic: false`` so the caller can warn that search has no semantic generalisation, and a later
run (with internet) replaces the vectors with real ones.

Run it while the API is stopped: the embedded Qdrant folder is locked to one process.
"""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.database.connection import SessionLocal, init_db  # noqa: E402
from app.database.models import Incident, IncidentEmbedding  # noqa: E402


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--json", action="store_true", help="print a JSON summary as the last line")
    args = p.parse_args()

    from app.rag.embeddings import embedding_service
    from app.rag.index import hybrid_index
    from app.services.incident_service import reindex_all

    t0 = time.time()
    init_db()
    db = SessionLocal()
    try:
        n_inc = db.query(Incident).count()
        embedding_service.warm_up()  # loads (and on first use downloads) the sentence-embedding model
        info = embedding_service.info()
        model_id = embedding_service.identifier
        embedded = db.query(IncidentEmbedding).filter(IncidentEmbedding.embedding_model == model_id).count()
        if n_inc and embedded < n_inc:
            print(f"Embedding {n_inc - embedded} incident(s) with {info['model']} ({info['backend']}) ...", flush=True)
            reindex_all(db)
            embedded = db.query(IncidentEmbedding).filter(IncidentEmbedding.embedding_model == model_id).count()
        hybrid_index.ensure(db)  # sync Qdrant from the embedding rows
        stats = hybrid_index.stats()
        probe = hybrid_index.search(db, "port scan reconnaissance probing many ports", top_k=3, threshold=0.0) if n_inc else []
        summary = {
            "incidents": n_inc, "embedded": embedded, "qdrant_points": stats.get("points"), "collection": stats.get("collection"),
            "store": f"{stats.get('mode')}: {stats.get('location')}", "embedding_backend": info["backend"], "embedding_model": info["model"],
            "semantic": bool(info["semantic"]), "probe_results": len(probe), "seconds": round(time.time() - t0, 1),
        }
    finally:
        db.close()
        hybrid_index.close()  # release the Qdrant folder lock before the API starts

    ok = summary["qdrant_points"] == summary["embedded"] == summary["incidents"] or summary["incidents"] == 0
    print(("Index ready: " if ok else "Index INCOMPLETE: ") + json.dumps(summary) if not args.json else json.dumps(summary), flush=True)
    return 0 if ok else 2


if __name__ == "__main__":
    sys.exit(main())
