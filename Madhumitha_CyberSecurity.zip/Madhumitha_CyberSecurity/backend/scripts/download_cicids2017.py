"""
Download real CIC-IDS2017 labelled flows (Parquet) from the public Hugging Face mirror
https://huggingface.co/datasets/bvsam/cic-ids-2017  (folder `traffic_labels/`, converted from the
official TrafficLabelling CSVs: includes Flow ID, IPs, ports and timestamps).

The default selection (~240 MB) covers every attack family named in the project brief:
FTP/SSH brute force, DoS (Hulk/GoldenEye/slowloris/Slowhttptest), Heartbleed, Web attacks,
Infiltration, Botnet, DDoS and Port Scan. Benign flows are present on every day.

Usage:
    python scripts/download_cicids2017.py            # default 7 files
    python scripts/download_cicids2017.py --all      # also Monday (mostly benign, 65 MB)
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.net import enable_system_trust_store  # noqa: E402

REPO_ID = "bvsam/cic-ids-2017"
DEFAULT_FILES = [
    "Tuesday-WorkingHours.pcap_ISCX.csv.parquet",
    "Wednesday-workingHours.pcap_ISCX.csv.parquet",
    "Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv.parquet",
    "Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv.parquet",
    "Friday-WorkingHours-Morning.pcap_ISCX.csv.parquet",
    "Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv.parquet",
    "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv.parquet",
]
MONDAY = "Monday-WorkingHours.pcap_ISCX.csv.parquet"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--all", action="store_true", help="also download Monday-WorkingHours (mostly benign)")
    parser.add_argument(
        "--dest",
        default=os.path.join(os.path.dirname(__file__), "..", "data", "cicids2017"),
        help="destination directory (default: backend/data/cicids2017)",
    )
    parser.add_argument("--check", action="store_true", help="only report which files are missing (exit 0 = complete, 1 = incomplete)")
    args = parser.parse_args()

    dest = os.path.abspath(args.dest)
    files = DEFAULT_FILES + ([MONDAY] if args.all else [])
    if args.check:
        missing = [n for n in files if not (os.path.exists(os.path.join(dest, n)) and os.path.getsize(os.path.join(dest, n)) > 1_000_000)]
        print(f"{len(files) - len(missing)}/{len(files)} dataset files present in {dest}")
        for n in missing:
            print(f"  missing: {n}")
        sys.exit(1 if missing else 0)

    enable_system_trust_store()  # corporate TLS interception: trust the OS certificate store
    from huggingface_hub import hf_hub_download

    os.makedirs(dest, exist_ok=True)

    for name in files:
        target = os.path.join(dest, name)
        if os.path.exists(target) and os.path.getsize(target) > 0:
            print(f"[skip] {name} already present")
            continue
        print(f"[get ] {name} ...", flush=True)
        path = hf_hub_download(
            repo_id=REPO_ID,
            repo_type="dataset",
            filename=f"traffic_labels/{name}",
            local_dir=dest,
        )
        # hf_hub_download keeps the repo sub-folder; flatten into dest for simpler globbing
        flat = os.path.join(dest, name)
        if os.path.abspath(path) != os.path.abspath(flat):
            os.replace(path, flat)
        print(f"[ok  ] {name}  {os.path.getsize(flat) / 1e6:.1f} MB")

    print(f"Done. Files are in {dest}")


if __name__ == "__main__":
    main()
