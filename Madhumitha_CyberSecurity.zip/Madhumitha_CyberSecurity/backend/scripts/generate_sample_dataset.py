﻿"""
Generates a SYNTHETIC demo dataset with the CIC-IDS2017 column layout.

THIS IS NOT REAL CIC-IDS2017 DATA. It exists only so the application can start (and the test-suite can run) on a
machine that does not have the real dataset. Per-class feature ranges are hand-written, so classes are trivially
separable and any metric computed on this data is NOT representative of real-world performance.
Use scripts/download_cicids2017.py for the real flows.
"""
import csv
import os
import random
from datetime import datetime, timedelta

ATTACK_PROFILES = {
    "Benign": {
        "ports": [80, 443, 53, 8080, 22],
        "protocols": [6, 17],
        "duration": (100, 500000),
        "fwd_pkts": (2, 30),
        "bwd_pkts": (2, 35),
        "pkt_len_mean": (40, 600),
        "pkt_size_avg": (50, 700),
        "bytes_sec": (100, 50000),
        "pkts_sec": (10, 500),
        "iat_mean": (100, 50000),
        "syn": (0, 1),
        "rst": (0, 0),
        "ack": (2, 40),
        "active_mean": (0, 10000),
        "idle_mean": (0, 50000),
        "weight": 35,
    },
    "DDoS": {
        "ports": [80, 443, 8080],
        "protocols": [6, 17],
        "duration": (1000, 50000),
        "fwd_pkts": (500, 8000),
        "bwd_pkts": (0, 5),
        "pkt_len_mean": (50, 200),
        "pkt_size_avg": (54, 210),
        "bytes_sec": (500000, 15000000),
        "pkts_sec": (5000, 80000),
        "iat_mean": (1, 50),
        "syn": (200, 5000),
        "rst": (0, 10),
        "ack": (0, 10),
        "active_mean": (500, 20000),
        "idle_mean": (0, 500),
        "weight": 15,
    },
    "DoS": {
        "ports": [80, 443, 8080],
        "protocols": [6],
        "duration": (200000, 12000000),
        "fwd_pkts": (50, 1500),
        "bwd_pkts": (1, 20),
        "pkt_len_mean": (100, 400),
        "pkt_size_avg": (110, 450),
        "bytes_sec": (10000, 500000),
        "pkts_sec": (50, 2000),
        "iat_mean": (1000, 50000),
        "syn": (10, 200),
        "rst": (1, 15),
        "ack": (5, 50),
        "active_mean": (10000, 200000),
        "idle_mean": (50000, 1000000),
        "weight": 12,
    },
    "Port Scan": {
        "ports": list(range(20, 1024, 25)) + [1433, 3306, 3389, 8080],
        "protocols": [6],
        "duration": (10, 5000),
        "fwd_pkts": (1, 4),
        "bwd_pkts": (0, 2),
        "pkt_len_mean": (0, 60),
        "pkt_size_avg": (0, 60),
        "bytes_sec": (0, 2000),
        "pkts_sec": (100, 5000),
        "iat_mean": (10, 500),
        "syn": (1, 4),
        "rst": (0, 2),
        "ack": (0, 1),
        "active_mean": (0, 500),
        "idle_mean": (0, 100),
        "weight": 12,
    },
    "Botnet": {
        "ports": [6667, 8080, 4444, 53, 80],
        "protocols": [6, 17],
        "duration": (50000, 2000000),
        "fwd_pkts": (10, 80),
        "bwd_pkts": (10, 80),
        "pkt_len_mean": (60, 300),
        "pkt_size_avg": (70, 320),
        "bytes_sec": (500, 20000),
        "pkts_sec": (5, 80),
        "iat_mean": (10000, 100000),
        "syn": (1, 3),
        "rst": (0, 1),
        "ack": (10, 80),
        "active_mean": (1000, 30000),
        "idle_mean": (50000, 500000),
        "weight": 8,
    },
    "Web Attack": {
        "ports": [80, 443, 8080],
        "protocols": [6],
        "duration": (5000, 150000),
        "fwd_pkts": (8, 50),
        "bwd_pkts": (5, 40),
        "pkt_len_mean": (300, 1400),
        "pkt_size_avg": (350, 1450),
        "bytes_sec": (2000, 80000),
        "pkts_sec": (20, 200),
        "iat_mean": (500, 10000),
        "syn": (1, 3),
        "rst": (0, 2),
        "ack": (8, 50),
        "active_mean": (500, 15000),
        "idle_mean": (0, 20000),
        "weight": 8,
    },
    "FTP/SSH Brute Force": {
        "ports": [21, 22],
        "protocols": [6],
        "duration": (20000, 300000),
        "fwd_pkts": (15, 120),
        "bwd_pkts": (10, 100),
        "pkt_len_mean": (40, 180),
        "pkt_size_avg": (50, 200),
        "bytes_sec": (1000, 40000),
        "pkts_sec": (50, 500),
        "iat_mean": (200, 5000),
        "syn": (5, 20),
        "rst": (2, 10),
        "ack": (15, 120),
        "active_mean": (1000, 25000),
        "idle_mean": (0, 10000),
        "weight": 6,
    },
    "Infiltration": {
        "ports": [443, 4444, 22, 8080],
        "protocols": [6],
        "duration": (100000, 5000000),
        "fwd_pkts": (20, 200),
        "bwd_pkts": (15, 180),
        "pkt_len_mean": (200, 900),
        "pkt_size_avg": (220, 950),
        "bytes_sec": (3000, 60000),
        "pkts_sec": (10, 150),
        "iat_mean": (5000, 40000),
        "syn": (1, 4),
        "rst": (0, 1),
        "ack": (20, 200),
        "active_mean": (5000, 80000),
        "idle_mean": (20000, 300000),
        "weight": 4,
    },
}

SRC_IPS = [
    "192.168.10.5", "192.168.10.8", "192.168.10.9", "192.168.10.14",
    "172.16.0.1", "172.16.0.5", "205.174.165.73", "185.190.140.2",
    "198.51.100.24", "203.0.113.88", "10.0.0.15", "10.0.0.42"
]

DST_IPS = [
    "192.168.10.50", "192.168.10.51", "192.168.10.1", "172.16.0.100",
    "205.174.165.80", "198.51.100.1", "10.0.0.1", "10.0.0.2"
]


def generate_cicids_dataset(output_path: str, num_records: int = 300):
    random.seed(42)
    categories = list(ATTACK_PROFILES.keys())
    weights = [ATTACK_PROFILES[c]["weight"] for c in categories]

    start_date = datetime(2026, 9, 1, 8, 0, 0)  # deliberately NOT 2017: synthetic data must not pass for the real capture

    fields = [
        "Flow ID", "Source IP", "Source Port", "Destination IP", "Destination Port",
        "Protocol", "Timestamp", "Flow Duration", "Total Forward Packets", "Total Backward Packets",
        "Total Length Forward", "Total Length Backward", "Flow Bytes/s", "Flow Packets/s",
        "Flow IAT Mean", "Packet Length Mean", "SYN count", "RST count", "ACK count",
        "Average Packet Size", "Active Mean", "Idle Mean", "Label"
    ]

    records = []
    for i in range(num_records):
        cat = random.choices(categories, weights=weights)[0]
        prof = ATTACK_PROFILES[cat]

        flow_id = f"CIC-{cat[:3].upper()}-{i+1:05d}"
        src_ip = random.choice(SRC_IPS)
        dst_ip = random.choice(DST_IPS)
        src_port = random.randint(1024, 65535)
        dst_port = random.choice(prof["ports"])
        protocol = random.choice(prof["protocols"])
        timestamp = (start_date + timedelta(minutes=random.randint(0, 14400))).strftime("%Y-%m-%d %H:%M:%S")

        duration = round(random.uniform(*prof["duration"]), 2)
        fwd_pkts = round(random.uniform(*prof["fwd_pkts"]), 1)
        bwd_pkts = round(random.uniform(*prof["bwd_pkts"]), 1)
        pkt_len_mean = round(random.uniform(*prof["pkt_len_mean"]), 2)
        pkt_size_avg = round(random.uniform(*prof["pkt_size_avg"]), 2)
        bytes_sec = round(random.uniform(*prof["bytes_sec"]), 2)
        pkts_sec = round(random.uniform(*prof["pkts_sec"]), 2)
        iat_mean = round(random.uniform(*prof["iat_mean"]), 2)
        syn = round(random.uniform(*prof["syn"]), 0)
        rst = round(random.uniform(*prof["rst"]), 0)
        ack = round(random.uniform(*prof["ack"]), 0)
        active_mean = round(random.uniform(*prof["active_mean"]), 2)
        idle_mean = round(random.uniform(*prof["idle_mean"]), 2)

        tot_len_fwd = round(fwd_pkts * pkt_len_mean * random.uniform(0.8, 1.2), 2)
        tot_len_bwd = round(bwd_pkts * pkt_len_mean * random.uniform(0.8, 1.2), 2)

        records.append({
            "Flow ID": flow_id,
            "Source IP": src_ip,
            "Source Port": src_port,
            "Destination IP": dst_ip,
            "Destination Port": dst_port,
            "Protocol": protocol,
            "Timestamp": timestamp,
            "Flow Duration": duration,
            "Total Forward Packets": fwd_pkts,
            "Total Backward Packets": bwd_pkts,
            "Total Length Forward": tot_len_fwd,
            "Total Length Backward": tot_len_bwd,
            "Flow Bytes/s": bytes_sec,
            "Flow Packets/s": pkts_sec,
            "Flow IAT Mean": iat_mean,
            "Packet Length Mean": pkt_len_mean,
            "SYN count": syn,
            "RST count": rst,
            "ACK count": ack,
            "Average Packet Size": pkt_size_avg,
            "Active Mean": active_mean,
            "Idle Mean": idle_mean,
            "Label": cat,
        })

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)

    print(f"Generated {len(records)} SYNTHETIC demo flow records (not real CIC-IDS2017) into {output_path}")


if __name__ == "__main__":
    generate_cicids_dataset(os.path.join(os.path.dirname(__file__), "..", "data", "synthetic_demo_sample.csv"), num_records=3000)

