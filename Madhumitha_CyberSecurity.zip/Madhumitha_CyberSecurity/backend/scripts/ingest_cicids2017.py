"""
Load CIC-IDS2017 flows into the incident database and build the retrieval index.

Design (keeps evaluation honest):
* the dataset is split with the same deterministic train/test split the model uses;
* the **knowledge base** (labelled historical incidents, status RESOLVED) is sampled from the *training* side;
* the **alerts** (status NEW, unlabelled) come from the *held-out* side and are triaged by the ML models on ingest,
  exactly like fresh detections: an analyst investigates them, gives feedback, and the feedback loop retrains.

Usage:
    python scripts/ingest_cicids2017.py                       # data/cicids2017/*.parquet, 600 KB incidents per class
    python scripts/ingest_cicids2017.py --reset               # wipe incidents first
    python scripts/ingest_cicids2017.py --data data/synthetic_demo_sample.csv --source synthetic-demo
"""
import argparse
import os
import sys
from typing import Optional

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.config import settings  # noqa: E402
from app.database.connection import SessionLocal, init_db  # noqa: E402
from app.database.models import AnalysisResult, Feedback, Incident, IncidentEmbedding  # noqa: E402
from app.domain import UNCLASSIFIED  # noqa: E402
from app.logging_config import logger  # noqa: E402
from app.ml.dataset import load_dataset, split_train_test  # noqa: E402
from app.ml.predictor import ml_predictor  # noqa: E402
from app.ml.risk import assess_confirmed_risk, assess_risk  # noqa: E402
from app.ml.training import DEFAULT_CAPS  # noqa: E402
from app.services.incident_service import apply_risk, upsert_embeddings  # noqa: E402

FEATURES = [
    "flow_duration", "total_fwd_packets", "total_bwd_packets", "total_length_fwd", "total_length_bwd", "flow_bytes_per_sec",
    "flow_packets_per_sec", "flow_iat_mean", "packet_length_mean", "syn_count", "rst_count", "ack_count", "average_packet_size",
    "active_mean", "idle_mean",
]


def _row_kwargs(row: pd.Series, keep_original_label: bool = True) -> dict:
    """Incident columns for one dataset row. Alerts (the unlabelled detections an analyst investigates) must not carry
    the dataset's original label: it would hand the ground truth to anyone reading the API/UI."""
    kw = {f: float(row[f]) for f in FEATURES}
    ts = row["timestamp"]
    kw.update(
        flow_id=str(row["flow_id"]), source_ip=str(row["source_ip"]), source_port=int(row["source_port"]),
        destination_ip=str(row["destination_ip"]), destination_port=int(row["destination_port"]), protocol=int(row["protocol"]),
        timestamp=None if pd.isna(ts) else ts.to_pydatetime(), original_label=str(row["original_label"]) if keep_original_label else None,
    )
    return kw


def _sample(df: pd.DataFrame, per_class: int, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    parts = []
    for _, grp in df.groupby("attack_type"):
        parts.append(grp if len(grp) <= per_class else grp.iloc[rng.choice(len(grp), size=per_class, replace=False)])
    return pd.concat(parts) if parts else df.iloc[0:0]


def ingest(path: Optional[str] = None, source: str = "cicids2017", kb_per_class: int = 600, alerts_per_class: int = 12, reset: bool = False, seed: int = 11) -> dict:
    path = path or settings.DATASET_DIR
    init_db()
    db = SessionLocal()
    try:
        if reset:
            for model in (Feedback, AnalysisResult, IncidentEmbedding, Incident):
                db.query(model).delete()
            db.commit()
            logger.info("Existing incidents, embeddings, analyses and feedback deleted (--reset)")

        df, report = load_dataset(path, max_per_label=DEFAULT_CAPS if source == "cicids2017" else None, source=source)
        df = df.reset_index(drop=True)
        test_mask = split_train_test(df)
        kb = _sample(df[~test_mask], kb_per_class, seed)
        alerts = _sample(df[test_mask], alerts_per_class, seed + 1)

        existing = {r[0] for r in db.query(Incident.flow_id).all()}
        kb, alerts = kb[~kb["flow_id"].isin(existing)], alerts[~alerts["flow_id"].isin(existing)]
        logger.info(f"Ingesting {len(kb)} labelled knowledge-base incidents and {len(alerts)} held-out alerts ({len(existing)} already present)")

        # model scores for risk (intrusion probability / anomaly) - the KB keeps its ground-truth class
        kb_scores = ml_predictor.predict_batch(kb) if ml_predictor.is_loaded else None
        al_scores = ml_predictor.predict_batch(alerts) if ml_predictor.is_loaded else None

        new_incidents = []
        for idx, row in kb.iterrows():
            inc = Incident(**_row_kwargs(row), attack_type=row["attack_type"], ground_truth_label=row["attack_type"], label_source="dataset",
                           data_source=source, status="RESOLVED")
            if kb_scores is not None:
                inc.intrusion_probability = float(kb_scores.at[idx, "intrusion_probability"])
                inc.anomaly_score = float(kb_scores.at[idx, "anomaly_score"])
            apply_risk(inc, assess_confirmed_risk(_row_kwargs(row), row["attack_type"], inc.intrusion_probability, inc.anomaly_score))
            new_incidents.append(inc)

        for idx, row in alerts.iterrows():
            inc = Incident(**_row_kwargs(row, keep_original_label=False), attack_type=UNCLASSIFIED, label_source="none", data_source=source, status="NEW")
            if al_scores is not None:
                s = al_scores.loc[idx]
                inc.predicted_attack_type, inc.prediction_confidence = s["predicted_attack_type"], float(s["prediction_confidence"])
                inc.intrusion_probability, inc.anomaly_score = float(s["intrusion_probability"]), float(s["anomaly_score"])
                inc.attack_type, inc.label_source = inc.predicted_attack_type, "model"
                flow = _row_kwargs(row) | {"destination_port": row["destination_port"]}
                apply_risk(inc, assess_risk(flow, inc.attack_type, inc.prediction_confidence, inc.intrusion_probability, inc.anomaly_score))
            new_incidents.append(inc)

        for i in range(0, len(new_incidents), 500):
            db.add_all(new_incidents[i : i + 500])
            db.commit()
            logger.info(f"  inserted {min(i + 500, len(new_incidents))}/{len(new_incidents)}")

        logger.info("Generating embeddings (this loads the sentence-embedding model on first use) ...")
        n_emb = 0
        for i in range(0, len(new_incidents), 512):
            n_emb += upsert_embeddings(db, new_incidents[i : i + 512])
            logger.info(f"  embedded {n_emb}/{len(new_incidents)}")

        summary = {
            "knowledge_base_incidents": int(len(kb)), "alerts": int(len(alerts)), "embedded": n_emb, "source": source,
            "kb_class_counts": kb["attack_type"].value_counts().to_dict(), "alert_class_counts_hidden_from_ui": alerts["attack_type"].value_counts().to_dict(),
            "load_report": {k: v for k, v in report.to_dict().items() if k in ("rows_read", "rows_dropped_invalid", "rows_dropped_duplicates", "files")},
        }
        logger.info(f"Ingestion complete: {summary['knowledge_base_incidents']} KB + {summary['alerts']} alerts")
        return summary
    finally:
        db.close()


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--data", default=None, help="file or directory (default: backend/data/cicids2017)")
    p.add_argument("--source", default="cicids2017", help="data_source tag (cicids2017 | synthetic-demo)")
    p.add_argument("--kb-per-class", type=int, default=600)
    p.add_argument("--alerts-per-class", type=int, default=12)
    p.add_argument("--reset", action="store_true", help="delete existing incidents first")
    a = p.parse_args()
    out = ingest(a.data, a.source, a.kb_per_class, a.alerts_per_class, a.reset)
    print(out)


if __name__ == "__main__":
    main()
