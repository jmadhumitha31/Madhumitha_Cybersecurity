"""Recompute risk score / level / priority for every incident with the current risk policy (after changing app/ml/risk.py)."""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.database.connection import SessionLocal, init_db  # noqa: E402
from app.database.models import Incident  # noqa: E402
from app.ml.risk import assess_confirmed_risk, assess_risk  # noqa: E402
from app.services.incident_service import apply_risk, incident_to_flow  # noqa: E402


def main() -> None:
    init_db()
    db = SessionLocal()
    n = 0
    try:
        for inc in db.query(Incident).yield_per(500):
            flow = incident_to_flow(inc)
            if inc.label_source in ("dataset", "analyst") and inc.ground_truth_label:
                risk = assess_confirmed_risk(flow, inc.ground_truth_label, inc.intrusion_probability, inc.anomaly_score)
            elif inc.prediction_confidence is not None and inc.predicted_attack_type:
                risk = assess_risk(flow, inc.predicted_attack_type, inc.prediction_confidence, inc.intrusion_probability, inc.anomaly_score)
            else:
                continue
            apply_risk(inc, risk)
            n += 1
        db.commit()
    finally:
        db.close()
    print(f"Recomputed risk for {n} incidents")


if __name__ == "__main__":
    main()
