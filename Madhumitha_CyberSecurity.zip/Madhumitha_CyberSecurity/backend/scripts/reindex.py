"""Regenerate every incident embedding with the active embedding model/text representation."""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.database.connection import SessionLocal, init_db  # noqa: E402
from app.services.incident_service import reindex_all  # noqa: E402

if __name__ == "__main__":
    init_db()
    db = SessionLocal()
    try:
        print(f"Re-indexed {reindex_all(db)} incidents")
    finally:
        db.close()
