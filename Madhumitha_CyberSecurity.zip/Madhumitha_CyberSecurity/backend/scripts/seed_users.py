import os
import secrets
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.config import settings  # noqa: E402
from app.database.connection import SessionLocal, init_db  # noqa: E402
from app.database.models import User  # noqa: E402
from app.logging_config import logger  # noqa: E402
from app.services.auth_service import get_password_hash  # noqa: E402

# Documented demo credentials: used ONLY outside production. In production passwords must be supplied via
# SEED_ADMIN_PASSWORD / SEED_ANALYST_PASSWORD / SEED_VIEWER_PASSWORD (or are randomly generated and printed once).
DEMO = {"admin": ("admin@soc.corp", "ADMIN", "admin123!"), "analyst": ("analyst@soc.corp", "ANALYST", "analyst123!"), "viewer": ("viewer@soc.corp", "VIEWER", "viewer123!")}


def seed_default_users() -> None:
    init_db()
    db = SessionLocal()
    try:
        for username, (email, role, demo_pw) in DEMO.items():
            if db.query(User).filter(User.username == username).first():
                logger.info(f"User already exists: {username}")
                continue
            pw = os.getenv(f"SEED_{username.upper()}_PASSWORD")
            if not pw:
                if settings.is_production:
                    pw = secrets.token_urlsafe(14)
                    print(f"[seed] generated password for {username}: {pw}  (shown once)")
                else:
                    pw = demo_pw
            db.add(User(username=username, email=email, hashed_password=get_password_hash(pw), role=role, is_active=True))
            logger.info(f"Seeded user: {username} ({role})")
        db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    seed_default_users()
