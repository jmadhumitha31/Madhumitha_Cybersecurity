"""
Test fixtures. Everything runs against a throw-away database and model directory - the tests can no longer
write into the real `soc_assistant.db` (the previous suite polluted the knowledge base with TEST-* incidents).

Environment is configured BEFORE the application is imported so `app.config.settings` picks it up.
"""
import os
import sys
import tempfile

_TMP = tempfile.mkdtemp(prefix="soc_tests_")
os.environ.update(
    {
        "DATABASE_URL": f"sqlite:///{_TMP.replace(chr(92), '/')}/test.db",
        "MODEL_DIR": os.path.join(_TMP, "models"),
        "DATASET_DIR": os.path.join(_TMP, "no_dataset_here"),
        "DATA_DIR": os.path.join(_TMP, "data"),
        "QDRANT_PATH": os.path.join(_TMP, "qdrant"),  # real on-disk embedded Qdrant, isolated from the application's index
        "EMBEDDING_BACKEND": "hashing",          # offline + fast; the real model is covered by an opt-in test
        "NVIDIA_API_KEY": "",
        "OLLAMA_BASE_URL": "http://127.0.0.1:9",  # nothing listens here
        "ENVIRONMENT": "test",
        "JWT_SECRET": "unit-test-secret-" + "x" * 40,
        "SIMILARITY_THRESHOLD": "0.3",
        "TEXT_SEARCH_THRESHOLD": "0.05",
    }
)
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "scripts")))

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.config import settings  # noqa: E402


@pytest.fixture(scope="session")
def bootstrapped():
    """Synthetic demo data -> trained models -> seeded users -> ingested incidents (small and quick)."""
    from app.database.connection import init_db
    from app.ml.dataset import load_dataset
    from app.ml.predictor import ml_predictor
    from app.ml.training import train_bundle
    from generate_sample_dataset import generate_cicids_dataset
    from ingest_cicids2017 import ingest
    from seed_users import seed_default_users

    init_db()
    seed_default_users()
    csv_path = os.path.join(_TMP, "synthetic.csv")
    generate_cicids_dataset(csv_path, num_records=1500)
    df, _ = load_dataset(csv_path, source="synthetic-demo")
    train_bundle(df, dataset_source="synthetic-demo", trigger="test", n_estimators=40, cv_folds=0, global_shap_per_class=8, save_dir=settings.MODEL_DIR)
    assert ml_predictor.reload()
    ingest(csv_path, source="synthetic-demo", kb_per_class=60, alerts_per_class=3)
    return csv_path


@pytest.fixture(scope="session")
def client(bootstrapped):
    from app.main import app

    with TestClient(app, raise_server_exceptions=False) as c:
        yield c


def _login(client: TestClient, username: str, password: str) -> dict:
    r = client.post("/api/v1/auth/login", json={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['data']['access_token']}"}


@pytest.fixture(scope="session")
def admin(client):
    return _login(client, "admin", "admin123!")


@pytest.fixture(scope="session")
def analyst(client):
    return _login(client, "analyst", "analyst123!")


@pytest.fixture(scope="session")
def viewer(client):
    return _login(client, "viewer", "viewer123!")


# a clearly malicious-looking flow used across tests
SCAN_FLOW = {
    "source_ip": "172.16.0.1", "source_port": 40000, "destination_ip": "192.168.10.50", "destination_port": 445, "protocol": 6,
    "flow_duration": 40.0, "total_fwd_packets": 1.0, "total_bwd_packets": 1.0, "total_length_fwd": 0.0, "total_length_bwd": 0.0,
    "flow_bytes_per_sec": 0.0, "flow_packets_per_sec": 40000.0, "flow_iat_mean": 40.0, "packet_length_mean": 0.0,
    "syn_count": 0.0, "rst_count": 0.0, "ack_count": 0.0, "average_packet_size": 0.0, "active_mean": 0.0, "idle_mean": 0.0,
}
