import uuid


def test_requests_without_token_are_rejected(client):
    """Regression: a missing token used to silently authenticate as ANALYST."""
    for path in ("/api/v1/auth/me", "/api/v1/incidents", "/api/v1/analytics/overview", "/api/v1/evaluation/runs"):
        assert client.get(path).status_code == 401, path
    assert client.post("/api/v1/incidents", json={}).status_code == 401


def test_invalid_token_rejected(client):
    assert client.get("/api/v1/auth/me", headers={"Authorization": "Bearer not.a.jwt"}).status_code == 401


def test_register_requires_admin_and_validates_role(client, analyst, admin):
    body = {"username": "u" + uuid.uuid4().hex[:6], "email": "x@example.com", "password": "longenough1", "role": "ADMIN"}
    assert client.post("/api/v1/auth/register", json=body).status_code == 401           # anonymous
    assert client.post("/api/v1/auth/register", json=body, headers=analyst).status_code == 403  # analyst
    bad_role = {**body, "role": "SUPERUSER"}
    assert client.post("/api/v1/auth/register", json=bad_role, headers=admin).status_code == 422
    ok = client.post("/api/v1/auth/register", json=body, headers=admin)
    assert ok.status_code == 201 and ok.json()["data"]["role"] == "ADMIN"


def test_public_signup_disabled_by_default(client):
    r = client.post("/api/v1/auth/signup", json={"username": "newbie1", "email": "n@example.com", "password": "longenough1"})
    assert r.status_code == 403


def test_viewer_is_read_only(client, viewer):
    assert client.get("/api/v1/incidents", headers=viewer).status_code == 200
    r = client.post("/api/v1/incidents", headers=viewer, json={"source_ip": "1.1.1.1", "source_port": 1, "destination_ip": "2.2.2.2", "destination_port": 80, "protocol": 6})
    assert r.status_code == 403


def test_login_throttle_locks_after_repeated_failures(client):
    name = "ghost" + uuid.uuid4().hex[:4]
    codes = [client.post("/api/v1/auth/login", json={"username": name, "password": "wrong"}).status_code for _ in range(7)]
    assert codes[0] == 401 and 429 in codes


def test_audit_log_is_admin_only(client, admin, analyst):
    assert client.get("/api/v1/audit", headers=analyst).status_code == 403
    r = client.get("/api/v1/audit?page_size=5", headers=admin)
    assert r.status_code == 200 and r.json()["data"]["total"] > 0
