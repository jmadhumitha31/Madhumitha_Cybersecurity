"""The loader must understand the *real* CIC-IDS2017 layout (the old one silently zeroed 6 of 17 features)."""
import numpy as np
import pandas as pd
import pytest

from app.domain import normalize_label
from app.ml.dataset import load_dataset, normalize_frame, split_train_test
from app.ml.preprocessing import FEATURE_COLUMNS

# header spelling taken from the project brief / official TrafficLabelling CSVs (note the leading spaces)
REAL_HEADERS = [
    "Flow ID", " Source IP", " Source Port", " Destination IP", " Destination Port", " Protocol", " Timestamp", " Flow Duration",
    " Total Fwd Packets", " Total Backward Packets", "Total Length of Fwd Packets", " Total Length of Bwd Packets", "Flow Bytes/s", " Flow Packets/s",
    " Flow IAT Mean", " Packet Length Mean", " SYN Flag Count", " RST Flag Count", " ACK Flag Count", " Average Packet Size", "Active Mean", " Idle Mean", " Label",
]


def _frame(rows):
    return pd.DataFrame(rows, columns=REAL_HEADERS)


def _row(label, i=0, **over):
    base = {
        "Flow ID": f"10.0.0.{i}-10.0.0.9-{40000 + i}-80-6", " Source IP": f"10.0.0.{i}", " Source Port": 40000 + i, " Destination IP": "10.0.0.9", " Destination Port": 80,
        " Protocol": 6, " Timestamp": "7/7/2017 8:59", " Flow Duration": 1000 + i, " Total Fwd Packets": 3, " Total Backward Packets": 2, "Total Length of Fwd Packets": 100,
        " Total Length of Bwd Packets": 200, "Flow Bytes/s": 300.0, " Flow Packets/s": 5.0, " Flow IAT Mean": 10.0, " Packet Length Mean": 50.0, " SYN Flag Count": 1,
        " RST Flag Count": 0, " ACK Flag Count": 1, " Average Packet Size": 60.0, "Active Mean": 0.0, " Idle Mean": 0.0, " Label": label,
    }
    base.update(over)
    return base


@pytest.mark.parametrize(
    "raw,expected",
    [("BENIGN", "Benign"), ("DoS Hulk", "DoS"), ("DoS GoldenEye", "DoS"), ("DoS slowloris", "DoS"), ("DoS Slowhttptest", "DoS"), ("DDoS", "DDoS"),
     ("PortScan", "Port Scan"), ("FTP-Patator", "FTP/SSH Brute Force"), ("SSH-Patator", "FTP/SSH Brute Force"), ("Bot", "Botnet"),
     ("Web Attack \x96 Brute Force", "Web Attack"), ("Web Attack – XSS", "Web Attack"), ("Web Attack  Sql Injection", "Web Attack"),
     ("Infiltration", "Infiltration"), ("Heartbleed", "Heartbleed"), ("Port Scan", "Port Scan"), ("Something New", None)],
)
def test_label_mapping(raw, expected):
    assert normalize_label(raw) == expected


def test_real_headers_are_recognised_and_no_feature_is_zeroed():
    df = normalize_frame(_frame([_row("DoS Hulk", i) for i in range(3)]))
    assert set(FEATURE_COLUMNS) <= set(df.columns)
    for col in ("total_fwd_packets", "total_length_fwd", "total_length_bwd", "syn_count", "rst_count", "ack_count"):
        assert df[col].abs().sum() > 0 or col == "rst_count", col
    assert (df["attack_type"] == "DoS").all() and (df["original_label"] == "DoS Hulk").all()
    assert str(df["timestamp"].iloc[0]).startswith("2017-07-07")


def test_cleaning_drops_inf_nan_negative_and_unknown_labels():
    from app.ml.dataset import LoadReport

    rep = LoadReport()
    raw = _frame([_row("BENIGN", 1), _row("BENIGN", 2, **{"Flow Bytes/s": np.inf}), _row("BENIGN", 3, **{" Flow Packets/s": np.nan}),
                  _row("BENIGN", 4, **{" Flow Duration": -1}), _row("Totally Unknown", 5)])
    df = normalize_frame(raw, report=rep)
    assert len(df) == 1 and rep.rows_dropped_invalid == 3 and rep.unknown_labels == {"Totally Unknown": 1}


def test_missing_metadata_columns_are_refused_unless_allowed():
    raw = _frame([_row("BENIGN")]).drop(columns=["Flow ID", " Source IP"])
    with pytest.raises(ValueError, match="flow metadata"):
        normalize_frame(raw)
    df = normalize_frame(raw, allow_missing_metadata=True)
    assert df["source_ip"].iloc[0] == "0.0.0.0"


def test_missing_feature_column_is_an_error_not_silent_zeros():
    raw = _frame([_row("BENIGN")]).drop(columns=[" SYN Flag Count"])
    with pytest.raises(ValueError, match="syn_count"):
        normalize_frame(raw)


@pytest.mark.parametrize("fmt", ["csv", "parquet"])
def test_load_dataset_from_files_dedups_and_caps(tmp_path, fmt):
    rows = [_row("BENIGN", i) for i in range(40)] + [_row("PortScan", 100 + i) for i in range(30)] + [_row("Heartbleed", 200 + i) for i in range(3)]
    rows.append(rows[0])  # exact duplicate
    f = _frame(rows)
    path = tmp_path / f"day.{fmt}"
    (f.to_csv(path, index=False, encoding="latin-1") if fmt == "csv" else f.to_parquet(path, index=False))
    df, rep = load_dataset(str(path), max_per_label={"BENIGN": 10})
    counts = df["attack_type"].value_counts().to_dict()
    assert counts["Benign"] == 10 and counts["Port Scan"] == 30 and counts["Heartbleed"] == 3  # rare classes kept in full
    assert df["flow_id"].is_unique and rep.rows_dropped_duplicates >= 1


def test_split_is_deterministic_and_gives_every_class_a_test_row():
    rows = [_row("BENIGN", i) for i in range(60)] + [_row("Heartbleed", 300 + i) for i in range(4)]
    df = normalize_frame(_frame(rows))
    m1, m2 = split_train_test(df), split_train_test(df.sample(frac=1, random_state=3).sort_index())
    assert m1.equals(m2)
    assert m1[df["attack_type"] == "Heartbleed"].any() and (~m1[df["attack_type"] == "Heartbleed"]).any()
