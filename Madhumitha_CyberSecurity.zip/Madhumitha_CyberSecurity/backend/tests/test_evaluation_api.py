"""Evaluation honesty: when a judge LLM is unavailable the API says so and returns NO scores (no invented numbers)."""
import json
import time

import httpx
import pytest

from app.config import settings
from app.llm.fallback import llm_fallback_handler
from app.evaluation.judge_utils import clamp01, extract_json_object

from conftest import SCAN_FLOW


def _analysed_incident(client, headers):
    inc = client.post("/api/v1/incidents", json={**SCAN_FLOW, "flow_id": f"EV-{time.time_ns()}"}, headers=headers).json()["data"]
    assert client.post(f"/api/v1/incidents/{inc['id']}/analyze", headers=headers).status_code == 200
    return inc


def test_judge_without_llm_returns_unavailable_and_no_scores(client, analyst):
    inc = _analysed_incident(client, analyst)
    r = client.post(f"/api/v1/evaluation/judge?incident_id={inc['id']}", headers=analyst)
    body = r.json()
    assert body["success"] is False
    d = body["data"]
    assert d["status"] == "unavailable" and d["scores"] is None
    assert "reasoning_quality" not in json.dumps(d)       # the old code fabricated reasoning_quality=0.89 here


def test_judge_batch_without_llm_is_unavailable(client, analyst):
    d = client.post("/api/v1/evaluation/judge/batch?limit=2", headers=analyst).json()["data"]
    assert d["status"] == "unavailable" and d["n_scored"] == 0


def test_deepeval_without_llm_is_unavailable_with_no_scores(client, analyst):
    _analysed_incident(client, analyst)
    r = client.post("/api/v1/evaluation/deepeval?limit=2", headers=analyst)
    assert r.status_code == 202
    for _ in range(60):
        d = client.get("/api/v1/evaluation/deepeval", headers=analyst).json()["data"]
        if d.get("run_status") != "running":
            break
        time.sleep(0.5)
    assert d["run_status"] == "unavailable" and d["status"] == "unavailable"
    for k in ("answer_relevancy", "faithfulness", "hallucination", "groundedness"):
        assert k not in d, k                                    # no invented 0.94 groundedness / baseline arrays


def test_judge_with_mocked_independent_llm(client, analyst, monkeypatch):
    inc = _analysed_incident(client, analyst)
    monkeypatch.setattr(settings, "NVIDIA_API_KEY", "nvapi-test")
    monkeypatch.setattr(settings, "JUDGE_MODEL", "judge/model")
    monkeypatch.setattr(settings, "JUDGE_FALLBACK_MODELS", "")
    verdict = {"correctness": 0.8, "relevance": 0.7, "reasoning_quality": 0.6, "recommendation_quality": 0.9, "verdict": "NEEDS_REVIEW",
               "critique": "ok", "unsupported_claims": []}

    def respond(request):
        assert json.loads(request.content)["model"] == "judge/model"
        return httpx.Response(200, json={"choices": [{"message": {"content": "```json\n" + json.dumps(verdict) + "\n```"}, "finish_reason": "stop"}]})

    monkeypatch.setattr(llm_fallback_handler.nvidia, "_client", httpx.Client(transport=httpx.MockTransport(respond)))
    d = client.post(f"/api/v1/evaluation/judge?incident_id={inc['id']}", headers=analyst).json()["data"]
    assert d["status"] == "ok" and d["scores"]["correctness"] == 0.8 and d["scores"]["verdict"] == "NEEDS_REVIEW"
    assert d["judge_model"] == "judge/model" and d["independent"] is True   # judge differs from the generator


def test_judge_repairs_then_gives_up_without_inventing_scores(client, analyst, monkeypatch):
    inc = _analysed_incident(client, analyst)
    monkeypatch.setattr(settings, "NVIDIA_API_KEY", "nvapi-test")
    monkeypatch.setattr(llm_fallback_handler.nvidia, "_client", httpx.Client(transport=httpx.MockTransport(
        lambda req: httpx.Response(200, json={"choices": [{"message": {"content": "I think it is fine."}, "finish_reason": "stop"}]}))))
    d = client.post(f"/api/v1/evaluation/judge?incident_id={inc['id']}", headers=analyst).json()["data"]
    assert d["status"] == "parse_failed" and d["scores"] is None


def test_deepeval_integration_matches_installed_library():
    """Regression: DeepEval 4.x rejected `_log_metric_to_confident`, making every metric fail in a live run."""
    from deepeval.metrics import AnswerRelevancyMetric, FaithfulnessMetric, GEval, HallucinationMetric
    from deepeval.test_case import LLMTestCaseParams
    from app.evaluation.deepeval_eval import _make_judge, measure_kwargs

    judge = _make_judge()
    assert judge.get_model_name().startswith("NIM judge")
    metrics = [
        AnswerRelevancyMetric(model=judge, async_mode=False), FaithfulnessMetric(model=judge, async_mode=False),
        HallucinationMetric(model=judge, async_mode=False),
        GEval(name="x", criteria="y", evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT], model=judge, async_mode=False),
    ]
    import inspect
    for m in metrics:
        accepted = set(inspect.signature(m.measure).parameters)
        assert set(measure_kwargs(m)) <= accepted, type(m).__name__          # never pass an argument the library lacks
    # custom judge contract: raw JSON text back from generate(), with or without a schema argument
    assert "generate" in dir(judge) and "a_generate" in dir(judge)


def test_hallucination_direction_probe_is_thread_safe():
    """Regression: probing inside worker threads (warnings.catch_warnings is not thread-safe) returned the wrong
    direction, so a 'no hallucination' score of 1.0 was reported as a 100% hallucination rate."""
    from concurrent.futures import ThreadPoolExecutor
    from deepeval.metrics import HallucinationMetric
    from app.evaluation import deepeval_eval

    HallucinationMetric(model=deepeval_eval._make_judge(), async_mode=False)   # consumes the library's once-per-process warning
    deepeval_eval._direction_cache.clear()
    with ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(lambda _: deepeval_eval.hallucination_higher_is_better(), range(12)))
    assert len(set(results)) == 1 and results[0] is True      # DeepEval 4.x: 1 = pass, so the rate must be 1 - score
    assert len(deepeval_eval._direction_cache) == 1           # probed once, then cached


def test_json_extraction_helpers():
    assert extract_json_object('noise ```json\n{"a": 1, "b": [1,2,]}\n``` tail') == {"a": 1, "b": [1, 2]}
    assert extract_json_object("no json here") is None
    assert clamp01(7) == 0.7 and clamp01(0.5) == 0.5 and clamp01(50) == 1.0   # 0-10 judge scales are normalised, absurd values clipped
    assert clamp01("x") is None and clamp01(-3) == 0.0 and clamp01(float("nan")) is None


def test_ml_evaluation_reports_provenance_and_synthetic_flag(client, analyst):
    d = client.get("/api/v1/evaluation/ml", headers=analyst).json()["data"]
    assert d["status"] == "ok" and d["dataset_source"] == "synthetic-demo" and d["synthetic"] is True
    assert d["n_test"] > 0 and d["per_class_metrics"] and d["intrusion_model"] and d["anomaly_model"]


def test_retrieval_evaluation_runs_and_beats_random(client, analyst):
    r = client.post("/api/v1/evaluation/retrieval", headers=analyst)
    d = r.json()["data"]
    assert r.status_code == 200 and d["status"] == "ok"
    assert d["with_endpoints"]["hybrid"]["precision_at_5"] > d["random_retrieval_precision"]
    assert set(d["with_endpoints"]) >= {"hybrid", "semantic_only", "keyword_only", "threshold_sweep", "per_class_precision_at_k"}
    assert "without_ip_addresses" in d


def test_analytics_has_no_fabricated_defaults(client, analyst):
    o = client.get("/api/v1/analytics/overview", headers=analyst).json()["data"]
    assert o["total_incidents"] > 0
    assert o["mean_model_confidence"] is None or 0 < o["mean_model_confidence"] <= 1
    assert o["mean_model_confidence"] != 0.942                    # the old hard-coded fallback
    for path in ("attacks", "severity", "protocols", "ports", "trends"):
        assert client.get(f"/api/v1/analytics/{path}", headers=analyst).status_code == 200


def test_runs_history_lists_status(client, analyst):
    runs = client.get("/api/v1/evaluation/runs", headers=analyst).json()["data"]
    assert runs and {"eval_type", "status", "metrics"} <= set(runs[0])
