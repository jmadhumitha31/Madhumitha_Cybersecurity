import uuid

from conftest import SCAN_FLOW


def _new(client, headers, **over):
    body = {**SCAN_FLOW, "flow_id": "T-" + uuid.uuid4().hex[:10], **over}
    r = client.post("/api/v1/incidents", json=body, headers=headers)
    assert r.status_code == 201, r.text
    return r.json()["data"]


def test_root_and_health(client):
    assert client.get("/").json()["status"] == "OPERATIONAL"
    h = client.get("/api/v1/health").json()["data"]
    assert h["status"] in ("Healthy", "Degraded") and {"database", "ml_model", "vector_index", "nvidia_llm"} <= set(h["components"])


def test_create_triages_automatically(client, analyst):
    inc = _new(client, analyst)
    assert inc["label_source"] == "model" and inc["attack_type"] != "Unclassified"
    assert inc["prediction_confidence"] is not None and inc["risk_score"] is not None and inc["priority"] in ("P1", "P2", "P3", "P4")
    assert inc["ground_truth_label"] is None and inc["predicted_attack_type"] == inc["attack_type"]


def test_duplicate_flow_id_is_conflict(client, analyst):
    inc = _new(client, analyst)
    r = client.post("/api/v1/incidents", json={**SCAN_FLOW, "flow_id": inc["flow_id"]}, headers=analyst)
    assert r.status_code == 409


def test_classify_endpoint_does_not_persist(client, analyst):
    before = client.get("/api/v1/incidents?page_size=1", headers=analyst).json()["pagination"]["total"]
    r = client.post("/api/v1/incidents/classify", json=SCAN_FLOW, headers=analyst)
    assert r.status_code == 200
    d = r.json()["data"]
    assert d["prediction"]["attack_type"] and d["risk"]["priority"] and d["prediction"]["explanation"]["contributions"]
    assert client.get("/api/v1/incidents?page_size=1", headers=analyst).json()["pagination"]["total"] == before


def test_full_investigation_workflow(client, analyst):
    inc = _new(client, analyst)
    r = client.post(f"/api/v1/incidents/{inc['id']}/analyze", headers=analyst)
    assert r.status_code == 200, r.text
    a = r.json()["data"]
    steps = [t["step"] for t in a["execution_trace"]]
    assert steps[0] == "Input Validation" and "Detection Agent" in steps and "Analysis & RAG Retrieval" in steps and "Risk Assessment Agent" in steps
    assert "Response Recommendation Agent" in steps and steps[-1].startswith("Final Validation")
    assert a["recommendations"] and a["analysis"] and a["requires_analyst_review"] is True
    assert a["llm_provider"] in ("nvidia", "ollama", "heuristic_rule_engine")
    assert all(c["passed"] for c in a["quality_checks"] if c["check"] in ("recommendations_safe", "risk_fields_consistent"))
    assert 0 <= a["risk_assessment"]["risk_score"] <= 100


def test_analysis_never_overwrites_ground_truth(client, analyst, bootstrapped):
    """Regression: analysing a dataset incident replaced its real label with the model's prediction."""
    kb = client.get("/api/v1/incidents?label_source=dataset&attack_type=Benign&page_size=1", headers=analyst).json()["data"][0]
    truth = kb["ground_truth_label"]
    assert truth == "Benign"
    client.post(f"/api/v1/incidents/{kb['id']}/analyze", headers=analyst)
    after = client.get(f"/api/v1/incidents/{kb['id']}", headers=analyst).json()["data"]["incident"]
    assert after["ground_truth_label"] == truth and after["attack_type"] == truth and after["label_source"] == "dataset"
    assert after["predicted_attack_type"] is not None  # the prediction is stored separately


def test_retrieval_query_excludes_label_and_self(client, analyst):
    from app.rag.retriever import rag_retriever
    from app.database.connection import SessionLocal

    inc = _new(client, analyst)
    db = SessionLocal()
    try:
        res = rag_retriever.retrieve_similar_incidents(db, {**SCAN_FLOW, "attack_type": "Heartbleed"}, top_k=3, threshold=0.0, exclude_id=inc["id"])
    finally:
        db.close()
    assert "heartbleed" not in res["query_text"].lower()           # a stored label can never leak into the query
    assert all(m["incident_id"] != inc["id"] and m["label_source"] in ("dataset", "analyst") for m in res["matches"])


def test_no_similar_incident_has_explicit_empty_state(client, analyst):
    from app.rag.retriever import rag_retriever
    from app.database.connection import SessionLocal

    db = SessionLocal()
    try:
        res = rag_retriever.retrieve_similar_incidents(db, SCAN_FLOW, threshold=0.999999)
    finally:
        db.close()
    assert res["found"] is False and res["message"] == "No sufficiently similar historical incidents were found."
    assert "No sufficiently similar" in res["evidence_context"]


# ---------------------------------------------------------------- feedback loop
def test_feedback_validation(client, analyst):
    inc = _new(client, analyst)
    url = f"/api/v1/incidents/{inc['id']}/feedback"
    assert client.post(url, json={"feedback_type": "Banana", "actual_label": "DDoS"}, headers=analyst).status_code == 422
    assert client.post(url, json={"feedback_type": "Incorrect", "actual_label": "NotARealClass"}, headers=analyst).status_code == 422
    assert client.post(url, json={"feedback_type": "Incorrect"}, headers=analyst).status_code == 422
    assert client.post(url, json={"feedback_type": "Useful"}, headers=analyst).status_code == 200  # recommendation feedback needs no label


def test_feedback_relabels_reindexes_and_feeds_retrieval(client, analyst, admin):
    inc = _new(client, analyst)
    r = client.post(f"/api/v1/incidents/{inc['id']}/feedback", json={"feedback_type": "Incorrect", "actual_label": "Web Attack", "analyst_feedback": "SQLi in WAF log"}, headers=analyst)
    assert r.status_code == 200 and r.json()["data"]["applied"] is True
    after = client.get(f"/api/v1/incidents/{inc['id']}", headers=analyst).json()["data"]["incident"]
    assert after["ground_truth_label"] == "Web Attack" and after["attack_type"] == "Web Attack" and after["label_source"] == "analyst"

    from app.database.connection import SessionLocal
    from app.database.models import IncidentEmbedding

    db = SessionLocal()
    try:
        emb = db.query(IncidentEmbedding).filter_by(incident_id=inc["id"]).one()
    finally:
        db.close()
    assert "Web Attack" in emb.text_representation          # embedding regenerated with the confirmed label
    st = client.get("/api/v1/feedback/stats", headers=analyst).json()["data"]
    assert st["total"] >= 1 and st["pending_for_training"] >= 1
    assert any(f["incident_id"] == inc["id"] for f in client.get("/api/v1/feedback", headers=analyst).json()["data"])


def test_false_positive_feedback_closes_incident(client, analyst):
    inc = _new(client, analyst)
    client.post(f"/api/v1/incidents/{inc['id']}/feedback", json={"feedback_type": "Incorrect", "actual_label": "Benign"}, headers=analyst)
    after = client.get(f"/api/v1/incidents/{inc['id']}", headers=analyst).json()["data"]["incident"]
    if inc["attack_type"] != "Benign":
        assert after["status"] == "FALSE_POSITIVE"
    assert after["risk_level"] == "Low"


def test_retrain_job_end_to_end(client, admin, analyst, bootstrapped):
    import time

    assert client.post("/api/v1/ml/retrain", headers=analyst).status_code == 403
    r = client.post("/api/v1/ml/retrain", headers=admin)
    assert r.status_code == 202
    for _ in range(120):
        st = client.get("/api/v1/ml/retrain/status", headers=admin).json()["data"]
        if st["status"] in ("completed", "failed"):
            break
        time.sleep(1)
    assert st["status"] == "completed", st
    assert st["result"]["decision"] in ("promoted", "rejected") and st["result"]["feedback_incidents_used"] >= 1
    assert "f1_macro" in st["result"]["candidate"]
    info = client.get("/api/v1/ml/model", headers=admin).json()["data"]
    assert info["loaded"] and len(info["versions"]) >= 2


# ---------------------------------------------------------------- prioritisation + misc
def test_triage_queue_is_sorted_by_risk(client, analyst):
    q = client.get("/api/v1/incidents/queue?limit=30", headers=analyst).json()["data"]
    assert len(q) >= 5
    scores = [i["risk_score"] for i in q]
    assert scores == sorted(scores, reverse=True) and all(i["status"] in ("NEW", "INVESTIGATING") for i in q)


def test_list_sorting_and_filters(client, analyst):
    r = client.get("/api/v1/incidents?sort=risk&page_size=10&label_source=dataset", headers=analyst).json()
    assert all(i["label_source"] == "dataset" for i in r["data"])
    s = [i["risk_score"] for i in r["data"]]
    assert s == sorted(s, reverse=True)
    assert client.get("/api/v1/incidents?sort=bogus", headers=analyst).status_code == 422


def test_status_update_and_explain(client, analyst):
    inc = _new(client, analyst)
    assert client.patch(f"/api/v1/incidents/{inc['id']}/status", json={"status": "RESOLVED"}, headers=analyst).json()["data"]["status"] == "RESOLVED"
    assert client.patch(f"/api/v1/incidents/{inc['id']}/status", json={"status": "WHATEVER"}, headers=analyst).status_code == 422
    ex = client.get(f"/api/v1/incidents/{inc['id']}/explain", headers=analyst).json()["data"]
    assert ex["explanation"]["contributions"]


def test_attack_profiles_endpoint(client, analyst):
    d = client.get("/api/v1/ml/profiles", headers=analyst).json()["data"]
    assert d["profiles"] and d["global_feature_importance"]
