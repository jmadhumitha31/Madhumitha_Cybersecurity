import numpy as np
import pytest

from app.domain import CLASSES
from app.ml.predictor import ml_predictor
from app.ml.preprocessing import FEATURE_COLUMNS, row_to_vector
from app.ml.risk import assess_risk

from conftest import SCAN_FLOW


def test_model_artifacts_loaded(bootstrapped):
    assert ml_predictor.is_loaded
    info = ml_predictor.info()
    assert info["dataset_source"] == "synthetic-demo" and set(info["classes"]) <= set(CLASSES)


def test_prediction_contract_and_outputs(bootstrapped):
    out = ml_predictor.predict_attack({**SCAN_FLOW, "total_bwd_packets": 1.0}, explain=True)
    assert out["status"] == "ok" and out["attack_type"] in CLASSES
    assert 0.0 <= out["confidence"] <= 1.0 and 0.0 <= out["intrusion_probability"] <= 1.0 and 0.0 <= out["anomaly_score"] <= 1.0
    assert out["top_classes"] and abs(sum(t["probability"] for t in out["top_classes"][:4]) - 1) < 0.5
    assert out["indicators"] and out["explanation"]["method"] in ("shap-tree", "occlusion")


def test_explanations_are_per_flow_not_global(bootstrapped):
    """Regression: the old 'feature_importance' was the same global top-5 for every flow."""
    a = ml_predictor.predict_attack({**SCAN_FLOW}, explain=True)
    b = ml_predictor.predict_attack({**SCAN_FLOW, "flow_duration": 9e7, "total_fwd_packets": 3000.0, "total_bwd_packets": 2000.0, "destination_port": 22,
                                     "flow_packets_per_sec": 40.0, "packet_length_mean": 900.0}, explain=True)
    ca = {c["feature"]: c["contribution"] for c in a["explanation"]["contributions"]}
    cb = {c["feature"]: c["contribution"] for c in b["explanation"]["contributions"]}
    assert ca and cb and ca != cb, "contributions must depend on the flow being explained"


def test_shap_attributions_sum_to_prediction(bootstrapped):
    b = ml_predictor.bundle
    x = row_to_vector(SCAN_FLOW)
    idx = int(np.argmax(b.class_proba(x)[0]))
    exp = b.explainer()
    sv = exp.shap_values(x, check_additivity=False)
    vals = sv[idx][0] if isinstance(sv, list) else sv[0, :, idx]
    base = exp.expected_value[idx] if hasattr(exp.expected_value, "__len__") else exp.expected_value
    assert abs(base + float(np.sum(vals)) - b.class_proba(x)[0][idx]) < 1e-3


def test_attack_profiles_cover_classes(bootstrapped):
    prof = ml_predictor.profiles()
    assert prof and all(p["top_features"] for p in prof.values())
    assert {f["feature"] for p in prof.values() for f in p["top_features"]} <= set(FEATURE_COLUMNS)


def test_intrusion_and_anomaly_models_separate_attacks_from_benign(bootstrapped):
    m = ml_predictor.bundle.metrics
    assert m["intrusion"]["roc_auc"] > 0.9 and m["anomaly"]["roc_auc_attack_vs_benign"] > 0.6


def test_unavailable_model_is_reported_not_faked(bootstrapped):
    from app.ml.predictor import MLPredictor

    empty = MLPredictor(model_dir="/definitely/not/here")
    out = empty.predict_attack(SCAN_FLOW)
    assert out["status"] == "unavailable" and out["attack_type"] == "Unclassified" and out["confidence"] == 0.0


# ---------------------------------------------------------------- prioritisation
FLOOD = {"destination_port": 80, "flow_packets_per_sec": 60000.0, "syn_count": 500.0, "total_fwd_packets": 2500.0, "total_bwd_packets": 1.0, "protocol": 6}


def test_risk_orders_attack_families_sensibly():
    benign = assess_risk({"destination_port": 443}, "Benign", 0.99, 0.01, 0.2)
    scan = assess_risk({"destination_port": 445, "flow_duration": 40, "total_fwd_packets": 1, "total_bwd_packets": 1}, "Port Scan", 0.95, 0.97, 0.9)
    ddos = assess_risk(FLOOD, "DDoS", 0.95, 0.99, 0.99)
    assert benign["risk_level"] == "Low" and benign["priority"] == "P4"
    assert ddos["risk_score"] > scan["risk_score"] > benign["risk_score"]
    assert ddos["risk_level"] in ("Critical", "High") and ddos["priority"] in ("P1", "P2")


def test_policy_floor_escalates_critical_families():
    r = assess_risk({"destination_port": 444}, "Heartbleed", 0.7, 0.5, 0.5)
    assert r["risk_level"] == "Critical" and r["priority"] == "P1" and any("Policy floor" in f for f in r["factors"])


def test_benign_prediction_with_high_intrusion_probability_is_escalated():
    r = assess_risk({"destination_port": 8000}, "Benign", 0.55, 0.9, 0.97)
    assert r["risk_level"] in ("Medium", "High") and any("independent intrusion model" in f for f in r["factors"])


def test_retrieval_agreement_adjusts_score():
    base = assess_risk(FLOOD, "DoS", 0.8, 0.9, 0.9)
    agree = assess_risk(FLOOD, "DoS", 0.8, 0.9, 0.9, neighbor_agreement=1.0)
    clash = assess_risk(FLOOD, "DoS", 0.8, 0.9, 0.9, neighbor_agreement=0.0)
    assert clash["risk_score"] < base["risk_score"] < agree["risk_score"]
