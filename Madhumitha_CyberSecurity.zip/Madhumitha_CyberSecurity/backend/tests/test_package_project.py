"""The portable-zip builder (package_project.py): what goes in, what stays out, and the secret scan."""
import importlib.util
import sqlite3
import stat
import sys
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
FAKE_KEY = "nvapi-" + "A1b2C3d4" * 8          # same shape as a real key (64 characters after the prefix)
FAKE_JWT = "jwt-secret-" + "x9" * 20


@pytest.fixture(scope="module")
def pp_module():
    spec = importlib.util.spec_from_file_location("package_project", ROOT / "package_project.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["package_project"] = mod
    spec.loader.exec_module(mod)
    return mod


def _write(path: Path, content, binary: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content if binary else content.encode("utf-8"))


@pytest.fixture()
def project(tmp_path, pp_module, monkeypatch):
    """A miniature project with everything the packager must include, plus everything it must leave out."""
    root = tmp_path / "proj"
    for rel in pp_module.MUST_HAVE:
        _write(root / rel, "x\n")
    _write(root / "setup.sh", "#!/usr/bin/env bash\r\necho hi\r\n")                  # CRLF on purpose: must be fixed in the zip
    _write(root / "setup.bat", "@echo off\necho hi\n")                              # LF on purpose: must become CRLF
    env = f"NVIDIA_API_KEY={FAKE_KEY}\nJWT_SECRET={FAKE_JWT}\nENVIRONMENT=development\n"
    _write(root / ".env", env)
    _write(root / "backend" / ".env", env)
    _write(root / ".env.local", f"OTHER_TOKEN={FAKE_KEY}\n")                         # other env files are never shipped
    db = root / "backend" / "soc_assistant.db"
    con = sqlite3.connect(db)
    con.execute("CREATE TABLE incidents (id INTEGER PRIMARY KEY, title TEXT)")
    con.executemany("INSERT INTO incidents (title) VALUES (?)", [("a",), ("b",), ("c",)])
    con.commit()
    con.close()
    _write(root / "soc_assistant.db", "stale root copy", )                          # stale copies / backups stay out
    _write(root / "backend" / "soc_assistant.db.pre-v2.bak", "backup")
    for rel in ("frontend/node_modules/vite/index.js", "backend/app/__pycache__/x.pyc", "backend/models/versions/v1/bundle.joblib",
                "backend/models/active_model.json", "backend/data/qdrant/collection/data.bin", "backend/data/cicids2017/Monday.parquet",
                "frontend/dist/index.html", "logs/setup.log", ".setup/state.json", ".tools/node/node.exe", ".deepeval/cache.json", "release/old.zip"):
        _write(root / rel, "junk")
    _write(root / "frontend" / "src" / "pages" / "logs" / "Logs.tsx", "keep: a nested 'logs' source folder is not the root logs folder")
    monkeypatch.setattr(pp_module, "ROOT", root)
    monkeypatch.setattr(pp_module, "RELEASE_DIR", root / "release")
    return root


def _build(pp, root, *flags):
    out = root / "release" / "t.zip"
    rc = pp.main(["--out", str(out), *flags])
    return rc, out


def test_line_endings_are_normalised_by_type(pp_module):
    assert pp_module.normalise("a.sh", b"x\r\ny\r\n") == b"x\ny\n"
    assert pp_module.normalise("a.bat", b"x\ny\r\n") == b"x\r\ny\r\n"
    assert pp_module.normalise("a.py", b"x\r\ny\n") == b"x\r\ny\n"                  # everything else is untouched


def test_walk_includes_sources_and_skips_state_caches_and_secrets(pp_module, project):
    names = {pp_module.posix(f) for f in pp_module.walk_project(include_dataset=False)}
    assert {"setup.sh", "frontend/src/pages/logs/Logs.tsx", ".env.example", "backend/requirements.txt"} <= names
    assert not any(n.startswith(("frontend/node_modules", "logs/", ".setup/", ".tools/", "release/", "backend/models/versions", "backend/data/qdrant",
                                 "backend/data/cicids2017", "frontend/dist", ".deepeval")) for n in names)
    assert not {".env", "backend/.env", ".env.local", "soc_assistant.db", "backend/soc_assistant.db", "backend/soc_assistant.db.pre-v2.bak",
                "backend/models/active_model.json"} & names
    assert not any(n.endswith(".pyc") for n in names)
    with_data = {pp_module.posix(f) for f in pp_module.walk_project(include_dataset=True)}
    assert "backend/data/cicids2017/Monday.parquet" in with_data


def test_default_zip_has_env_files_a_fresh_jwt_secret_and_a_consistent_database(pp_module, project, tmp_path):
    rc, out = _build(pp_module, project)
    assert rc == 0 and out.exists()
    top = pp_module.ROOT_NAME + "/"
    with zipfile.ZipFile(out) as z:
        names = set(z.namelist())
        assert all(n.startswith(top) for n in names)
        assert {top + ".env", top + "backend/.env", top + "backend/soc_assistant.db"} <= names
        for rel in (".env", "backend/.env"):
            text = z.read(top + rel).decode()
            assert FAKE_KEY in text                                                  # the key travels with the zip, as requested
            assert FAKE_JWT not in text and "JWT_SECRET=" in text and len(text.split("JWT_SECRET=")[1].split("\n")[0]) >= 48
        assert top + ".env.local" not in names and top + "soc_assistant.db" not in names
        assert not any("node_modules" in n or "__pycache__" in n or "versions" in n or "qdrant" in n for n in names)
        sh = z.read(top + "setup.sh")
        assert b"\r" not in sh and (z.getinfo(top + "setup.sh").external_attr >> 16) & stat.S_IXUSR
        assert z.read(top + "setup.bat").count(b"\r\n") == z.read(top + "setup.bat").count(b"\n")
        z.extract(top + "backend/soc_assistant.db", tmp_path / "x")
    con = sqlite3.connect(tmp_path / "x" / top / "backend" / "soc_assistant.db")
    assert con.execute("SELECT COUNT(*) FROM incidents").fetchone()[0] == 3 and con.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    con.close()
    assert pp_module.main(["--verify", str(out)]) == 0


def test_no_secrets_and_no_database_flags(pp_module, project):
    rc, out = _build(pp_module, project, "--no-secrets", "--no-database")
    assert rc == 0
    with zipfile.ZipFile(out) as z:
        names = z.namelist()
        assert not any(n.rsplit("/", 1)[-1] in (".env",) for n in names) and not any(n.endswith(".db") for n in names)
        assert all(FAKE_KEY.encode() not in z.read(n) for n in names)


def test_a_key_anywhere_but_the_env_files_blocks_the_zip(pp_module, project, capsys):
    _write(project / "docs" / "notes.md", f"my key is {FAKE_KEY}\n")
    rc, out = _build(pp_module, project)
    assert rc == 1 and not out.exists() and not list(out.parent.glob("*.partial"))
    shown = capsys.readouterr().out
    assert "docs/notes.md" in shown and FAKE_KEY not in shown                        # names the file, never the secret
    # --no-secrets: the key must not be in the zip at all, including the env files' absence being enforced
    rc2, _ = _build(pp_module, project, "--no-secrets")
    assert rc2 == 1


def test_the_old_jwt_secret_must_not_appear_anywhere(pp_module, project):
    _write(project / "docs" / "jwt.md", f"token secret {FAKE_JWT}\n")
    rc, out = _build(pp_module, project)
    assert rc == 1 and not out.exists()


def test_verify_flags_forbidden_members_and_missing_files(pp_module, project, tmp_path):
    bad = tmp_path / "bad.zip"
    top = pp_module.ROOT_NAME + "/"
    with zipfile.ZipFile(bad, "w") as z:
        z.writestr(top + "README.md", "x")
        z.writestr(top + "frontend/node_modules/a.js", "x")
        z.writestr(top + "backend/models/versions/v1/bundle.joblib", "x")
        z.writestr(top + "stray.db", "x")
        z.writestr(top + "backend/.env.local", "x")
    problems, _ = pp_module.verify_zip(bad, {}, expect_env=False, expect_db=False)
    text = "\n".join(problems)
    assert "node_modules" in text and "versions" in text and "stray.db" in text and ".env.local" in text and "missing required file: setup.bat" in text


def test_dry_run_lists_files_without_writing_a_zip(pp_module, project, capsys):
    assert pp_module.main(["--list"]) == 0
    assert "setup_project.py" in capsys.readouterr().out and not (project / "release" / "t.zip").exists()
