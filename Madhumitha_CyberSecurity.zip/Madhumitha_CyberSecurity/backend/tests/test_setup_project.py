"""The one-command setup (setup_project.py) and the helper scripts it drives."""
import importlib.util
import json
import os
import socket
import subprocess
import sys
import time
from argparse import Namespace
from pathlib import Path

import pytest

BACKEND = Path(__file__).resolve().parents[1]
ROOT = BACKEND.parent


@pytest.fixture(scope="module")
def sp():
    spec = importlib.util.spec_from_file_location("setup_project", ROOT / "setup_project.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["setup_project"] = mod
    spec.loader.exec_module(mod)
    return mod


# ---------------------------------------------------------------------------------------------- version rules
def test_version_parsing_and_supported_ranges(sp):
    assert sp.parse_version("Python 3.11.9") == (3, 11, 9) and sp.parse_version("v20.18.0\n") == (20, 18, 0) and sp.parse_version("nope") is None
    assert sp.python_supported((3, 11, 9)) and sp.python_supported((3, 12, 1)) and not sp.python_supported((3, 10, 14)) and not sp.python_supported((3, 13, 0))
    assert not sp.python_supported(None)
    # Vite 8 / rolldown: node ^20.19.0 || >=22.12.0. A hard requirement: on 20.18 a clean `npm ci` skips the native binding (found by the clean-room run).
    assert not sp.node_supported((20, 18, 0)) and sp.node_supported((20, 19, 0)) and sp.node_supported((20, 22, 3))
    assert not sp.node_supported((21, 7, 0)) and not sp.node_supported((22, 11, 1)) and sp.node_supported((22, 12, 0)) and sp.node_supported((22, 21, 0)) and sp.node_supported((24, 0, 0))
    assert not sp.node_supported((18, 20, 0)) and not sp.node_supported(None)


def test_windows_long_path_guard_moves_the_venv_to_a_short_path(sp, tmp_path):
    assert sp.venv_path_ok(Path("C:/p/.venv"), windows=True)
    long_root = Path("C:/Users/some.very.long.user.name/Documents/Projects/Security Operations Center/AI Incident Response Assistant/final_project_v2")
    assert not sp.venv_path_ok(long_root / ".venv", windows=True) and sp.venv_path_ok(long_root / ".venv", windows=False)
    chosen, why = sp.choose_venv_dir(long_root, None, None, windows=True, home=tmp_path)
    assert chosen == tmp_path / ".soc-venv" and "too long" in why
    short, why = sp.choose_venv_dir(Path("C:/p"), None, None, windows=True)
    assert short == Path("C:/p/.venv") and why == "inside the project"
    assert sp.choose_venv_dir(long_root, str(tmp_path / "mine"), None, windows=True)[0] == (tmp_path / "mine").resolve()
    keep = tmp_path / "kept"
    keep.mkdir()
    assert sp.choose_venv_dir(long_root, None, str(keep), windows=True)[0] == keep      # a remembered, existing venv is reused
    assert sp.venv_python(Path("/v"), windows=True).as_posix().endswith("Scripts/python.exe") and sp.venv_python(Path("/v"), windows=False).as_posix().endswith("bin/python")


# ---------------------------------------------------------------------------------------------- .env editing
EXAMPLE = """# header comment
ENVIRONMENT=development            # "production" refuses to start with the default JWT secret
NVIDIA_API_KEY=
# QDRANT_URL=http://localhost:6333
JWT_SECRET=                        # REQUIRED in production: python -c "import secrets"
CORS_ORIGINS=http://localhost:5173
"""


def test_env_editing_keeps_comments_and_never_overwrites_existing_values(sp):
    assert sp.env_value(EXAMPLE, "JWT_SECRET") == "" and sp.env_value(EXAMPLE, "ENVIRONMENT") == "development" and sp.env_value(EXAMPLE, "MISSING") == ""
    text, changed = sp.edit_env_text(EXAMPLE, {"JWT_SECRET": "s3cret-value"}, only_if_empty=["JWT_SECRET"])
    assert changed == ["JWT_SECRET"] and "JWT_SECRET=s3cret-value" in text and "# header comment" in text and "# QDRANT_URL=http://localhost:6333" in text
    assert sp.env_value(text, "ENVIRONMENT") == "development" and "CORS_ORIGINS=http://localhost:5173" in text
    again, changed2 = sp.edit_env_text(text, {"JWT_SECRET": "another"}, only_if_empty=["JWT_SECRET"])
    assert changed2 == [] and sp.env_value(again, "JWT_SECRET") == "s3cret-value"                  # an existing secret is never replaced
    forced, changed3 = sp.edit_env_text(text, {"NVIDIA_API_KEY": "nvapi-abc"})                      # an explicit key is written
    assert changed3 == ["NVIDIA_API_KEY"] and sp.env_value(forced, "NVIDIA_API_KEY") == "nvapi-abc"
    appended, changed4 = sp.edit_env_text(EXAMPLE, {"NEW_KEY": "1"})
    assert changed4 == ["NEW_KEY"] and appended.rstrip().endswith("NEW_KEY=1")


def _fake_project(sp, monkeypatch, tmp_path):
    (tmp_path / "backend").mkdir()
    (tmp_path / "frontend").mkdir()
    (tmp_path / "backend" / ".env.example").write_text(EXAMPLE, encoding="utf-8")
    for name, value in (("ROOT", tmp_path), ("BACKEND", tmp_path / "backend"), ("FRONTEND", tmp_path / "frontend"), ("STATE_DIR", tmp_path / ".setup"),
                        ("STATE_FILE", tmp_path / ".setup" / "state.json"), ("PID_FILE", tmp_path / ".setup" / "pids.json"), ("LOG_DIR", tmp_path / "logs")):
        monkeypatch.setattr(sp, name, value)
    return tmp_path


def _args(sp, **kw):
    ns = sp.build_parser().parse_args([])
    for k, v in kw.items():
        setattr(ns, k, v)
    return ns


def test_configure_generates_a_secret_stores_the_key_and_never_logs_it(sp, monkeypatch, tmp_path, capsys):
    root = _fake_project(sp, monkeypatch, tmp_path)
    monkeypatch.delenv("NVIDIA_API_KEY", raising=False)
    con = sp.Console(root / "logs" / "t.log")
    s = sp.Setup(_args(sp, nvidia_key="nvapi-SUPERSECRETKEY123456", no_prompt=True), con, sp.State())
    s.configure()
    env = (root / "backend" / ".env").read_text(encoding="utf-8")
    secret = sp.env_value(env, "JWT_SECRET")
    assert len(secret) >= 48 and sp.env_value(env, "NVIDIA_API_KEY") == "nvapi-SUPERSECRETKEY123456" and sp.env_value(env, "ENVIRONMENT") == "development"
    con.close()
    shown = capsys.readouterr().out + (root / "logs" / "t.log").read_text(encoding="utf-8")
    assert "SUPERSECRETKEY123456" not in shown and secret not in shown                              # secrets never reach the console or the log
    # second run: nothing is regenerated, an environment-provided key does not replace the stored one
    monkeypatch.setenv("NVIDIA_API_KEY", "nvapi-DIFFERENT-KEY-000000")
    con2 = sp.Console(root / "logs" / "t2.log")
    sp.Setup(_args(sp, no_prompt=True), con2, sp.State()).configure()
    con2.close()
    env2 = (root / "backend" / ".env").read_text(encoding="utf-8")
    assert sp.env_value(env2, "JWT_SECRET") == secret and sp.env_value(env2, "NVIDIA_API_KEY") == "nvapi-SUPERSECRETKEY123456"


def test_configure_without_a_key_runs_offline_and_says_so(sp, monkeypatch, tmp_path, capsys):
    root = _fake_project(sp, monkeypatch, tmp_path)
    monkeypatch.delenv("NVIDIA_API_KEY", raising=False)
    con = sp.Console(root / "logs" / "t.log")
    sp.Setup(_args(sp, no_prompt=True), con, sp.State()).configure()
    con.close()
    assert sp.env_value((root / "backend" / ".env").read_text(encoding="utf-8"), "NVIDIA_API_KEY") == ""
    assert "offline playbooks" in capsys.readouterr().out


# ---------------------------------------------------------------------------------------------- state, skip logic, helpers
def test_done_checks_follow_the_real_artifacts(sp, monkeypatch, tmp_path):
    root = _fake_project(sp, monkeypatch, tmp_path)
    con = sp.Console(root / "logs" / "t.log")
    state = sp.State()
    s = sp.Setup(_args(sp), con, state)
    assert s.frontend_done()[0] is False and s.bootstrap_done()[0] is False
    (root / "frontend" / "package.json").write_text("{}", encoding="utf-8")
    (root / "frontend" / "package-lock.json").write_text("{}", encoding="utf-8")
    (root / "frontend" / "node_modules" / "vite").mkdir(parents=True)
    assert s.frontend_done()[0] is False                                         # node_modules without a recorded hash is not trusted
    state.set(npm_hash=s.npm_hash())
    monkeypatch.setattr(sp.Setup, "vite_loads", lambda self: (False, "Cannot find native binding"))
    ok, detail = s.frontend_done()
    assert ok is False and "unusable" in detail and "native binding" in detail          # packages present but Vite cannot start: not "done"
    monkeypatch.setattr(sp.Setup, "vite_loads", lambda self: (True, ""))
    assert s.frontend_done()[0] is True
    (root / "frontend" / "package-lock.json").write_text('{"changed": true}', encoding="utf-8")
    assert s.frontend_done()[0] is False                                         # a changed lock file forces a reinstall
    # database + models
    import sqlite3

    (root / "backend" / "models").mkdir()
    (root / "backend" / "models" / "active_model.json").write_text("{}", encoding="utf-8")
    db = sqlite3.connect(root / "backend" / "soc_assistant.db")
    db.execute("CREATE TABLE incidents (id INTEGER PRIMARY KEY)")
    db.commit()
    assert s.bootstrap_done()[0] is False                                        # tables exist but no incidents yet
    db.execute("INSERT INTO incidents DEFAULT VALUES")
    db.commit()
    db.close()
    ok, detail = s.bootstrap_done()
    assert ok and "1 incidents" in detail
    con.close()
    assert sp.State().get("npm_hash") == state.get("npm_hash")                    # state persists on disk


def test_combined_hash_changes_with_content_and_ports_are_probed(sp, tmp_path):
    a, b = tmp_path / "a.txt", tmp_path / "b.txt"
    a.write_text("1")
    b.write_text("2")
    h = sp.combined_hash([a, b])
    assert h == sp.combined_hash([a, b])
    b.write_text("3")
    assert h != sp.combined_hash([a, b]) and sp.combined_hash([tmp_path / "missing.txt"])
    with socket.socket() as busy:
        busy.bind(("127.0.0.1", 0))
        busy.listen(1)
        port = busy.getsockname()[1]
        assert not sp.port_free(port) and sp.pick_port(port) != port
        assert sp.pick_port(port, avoid=(port + 1,)) not in (port, port + 1)       # busy and explicitly avoided ports are both skipped


def test_heartbeat_shows_the_log_message_not_raw_json(sp):
    rec = json.dumps({"timestamp": "2026-10-08T14:09:02+00:00", "level": "INFO", "message": "Training RandomForest on 95,997 flows", "module": "training"})
    assert sp.progress_snippet(rec) == "Training RandomForest on 95,997 flows"
    assert sp.progress_snippet("Fetching 5 files:  40%|████      | 2/5 [00:00<00:01,  2.88it/s]").startswith("Fetching 5 files: 40%|")
    assert len(sp.progress_snippet("x" * 500)) == 80 and sp.progress_snippet("{not json") == "{not json"


def test_redaction_and_logged_commands(sp, tmp_path, capsys):
    assert sp.redact("key=nvapi-abcdef1234567890 and token SECRET-VALUE", ["SECRET-VALUE"]) == "key=nvapi-[REDACTED] and token [REDACTED]"
    con = sp.Console(tmp_path / "x.log")
    rc, tail = sp.run_logged(con, [sys.executable, "-c", "print('hello'); print('line two')"], "demo")
    assert rc == 0 and tail[-1] == "line two"
    rc, tail = sp.run_logged(con, [sys.executable, "-c", "import sys; print('boom', file=sys.stderr); sys.exit(3)"], "failing demo")
    assert rc == 3 and "boom" in tail[-1]
    assert sp.run_logged(con, ["definitely-not-a-command-xyz"], "missing")[0] == 127
    con.close()
    assert "hello" in (tmp_path / "x.log").read_text(encoding="utf-8")


def test_check_mode_changes_nothing(sp, monkeypatch, tmp_path, capsys):
    root = _fake_project(sp, monkeypatch, tmp_path)
    before = sorted(p.name for p in root.rglob("*") if p.is_file())
    assert sp.main(["--check"]) == 0
    out = capsys.readouterr().out
    assert "Dry run: nothing will be changed" in out and "[todo] python packages" in out
    after = sorted(p.name for p in root.rglob("*") if p.is_file() and p.suffix != ".log")
    assert [n for n in after if n not in before] == []                            # only the log file is written


# ---------------------------------------------------------------------------------------------- helper scripts
def test_dataset_check_reports_missing_files(tmp_path):
    cmd = [sys.executable, str(BACKEND / "scripts" / "download_cicids2017.py"), "--check", "--dest", str(tmp_path)]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(BACKEND))
    assert r.returncode == 1 and "0/7 dataset files present" in r.stdout and "Tuesday-WorkingHours" in r.stdout
    for line in r.stdout.splitlines():
        if "missing:" in line:
            (tmp_path / line.split("missing:")[1].strip()).write_bytes(b"x" * 1_100_000)
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(BACKEND))
    assert r.returncode == 0 and "7/7 dataset files present" in r.stdout


def test_build_index_script_embeds_everything_and_proves_the_index_answers(bootstrapped):
    env = {**os.environ, "QDRANT_PATH": ":memory:"}                              # the API test client holds the on-disk folder lock
    r = subprocess.run([sys.executable, str(BACKEND / "scripts" / "build_index.py"), "--json"], capture_output=True, text=True, cwd=str(BACKEND), env=env)
    assert r.returncode == 0, r.stdout[-800:] + r.stderr[-800:]
    summary = json.loads(r.stdout.strip().splitlines()[-1])
    assert summary["incidents"] > 50 and summary["incidents"] == summary["embedded"] == summary["qdrant_points"]
    assert summary["probe_results"] > 0 and summary["semantic"] is False         # tests use the hashing backend, and say so


def test_heartbeat_does_not_spin_when_the_child_closes_stdout_but_keeps_running(sp, tmp_path, capsys):
    """pip's launcher and similar children close their pipe before they exit; the heartbeat loop must wait on the process, not busy-loop."""
    con = sp.Console(tmp_path / "t.log")
    code = "import os, time; os.close(1); os.close(2); time.sleep(1.2); os._exit(0)"
    t0 = time.time()
    rc, _ = sp.run_logged(con, [sys.executable, "-c", code], "lingering", heartbeat=0.3)
    elapsed = time.time() - t0
    con.close()
    beats = capsys.readouterr().out.count("... lingering")
    assert rc == 0 and elapsed >= 1.0 and 1 <= beats <= elapsed / 0.3 + 2, (beats, elapsed)   # a busy loop would print thousands
