"""Qdrant (embedded, on-device) vector store and the hybrid index built on it."""
import numpy as np
import pytest

from app.config import settings
from app.rag.bm25 import tokenize
from app.rag.vector_store import QdrantVectorStore, collection_name_for

DIM = 16


def _vectors(n, seed=0):
    v = np.random.default_rng(seed).normal(size=(n, DIM)).astype("float32")
    return v / np.linalg.norm(v, axis=1, keepdims=True)


def _fill(store, name, n=60, seed=0):
    V = _vectors(n, seed)
    wanted = {i + 1: f"r{i}" for i in range(n)}
    stats = store.sync(name, DIM, wanted, lambda chunk: {i: V[i - 1].tolist() for i in chunk})
    return V, wanted, stats


def test_collection_names_are_isolated_per_embedding_model_and_dimension():
    a = collection_name_for("fastembed:sentence-transformers/all-MiniLM-L6-v2|sem3", 384)
    b = collection_name_for("hashing-384|sem3", 384)
    assert a != b and a != collection_name_for("fastembed:sentence-transformers/all-MiniLM-L6-v2|sem3", 768)
    assert a.startswith(settings.QDRANT_COLLECTION) and all(c.isalnum() or c == "_" for c in a)


def test_index_is_persisted_on_disk_and_survives_reopen(tmp_path):
    path = str(tmp_path / "qdrant")
    store = QdrantVectorStore(path=path)
    V, wanted, stats = _fill(store, "c")
    assert stats["upserted"] == 60 and store.count("c") == 60
    before = store.search("c", V[5], limit=3)
    store.close()

    reopened = QdrantVectorStore(path=path)            # a fresh process would do exactly this
    assert reopened.count("c") == 60 and reopened.revisions("c") == wanted
    after = reopened.search("c", V[5], limit=3)
    assert [i for i, _ in after] == [i for i, _ in before] and [s for _, s in after] == pytest.approx([s for _, s in before], abs=1e-5)
    reopened.close()


@pytest.mark.filterwarnings("ignore::ResourceWarning")   # qdrant-client leaks the lock-file handle when its constructor fails
def test_embedded_store_is_locked_to_one_process(tmp_path):
    path = str(tmp_path / "qdrant")
    first = QdrantVectorStore(path=path)
    first.client()
    with pytest.raises(RuntimeError, match="already accessed"):
        QdrantVectorStore(path=path).client()
    first.close()


def test_sync_is_incremental_and_transfers_no_vectors_when_unchanged(tmp_path):
    store = QdrantVectorStore(path=str(tmp_path / "q"))
    V, wanted, _ = _fill(store, "c")

    def never(_chunk):
        raise AssertionError("unchanged points must not be reloaded")

    again = store.sync("c", DIM, wanted, never)
    assert again == {"upserted": 0, "deleted": 0, "unchanged": 60, "skipped_invalid": 0}

    changed = dict(wanted)
    del changed[1]                                       # deleted incident
    changed[2] = "new-revision"                          # re-embedded incident
    changed[100] = "r100"                                # new incident
    loaded = []

    def load(chunk):
        loaded.extend(chunk)
        return {i: V[0].tolist() for i in chunk}

    stats = store.sync("c", DIM, changed, load)
    assert sorted(loaded) == [2, 100] and stats["upserted"] == 2 and stats["deleted"] == 1
    assert store.count("c") == 60 and 1 not in store.revisions("c") and store.revisions("c")[2] == "new-revision"
    store.close()


def test_invalid_vectors_are_skipped_not_indexed(tmp_path):
    store = QdrantVectorStore(path=str(tmp_path / "q"))
    stats = store.sync("c", DIM, {1: "a", 2: "b"}, lambda chunk: {1: [0.1] * DIM, 2: [0.1] * (DIM - 1)})
    assert stats["upserted"] == 1 and stats["skipped_invalid"] == 1 and store.count("c") == 1
    store.close()


def test_search_matches_exact_cosine_and_respects_id_restrictions(tmp_path):
    store = QdrantVectorStore(path=str(tmp_path / "q"))
    V, _, _ = _fill(store, "c", n=200, seed=3)
    q = _vectors(1, seed=99)[0]
    exact = V @ q

    top = store.search("c", q, limit=10)
    assert [i for i, _ in top] == [int(i) + 1 for i in np.argsort(-exact)[:10]]
    assert np.allclose([s for _, s in top], np.sort(exact)[::-1][:10], atol=1e-5)

    allowed = [3, 50, 120, 199]
    only = store.search("c", q, limit=10, must_ids=allowed)
    assert sorted(i for i, _ in only) == allowed
    banned = store.search("c", q, limit=5, must_not_ids=[top[0][0], top[1][0]])
    assert top[0][0] not in [i for i, _ in banned] and banned[0][0] == top[2][0]
    assert store.search("c", q, limit=5, must_ids=[]) == []

    sub = store.scores_for("c", q, [7, 8, 9])
    assert sub == pytest.approx({7: exact[6], 8: exact[7], 9: exact[8]}, abs=1e-5)
    store.close()


def test_dimension_mismatch_fails_loudly_instead_of_corrupting_the_index(tmp_path):
    store = QdrantVectorStore(path=str(tmp_path / "q"))
    _fill(store, "c", n=10)
    with pytest.raises(RuntimeError, match="expected 8"):
        store.sync("c", 8, {1: "x"}, lambda chunk: {1: [0.2] * 8})
    assert store.count("c") == 10                      # nothing was touched
    store.close()


# --------------------------------------------------------------------------------------------- the index on top of it
def _toy_index():
    """300 documents share one vector (a dense tie larger than any candidate pool) and carry graded lexical matches; 20 more
    match every query term but are dense-dissimilar, so they crowd the lexical pool. A fixed-size pool misses the true top hits."""
    from app.rag.bm25 import BM25Index
    from app.rag.index import HybridIndex

    rng = np.random.default_rng(5)
    v0 = _vectors(1, seed=1)[0]
    vecs, texts = [], []
    for i in range(300):                                   # tied on the dense channel, graded on the lexical one
        vecs.append(v0)
        texts.append(" ".join(f"q{j}" for j in range(1, 2 + i % 5)) + f" filler{i}")
    for i in range(20):                                    # lexical crowd: all six terms, weak dense similarity
        w = rng.normal(size=DIM).astype("float32")
        w -= (w @ v0) * v0
        vecs.append(w / np.linalg.norm(w))
        texts.append("q1 q2 q3 q4 q5 q6 " + f"crowd{i}")
    for i in range(80):                                    # unrelated filler
        w = rng.normal(size=DIM).astype("float32")
        vecs.append(w / np.linalg.norm(w))
        texts.append(f"noise{i} other{i}")
    V = np.asarray(vecs, dtype=np.float32)
    store = QdrantVectorStore(path=":memory:")
    index = HybridIndex(store=store)
    index.ids = np.arange(1, len(V) + 1, dtype=np.int64)
    index._row_of = {int(i): n for n, i in enumerate(index.ids)}
    index.collection = "toy"
    index.bm25 = BM25Index().build([tokenize(t) for t in texts])
    store.sync("toy", DIM, {int(i): "r" for i in index.ids}, lambda chunk: {i: V[i - 1].tolist() for i in chunk})
    return index, V, v0, "q1 q2 q3 q4 q5 q6"


@pytest.mark.parametrize("pool", [3, 10, 50, 100])
def test_hybrid_top_k_is_exact_even_when_dense_ties_exceed_the_candidate_pool(pool):
    index, V, q, text = _toy_index()
    n, alpha = len(V), 0.6
    mask = np.ones(n, dtype=bool)
    scores, _, _ = index.score(text, q, mask, alpha, pool=pool, k=5)
    exact = alpha * np.clip(V @ q, 0.0, 1.0) + (1 - alpha) * index.bm25.normalized_scores(tokenize(text))
    got = np.sort(scores["hybrid"][np.argsort(-scores["hybrid"], kind="stable")[:5]])[::-1]
    want = np.sort(exact)[::-1][:5]
    np.testing.assert_allclose(got, want, atol=1e-4)
    # the semantic top-k is exact too, and tie-inclusive: every one of the 300 tied documents is a candidate
    sem_scores = index.score(text, q, mask, alpha, modes=("semantic",), pool=pool, k=5)[0]["semantic"]
    assert (sem_scores >= 0).sum() >= min(pool, 300) and np.isclose(sem_scores.max(), 1.0, atol=1e-5)
    index.close()


def test_masked_candidates_never_leak_into_results():
    index, V, q, text = _toy_index()
    mask = np.zeros(len(V), dtype=bool)
    mask[[5, 17, 305]] = True                              # only three documents are allowed
    for mode in ("hybrid", "semantic", "keyword"):
        s = index.score(text, q, mask, 0.6, modes=(mode,), pool=10, k=5)[0][mode]
        assert set(np.nonzero(s >= 0)[0]) <= {5, 17, 305}
    index.close()


def _index_inputs(db):
    from app.database.models import IncidentEmbedding
    from app.rag.embeddings import embedding_service
    from app.rag.index import hybrid_index

    hybrid_index.ensure(db)
    rows = (
        db.query(IncidentEmbedding.incident_id, IncidentEmbedding.embedding_vector, IncidentEmbedding.text_representation)
        .filter(IncidentEmbedding.embedding_model == embedding_service.identifier)
        .order_by(IncidentEmbedding.incident_id)
        .all()
    )
    return hybrid_index, rows


def test_hybrid_index_scores_equal_brute_force_scoring(client):
    """The Qdrant-backed hybrid score must equal the exact NumPy blend it replaced, for every mode."""
    from app.database.connection import SessionLocal

    with SessionLocal() as db:
        index, rows = _index_inputs(db)
        V = np.asarray([r[1] for r in rows], dtype=np.float32)
        n, alpha = len(rows), settings.HYBRID_ALPHA
        assert n >= 50 and list(index.ids) == [r[0] for r in rows]
        assert index.store.count(index.collection) == n                      # every document is in Qdrant
        for pos in range(0, n, max(n // 12, 1)):
            inc_id, vec, text = rows[pos]
            q = np.asarray(vec, dtype=np.float32)
            mask = np.ones(n, dtype=bool)
            mask[pos] = False
            scores, _, _ = index.score(text, q, mask, alpha, pool=3, k=5)   # tiny pool: the exactness bound must widen it
            sem = np.clip(V @ q, 0.0, 1.0)
            kw = index.bm25.normalized_scores(tokenize(text))
            for mode, exact in (("hybrid", alpha * sem + (1 - alpha) * kw), ("semantic", sem), ("keyword", kw)):
                exact = np.where(mask, exact, -1.0)
                got = np.sort(scores[mode][np.argsort(-scores[mode])[:5]])[::-1]
                want = np.sort(exact[np.argsort(-exact)[:5]])[::-1]
                np.testing.assert_allclose(got, want, atol=1e-4, err_msg=f"{mode} top-5 scores differ for incident {inc_id}")


def test_hybrid_search_honours_metadata_filters_through_qdrant(client):
    from app.database.connection import SessionLocal
    from app.database.models import Incident
    from app.rag.hybrid_search import hybrid_search_service

    with SessionLocal() as db:
        index, rows = _index_inputs(db)
        probe = db.query(Incident).filter(Incident.id == rows[0][0]).one()
        hits = hybrid_search_service.search(db, rows[0][2], filters={"attack_type": probe.attack_type}, top_k=5, similarity_threshold=0.0)
        assert hits and all(h["attack_type"] == probe.attack_type for h in hits)
        none = hybrid_search_service.search(db, rows[0][2], filters={"attack_type": "No Such Attack"}, top_k=5, similarity_threshold=0.0)
        assert none == []
        excl = hybrid_search_service.search(db, rows[0][2], top_k=5, similarity_threshold=0.0, exclude_id=probe.id)
        assert excl and probe.id not in [h["incident_id"] for h in excl]


def test_health_reports_the_qdrant_store(client):
    h = client.get("/api/v1/health").json()["data"]["components"]["vector_index"]
    assert h["engine"] == "qdrant" and h["store_mode"] == "local" and "Qdrant" in h["details"]
    assert h["qdrant_points"] in (None, h["current_model_documents"])


def test_index_rebuilds_from_sql_when_the_qdrant_folder_is_lost(client):
    """The SQL embedding rows are the system of record: a wiped collection is refilled without re-embedding."""
    import shutil

    from app.database.connection import SessionLocal

    with SessionLocal() as db:
        index, rows = _index_inputs(db)
        n = len(rows)
        index.close()                                   # release the storage lock, then lose the folder (new machine, cleaned disk)
        shutil.rmtree(settings.QDRANT_PATH)
        index.invalidate()
        index.ensure(db)                                # reopens an empty store and refills it from the SQL rows
        assert index.last_sync["upserted"] == n and index.store.count(index.collection) == n
        assert index.search(db, rows[0][2], top_k=3, threshold=0.0)
