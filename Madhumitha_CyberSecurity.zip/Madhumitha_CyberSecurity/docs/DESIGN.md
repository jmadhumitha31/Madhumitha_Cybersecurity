# Design Document - AI-Powered Cybersecurity Incident Response Assistant

Companion files: [`architecture.svg`](architecture.svg) (diagram), [`../README.md`](../README.md) (how to run), `presentation/` (10-minute deck).

## 1. Problem and scope

Security analysts must (a) find similar past incidents, (b) classify attack patterns, (c) judge severity, and (d) decide
what to investigate first, across large volumes of network-flow records. This system retrieves similar historical
incidents, classifies and scores flows, explains why, drafts investigation guidance with an LLM, and learns from
analyst feedback. Dataset: **CIC-IDS2017** (labelled benign + 14 attack labels, mapped to 9 families).

### Requirement traceability (PDF brief → implementation)

| Brief requirement | Where it lives | How it is verified |
|---|---|---|
| Basic RAG, historical similarity search | `app/rag/*`, `POST /search`, retriever in the analysis agent | leave-one-out benchmark (`/evaluation/retrieval`), `tests/test_search.py` |
| Hybrid keyword + semantic retrieval | `rag/index.py`: MiniLM dense (384-d) in on-device Qdrant (`rag/vector_store.py`) + BM25, α = 0.6 | benchmark compares hybrid vs each channel |
| Incident classification agent | `agents/detection_agent.py` → `ml/predictor.py` | held-out evaluation, `tests/test_ml.py` |
| Metadata filtering (type, protocol, src/dst, ports, time) | `rag/filters.py` (SQL), UI filter panel | `tests/test_search.py` (every filter, tz-aware time) |
| Investigation + response recommendations | `agents/response_agent.py`, `llm/*` | LangGraph trace, output validation checks |
| Input-validation guardrails | `guardrails/input_validation.py`, pydantic bounds | `tests/test_guardrails.py` |
| Incident prioritisation | `ml/risk.py`, `GET /incidents/queue` | `tests/test_ml.py`, triage queue in UI |
| API endpoints | `app/api/v1/*` (OpenAPI at `/docs`) | `tests/` (195 tests) |
| DeepEval | `evaluation/deepeval_eval.py` (real library, independent judge) | live runs stored in `evaluation_runs` |
| Attack-type + intrusion-risk model | classifier + calibrated binary intrusion model | held-out metrics |
| LLM-as-Judge | `evaluation/llm_judge.py` (independent model, strict mode) | live runs, mocked-transport tests |
| Multi-agent workflow | `graph/` (LangGraph: validate → detect → analyse → risk → respond → validate) | execution trace per run |
| Anomaly / suspicious-traffic risk | Isolation Forest on benign traffic, ECDF-calibrated score | AUC on unseen attacks |
| Explainability of features vs attack types | per-flow SHAP, class profiles, mean \|SHAP\| (`ml/explainability.py`) | additivity test, UI chart |
| Explainability and observability of every query | `app/observability/*`, `api/v1/observability.py`, *Explain & Traces* page | `tests/test_observability.py` (22 tests), live traces of real AICredits GPT-4o-mini runs |
| Feedback loop | feedback → relabel → re-embed → retrain job (`ml/retrain.py`) | `tests/test_incidents_api.py` end-to-end |
| Simple front-end | `frontend/` (React 19 + TS + Tailwind + Recharts) | type-check + production build, live browser run |
| Deliverables | `docs/architecture.svg`, this file, `docs/presentation/`, full code | - |

## 2.1 System Architecture Diagram & 10-Component Decomposition
![AI-Powered Cybersecurity Incident Response Assistant Architecture](../architecture/Architecture_Diagram.png)

The system is organized into **10 decoupled architectural components** operating across a **7-stage end-to-end flow** (**Detect • Analyse • Investigate • Respond • Report**):
1. **Data Sources / Ingestion:** Ingests Network Traffic (PCAP, NetFlow, logs), Firewall & IDS/IPS Alerts, Endpoint Logs (EDR, system logs), and User-Submitted Files (CSV, JSON).
2. **Data Ingestion Pipeline:** Deterministic 6-step pipeline: **Collect • Parse & Normalize • Validate • Deduplicate • Enrich • Queue/Batch**.
3. **Backend & Orchestration:** High-concurrency **FastAPI** ASGI service, Pydantic v2 schemas, JWT RBAC security, input guardrails, and **LangGraph** orchestrator connected to the **React 19 SPA** and **Streamlit** frontends.
4. **LangGraph Investigation Workflow:** 6-node stateful workflow: **1. Validate Input → 2. Detection Agent → 3. Analysis Agent → 4. Risk Agent → 5. Response Agent → 6. Final Validation Gate**.
5. **ML Models (Tri-Model + XAI):** Random Forest Classifier (99.0% acc), Gradient Boosting Intrusion Model (0.998 AUC), Isolation Forest Anomaly Detector, and SHAP TreeExplainer local feature attribution.
6. **LLM Providers (Multi-Tier Hierarchy):** Primary **AICredits** (GPT-4o-mini) → Fallback **NVIDIA NIM** (Llama-3.2-11B) → Local **Ollama** (Llama 3.1) → **Offline Deterministic Playbooks**.
7. **RAG Knowledge Base:** 4,236 confirmed incidents, FastEmbed ONNX (`sentence-transformers/all-MiniLM-L6-v2`), and **Qdrant** Embedded HNSW vector store + Okapi BM25 keyword matching.
8. **Guardrails:** 4-layer defense: schema bounds, prompt injection filtering, output formatting validation, and factual flow reference enforcement.
9. **Investigation Report:** Standardized four-section incident report with transparent mathematical risk score (0–100), priority (P1–P4), telemetry evidence, and Trace ID.
10. **Monitoring & Evaluation:** DeepEval (100% Relevancy, 96.25% Faithfulness, 0% Hallucination), RAG metrics (P@1: 98.41%, MRR: 0.9889), OpenTelemetry span tracing, and Analyst Feedback loop.

### End-to-End Operational Flow (7 Stages)
1. **Collect & Ingest Data** → 2. **Normalize & Validate** → 3. **Detect & Classify** → 4. **Analyse & Enrich** → 5. **Assess Risk & Explain** → 6. **Generate Response & Report** → 7. **Validate & Monitor**.


## 2.2 End-to-End System Data Flow Architecture Diagram
![End-to-End System Data Flow Architecture](../architecture/Data_Flow_Architecture.png)

### Detailed Operational Data Flow Across 7 Stages

```mermaid
flowchart TD
    %% Styling definitions
    classDef source fill:#0f172a,stroke:#0284c7,stroke-width:2px,color:#f8fafc;
    classDef pipe fill:#0f172a,stroke:#06b6d4,stroke-width:2px,color:#f8fafc;
    classDef api fill:#0f172a,stroke:#8b5cf6,stroke-width:2px,color:#f8fafc;
    classDef graph fill:#111827,stroke:#10b981,stroke-width:2px,color:#f8fafc;
    classDef ml fill:#1e293b,stroke:#f59e0b,stroke-width:2px,color:#f8fafc;
    classDef rag fill:#1e293b,stroke:#ec4899,stroke-width:2px,color:#f8fafc;
    classDef risk fill:#1e293b,stroke:#eab308,stroke-width:2px,color:#f8fafc;
    classDef llm fill:#1e293b,stroke:#10b981,stroke-width:2px,color:#f8fafc;
    classDef gate fill:#1e293b,stroke:#ef4444,stroke-width:2px,color:#f8fafc;
    classDef store fill:#0f172a,stroke:#6366f1,stroke-width:2px,color:#f8fafc;
    classDef ui fill:#0f172a,stroke:#0284c7,stroke-width:2px,color:#f8fafc;
    classDef feedback fill:#0f172a,stroke:#f43f5e,stroke-width:2px,color:#f8fafc;

    %% Stage 1
    subgraph S1 ["Stage 1: Telemetry & Ingestion"]
        SRC["Raw Telemetry Sources<br/>• PCAP / NetFlow / IPFIX<br/>• CIC-IDS2017 Dataset (2.59M flows)<br/>• Suricata / Snort IDS Alerts<br/>• Analyst CSV / JSON Uploads"]:::source
    end

    %% Stage 2
    subgraph S2 ["Stage 2: Ingestion Pipeline & Guardrails"]
        PIPE["Data Ingestion Pipeline<br/>1. Header Parse & Rate Calculation<br/>2. NaN / Inf / Negative Filtering<br/>3. Deduplication (423k dropped)<br/>4. RFC 1918 & Port Bound Validation<br/>5. Prompt-Injection Screening"]:::pipe
    end

    %% Stage 3
    subgraph S3 ["Stage 3: Triage Queue & API"]
        QUEUE["Active Triage Queue (SQLite)<br/>• 90 NEW Alerts (P1-P4)<br/>• 5 INVESTIGATING Active"]:::api
        API["FastAPI Orchestrator (/api/v1)<br/>• JWT RBAC Authentication<br/>• POST /incidents/{id}/analyze<br/>• Spawns LangGraph StateGraph"]:::api
    end

    %% Stage 4
    subgraph S4 ["Stage 4: LangGraph Multi-Agent Investigation Engine"]
        N1["4.1 Validate Input<br/>• Feature schema assertions<br/>• Baseline checks"]:::graph
        N2["4.2 Detection Agent (Tri-Model + XAI)<br/>• Random Forest (99% acc, 9 classes)<br/>• Gradient Boosting (0.998 AUC intrusion)<br/>• Isolation Forest (ECDF anomaly score)<br/>• SHAP TreeExplainer local attributions"]:::ml
        N3["4.3 Analysis Agent (Hybrid RAG)<br/>• Label-free behavioral query<br/>• FastEmbed (MiniLM 384-d dense)<br/>• Qdrant HNSW (4,236 resolved cases)<br/>• Okapi BM25 Lexical Keyword Match<br/>• Hybrid Score = 0.6 Dense + 0.4 BM25"]:::rag
        N4["4.4 Risk Assessment Agent<br/>• Deterministic Risk Formula (0-100)<br/>• 0.40 Sev + 0.25 P(mal) + 0.15 Anom + 0.20 Ind<br/>• Priority Classification: P1 - P4"]:::risk
        N5["4.5 Response Agent (LLM Reasoning)<br/>• PRIMARY: AICredits GPT-4o-mini<br/>• Multi-Tier Fallback: NVIDIA NIM -> Ollama<br/>• Generates 4-Section Response Report"]:::llm
        N6["4.6 Final Validation Gate<br/>• 6 Safety & Hallucination checks<br/>• Non-destructive actions enforced<br/>• Mandatory human authorization"]:::gate
    end

    %% Stage 5
    subgraph S5 ["Stage 5: Dual Persistence & Observability"]
        DB["SQLite DB & OpenTelemetry<br/>• incidents: status -> INVESTIGATING<br/>• analysis_results: report, SHAP, score<br/>• audit_logs & traces (X-Trace-ID)"]:::store
        QDRANT["Qdrant Vector Store<br/>• 4,236 Historical Vectors<br/>• Embeds confirmed solutions"]:::store
    end

    %% Stage 6
    subgraph S6 ["Stage 6: React 19 SOC Cockpit"]
        UI["React 19 Dashboard<br/>• Triage Queue with P1-P4 Badges<br/>• SHAP Recharts Waterfall Chart<br/>• Top-K Similar Historical Incidents<br/>• AICredits GPT-4o-mini Report Badge<br/>• Interactive Containment Checklist"]:::ui
    end

    %% Stage 7
    subgraph S7 ["Stage 7: Human-in-the-Loop Feedback Loop"]
        FB["Analyst Decision & Learning<br/>• Confirm Attack / Mark False Positive<br/>• Authorize Containment Execution<br/>• Incident Marked RESOLVED<br/>• Re-vectorize & Insert to Qdrant<br/>• Scheduled Retraining (ml/retrain.py)"]:::feedback
    end

    %% Flow transitions
    SRC -->|Raw 5-tuple & Telemetry| PIPE
    PIPE -->|Split: 4,236 Resolved| QDRANT
    PIPE -->|Split: 95 Active Alerts| QUEUE
    QUEUE -->|Analyst Clicks Investigate| API
    API -->|Init IncidentState| N1
    N1 -->|Validated Flow Features| N2
    N2 -->|Predictions & SHAP Drivers| N3
    N3 -->|Top-K Historical Incident Context| N4
    N4 -->|Risk Score & Priority P1-P4| N5
    N5 -->|Drafted Incident Report| N6
    N6 -->|Persist Results & Spans| DB
    N6 -->|Structured JSON Payload| UI
    UI -->|Analyst Verdict & Containment Action| FB
    FB -->|Embed New Verified Incident| QDRANT
    FB -.->|Retrain Trigger if F1 Drift| N2
```

The system data pipeline proceeds through 7 deterministic phases:

1. **Stage 1 (Ingestion):** Network flows (PCAP, NetFlow, or CIC-IDS2017) are captured as 80+ dimensional feature vectors containing packet counts, inter-arrival times (IAT), directional volume, and TCP flags.
2. **Stage 2 (Pipeline & Input Guardrails):** Headers are normalized, negative durations and invalid infinities/NaNs are stripped, duplicates are pruned, and input guardrails assert IP RFC boundaries and port limits.
3. **Stage 3 (Triage Queue & API Orchestration):** Resolved incidents seed the historical knowledge base, while 95 active flows are routed to the SQLite triage queue (`NEW` and `INVESTIGATING`). An analyst selecting an alert triggers `POST /api/v1/incidents/{id}/analyze`.
4. **Stage 4 (LangGraph Multi-Agent Engine):**
   - **4.1 Validate Input:** Confirms telemetry integrity.
   - **4.2 Detection Agent:** Runs the Tri-Model ML ensemble (Random Forest attack classifier, Gradient Boosting intrusion detector, Isolation Forest anomaly scorer) and generates SHAP local feature attributions.
   - **4.3 Analysis Agent:** Synthesizes a label-free behavioural query and executes hybrid retrieval (FastEmbed dense vector cosine search in Qdrant across 4,236 resolved incidents + Okapi BM25 lexical match, fused at $lpha = 0.60$).
   - **4.4 Risk Agent:** Computes the mathematical risk score (0–100) and maps the incident to P1 (Critical), P2 (High), P3 (Medium), or P4 (Low).
   - **4.5 Response Agent:** Formulates a forensic incident prompt and queries **AICredits GPT-4o-mini** (with NVIDIA NIM fallback) to produce root-cause analysis, forensic evidence breakdown, and containment playbooks.
   - **4.6 Final Validation Gate:** Audits the report for hallucinated IDs and ensures action commands are safe and strictly proposed for human sign-off.
5. **Stage 5 (Dual Persistence & Tracing):** Investigation results, execution latencies, risk factors, and OpenTelemetry spans are committed to SQLite (`soc_assistant.db`) under an immutable `X-Trace-ID`.
6. **Stage 6 (React 19 Presentation):** The frontend renders the complete incident cockpit—interactive SHAP waterfall charts, similar incident cards, risk gauge, AICredits model badge, and interactive containment checklist.
7. **Stage 7 (Human-in-the-Loop Feedback & Continuous Learning):** The SOC analyst reviews and confirms or adjusts the classification, approves containment actions, and marks the case `RESOLVED`. The verified flow is embedded into Qdrant as new ground truth, and the retraining pipeline (`ml/retrain.py`) monitors model drift.

## 2. Data

* **Real data**: `bvsam/cic-ids-2017` (Hugging Face Parquet mirror of the official TrafficLabelling CSVs) downloaded by
  `scripts/download_cicids2017.py`: 2.59 M flows read, 291 k dropped (NaN/inf/negative), 423 k exact duplicates removed.
* **Loader** (`ml/dataset.py`) understands real header spellings, the mangled en-dash in `Web Attack – …`, mixed
  timestamp formats, repeating Flow IDs and per-label sampling caps (rare classes - Heartbleed 11 flows, Infiltration
  36 - are always kept whole). Raw labels map to 9 families (`domain.py`).
* **Split**: deterministic hash of flow identity, 75/25, every class with ≥ 2 rows gets ≥ 1 test row. The *knowledge
  base* is sampled from the training side; the *alerts* an analyst investigates come from the held-out side and carry no
  label (the dataset's label is not stored on them).
* **Synthetic fallback** (`scripts/generate_sample_dataset.py`) exists only so the app can start without the dataset; it
  is tagged `synthetic-demo` everywhere and the UI shows a warning banner.

Real-traffic facts the design had to respect (measured, not assumed): SYN/RST/ACK are 0/1 flags (so "500 SYNs" never
occurs); the DDoS family is a slow HTTP flood (median 2.4 pkts/s per flow); port scans are 1-packet probes lasting
microseconds; Heartbleed and the Metasploit infiltration both use TCP port 444.

## 3. Machine learning (`app/ml`)

| Model | Algorithm | Held-out result (31,675 unseen flows) |
|---|---|---|
| Attack-type classifier | RandomForest (150 trees, class-balanced) on 17 flow features | accuracy 99.0 %, macro-F1 0.952; Botnet / Web Attack precision ≈ 0.81; Infiltration recall 0.70 (n = 10) |
| Intrusion-risk model | Gradient boosting + sigmoid calibration, benign vs attack | ROC-AUC 0.997, 86.6 % detection at 1 % FPR |
| Anomaly detector | Isolation Forest fitted on **benign only**, ECDF-calibrated to 0-1 | ROC-AUC 0.939 against attacks it never saw |

Models are versioned bundles (`models/versions/<ts>/bundle.joblib` + `metrics.json`); `active_model.json` selects the
live one and can be hot-reloaded. Reported caveats are part of the artefact (`metadata.caveat`): a random split
over-estimates cross-network performance, classes with < 30 test flows are flagged "low support".

**Explainability.** *Local*: SHAP `TreeExplainer` contribution of each feature to the predicted class probability for
the flow being investigated (additivity is unit-tested). *Global*: per-class median / IQR profile versus benign, plus mean
|SHAP| per class computed at training time. *Narrative*: data-driven evidence statements ("Backward Bytes is 55,095× the
benign median") plus protocol/port semantics.

**Risk and priority** (`ml/risk.py`) - a transparent score, not a black box:
`score = 100 · (0.40·severity(class)·confidence + 0.25·P(malicious) + 0.15·anomaly + 0.20·traffic indicators)` ± 0.06 for
retrieval agreement; policy floors (confident Heartbleed/Infiltration ⇒ Critical, Botnet ⇒ High) and an escalation when the
classifier says Benign but the independent intrusion model disagrees. Levels: ≥ 75 Critical (P1), ≥ 55 High (P2), ≥ 35 Medium
(P3), else Low (P4). A dataset- or analyst-confirmed Benign flow is always Low.

## 4. Hybrid retrieval (`app/rag`)

* **Dense channel**: `sentence-transformers/all-MiniLM-L6-v2` through `fastembed` (ONNX, no PyTorch). It embeds a compact
  *behavioural description* of the flow (service, duration class, packet volume, direction, payload size, rate, idle gaps).
  The vectors live in **Qdrant, embedded and on-device** (`QDRANT_PATH`, default `backend/data/qdrant`; cosine distance,
  one collection per embedding model and dimension) and Qdrant performs the similarity search.
* **Lexical channel**: Okapi BM25 with IDF and length normalisation over the full text (IPs, ports, exact metrics, attack
  family descriptions); scores normalised against the query's self-match so thresholds are meaningful. The postings are
  derived from the stored texts and rebuilt in a fraction of a second when the table changes; they are not persisted.
* **Score** `α·dense + (1-α)·BM25`, α = 0.6. Metadata filters compile to SQL (the database owns the mutable fields: type,
  status, risk) and reach Qdrant as an id restriction.
* **Exactness.** The blend is exact for the top-k, not "approximately the best of a fixed pool": candidate pools are
  tie-inclusive (flow descriptions are bucketed, so a median of ~100 and up to ~500 documents tie with the best dense
  score) and a threshold-algorithm bound (`α·dense_boundary + (1-α)·BM25_boundary`) widens the pool whenever the k-th hit
  does not clear it. A constructed worst case (300 tied vectors, a crowded lexical pool) returns the exact scores where a
  fixed pool of 10 returns 0.75 / 0.75 / 0.70 for ranks 3-5 instead of 0.83.
* **Index storage.** The SQL `incident_embeddings` rows stay the system of record; the Qdrant collection is diff-synced
  from them (a per-point fingerprint of the row), so a restart over an unchanged store transfers no vectors (index ready
  in 0.3 s for 4,331 incidents) and a lost Qdrant folder is refilled from SQL without re-embedding. The embedded store is
  locked to one process; several API workers need a Qdrant server (`QDRANT_URL`, same client API, not exercised here).
* **Label-free queries**: when investigating an alert the query is built from telemetry only; neither a stored label nor
  the model's own prediction can leak into retrieval. Only *confirmed* (dataset or analyst) incidents count as evidence.
* **Empty state** is explicit: *"No sufficiently similar historical incidents were found."* (threshold 0.75 for incident
  → history, 0.20 for free text; both calibrated on real data).

**Measured design decisions** (leave-one-out, 315 queries over 4,235 labelled incidents, random precision 0.141):

| Variant | P@5 |
|---|---|
| Dense, document text with attack-family sentence | 0.274 |
| Dense, behaviour-only text (**chosen**) | 0.865 |
| BM25 only | 0.940 |
| **Hybrid (deployed, searched through Qdrant)** | **P@1 0.984, P@5 0.956, MRR 0.989** |
| Hybrid with IP addresses removed | 0.939 |

The first row is why the dense text excludes the label description: the long family sentence on documents (absent from
queries) dominated the embedding.

*Tie handling matters for the dense-only rows.* Many flows have an identical description, hence an identical vector, so
the top-5 among exactly tied documents is arbitrary. The benchmark therefore rounds scores to 6 decimals and shuffles ties
with a fixed seed. Ordering ties by index instead made the same dense-only run score anywhere from 0.71 to 0.87 P@5 (an
earlier revision of this table quoted 0.857, one such arbitrary order). The hybrid and BM25 rows are unaffected, and
moving the dense channel into Qdrant left the hybrid metrics identical to four decimals.

## 5. Agents and workflow (`app/graph`, `app/agents`)

LangGraph `StateGraph` with a conditional edge after input validation. Nodes: **validate_input** → **Detection**
(class, intrusion probability, anomaly, SHAP) → **Analysis** (hybrid RAG, class vote) → **Risk** (score, level,
priority, factors) → **Response** (LLM analysis + actions) → **final_validation**. The last node is a real gate: it checks
that recommendations are safe, risk fields are consistent, the predicted class is addressed, and that **no incident
identifier appears that was not retrieved** (hallucination guard). Containment advice is always a proposal that needs analyst
approval; `requires_analyst_review` is always true.

## 6. LLM layer (`app/llm`)

Chain: **AICredits (GPT-4o-mini / GPT-4o) → NVIDIA NIM (fallback) → Ollama (local) → offline playbooks**.

* TLS: corporate TLS inspection made every HTTPS call fail with `CERTIFICATE_VERIFY_FAILED`, silently degrading the app to
  canned text. The app now trusts the OS certificate store (`truststore`); verification is never disabled.
* Models: the provider walks a model list. `meta/llama-3.1-70b-instruct` is retired (HTTP 410), and several listed
  models return 404 "not deployed for this account". Probed outcome: primary generator AICredits (`gpt-4o-mini`), fallback `meta/llama-3.2-11b-vision-instruct`,
  independent judge `nvidia/nemotron-3-super-120b-a12b` (fallback `openai/gpt-oss-20b`).
* Reasoning models spend tokens "thinking": empty `content` with `finish_reason=length` is treated as a failure and the next
  model is tried; judge calls use a larger budget.
* Every response carries an `attempts` log (provider, model, status, error, latency) shown in the UI.
* **Strict mode** (`generate_strict`) is for evaluators: it never degrades to canned text; no judge ⇒ `unavailable`.
* The offline engine has per-family playbooks that reference the flow's hosts and ports and is always labelled as such.

## 7. Feedback loop (`ml/retrain.py`, `services/incident_service.py`)

1. An analyst submits *Correct / Incorrect / Partially correct* with a confirmed family (validated enum).
2. The incident's `ground_truth_label` is set (source `analyst`), risk recomputed, and the embedding regenerated, so it
   becomes retrievable evidence immediately.
3. `POST /ml/retrain` (admin, background job) trains a candidate on *base data + all analyst-confirmed incidents*
   (weight ×5, training side only), scores candidate and current model on the **same** held-out split, and promotes the
   candidate unless macro-F1 regresses by more than one point. Every attempt is recorded (`model_versions`, `evaluation_runs`).

## 8. Evaluation suite (`app/evaluation`)

* **ML**: held-out metrics with provenance; re-scoring recomputes them from the dataset.
* **Retrieval**: leave-one-out P@k, hit@k, MRR, nDCG, baselines, IP-free variant, threshold sweep.
* **DeepEval** (real library): AnswerRelevancy, Faithfulness, Hallucination, GEval(recommendation safety) with an
  independent NIM judge. Normalises the library's direction change (4.x: 1 = pass) to a hallucination *rate*.
  Last live run (4 stored analyses synthesized by AICredits (`gpt-4o-mini`), judge `nvidia/nemotron-3-super-120b-a12b`,
  16/16 metric scores, 44 judge calls, 465 s): answer relevancy 100 %, faithfulness 96 %, hallucination rate 0 %,
  recommendation quality 45 % (the weakest result: steps often omit a host or port; the prompt now requires them, which
  moved the same four incidents from 40 % to 45 %, within the noise of n = 4). An earlier run scored only 10/16 because of
  judge-JSON failures; those errors were reported as errors, not as zeros, and the judge adapter now extracts the JSON object
  and retries a reasoning model that spends its whole token budget thinking.
* **LLM-as-Judge**: independent model, JSON verdict with one repair attempt; `unavailable` / `parse_failed` produce no scores.
  The judge sees evidence and dataset facts and is told to penalise unsupported claims, not textbook deviations.
* Deterministic guardrail metrics (unsafe automation rate, human-gate rate) are reported separately from LLM scores.

## 9. Observability and explainability (`app/observability`)

**Goal.** Any answer the system gives must be reconstructable afterwards: who asked what, which guardrail or model decided what,
on which evidence, how long each step took, and what came back. Every analyst query is therefore a *trace*; the *Explain & Traces*
page (`/observability`) is the audit and analysis surface.

**Data model.** `traces` (one row per query: kind, user, query text, status, duration, DB time/queries, sanitised input/output,
summary facts) and `trace_spans` (a tree: name, component, start offset, duration, *self* time, attributes, error). Status is
`ok`, `degraded` (answered, but a component failed or fell back, e.g. the LLM chain ended at the offline playbooks), `rejected`
(a guardrail or validation refused it) or `error`. Traced operations: search, copilot chat, classify, incident create / analyse /
explain / feedback, evaluation runs, retraining, index reindex, and the start-up warm-up. Background jobs (DeepEval, retraining)
are traces of their own.

**Tracer.** Context variables carry the active trace into Starlette's worker threads, so instrumented code needs no plumbing.
Outside a trace a span is a no-op (scripts and tests pay nothing); the retrieval benchmark's ~600 queries are suppressed and
summarised by one span. Everything stored is passed through a cleaner (secrets scrubbed by key and by pattern, strings clipped,
collections capped, numpy/datetime made JSON-safe, spans capped per trace). Persisting a trace can fail without failing the
request. SQLAlchemy events count database queries and time per trace; per-trace counters (`llm.calls`, `retrieval.empty`,
`guardrail.blocked.*` ...) let the metrics endpoint aggregate without loading span payloads.

| Span | Component | What it records |
|---|---|---|
| `guardrail.input_validation` / `.security_screen` / `.relevance` | guardrail | which rule fired, the vocabulary that made a query on-topic |
| `ml.classifier` / `.intrusion_model` / `.anomaly_detector` / `.explain` | ml | class + confidence + runners-up, P(malicious), anomaly percentile, top SHAP drivers |
| `retrieval.sql_filters` / `.dense_qdrant` / `.bm25` / `.dense_exact_fill` / `.score` / `.search` | retrieval | eligible incidents, Qdrant pool and ties, query terms, exactness stats, ranked results with dense/BM25 split and matched terms |
| `embedding.embed`, `index.ensure`, `index.sync` | embedding / retrieval | model, dimension, time; whether the index had to sync |
| `risk.assess` | risk | inputs, the weighted components, policy floors |
| `llm.generate` | llm | provider chain, every attempt, tokens, prompt hash and (optionally) scrubbed prompt/response previews |
| `agent.*`, `workflow.investigation`, `response.postprocess`, `agent.final_validation` | agent / guardrail | each LangGraph node's decision, rewritten unsafe steps, the six output checks |
| `chat.*`, `feedback.relabel`, `incident.triage`, `ml.promotion_decision` | various | copilot routing, label change and its effect, retraining decision |

**Explanation.** `explain_trace` turns the spans into a numbered narrative and structured evidence (retrieval table with matched
terms, SHAP chart, risk arithmetic, LLM attempts, checks). It is deterministic and uses no LLM, so it cannot assert anything the
system did not do. `system_explanation` documents each pipeline stage with its *live* weights, thresholds and models. The
narrative explains what the system did; it cannot explain why the LLM chose its words (the trace shows the prompt, evidence and
output checks instead).

**Metrics.** Aggregated from the stored traces: volume by outcome over time, p50/p95/p99 per operation, self time per component,
LLM fallback and failed-attempt rates and tokens, empty-search rate, pool widenings, guardrail blocks, output-check pass rate.
Also available as Prometheus text.

**Correlation.** `X-Trace-ID` on every traced response and `trace_id` in the body (search, chat, analysis, classify, explain);
the trace id is stored in the audit-log entry's details and on each stored analysis (`analysis_results.trace_id`), and every JSON
log line carries it.

**Access and privacy.** Analysts and admins see all traces; viewers see only their own; export needs analyst/admin and is itself
audited; retention pruning is admin-only. Prompt/response previews can be switched off (`TRACE_STORE_PAYLOADS`); retention defaults
to 30 days.

**Cost (measured).** 4 µs per span; about 11 ms to persist a trace synchronously (a warm search is 100-140 ms, an investigation 13-20 s);
about 14 kB per trace.

**What it found the first time it ran on real data.** (1) A free-text search took 510 ms, 352 ms of it inside `retrieval.score`: the
new `dense_exact_fill` span showed embedded Qdrant spending ~0.4 ms per id on a `has_id` filter. Fetching those vectors and taking the
cosine locally, and only for lexical candidates whose upper bound can still reach the top-k, brought the search to ~140 ms with
identical results (brute-force parity tests unchanged). (2) A test that sends `api_key=...` as a search query showed the BM25 span
listing the secret's *tokens*; displayed terms now come from the scrubbed text. (3) The key filter wrongly scrubbed `prompt_tokens`;
it now matches `token` only as a whole word. Each is covered by a regression test.

## 10. Security

JWT (HS256) + bcrypt; roles re-read from the database; no anonymous fallback; admin-only account creation; login
throttling; production refuses the default JWT secret; strict CORS; security headers; prompt-injection screening and
prompt sanitising of untrusted fields; secrets never logged (scrubbed); `.env` is git/docker-ignored.

## 11. Deployment

Local: SQLite + Vite dev server. Docker Compose: PostgreSQL 16, backend (entrypoint bootstraps users → models →
incidents → index), nginx serving the SPA and proxying `/api`. The vector index is embedded Qdrant on a named volume
(`qdrantdata` → `/app/qdrant_storage`); the embedding rows stay in SQL as the rebuild source, so no pgvector extension is
needed. Embedded Qdrant holds its collection in RAM while open and its client warns beyond 20,000 points; beyond that, point
`QDRANT_URL` at a Qdrant server.

**First run on a new computer.** `setup.bat` / `setup.sh` are thin OS-specific entry points that make sure Python 3.11/3.12 and Node
(20.19+ / 22.12+) exist, then hand over to the stdlib-only `setup_project.py`, which runs nine idempotent, resumable steps (preflight,
venv, pinned packages from `constraints.txt`, `.env`, `npm ci`, dataset, bootstrap, index, start) and verifies each by its real artefact
rather than a flag (`.setup/state.json` only caches hashes and choices). Two findings from the clean-room run shaped it: Vite 8's bundler
needs Node 20.19+/22.12+ and on an older Node `npm ci` *silently skips* the platform-native binding (so the Node rule is hard and the
install is followed by an actual `import('vite')`), and on Windows a long project path can push the virtual environment beyond the
260-character limit (the venv then goes to `~/.soc-venv`).

**Sharing the project.** `package_project.py` (`package.bat` / `package.sh`) builds the zip instead of a hand-made archive: sources and
scripts, the two `.env` files (with a freshly generated `JWT_SECRET`), and a consistent SQLite snapshot of `backend/soc_assistant.db`
(online-backup API, integrity-checked); never `node_modules`, virtual environments, models, the Qdrant index, the dataset, logs or stale
database copies, all of which setup rebuilds. The zip is verified before release (forbidden members, required files, line endings and
executable bits, byte-level scan for every secret in the `.env` files) and the build refuses to produce a zip in which the API key would
appear anywhere but the `.env` files. Shipping the `.env` shares the API keys (AICredits / NVIDIA) with the recipient: it is the sender's explicit choice,
and `--no-secrets` builds a key-free zip.

## 12. Known limitations

* Random 75/25 split on one dataset; real-world generalisation will be lower. Heartbleed (3 test flows) and Infiltration
  (10) cannot be evaluated reliably.
* Benign→Web Attack / Botnet confusions drive the lower precision of those two classes.
* LLM latency varies (16-60 s per investigation); the 11B generator is modest, and an LLM judge is itself fallible (it
  rejected a correct Heartbleed analysis until given dataset context).
* The embedded Qdrant store is locked to one API process (the container entrypoint refuses `UVICORN_WORKERS` > 1 without
  `QDRANT_URL`). Server mode uses the same client API but has not been exercised here. BM25 postings are rebuilt in memory.
* Docker images were not built in the authoring environment (Docker unavailable); scripts and compose were syntax-checked.
* Setup and packaging were verified on Windows only (clean-room runs from a fresh folder and from the built zip). `setup.sh` and
  `package.sh` are syntax-checked and dry-run; the winget / python.org / nodejs.org installer branches and Windows-on-ARM were not
  exercised because those sites were unreachable from the authoring network.
* Traces are stored in the application database and written synchronously (about 11 ms and 14 kB each); a dedicated trace store or an
  OpenTelemetry exporter would be the next step at larger scale and is not implemented. The explanation narrative covers what the
  system did, not the LLM's internal reasoning.
