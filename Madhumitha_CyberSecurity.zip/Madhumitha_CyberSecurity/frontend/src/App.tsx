import React, { lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/layout/Layout';
import { ProtectedRoute } from './components/common/ProtectedRoute';
import { Login } from './pages/Login';

// Every page after sign-in is its own chunk, so the login screen and the first paint no longer pay for charts,
// markdown, the trace inspector and every other page.
const Dashboard = lazy(() => import('./pages/Dashboard').then((m) => ({ default: m.Dashboard })));
const Incidents = lazy(() => import('./pages/Incidents').then((m) => ({ default: m.Incidents })));
const IncidentDetails = lazy(() => import('./pages/IncidentDetails').then((m) => ({ default: m.IncidentDetails })));
const AddIncident = lazy(() => import('./pages/AddIncident').then((m) => ({ default: m.AddIncident })));
const AISearch = lazy(() => import('./pages/AISearch').then((m) => ({ default: m.AISearch })));
const History = lazy(() => import('./pages/History').then((m) => ({ default: m.History })));
const Analytics = lazy(() => import('./pages/Analytics').then((m) => ({ default: m.Analytics })));
const Investigation = lazy(() => import('./pages/Investigation').then((m) => ({ default: m.Investigation })));
const Evaluation = lazy(() => import('./pages/Evaluation').then((m) => ({ default: m.Evaluation })));
const Observability = lazy(() => import('./pages/Observability').then((m) => ({ default: m.Observability })));
const Settings = lazy(() => import('./pages/Settings').then((m) => ({ default: m.Settings })));
const Chatbot = lazy(() => import('./pages/Chatbot').then((m) => ({ default: m.Chatbot })));

export const App: React.FC = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />

        {/* Everything else requires a valid session */}
        <Route element={<ProtectedRoute />}>
          <Route element={<Layout />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/chat" element={<Chatbot />} />
            <Route path="/incidents" element={<Incidents />} />
            <Route path="/incidents/:id" element={<IncidentDetails />} />
            <Route path="/add-incident" element={<AddIncident />} />
            <Route path="/ai-search" element={<AISearch />} />
            <Route path="/history" element={<History />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/investigation" element={<Investigation />} />
            <Route path="/evaluation" element={<Evaluation />} />
            <Route path="/observability" element={<Observability />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
        </Route>

        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
