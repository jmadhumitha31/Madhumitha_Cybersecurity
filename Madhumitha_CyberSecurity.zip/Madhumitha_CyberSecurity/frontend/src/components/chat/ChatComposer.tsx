import React, { useId, useLayoutEffect, useRef, useState } from 'react';
import { Send } from 'lucide-react';
import { cn } from '../../lib/cn';
import { Button, IconButton } from '../ui/Button';

interface ChatComposerProps {
  onSend: (text: string) => void;
  /** Blocks sending (a reply is in flight) without taking focus away from the field. */
  busy?: boolean;
  placeholder: string;
  compact?: boolean;
  autoFocus?: boolean;
}

/**
 * Multi-line prompt box: Enter sends, Shift+Enter inserts a newline, and it grows up to ~6 lines so pasted log excerpts
 * are readable (the old single-line <input> could not show them).
 */
export const ChatComposer: React.FC<ChatComposerProps> = ({ onSend, busy = false, placeholder, compact = false, autoFocus = false }) => {
  const [value, setValue] = useState('');
  const ref = useRef<HTMLTextAreaElement>(null);
  const id = useId();

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = 'auto';
    // The box is border-box, so the border has to be added to the content height or the field overflows by 2px.
    const wanted = el.scrollHeight + (el.offsetHeight - el.clientHeight);
    el.style.height = `${Math.min(wanted, 160)}px`;
    // Only show a scrollbar once the text really exceeds the maximum height.
    el.style.overflowY = wanted > 160 ? 'auto' : 'hidden';
  }, [value]);

  const submit = () => {
    const text = value.trim();
    if (!text || busy) return;
    onSend(text);
    setValue('');
  };

  return (
    <div>
      <div className="flex items-end gap-2">
        <div className="min-w-0 flex-1">
          <label htmlFor={id} className="sr-only">
            Message the copilot
          </label>
          <textarea
            id={id}
            ref={ref}
            rows={1}
            autoFocus={autoFocus}
            value={value}
            placeholder={placeholder}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
                e.preventDefault();
                submit();
              }
            }}
            className={cn(
              'block max-h-40 w-full resize-none rounded-lg border border-soc-border bg-soc-card text-slate-100',
              'transition-colors hover:border-soc-borderLight focus-visible:border-cyan-500',
              compact ? 'px-3 py-2 text-xs' : 'px-3.5 py-2.5 text-sm',
            )}
          />
        </div>
        {compact ? (
          <IconButton label="Send message" icon={Send} variant="primary" disabled={busy || !value.trim()} onClick={submit} className="h-9 w-9" />
        ) : (
          <Button variant="primary" icon={Send} disabled={busy || !value.trim()} onClick={submit}>
            Send
          </Button>
        )}
      </div>
      {!compact && <p className="mt-1.5 text-2xs text-soc-textMuted">Enter to send · Shift+Enter for a new line</p>}
    </div>
  );
};
