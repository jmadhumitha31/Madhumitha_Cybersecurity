import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { chatService } from '../../services/chatService';
import type { ChatMessage, ChatSuggestion } from '../../types';
import { BRAND } from '../../lib/brand';
import { ChatContext, type SendOptions } from './chatContext';

const GREETING: ChatMessage = {
  role: 'assistant',
  content:
    `Hi, I'm **${BRAND.copilot}**. I answer from your labelled incident knowledge base and cite the incidents I used.\n\n` +
    'Ask about an active incident, a flow signature (DDoS, port scan, botnet, infiltration) or a containment playbook. ' +
    'The footer of every reply says which model answered, and whether it fell back to offline playbooks.',
};

const stamp = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

/**
 * Holds the one conversation shared by the full-page copilot and the floating launcher, so expanding the launcher (or
 * navigating between pages) no longer throws the chat away.
 */
export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([GREETING]);
  const [isLoading, setIsLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<ChatSuggestion[]>([]);
  const messagesRef = useRef(messages);
  const busyRef = useRef(false);

  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  useEffect(() => {
    let alive = true;
    chatService
      .getSuggestions()
      .then((s) => alive && setSuggestions(s))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, []);

  const send = useCallback(async (text: string, options: SendOptions = {}) => {
    const message = text.trim();
    if (!message || busyRef.current) return;
    busyRef.current = true;
    const history = messagesRef.current.slice(-8).map((m) => ({ role: m.role, content: m.content }));
    setMessages((prev) => [...prev, { role: 'user', content: message, timestamp: stamp() }]);
    setIsLoading(true);
    try {
      const r = await chatService.sendMessage({
        message,
        history,
        incident_id: options.incidentId ?? undefined,
        use_rag: options.useRag ?? true,
      });
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: r.reply,
          timestamp: stamp(),
          citations: r.citations,
          incident_context: r.incident_context,
          llm_provider: r.llm_provider,
          model_name: r.model_name,
          fallback_used: r.fallback_used,
          llm_attempts: r.llm_attempts,
          trace_id: r.trace_id,
        },
      ]);
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'Unknown network error';
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          isError: true,
          timestamp: stamp(),
          content: `**The query could not be completed.** ${reason}\n\nCheck that the backend service is running and an LLM provider is configured.`,
        },
      ]);
    } finally {
      busyRef.current = false;
      setIsLoading(false);
    }
  }, []);

  const clear = useCallback(() => setMessages([{ role: 'assistant', content: 'Conversation cleared. What would you like to investigate?' }]), []);

  const value = useMemo(() => ({ messages, isLoading, suggestions, send, clear }), [messages, isLoading, suggestions, send, clear]);
  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
};
