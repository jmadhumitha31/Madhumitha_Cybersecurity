import React, { useEffect, useId, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bot, Maximize2, Trash2, X } from 'lucide-react';
import { BRAND } from '../../lib/brand';
import { ENGINE_DOT, describeEngine } from '../../lib/engine';
import { useHealth } from '../../lib/useHealth';
import { cn } from '../../lib/cn';
import { IconButton } from '../ui/Button';
import { ChatComposer } from './ChatComposer';
import { MessageBubble, TypingIndicator } from './MessageBubble';
import { useChat } from './useChat';

/**
 * Quick-ask launcher on every page except /chat. It shares one conversation with the full-page copilot, so "Expand"
 * continues the same thread. Not modal: the page behind stays usable, and Escape closes it.
 */
export const FloatingChatbot: React.FC = () => {
  const [open, setOpen] = useState(false);
  const { messages, isLoading, suggestions, send, clear } = useChat();
  const { health } = useHealth();
  const engine = describeEngine(health);
  const navigate = useNavigate();
  const endRef = useRef<HTMLDivElement>(null);
  const launcherRef = useRef<HTMLButtonElement>(null);
  const panelId = useId();

  useEffect(() => {
    if (open) endRef.current?.scrollIntoView({ block: 'end' });
  }, [open, messages, isLoading]);

  const close = () => {
    setOpen(false);
    launcherRef.current?.focus();
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3">
      {open && (
        <div
          id={panelId}
          role="dialog"
          aria-label={`${BRAND.copilot} quick chat`}
          onKeyDown={(e) => e.key === 'Escape' && close()}
          className="flex h-[36rem] max-h-[calc(100dvh-8rem)] w-[26.5rem] max-w-[calc(100vw-2rem)] animate-pop-in flex-col overflow-hidden rounded-2xl border border-soc-borderLight bg-soc-surface shadow-2xl shadow-black/60"
        >
          <div className="flex shrink-0 items-center justify-between gap-2 border-b border-soc-border bg-soc-dark px-4 py-3">
            <div className="flex min-w-0 items-center gap-2.5">
              <div className="rounded-lg border border-cyan-800 bg-cyan-950/70 p-1.5 text-cyan-300">
                <Bot className="h-4 w-4" aria-hidden />
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-50">{BRAND.copilot}</p>
                <p className="flex items-center gap-1.5 truncate text-2xs text-soc-textMuted">
                  <span className={cn('h-1.5 w-1.5 shrink-0 rounded-full', ENGINE_DOT[engine.tone])} aria-hidden />
                  <span className="truncate">{engine.label}</span>
                </p>
              </div>
            </div>
            <div className="flex shrink-0 items-center">
              <IconButton
                label="Open in full workspace"
                icon={Maximize2}
                onClick={() => {
                  setOpen(false);
                  navigate('/chat');
                }}
              />
              <IconButton label="Clear conversation" icon={Trash2} onClick={clear} />
              <IconButton label="Close chat" icon={X} onClick={close} />
            </div>
          </div>

          <div role="log" aria-live="polite" aria-label="Conversation" className="flex-1 space-y-4 overflow-y-auto p-4">
            {messages.map((m, i) => (
              <MessageBubble key={i} message={m} compact />
            ))}
            {isLoading && <TypingIndicator label="Working on it" />}
            <div ref={endRef} />
          </div>

          <div className="shrink-0 space-y-3 border-t border-soc-border bg-soc-dark p-3">
            {suggestions.length > 0 && messages.length <= 2 && (
              <ul className="flex flex-wrap gap-1.5" aria-label="Suggested questions">
                {suggestions.slice(0, 3).map((s) => (
                  <li key={s.id}>
                    <button
                      type="button"
                      disabled={isLoading}
                      onClick={() => void send(s.prompt)}
                      className="rounded-full border border-soc-border bg-soc-card px-2.5 py-1 text-2xs text-slate-300 transition-colors hover:border-cyan-700 hover:text-cyan-200 disabled:opacity-50"
                    >
                      {s.title}
                    </button>
                  </li>
                ))}
              </ul>
            )}
            <ChatComposer compact autoFocus busy={isLoading} onSend={(t) => void send(t)} placeholder="Ask about an incident, e.g. “Analyze incident #1”" />
          </div>
        </div>
      )}

      <button
        ref={launcherRef}
        type="button"
        onClick={() => (open ? close() : setOpen(true))}
        aria-expanded={open}
        aria-controls={open ? panelId : undefined}
        className="inline-flex h-11 items-center gap-2 rounded-full border border-cyan-500/40 bg-cyan-700 px-4 text-sm font-medium text-white shadow-lg shadow-black/40 transition-colors hover:bg-cyan-600"
      >
        <Bot className="h-4 w-4" aria-hidden />
        <span className="hidden sm:inline">Ask Copilot</span>
        <span className="sr-only sm:hidden">Ask Copilot</span>
      </button>
    </div>
  );
};
