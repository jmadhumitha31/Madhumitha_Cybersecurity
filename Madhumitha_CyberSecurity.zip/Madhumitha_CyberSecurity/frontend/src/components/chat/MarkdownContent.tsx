import React, { useMemo } from 'react';
import { marked } from 'marked';
import DOMPurify from 'dompurify';
import { cn } from '../../lib/cn';

marked.setOptions({ gfm: true, breaks: true });

// Links in model output open in a new tab and never leak the opener.
DOMPurify.addHook('afterSanitizeAttributes', (node) => {
  if (node.tagName === 'A') {
    node.setAttribute('target', '_blank');
    node.setAttribute('rel', 'noopener noreferrer');
  }
});

const escapeText = (text: string): string => {
  const el = document.createElement('div');
  el.textContent = text;
  return el.innerHTML;
};

/**
 * Markdown from the LLM and the chat is untrusted (it can echo retrieved or user-supplied text), and `marked` does not
 * sanitise. The HTML is therefore passed through DOMPurify before it is injected.
 */
const render = (markdown: string): string => {
  try {
    const html = marked.parse(markdown || '', { async: false }) as string;
    return DOMPurify.sanitize(html, { USE_PROFILES: { html: true } });
  } catch {
    return escapeText(markdown);
  }
};

interface MarkdownContentProps {
  content: string;
  className?: string;
}

export const MarkdownContent: React.FC<MarkdownContentProps> = ({ content, className }) => {
  const html = useMemo(() => render(content), [content]);
  return <div className={cn('soc-markdown text-sm text-slate-200', className)} dangerouslySetInnerHTML={{ __html: html }} />;
};
