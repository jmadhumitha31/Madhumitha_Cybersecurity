import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, AlertCircle, Bot, Check, Copy, Cpu, Database, User } from 'lucide-react';
import { cn } from '../../lib/cn';
import { providerLabel, shortModel } from '../../lib/format';
import type { ChatMessage } from '../../types';
import { MarkdownContent } from './MarkdownContent';

interface MessageBubbleProps {
  message: ChatMessage;
  /** Tighter layout for the floating launcher. */
  compact?: boolean;
}

/** One chat turn. Shared by the full-page copilot and the floating launcher so both look and behave the same. */
export const MessageBubble: React.FC<MessageBubbleProps> = ({ message, compact = false }) => {
  const isUser = message.role === 'user';
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      /* clipboard unavailable (insecure context or blocked): nothing useful to do */
    }
  };

  const failed = message.fallback_used ? (message.llm_attempts ?? []).filter((a) => !a.ok) : [];
  const shownCitations = (message.citations ?? []).slice(0, compact ? 3 : 8);
  const hiddenCitations = (message.citations?.length ?? 0) - shownCitations.length;

  return (
    <div className={cn('group flex gap-3', isUser && 'flex-row-reverse')}>
      <div
        aria-hidden
        className={cn(
          'flex shrink-0 items-center justify-center rounded-full border',
          compact ? 'h-7 w-7' : 'h-8 w-8',
          isUser ? 'border-blue-700/60 bg-blue-950/70 text-blue-200' : 'border-cyan-700/60 bg-cyan-950/70 text-cyan-300',
        )}
      >
        {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
      </div>

      <div
        className={cn(
          'min-w-0 rounded-xl border px-4 py-3',
          compact ? 'max-w-[88%]' : 'max-w-[min(100%,46rem)]',
          isUser ? 'border-cyan-900/60 bg-cyan-950/40' : message.isError ? 'border-red-900/60 bg-red-950/30' : 'border-soc-border bg-soc-surface',
        )}
      >
        <div className="mb-1.5 flex items-center justify-between gap-4 text-2xs text-soc-textMuted">
          <span className="flex items-center gap-1.5 font-semibold text-slate-300">
            {message.isError && <AlertCircle className="h-3.5 w-3.5 text-red-400" aria-hidden />}
            {isUser ? 'You' : 'Copilot'}
          </span>
          <span className="flex items-center gap-2">
            {message.timestamp && <time>{message.timestamp}</time>}
            {!isUser && (
              <button
                type="button"
                onClick={copy}
                aria-label={copied ? 'Copied' : 'Copy message'}
                title="Copy message"
                // Hidden until hover or keyboard focus, but never unreachable for keyboard users.
                className="rounded p-0.5 text-slate-400 opacity-0 transition-opacity hover:text-cyan-300 focus-visible:opacity-100 group-focus-within:opacity-100 group-hover:opacity-100"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              </button>
            )}
          </span>
        </div>

        <MarkdownContent content={message.content} className={compact ? 'text-xs' : undefined} />

        {shownCitations.length > 0 && (
          <div className="mt-3 border-t border-soc-border/70 pt-3">
            <p className="mb-1.5 flex items-center gap-1.5 text-2xs font-semibold text-cyan-300">
              <Database className="h-3 w-3" aria-hidden />
              Grounded in these incidents
            </p>
            <ul className="flex flex-wrap gap-1.5">
              {shownCitations.map((c) => (
                <li key={c.incident_id}>
                  <Link
                    to={`/incidents/${c.incident_id}`}
                    className="inline-flex items-center gap-1.5 rounded-md border border-cyan-900/60 bg-soc-darkest px-2 py-1 text-2xs text-slate-300 transition-colors hover:border-cyan-600 hover:text-cyan-200"
                  >
                    <span className="font-mono">#{c.incident_id}</span>
                    <span className="font-semibold text-cyan-300">{c.attack_type}</span>
                    <span className="tabular-nums text-soc-textMuted">{(c.similarity_score * 100).toFixed(0)}%</span>
                  </Link>
                </li>
              ))}
              {hiddenCitations > 0 && <li className="self-center text-2xs text-soc-textMuted">+{hiddenCitations} more</li>}
            </ul>
          </div>
        )}

        {!isUser && (message.trace_id || (message.llm_provider && message.llm_provider !== 'none')) && (
          <div className="mt-3 flex flex-wrap items-center justify-between gap-x-4 gap-y-1 border-t border-soc-border/50 pt-2 text-2xs text-soc-textMuted">
            {message.llm_provider && message.llm_provider !== 'none' ? (
              <span className="flex items-center gap-1.5 text-slate-400">
                <Cpu className="h-3 w-3 text-cyan-400" aria-hidden />
                {providerLabel(message.llm_provider)}
                {message.model_name && message.llm_provider !== 'heuristic_rule_engine' ? ` · ${shortModel(message.model_name)}` : ''}
                {message.fallback_used && (
                  <span
                    className="ml-1 rounded bg-amber-950/60 px-1.5 py-0.5 text-amber-300"
                    title={failed.map((a) => `${a.provider}${a.model ? '/' + a.model : ''}: ${a.error || a.status}`).join(' | ') || 'A fallback provider answered'}
                  >
                    fallback
                  </span>
                )}
              </span>
            ) : (
              <span />
            )}
            {message.trace_id && (
              <Link to={`/observability?trace=${message.trace_id}`} className="inline-flex items-center gap-1 text-cyan-300 hover:underline" title="Guardrail decisions, retrieval, LLM call and timings for this answer">
                <Activity className="h-3 w-3" aria-hidden />
                Why this answer?
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

/** "Copilot is working" row: animated dots (replaces the spinning robot icon). */
export const TypingIndicator: React.FC<{ label?: string }> = ({ label = 'Searching the knowledge base and drafting an answer' }) => (
  <div className="flex gap-3" role="status" aria-live="polite">
    <div aria-hidden className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-cyan-700/60 bg-cyan-950/70 text-cyan-300">
      <Bot className="h-4 w-4" />
    </div>
    <div className="flex items-center gap-3 rounded-xl border border-soc-border bg-soc-surface px-4 py-3 text-xs text-slate-300">
      <span className="flex items-center gap-1" aria-hidden>
        <span className="typing-dot" />
        <span className="typing-dot" />
        <span className="typing-dot" />
      </span>
      <span>{label}…</span>
    </div>
  </div>
);
