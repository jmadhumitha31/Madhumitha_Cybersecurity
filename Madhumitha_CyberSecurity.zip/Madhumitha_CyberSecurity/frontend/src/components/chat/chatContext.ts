import { createContext } from 'react';
import type { ChatMessage, ChatSuggestion } from '../../types';

export interface SendOptions {
  incidentId?: number | null;
  useRag?: boolean;
}

export interface ChatContextValue {
  messages: ChatMessage[];
  isLoading: boolean;
  suggestions: ChatSuggestion[];
  send: (text: string, options?: SendOptions) => Promise<void>;
  clear: () => void;
}

export const ChatContext = createContext<ChatContextValue | null>(null);
