import React from 'react';
import { cn } from '../../lib/cn';

export type BadgeVariant = 'critical' | 'high' | 'medium' | 'low' | 'neutral' | 'cyan' | 'purple' | 'sky';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
  className?: string;
}

const VARIANT: Record<BadgeVariant, string> = {
  critical: 'bg-red-950/60 text-red-300 border-red-800/60',
  high: 'bg-orange-950/60 text-orange-300 border-orange-800/60',
  medium: 'bg-yellow-950/60 text-yellow-300 border-yellow-800/60',
  low: 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60',
  neutral: 'bg-slate-800/70 text-slate-300 border-slate-700/60',
  cyan: 'bg-cyan-950/60 text-cyan-300 border-cyan-800/60',
  purple: 'bg-purple-950/60 text-purple-300 border-purple-800/60',
  sky: 'bg-sky-950/60 text-sky-300 border-sky-800/60',
};

const SIZE = {
  sm: 'px-2 py-0.5 text-xs',
  md: 'px-2.5 py-1 text-xs font-semibold',
};

/** Pill label. Sans-serif: badges carry words, not data (identifiers inside a badge can opt into `font-mono`). */
export const Badge: React.FC<BadgeProps> = ({ children, variant = 'neutral', size = 'sm', className }) => (
  <span className={cn('inline-flex items-center gap-1.5 rounded-md border font-medium whitespace-nowrap', VARIANT[variant], SIZE[size], className)}>
    {children}
  </span>
);
