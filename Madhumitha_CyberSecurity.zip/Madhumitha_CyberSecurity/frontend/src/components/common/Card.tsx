import React, { useId, useState } from 'react';
import { ChevronRight } from 'lucide-react';
import { cn } from '../../lib/cn';

interface CardProps {
  title?: string;
  subtitle?: React.ReactNode;
  badge?: React.ReactNode;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  /** Header becomes a disclosure button; use for provenance / "how this was produced" content. */
  collapsible?: boolean;
  defaultOpen?: boolean;
  /** Set false when the body supplies its own padding (e.g. an edge-to-edge table). */
  padded?: boolean;
  id?: string;
}

export const Card: React.FC<CardProps> = ({
  title,
  subtitle,
  badge,
  action,
  children,
  className,
  collapsible = false,
  defaultOpen = true,
  padded = true,
  id,
}) => {
  const [open, setOpen] = useState(defaultOpen);
  const uid = useId();
  const titleId = `${uid}-title`;
  const bodyId = `${uid}-body`;
  const hasHeader = Boolean(title || subtitle || badge || action);
  const expanded = !collapsible || open;

  const heading = title ? (
    <h2 id={titleId} className="text-sm font-semibold text-slate-50">
      {title}
    </h2>
  ) : null;

  return (
    <section id={id} aria-labelledby={title ? titleId : undefined} className={cn('overflow-hidden rounded-xl border border-soc-border bg-soc-surface', className)}>
      {hasHeader && (
        <div className={cn('flex items-start justify-between gap-4 px-5 py-4', expanded && 'border-b border-soc-border')}>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2.5">
              {collapsible ? (
                <button
                  type="button"
                  aria-expanded={open}
                  aria-controls={bodyId}
                  onClick={() => setOpen((v) => !v)}
                  className="-ml-1 flex items-center gap-1.5 rounded text-left"
                >
                  <ChevronRight className={cn('h-4 w-4 text-slate-400 transition-transform', open && 'rotate-90')} aria-hidden />
                  {heading}
                </button>
              ) : (
                heading
              )}
              {badge}
            </div>
            {subtitle && <p className="mt-1 max-w-3xl text-xs text-soc-textMuted">{subtitle}</p>}
          </div>
          {action && <div className="shrink-0">{action}</div>}
        </div>
      )}
      <div id={bodyId} hidden={!expanded} className={cn(padded && 'p-5')}>
        {children}
      </div>
    </section>
  );
};
