import React from 'react';
import { cn } from '../../lib/cn';
import { ChartSkeleton } from './LoadingSkeleton';
import { EmptyState } from '../ui/EmptyState';
import { BarChart3 } from 'lucide-react';

interface ChartFrameProps {
  /** Plain-language summary for screen readers (an SVG chart has no text alternative by itself). */
  label: string;
  loading?: boolean;
  empty?: boolean;
  /** Tailwind height class; Recharts' ResponsiveContainer needs a parent with an explicit height. */
  heightClass?: string;
  children: React.ReactNode;
}

/** Gives every chart the same height, a loading placeholder, an empty state and an accessible name. */
export const ChartFrame: React.FC<ChartFrameProps> = ({ label, loading = false, empty = false, heightClass = 'h-64', children }) => {
  if (loading) return <ChartSkeleton className={heightClass} />;
  if (empty) return <EmptyState icon={BarChart3} title="No data yet" description="This chart fills in as incidents are ingested." className={cn(heightClass, 'justify-center py-0')} />;
  return (
    <div role="img" aria-label={label} className={cn('w-full', heightClass)}>
      {children}
    </div>
  );
};
