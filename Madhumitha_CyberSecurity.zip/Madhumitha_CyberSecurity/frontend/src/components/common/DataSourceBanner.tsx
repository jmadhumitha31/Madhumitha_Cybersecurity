import React from 'react';
import { Alert } from '../ui/Alert';
import { useHealth } from '../../lib/useHealth';

/** Warns loudly when the running model/knowledge base was built from the synthetic demo dataset. */
export const DataSourceBanner: React.FC = () => {
  const { health } = useHealth();
  if (health?.components?.ml_model?.dataset_source !== 'synthetic-demo') return null;
  return (
    <Alert variant="warning" title="Synthetic demo data">
      The real CIC-IDS2017 dataset is not installed, so the model and knowledge base were built from a generated sample. All metrics are not
      representative. Run <code className="rounded bg-black/30 px-1 py-0.5 font-mono text-xs">python scripts/download_cicids2017.py</code>, then re-bootstrap.
    </Alert>
  );
};
