import React from 'react';
import { AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import { Badge, type BadgeVariant } from './Badge';

type Health = 'Healthy' | 'Degraded' | 'Unavailable';

const STATUS: Record<Health, { variant: BadgeVariant; Icon: typeof CheckCircle2 }> = {
  Healthy: { variant: 'low', Icon: CheckCircle2 },
  Degraded: { variant: 'medium', Icon: AlertTriangle },
  Unavailable: { variant: 'critical', Icon: XCircle },
};

/** Component health as icon + word + colour (never colour alone). Unknown values are shown as Unavailable. */
export const HealthBadge: React.FC<{ status: Health | string }> = ({ status }) => {
  const known = (status in STATUS ? status : 'Unavailable') as Health;
  const { variant, Icon } = STATUS[known];
  return (
    <Badge variant={variant}>
      <Icon className="h-3.5 w-3.5" aria-hidden />
      {known}
    </Badge>
  );
};
