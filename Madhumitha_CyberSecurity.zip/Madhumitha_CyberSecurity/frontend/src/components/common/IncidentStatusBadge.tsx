import React from 'react';
import { Ban, CheckCircle2, CircleDot, Search, type LucideIcon } from 'lucide-react';
import { Badge, type BadgeVariant } from './Badge';
import { statusLabel } from '../../lib/format';
import type { IncidentStatus } from '../../types';

// Workflow state gets its own hues (sky / violet / emerald / slate) plus an icon, so it never reads as severity.
const STATUS: Record<IncidentStatus, { variant: BadgeVariant; Icon: LucideIcon }> = {
  NEW: { variant: 'sky', Icon: CircleDot },
  INVESTIGATING: { variant: 'purple', Icon: Search },
  RESOLVED: { variant: 'low', Icon: CheckCircle2 },
  FALSE_POSITIVE: { variant: 'neutral', Icon: Ban },
};

export const IncidentStatusBadge: React.FC<{ status: IncidentStatus }> = ({ status }) => {
  const { variant, Icon } = STATUS[status] ?? STATUS.NEW;
  return (
    <Badge variant={variant}>
      <Icon className="h-3 w-3" aria-hidden />
      {statusLabel(status)}
    </Badge>
  );
};
