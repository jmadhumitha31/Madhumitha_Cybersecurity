import React from 'react';
import { cn } from '../../lib/cn';

/** A single placeholder block. Decorative: the surrounding region announces "Loading" once. */
export const Skeleton: React.FC<{ className?: string }> = ({ className }) => (
  <div aria-hidden className={cn('animate-pulse rounded bg-soc-border/50', className)} />
);

const Status: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className }) => (
  <div role="status" aria-live="polite" className={className}>
    <span className="sr-only">Loading</span>
    {children}
  </div>
);

/** Stacked text-like bars. */
export const LoadingSkeleton: React.FC<{ rows?: number; height?: string }> = ({ rows = 4, height = 'h-6' }) => (
  <Status className="space-y-3">
    {Array.from({ length: rows }).map((_, idx) => (
      <Skeleton key={idx} className={height} />
    ))}
  </Status>
);

/** Placeholder for a row of KPI cards (same grid as the real thing, so nothing jumps when data arrives). */
export const StatGridSkeleton: React.FC<{ count?: number }> = ({ count = 5 }) => (
  <Status className="grid grid-cols-[repeat(auto-fit,minmax(13rem,1fr))] gap-4">
    {Array.from({ length: count }).map((_, i) => (
      <div key={i} className="rounded-xl border border-soc-border bg-soc-surface p-4">
        <Skeleton className="h-4 w-28" />
        <Skeleton className="mt-3 h-8 w-20" />
        <Skeleton className="mt-2 h-3.5 w-36" />
      </div>
    ))}
  </Status>
);

/** Header + rows, for tables that are still loading. */
export const TableSkeleton: React.FC<{ rows?: number }> = ({ rows = 6 }) => (
  <Status className="space-y-2">
    <Skeleton className="h-8 w-full" />
    {Array.from({ length: rows }).map((_, i) => (
      <Skeleton key={i} className="h-10 w-full" />
    ))}
  </Status>
);

/** Fixed-height block where a chart will render. */
export const ChartSkeleton: React.FC<{ className?: string }> = ({ className }) => (
  <Status>
    <Skeleton className={cn('h-64 w-full', className)} />
  </Status>
);
