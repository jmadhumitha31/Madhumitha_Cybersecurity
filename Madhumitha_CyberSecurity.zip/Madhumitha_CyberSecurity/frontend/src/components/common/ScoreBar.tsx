import React from 'react';
import { cn } from '../../lib/cn';

interface ScoreBarProps {
  label: string;
  value: number | null | undefined; // 0..1
  hint?: string;
  tone?: 'cyan' | 'red' | 'amber' | 'emerald' | 'purple';
}

const TONES = {
  cyan: 'bg-cyan-500',
  red: 'bg-red-500',
  amber: 'bg-amber-500',
  emerald: 'bg-emerald-500',
  purple: 'bg-purple-500',
};

/** Horizontal meter for 0..1 model outputs. Shows N/A (never a made-up default) when the value is missing. */
export const ScoreBar: React.FC<ScoreBarProps> = ({ label, value, hint, tone = 'cyan' }) => {
  const has = value !== null && value !== undefined && !Number.isNaN(value);
  const pct = has ? Math.max(0, Math.min(1, value as number)) * 100 : 0;
  return (
    <div title={hint}>
      <div className="mb-1.5 flex items-baseline justify-between gap-3 text-xs">
        <span className="text-soc-textMuted">{label}</span>
        <span className="font-semibold tabular-nums text-slate-100">{has ? `${pct.toFixed(1)}%` : 'N/A'}</span>
      </div>
      <div
        role="meter"
        aria-label={label}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={has ? Math.round(pct) : undefined}
        aria-valuetext={has ? `${pct.toFixed(1)} percent` : 'not available'}
        className="h-2 overflow-hidden rounded-full bg-soc-darkest"
      >
        <div className={cn('h-full rounded-full', TONES[tone])} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
};
