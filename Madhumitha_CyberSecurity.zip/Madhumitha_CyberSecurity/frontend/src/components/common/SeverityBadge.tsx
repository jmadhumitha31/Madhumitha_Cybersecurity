import React from 'react';
import { Badge, type BadgeVariant } from './Badge';
import type { Priority, Severity } from '../../types';

const VARIANT: Record<Severity, BadgeVariant> = { Critical: 'critical', High: 'high', Medium: 'medium', Low: 'low' };

interface SeverityBadgeProps {
  level: Severity;
  priority?: Priority;
  size?: 'sm' | 'md';
  /** Text after the level, e.g. "score 82.1". */
  suffix?: string;
}

/** Severity (and optional SOC priority) as a coloured label. The text always names the level, never colour alone. */
export const SeverityBadge: React.FC<SeverityBadgeProps> = ({ level, priority, size = 'sm', suffix }) => (
  <Badge variant={VARIANT[level] ?? 'neutral'} size={size}>
    {level}
    {priority && <span className="opacity-80">{priority}</span>}
    {suffix && <span className="opacity-80">{suffix}</span>}
  </Badge>
);
