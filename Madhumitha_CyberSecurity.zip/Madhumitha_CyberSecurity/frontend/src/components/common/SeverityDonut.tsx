import React from 'react';
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { SEVERITY_COLORS, tooltipProps } from '../../lib/chartTheme';
import type { SeverityDistributionItem } from '../../types';
import { ChartFrame } from './ChartFrame';

const ORDER = ['Critical', 'High', 'Medium', 'Low'];

interface SeverityDonutProps {
  data: SeverityDistributionItem[];
  loading?: boolean;
}

/** Severity breakdown: donut plus a legend carrying the actual numbers, so colour is never the only encoding. */
export const SeverityDonut: React.FC<SeverityDonutProps> = ({ data, loading = false }) => {
  const rows = [...data].sort((a, b) => ORDER.indexOf(a.risk_level) - ORDER.indexOf(b.risk_level));
  const total = rows.reduce((sum, r) => sum + r.count, 0);
  return (
    <div>
      <ChartFrame
        label={`Donut chart of incidents by severity: ${rows.map((r) => `${r.risk_level} ${r.count.toLocaleString()}`).join(', ')}.`}
        loading={loading}
        empty={!loading && total === 0}
        heightClass="h-44"
      >
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={rows} dataKey="count" nameKey="risk_level" cx="50%" cy="50%" innerRadius={52} outerRadius={78} paddingAngle={3} stroke="none">
              {rows.map((r) => (
                <Cell key={r.risk_level} fill={SEVERITY_COLORS[r.risk_level] ?? '#64748b'} />
              ))}
            </Pie>
            <Tooltip {...tooltipProps} />
          </PieChart>
        </ResponsiveContainer>
      </ChartFrame>
      {total > 0 && (
        <ul className="mt-4 space-y-1.5 text-xs">
          {rows.map((r) => (
            <li key={r.risk_level} className="flex items-center justify-between gap-3">
              <span className="flex items-center gap-2 text-slate-200">
                <span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: SEVERITY_COLORS[r.risk_level] ?? '#64748b' }} aria-hidden />
                {r.risk_level}
              </span>
              <span className="tabular-nums text-soc-textMuted">
                {r.count.toLocaleString()} · {((r.count / total) * 100).toFixed(0)}%
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
