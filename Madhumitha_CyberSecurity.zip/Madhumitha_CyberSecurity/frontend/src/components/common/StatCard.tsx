import React from 'react';
import { Link } from 'react-router-dom';
import type { LucideIcon } from 'lucide-react';
import { cn } from '../../lib/cn';
import { Skeleton } from './LoadingSkeleton';

interface StatCardProps {
  label: string;
  value: string | number;
  change?: string;
  isPositive?: boolean;
  icon: LucideIcon;
  variant?: 'cyan' | 'red' | 'orange' | 'yellow' | 'emerald';
  /** Show a placeholder of the same shape while data loads (no layout shift). */
  loading?: boolean;
  /** Makes the whole card a link. */
  to?: string;
}

const ICON_TONE = {
  cyan: 'text-cyan-400',
  red: 'text-red-400',
  orange: 'text-orange-400',
  yellow: 'text-yellow-400',
  emerald: 'text-emerald-400',
};

export const StatCard: React.FC<StatCardProps> = ({ label, value, change, isPositive, icon: Icon, variant = 'cyan', loading = false, to }) => {
  const body = (
    <>
      <div className="flex items-center gap-2 text-xs font-medium text-soc-textMuted">
        <Icon className={cn('h-4 w-4 shrink-0', ICON_TONE[variant])} aria-hidden />
        <span>{label}</span>
      </div>
      {loading ? (
        <>
          <Skeleton className="mt-3 h-8 w-24" />
          <Skeleton className="mt-2 h-3.5 w-36" />
        </>
      ) : (
        <>
          <div className="mt-2 text-2xl font-semibold tabular-nums text-slate-50">{value}</div>
          {change && <p className={cn('mt-1 text-xs', isPositive ? 'text-emerald-400' : 'text-soc-textMuted')}>{change}</p>}
        </>
      )}
    </>
  );
  const classes = 'block rounded-xl border border-soc-border bg-soc-surface p-4';
  return to ? (
    <Link to={to} className={cn(classes, 'transition-colors hover:border-soc-borderLight hover:bg-soc-card/60')}>
      {body}
    </Link>
  ) : (
    <div className={classes}>{body}</div>
  );
};
