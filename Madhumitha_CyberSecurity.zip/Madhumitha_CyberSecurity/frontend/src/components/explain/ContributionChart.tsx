import React from 'react';
import { Bar, BarChart, CartesianGrid, Cell, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { CHART, axisProps, tooltipProps } from '../../lib/chartTheme';
import { compact } from '../../lib/format';
import type { Explanation } from '../../types';

/**
 * Per-flow explanation: signed SHAP contribution of each feature to the predicted class probability.
 * Green bars push the model towards the predicted class, red bars push away from it.
 */
export const ContributionChart: React.FC<{ explanation: Explanation }> = ({ explanation }) => {
  const rows = explanation.contributions.slice(0, 8).map((c) => ({
    name: c.label,
    contribution: Number(c.contribution.toFixed(4)),
    value: c.value,
    benign: c.benign_median,
    ratio: c.ratio_to_benign,
  }));
  const supporting = rows.filter((r) => r.contribution >= 0).length;
  return (
    <div>
      <div role="img" aria-label={`Bar chart of the ${rows.length} features that most influenced the verdict for class ${explanation.target_class}: ${supporting} push towards it, ${rows.length - supporting} push away.`} className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={rows} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 4 }}>
            <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
            <XAxis type="number" {...axisProps} />
            <YAxis type="category" dataKey="name" width={160} {...axisProps} />
            <ReferenceLine x={0} stroke={CHART.axisLine} />
            <Tooltip
              {...tooltipProps}
              formatter={(v, _name, item) => {
                const p = item.payload as (typeof rows)[number];
                return [`${Number(v) > 0 ? '+' : ''}${v}  (value ${compact(p.value)} vs benign median ${compact(p.benign)})`, 'contribution'];
              }}
            />
            <Bar dataKey="contribution" radius={[0, 3, 3, 0]}>
              {rows.map((r, i) => (
                <Cell key={i} fill={r.contribution >= 0 ? '#10b981' : '#ef4444'} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <p className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-soc-textMuted">
        <span>
          {explanation.method === 'shap-tree' ? 'SHAP (TreeExplainer)' : 'Occlusion attribution'} for class <strong className="text-slate-200">{explanation.target_class}</strong>.
        </span>
        <span className="flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-emerald-500" aria-hidden />
            Pushes towards this class
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-red-500" aria-hidden />
            Pushes away
          </span>
        </span>
      </p>
    </div>
  );
};
