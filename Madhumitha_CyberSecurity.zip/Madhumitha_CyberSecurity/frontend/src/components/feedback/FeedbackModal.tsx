import React, { useId, useState } from 'react';
import { MessageSquare } from 'lucide-react';
import { incidentService } from '../../services/incidentService';
import { ATTACK_CLASSES } from '../../types';
import { Alert } from '../ui/Alert';
import { Button } from '../ui/Button';
import { Select, Textarea } from '../ui/Input';
import { Modal } from '../ui/Modal';

interface FeedbackModalProps {
  incidentId: number;
  currentPrediction: string;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (message: string) => void;
}

const TYPES = ['Correct', 'Incorrect', 'Partially Correct', 'Useful', 'Not Useful'];
const JUDGED = new Set(['Correct', 'Incorrect', 'Partially Correct']);
const FORM_ID = 'analyst-feedback-form';

interface FormProps extends Omit<FeedbackModalProps, 'isOpen'> {
  onBusyChange: (busy: boolean) => void;
}

/** Mounted only while the dialog is open, so every opening starts from a fresh form. */
const FeedbackForm: React.FC<FormProps> = ({ incidentId, currentPrediction, onClose, onSuccess, onBusyChange }) => {
  const initial = (ATTACK_CLASSES as readonly string[]).includes(currentPrediction) ? currentPrediction : 'Benign';
  const [feedbackType, setFeedbackType] = useState('Correct');
  const [actualLabel, setActualLabel] = useState(initial);
  const [comments, setComments] = useState('');
  const [error, setError] = useState<string | null>(null);
  const groupId = useId();
  const judged = JUDGED.has(feedbackType);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    onBusyChange(true);
    setError(null);
    try {
      await incidentService.submitFeedback(incidentId, {
        feedback_type: feedbackType,
        actual_label: judged ? actualLabel : undefined,
        analyst_feedback: comments.trim() || undefined,
      });
      onSuccess(
        judged
          ? `Recorded. The incident is now labelled “${actualLabel}” (analyst-confirmed), re-indexed as retrievable evidence, and queued for the next model retraining.`
          : 'Recorded. Thank you: this rates the quality of the recommendations.',
      );
      onClose();
    } catch (err) {
      setError(err instanceof Error && err.message ? err.message : 'Failed to submit feedback');
    } finally {
      onBusyChange(false);
    }
  };

  return (
    <form id={FORM_ID} onSubmit={handleSubmit} className="space-y-5 text-sm">
      {error && <Alert variant="error">{error}</Alert>}

      <p className="text-soc-textMuted">
        Model verdict: <strong className="text-slate-100">{currentPrediction}</strong>
      </p>

      <fieldset>
        <legend className="mb-1.5 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Feedback category</legend>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {TYPES.map((type, i) => (
            <label key={type} className="cursor-pointer">
              <input
                type="radio"
                name={groupId}
                value={type}
                checked={feedbackType === type}
                onChange={() => setFeedbackType(type)}
                data-autofocus={i === 0 ? '' : undefined}
                className="peer sr-only"
              />
              <span className="block rounded-md border border-soc-border bg-soc-card px-2 py-2 text-center text-xs font-medium text-slate-300 transition-colors hover:border-soc-borderLight peer-checked:border-cyan-500 peer-checked:bg-cyan-950/60 peer-checked:text-cyan-100 peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-cyan-400">
                {type}
              </span>
            </label>
          ))}
        </div>
      </fieldset>

      {judged ? (
        <Select
          label="Confirmed attack classification"
          value={actualLabel}
          onChange={(e) => setActualLabel(e.target.value)}
          hint="This becomes the incident’s ground truth: it is re-embedded into the knowledge base and used when the model is retrained."
        >
          {ATTACK_CLASSES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </Select>
      ) : (
        <p className="text-xs text-soc-textMuted">“Useful / Not useful” rates the written analysis and recommendations; it does not change the incident’s label.</p>
      )}

      <Textarea
        label="Verification notes (optional)"
        rows={3}
        value={comments}
        maxLength={2000}
        onChange={(e) => setComments(e.target.value)}
        placeholder="e.g. Confirmed against WAF logs: SQL injection payload in the id parameter"
        hint={`${comments.length}/2000`}
      />
    </form>
  );
};

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose, ...rest }) => {
  const [busy, setBusy] = useState(false);
  return (
    <Modal
      open={isOpen}
      onClose={onClose}
      title="Analyst feedback"
      icon={MessageSquare}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button type="submit" form={FORM_ID} variant="primary" loading={busy}>
            {busy ? 'Submitting…' : 'Record feedback'}
          </Button>
        </>
      }
    >
      <FeedbackForm {...rest} onClose={onClose} onBusyChange={setBusy} />
    </Modal>
  );
};
