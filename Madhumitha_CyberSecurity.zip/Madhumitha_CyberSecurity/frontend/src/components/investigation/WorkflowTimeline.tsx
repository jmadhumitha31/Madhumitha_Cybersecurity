import React from 'react';
import { AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import { cn } from '../../lib/cn';
import type { ExecutionTraceItem } from '../../types';

interface WorkflowTimelineProps {
  trace: ExecutionTraceItem[];
  totalTimeMs?: number;
}

export const WorkflowTimeline: React.FC<WorkflowTimelineProps> = ({ trace, totalTimeMs }) => {
  if (!trace || trace.length === 0) {
    return <p className="py-6 text-center text-sm text-soc-textMuted">No workflow trace yet. Run an investigation to see each LangGraph stage.</p>;
  }

  return (
    <div className="space-y-4">
      {totalTimeMs !== undefined && (
        <div className="flex items-center justify-between border-b border-soc-border pb-3 text-xs">
          <span className="text-soc-textMuted">Total orchestration latency</span>
          <span className="font-semibold tabular-nums text-cyan-300">{totalTimeMs.toFixed(1)} ms</span>
        </div>
      )}

      <ol className="relative space-y-3 pl-8 before:absolute before:bottom-3 before:left-[0.6875rem] before:top-3 before:w-px before:bg-soc-border">
        {trace.map((item, index) => {
          const passed = item.status === 'PASSED' || item.status === 'COMPLETED';
          const failed = item.status === 'FAILED';
          const Icon = passed ? CheckCircle2 : failed ? AlertCircle : Clock;
          return (
            <li key={index} className="relative">
              <span
                className={cn(
                  'absolute -left-8 top-2.5 flex h-6 w-6 items-center justify-center rounded-full border bg-soc-surface',
                  passed ? 'border-emerald-600 text-emerald-400' : failed ? 'border-red-600 text-red-400' : 'border-cyan-600 text-cyan-400',
                )}
              >
                <Icon className="h-3.5 w-3.5" aria-label={passed ? 'Passed' : failed ? 'Failed' : 'In progress'} />
              </span>
              <div className="rounded-lg bg-soc-card/60 p-3">
                <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-0.5">
                  <span className="text-sm font-semibold text-slate-100">{item.step}</span>
                  <span className="flex items-center gap-2 text-xs tabular-nums text-soc-textMuted">
                    <time>{item.timestamp}</time>
                    <span className="text-cyan-300">{item.duration_ms} ms</span>
                  </span>
                </div>
                <p className="mt-1 text-xs text-slate-300">{item.details}</p>
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
};
