import React, { useId, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CornerDownLeft, Hash, Search, type LucideIcon } from 'lucide-react';
import { cn } from '../../lib/cn';
import { ROUTES } from '../../lib/routes';
import { Modal } from '../ui/Modal';

interface Command {
  id: string;
  label: string;
  hint?: string;
  icon: LucideIcon;
  run: () => void;
}

const Body: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [active, setActive] = useState(0);
  const listId = useId();

  const commands = useMemo<Command[]>(() => {
    const q = query.trim();
    const go = (path: string) => () => {
      onClose();
      navigate(path);
    };
    const list: Command[] = [];
    if (/^#?\d+$/.test(q)) list.push({ id: 'open-id', label: `Open incident #${q.replace('#', '')}`, icon: Hash, run: go(`/incidents/${q.replace('#', '')}`) });
    if (q) {
      list.push({
        id: 'search',
        label: `Search incidents for “${q}”`,
        hint: 'Hybrid retrieval',
        icon: Search,
        run: go(`/ai-search?q=${encodeURIComponent(q)}`),
      });
    }
    const needle = q.toLowerCase();
    ROUTES.filter((r) => !needle || [r.title, r.description, ...(r.keywords ?? [])].join(' ').toLowerCase().includes(needle)).forEach((r) =>
      list.push({ id: r.path, label: r.title, hint: 'Go to page', icon: r.icon, run: go(r.path) }),
    );
    return list;
  }, [query, navigate, onClose]);

  const selected = Math.min(active, Math.max(0, commands.length - 1));

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActive((selected + 1) % commands.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActive((selected - 1 + commands.length) % commands.length);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      commands[selected]?.run();
    }
  };

  return (
    <div>
      <div className="flex items-center gap-3 border-b border-soc-border px-4">
        <Search className="h-4 w-4 shrink-0 text-slate-400" aria-hidden />
        <label htmlFor={`${listId}-input`} className="sr-only">
          Search pages and incidents
        </label>
        <input
          id={`${listId}-input`}
          data-autofocus
          role="combobox"
          aria-expanded="true"
          aria-controls={listId}
          aria-activedescendant={commands[selected] ? `${listId}-${selected}` : undefined}
          aria-autocomplete="list"
          autoComplete="off"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setActive(0);
          }}
          onKeyDown={onKeyDown}
          placeholder="Jump to a page, an incident number, or search incidents…"
          className="h-12 w-full bg-transparent text-sm text-slate-100 focus-visible:outline-none"
        />
        <kbd className="shrink-0 rounded border border-soc-border bg-soc-card px-1.5 py-0.5 text-2xs text-slate-400">Esc</kbd>
      </div>
      <ul id={listId} role="listbox" aria-label="Results" className="max-h-80 overflow-y-auto p-2">
        {commands.length === 0 && <li className="px-3 py-6 text-center text-xs text-soc-textMuted">Nothing matches “{query}”.</li>}
        {commands.map((c, i) => (
          <li
            key={c.id}
            id={`${listId}-${i}`}
            role="option"
            aria-selected={i === selected}
            onMouseMove={() => setActive(i)}
            onClick={c.run}
            className={cn('flex cursor-pointer items-center gap-3 rounded-md px-3 py-2 text-sm', i === selected ? 'bg-cyan-950/60 text-cyan-100' : 'text-slate-300')}
          >
            <c.icon className="h-4 w-4 shrink-0 text-slate-400" aria-hidden />
            <span className="min-w-0 flex-1 truncate">{c.label}</span>
            {c.hint && <span className="text-2xs text-soc-textMuted">{c.hint}</span>}
            {i === selected && <CornerDownLeft className="h-3.5 w-3.5 text-slate-400" aria-hidden />}
          </li>
        ))}
      </ul>
    </div>
  );
};

/** Ctrl/⌘+K palette: jump to any page, open an incident by number, or send free text to the incident search. */
export const CommandPalette: React.FC<{ open: boolean; onClose: () => void }> = ({ open, onClose }) => (
  <Modal open={open} onClose={onClose} title="Command palette" hideHeader padded={false} placement="top" className="max-w-xl overflow-hidden">
    <Body onClose={onClose} />
  </Modal>
);
