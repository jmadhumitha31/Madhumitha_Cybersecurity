import React, { Suspense, useCallback, useEffect, useRef, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { cn } from '../../lib/cn';
import { LoadingSkeleton } from '../common/LoadingSkeleton';
import { Sidebar } from './Sidebar';
import { Navbar } from './Navbar';
import { CommandPalette } from './CommandPalette';
import { ChatProvider } from '../chat/ChatProvider';
import { FloatingChatbot } from '../chat/FloatingChatbot';

const COLLAPSE_KEY = 'soc_sidebar_collapsed';

const readCollapsed = (): boolean => {
  try {
    return localStorage.getItem(COLLAPSE_KEY) === '1';
  } catch {
    return false;
  }
};

export const Layout: React.FC = () => {
  const { pathname } = useLocation();
  const [collapsed, setCollapsed] = useState(readCollapsed);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  // The full-page copilot is the chat surface on /chat, so the launcher would only duplicate (and cover) it.
  const onChatPage = pathname === '/chat';

  const toggleCollapsed = useCallback(() => {
    setCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(COLLAPSE_KEY, next ? '1' : '0');
      } catch {
        /* storage unavailable: the preference just will not persist */
      }
      return next;
    });
  }, []);

  // `main` is one long-lived scroll container, so without this a new page opens at the previous page's scroll offset.
  const mainRef = useRef<HTMLElement>(null);
  useEffect(() => {
    mainRef.current?.scrollTo({ top: 0 });
  }, [pathname]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen((open) => !open);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <ChatProvider>
      <div className="flex h-dvh w-full overflow-hidden bg-soc-darkest text-slate-100">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-md focus:bg-cyan-700 focus:px-4 focus:py-2 focus:text-sm focus:font-medium focus:text-white"
        >
          Skip to main content
        </a>

        <Sidebar collapsed={collapsed} onToggleCollapsed={toggleCollapsed} mobileOpen={mobileOpen} onCloseMobile={() => setMobileOpen(false)} />

        <div className="flex min-w-0 flex-1 flex-col">
          <Navbar onOpenPalette={() => setPaletteOpen(true)} onOpenMobileNav={() => setMobileOpen(true)} />
          {/* Bottom padding keeps the last row of any page clear of the floating launcher. */}
          <main ref={mainRef} id="main" tabIndex={-1} className={cn('soc-grid-bg flex-1 overflow-y-auto p-(--page-pad) focus-visible:outline-none', !onChatPage && 'pb-24')}>
            <div className="mx-auto w-full max-w-[1600px]">
              <Suspense fallback={<LoadingSkeleton rows={6} height="h-16" />}>
                <Outlet />
              </Suspense>
            </div>
          </main>
        </div>

        {!onChatPage && <FloatingChatbot />}
        <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />
      </div>
    </ChatProvider>
  );
};
