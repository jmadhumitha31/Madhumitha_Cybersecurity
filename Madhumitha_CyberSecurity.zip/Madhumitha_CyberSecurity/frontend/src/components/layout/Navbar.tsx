import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, Menu, Search } from 'lucide-react';
import { authService } from '../../services/authService';
import { analyticsService } from '../../services/analyticsService';
import { resetHealth } from '../../lib/useHealth';
import { cn } from '../../lib/cn';
import { Skeleton } from '../common/LoadingSkeleton';
import { Button, IconButton } from '../ui/Button';

const IS_MAC = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/i.test(navigator.userAgent);
const POLL_MS = 60_000;

interface NavbarProps {
  onOpenPalette: () => void;
  onOpenMobileNav: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenPalette, onOpenMobileNav }) => {
  const navigate = useNavigate();
  const user = authService.getStoredUser();
  const [p1, setP1] = useState<number | null>(null);
  const [unavailable, setUnavailable] = useState(false);

  // Open-P1 count, refreshed every minute so the header does not go stale during a shift.
  useEffect(() => {
    let alive = true;
    const load = () =>
      analyticsService
        .getOverview()
        .then((o) => {
          if (!alive) return;
          setP1(o.p1_open ?? 0);
          setUnavailable(false);
        })
        .catch(() => alive && setUnavailable(true));
    void load();
    const timer = window.setInterval(load, POLL_MS);
    return () => {
      alive = false;
      window.clearInterval(timer);
    };
  }, []);

  const handleLogout = () => {
    authService.logout();
    resetHealth();
    navigate('/login');
  };

  const hot = (p1 ?? 0) > 0;
  const initials = (user?.username ?? '?').slice(0, 2).toUpperCase();
  const role = user?.role ? user.role.charAt(0) + user.role.slice(1).toLowerCase() : '';

  return (
    <header className="flex h-16 shrink-0 items-center gap-3 border-b border-soc-border bg-soc-dark px-4 md:px-6">
      <IconButton label="Open navigation" icon={Menu} onClick={onOpenMobileNav} className="lg:hidden" />

      <button
        type="button"
        onClick={onOpenPalette}
        aria-label="Search pages and incidents"
        aria-keyshortcuts="Control+K Meta+K"
        className="flex h-9 w-full max-w-md items-center gap-2.5 rounded-md border border-soc-border bg-soc-surface px-3 text-xs text-soc-textMuted transition-colors hover:border-soc-borderLight"
      >
        <Search className="h-4 w-4 shrink-0 text-slate-400" aria-hidden />
        <span className="hidden truncate sm:inline">Search pages and incidents…</span>
        <kbd className="ml-auto hidden rounded border border-soc-border bg-soc-card px-1.5 py-0.5 text-2xs text-slate-300 sm:inline">{IS_MAC ? '⌘K' : 'Ctrl K'}</kbd>
      </button>

      <div className="ml-auto flex items-center gap-3">
        <Link
          to="/incidents?sort=risk"
          title="Open P1 incidents: go to the risk-ranked triage queue"
          className={cn(
            'inline-flex h-9 shrink-0 items-center gap-2 whitespace-nowrap rounded-md border px-3 text-xs font-semibold transition-colors',
            p1 === null
              ? 'border-soc-border bg-soc-surface text-slate-300'
              : hot
                ? 'border-red-900/70 bg-red-950/40 text-red-200 hover:bg-red-950/60'
                : 'border-emerald-900/60 bg-emerald-950/30 text-emerald-200 hover:bg-emerald-950/50',
          )}
        >
          <span className={cn('h-2 w-2 rounded-full', p1 === null ? 'bg-slate-500' : hot ? 'bg-red-400' : 'bg-emerald-400')} aria-hidden />
          {p1 !== null ? `${p1} open P1` : unavailable ? 'P1 unavailable' : <Skeleton className="h-3.5 w-14" />}
        </Link>

        <div className="flex items-center gap-2.5 border-l border-soc-border pl-3">
          <div aria-hidden className="flex h-8 w-8 items-center justify-center rounded-full border border-soc-border bg-soc-card text-xs font-semibold text-slate-200">
            {initials}
          </div>
          <div className="hidden text-xs leading-tight md:block">
            <div className="font-semibold text-slate-100">{user?.username ?? 'Unknown user'}</div>
            <div className="text-soc-textMuted">{role}</div>
          </div>
          <Button variant="ghost" size="sm" icon={LogOut} onClick={handleLogout} aria-label="Sign out">
            <span className="hidden md:inline">Sign out</span>
          </Button>
        </div>
      </div>
    </header>
  );
};
