import React, { useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { PanelLeftClose, PanelLeftOpen, ShieldAlert, X } from 'lucide-react';
import { BRAND } from '../../lib/brand';
import { cn } from '../../lib/cn';
import { ENGINE_DOT, describeEngine } from '../../lib/engine';
import { NAV_GROUPS, ROUTES } from '../../lib/routes';
import { useHealth } from '../../lib/useHealth';
import { IconButton } from '../ui/Button';

const PLATFORM_DOT = { Healthy: 'bg-emerald-400', Degraded: 'bg-amber-400', Unavailable: 'bg-red-400' } as const;

/** Live platform / LLM / model summary from /health. Links to the full System status page. */
const StatusPanel: React.FC<{ collapsed: boolean; onNavigate?: () => void }> = ({ collapsed, onNavigate }) => {
  const { health } = useHealth();
  const engine = describeEngine(health);
  const platform = health?.status;
  const dot = platform ? PLATFORM_DOT[platform] : 'bg-slate-500';
  const summary = `Platform ${platform ?? 'unknown'}. ${engine.label}.`;

  if (collapsed) {
    return (
      <NavLink to="/settings" onClick={onNavigate} title={summary} aria-label={`System status: ${summary}`} className="mx-auto flex h-10 w-10 items-center justify-center rounded-md hover:bg-soc-card">
        <span className={cn('h-2.5 w-2.5 rounded-full', dot)} aria-hidden />
      </NavLink>
    );
  }
  return (
    <NavLink to="/settings" onClick={onNavigate} className="block space-y-2 rounded-lg bg-soc-card/60 p-3 text-xs transition-colors hover:bg-soc-card">
      <div className="flex items-center justify-between">
        <span className="text-soc-textMuted">Platform</span>
        <span className="flex items-center gap-1.5 font-medium text-slate-200">
          <span className={cn('h-2 w-2 rounded-full', dot)} aria-hidden />
          {platform ?? 'Unknown'}
        </span>
      </div>
      <div className="flex items-center justify-between gap-3">
        <span className="text-soc-textMuted">LLM</span>
        <span className="flex min-w-0 items-center gap-1.5 text-slate-200">
          <span className={cn('h-2 w-2 shrink-0 rounded-full', ENGINE_DOT[engine.tone])} aria-hidden />
          <span className="truncate">{engine.badge}</span>
        </span>
      </div>
      <div className="flex items-center justify-between gap-3">
        <span className="text-soc-textMuted">ML data</span>
        <span className="truncate text-slate-200" title={health?.components?.ml_model?.model_version}>
          {health?.components?.ml_model?.dataset_source ?? '…'}
        </span>
      </div>
    </NavLink>
  );
};

interface ContentProps {
  collapsed: boolean;
  onNavigate?: () => void;
  onToggleCollapsed?: () => void;
  /** Mobile drawer: shows a close button instead of the collapse toggle. */
  onClose?: () => void;
}

const SidebarContent: React.FC<ContentProps> = ({ collapsed, onNavigate, onToggleCollapsed, onClose }) => (
  <div className="flex h-full flex-col">
    <div className={cn('flex h-16 shrink-0 items-center gap-3 border-b border-soc-border', collapsed ? 'justify-center px-2' : 'px-4')}>
      <div className="shrink-0 rounded-lg border border-cyan-800 bg-cyan-950/70 p-2 text-cyan-300">
        <ShieldAlert className="h-5 w-5" aria-hidden />
      </div>
      {!collapsed && (
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-slate-50">{BRAND.name}</p>
          <p className="truncate text-xs text-soc-textMuted">{BRAND.tagline}</p>
        </div>
      )}
      {onClose && <IconButton label="Close navigation" icon={X} onClick={onClose} />}
    </div>

    <nav aria-label="Primary" className="flex-1 space-y-5 overflow-y-auto px-3 py-4">
      {NAV_GROUPS.map((group) => (
        <div key={group.id}>
          {collapsed ? (
            <div className="mx-2 mb-2 border-t border-soc-border first:hidden" aria-hidden />
          ) : (
            <p className="px-3 pb-1.5 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">{group.label}</p>
          )}
          <ul className="space-y-0.5">
            {ROUTES.filter((r) => r.group === group.id).map((route) => (
              <li key={route.path}>
                <NavLink
                  to={route.path}
                  onClick={onNavigate}
                  title={collapsed ? route.title : undefined}
                  className={({ isActive }) =>
                    cn(
                      'flex items-center gap-3 rounded-md py-2 text-sm font-medium transition-colors',
                      collapsed ? 'justify-center px-0' : 'px-3',
                      isActive ? 'bg-cyan-950/60 text-cyan-100' : 'text-slate-300 hover:bg-soc-card hover:text-white',
                    )
                  }
                >
                  <route.icon className="h-4 w-4 shrink-0" aria-hidden />
                  <span className={collapsed ? 'sr-only' : 'truncate'}>{route.title}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </nav>

    <div className="shrink-0 space-y-2 border-t border-soc-border p-3">
      <StatusPanel collapsed={collapsed} onNavigate={onNavigate} />
      {onToggleCollapsed && (
        <div className={cn('flex', collapsed ? 'justify-center' : 'justify-end')}>
          <IconButton
            label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            icon={collapsed ? PanelLeftOpen : PanelLeftClose}
            onClick={onToggleCollapsed}
            aria-expanded={!collapsed}
          />
        </div>
      )}
    </div>
  </div>
);

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapsed: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ collapsed, onToggleCollapsed, mobileOpen, onCloseMobile }) => {
  useEffect(() => {
    if (!mobileOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onCloseMobile();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [mobileOpen, onCloseMobile]);

  return (
    <>
      <aside
        className={cn(
          'hidden shrink-0 border-r border-soc-border bg-soc-dark transition-[width] duration-200 lg:block',
          collapsed ? 'w-[4.5rem]' : 'w-64',
        )}
      >
        <SidebarContent collapsed={collapsed} onToggleCollapsed={onToggleCollapsed} />
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 animate-fade-in bg-black/70" onClick={onCloseMobile} aria-hidden />
          <aside className="absolute inset-y-0 left-0 w-64 animate-fade-in border-r border-soc-border bg-soc-dark shadow-2xl">
            <SidebarContent collapsed={false} onNavigate={onCloseMobile} onClose={onCloseMobile} />
          </aside>
        </div>
      )}
    </>
  );
};
