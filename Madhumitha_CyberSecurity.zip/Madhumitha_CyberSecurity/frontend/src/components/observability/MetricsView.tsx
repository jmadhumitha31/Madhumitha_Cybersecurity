import React, { useEffect, useState } from 'react';
import { Bar, BarChart, CartesianGrid, Cell, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Card } from '../common/Card';
import { Badge } from '../common/Badge';
import { LoadingSkeleton } from '../common/LoadingSkeleton';
import { ChartFrame } from '../common/ChartFrame';
import { Alert } from '../ui/Alert';
import { DefinitionList } from '../ui/Metric';
import { Segmented } from '../ui/Tabs';
import { Table, TableWrap, Td, Th, Tr } from '../ui/Table';
import { observabilityService } from '../../services/observabilityService';
import { CHART, axisProps, legendProps, tooltipProps } from '../../lib/chartTheme';
import type { ObservabilityMetrics } from '../../types';
import { ComponentChip, Stat, StatusBadge } from './shared';
import { STATUS_COLORS, colorFor, fmtMs, fmtPct, shortId } from './utils';

const WINDOWS = ['1h', '6h', '24h', '7d', '30d'].map((w) => ({ id: w, label: w }));

const tickLabel = (iso: string, window: string): string => {
  const d = new Date(`${iso}Z`);
  return window === '7d' || window === '30d' ? d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
};

interface Loaded {
  window: string;
  data: ObservabilityMetrics | null;
  error: string | null;
}

export const MetricsView: React.FC<{ onOpenTrace: (id: string) => void }> = ({ onOpenTrace }) => {
  const [window, setWindow] = useState('24h');
  const [loaded, setLoaded] = useState<Loaded | null>(null);

  useEffect(() => {
    let alive = true;
    observabilityService
      .metrics(window)
      .then((data) => alive && setLoaded({ window, data, error: null }))
      .catch((e: Error) => alive && setLoaded({ window, data: null, error: e.message }));
    return () => {
      alive = false;
    };
  }, [window]);

  // Results are keyed by window, so switching windows shows a skeleton instead of the previous window's numbers.
  const current = loaded?.window === window ? loaded : null;
  const picker = <Segmented options={WINDOWS} value={window} onChange={setWindow} label="Time window" />;

  if (!current) {
    return (
      <div className="space-y-5">
        <div className="flex justify-end">{picker}</div>
        <LoadingSkeleton rows={4} height="h-24" />
      </div>
    );
  }
  if (current.error || !current.data) {
    return (
      <div className="space-y-5">
        <div className="flex justify-end">{picker}</div>
        <Alert variant="error" title="Could not load metrics">
          {current.error}
        </Alert>
      </div>
    );
  }

  const m = current.data;
  const lat = m.totals.interactive_latency_ms;
  const kinds = Object.entries(m.per_kind);
  const latencyRows = kinds.filter(([, v]) => v.p50 !== null).map(([k, v]) => ({ kind: k, p50: v.p50, p95: v.p95 }));
  const timeRows = Object.entries(m.time_by_component).map(([c, v]) => ({ component: c, ms: v.self_ms }));
  const series = m.timeseries.map((b) => ({ ...b, label: tickLabel(b.t, m.window) }));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-soc-textMuted">Computed from the stored traces · {m.totals.traces.toLocaleString()} analyst queries in the window.</p>
        {picker}
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-7">
        <Stat label="Queries" value={m.totals.traces.toLocaleString()} />
        <Stat label="Error rate" value={fmtPct(m.totals.error_rate)} tone={(m.totals.error_rate ?? 0) > 0 ? 'text-red-400' : 'text-emerald-400'} />
        <Stat label="Degraded" value={fmtPct(m.totals.degraded_rate)} tone={(m.totals.degraded_rate ?? 0) > 0 ? 'text-yellow-400' : undefined} hint="Answered, but a component failed or fell back (e.g. LLM → offline playbooks)" />
        <Stat label="Latency p50" value={fmtMs(lat.p50)} hint="Interactive queries only" />
        <Stat label="Latency p95" value={fmtMs(lat.p95)} hint="Interactive queries only" />
        <Stat label="LLM fallback" value={fmtPct(m.llm.fallback_rate)} tone={(m.llm.fallback_rate ?? 0) > 0 ? 'text-yellow-400' : 'text-emerald-400'} hint={`${m.llm.fallbacks} of ${m.llm.calls} LLM calls`} />
        <Stat label="Empty searches" value={fmtPct(m.retrieval.empty_rate)} hint="Searches where nothing cleared the similarity threshold" />
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Card title="Queries over time" subtitle="Stacked by outcome.">
          <ChartFrame label={`Stacked bar chart of ${m.totals.traces} queries over time by outcome: ok, degraded, rejected, error.`} empty={series.length === 0}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={series} margin={{ top: 4, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="label" {...axisProps} interval="preserveStartEnd" />
                <YAxis {...axisProps} allowDecimals={false} />
                <Tooltip {...tooltipProps} />
                <Legend {...legendProps} />
                {(['ok', 'degraded', 'rejected', 'error'] as const).map((s) => (
                  <Bar key={s} dataKey={s} stackId="a" fill={STATUS_COLORS[s]} />
                ))}
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>
        </Card>

        <Card title="Latency by operation" subtitle="p50 and p95 in milliseconds.">
          <ChartFrame label="Bar chart of p50 and p95 latency for each kind of operation." empty={latencyRows.length === 0}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={latencyRows} layout="vertical" margin={{ top: 4, right: 12, left: 8, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" {...axisProps} />
                <YAxis type="category" dataKey="kind" width={120} {...axisProps} />
                <Tooltip {...tooltipProps} formatter={(v) => fmtMs(Number(v))} />
                <Legend {...legendProps} />
                <Bar dataKey="p50" fill={CHART.primary} radius={[0, 3, 3, 0]} />
                <Bar dataKey="p95" fill={CHART.secondary} radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>
        </Card>

        <Card title="Where the time goes" subtitle="Self time per component across all queries in the window.">
          <ChartFrame label="Bar chart of self time per component." empty={timeRows.length === 0}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={timeRows} layout="vertical" margin={{ top: 4, right: 12, left: 8, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" {...axisProps} tickFormatter={(v) => fmtMs(Number(v))} />
                <YAxis type="category" dataKey="component" width={90} {...axisProps} />
                <Tooltip {...tooltipProps} formatter={(v) => fmtMs(Number(v))} />
                <Bar dataKey="ms" name="Self time" radius={[0, 3, 3, 0]}>
                  {timeRows.map((r) => (
                    <Cell key={r.component} fill={colorFor(r.component)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>
        </Card>

        <Card title="LLM, retrieval and guardrails" subtitle="Counters recorded inside the traces.">
          <DefinitionList
            items={[
              { label: 'LLM calls', value: `${m.llm.calls} (${m.llm.failed_attempts} failed attempts)` },
              { label: 'LLM latency p50 / p95', value: `${fmtMs(m.llm.latency_ms.p50)} / ${fmtMs(m.llm.latency_ms.p95)}` },
              { label: 'Tokens in / out', value: `${m.llm.prompt_tokens.toLocaleString()} / ${m.llm.completion_tokens.toLocaleString()}` },
              { label: 'Searches / empty', value: `${m.retrieval.searches} / ${m.retrieval.empty}` },
              { label: 'Avg candidates scored', value: m.retrieval.avg_candidates_scored ?? 'n/a' },
              { label: 'Pool widenings (exactness bound)', value: m.retrieval.pool_widenings },
              { label: 'Avg dense ties at top', value: m.retrieval.avg_dense_ties_at_top ?? 'n/a' },
              { label: 'Blocked: security / relevance', value: `${m.guardrails.blocked_security} / ${m.guardrails.blocked_relevance}` },
              { label: 'Input validation failures', value: m.guardrails.validation_failed },
              { label: 'Output checks passed', value: `${fmtPct(m.guardrails.output_check_pass_rate)} (${m.guardrails.output_checks_failed} failed)` },
              { label: 'Low-confidence predictions', value: `${m.ml.low_confidence} of ${m.ml.predictions} (${fmtPct(m.ml.low_confidence_rate)})` },
            ]}
          />
          {Object.keys(m.llm.models).length > 0 && (
            <TableWrap className="mt-4">
              <Table caption="LLM calls per provider and model">
                <thead>
                  <tr>
                    <Th>Provider / model</Th>
                    <Th numeric>Calls</Th>
                    <Th numeric>Avg latency</Th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(m.llm.models).map(([model, v]) => (
                    <Tr key={model}>
                      <Td mono className="text-slate-300">
                        {model}
                      </Td>
                      <Td numeric>{v.calls}</Td>
                      <Td numeric>{fmtMs(v.avg_latency_ms)}</Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
            </TableWrap>
          )}
        </Card>
      </div>

      <Card title="Operations" subtitle="Per kind of query: volume, outcomes and latency." padded={false}>
        <TableWrap>
          <Table caption="Operations">
            <thead>
              <tr>
                <Th>Kind</Th>
                <Th numeric>Count</Th>
                <Th numeric>OK</Th>
                <Th numeric>Degraded</Th>
                <Th numeric>Rejected</Th>
                <Th numeric>Error</Th>
                <Th numeric>p50</Th>
                <Th numeric>p95</Th>
                <Th numeric>DB ms</Th>
                <Th numeric>DB queries</Th>
              </tr>
            </thead>
            <tbody>
              {kinds.map(([k, v]) => (
                <Tr key={k}>
                  <Td mono className="text-slate-100">
                    {k}
                  </Td>
                  <Td numeric>{v.count}</Td>
                  <Td numeric className="text-emerald-400">
                    {v.ok}
                  </Td>
                  <Td numeric className="text-yellow-400">
                    {v.degraded}
                  </Td>
                  <Td numeric className="text-orange-400">
                    {v.rejected}
                  </Td>
                  <Td numeric className="text-red-400">
                    {v.error}
                  </Td>
                  <Td numeric>{fmtMs(v.p50)}</Td>
                  <Td numeric>{fmtMs(v.p95)}</Td>
                  <Td numeric>{v.avg_db_ms}</Td>
                  <Td numeric>{v.avg_db_queries}</Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        </TableWrap>
      </Card>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Card title="Busiest spans" subtitle="Ranked by total self time." padded={false}>
          <TableWrap>
            <Table caption="Busiest spans">
              <thead>
                <tr>
                  <Th>Span</Th>
                  <Th numeric>Count</Th>
                  <Th numeric>Avg</Th>
                  <Th numeric>Max</Th>
                  <Th numeric>Self total</Th>
                </tr>
              </thead>
              <tbody>
                {m.top_spans.map((s) => (
                  <Tr key={s.name}>
                    <Td>
                      <ComponentChip component={s.component} /> <span className="font-mono text-slate-200">{s.name}</span>
                      {s.errors > 0 && <span className="text-red-400"> ({s.errors} errors)</span>}
                    </Td>
                    <Td numeric>{s.count}</Td>
                    <Td numeric>{fmtMs(s.avg_ms)}</Td>
                    <Td numeric>{fmtMs(s.max_ms)}</Td>
                    <Td numeric className="font-semibold text-slate-100">
                      {fmtMs(s.self_ms_total)}
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          </TableWrap>
        </Card>

        <div className="space-y-6">
          <Card title="Slowest queries" subtitle="Open a trace to see where the time went.">
            {m.slowest_traces.length === 0 ? (
              <p className="text-sm text-soc-textMuted">No interactive queries in this window.</p>
            ) : (
              <ul className="space-y-1">
                {m.slowest_traces.map((t) => (
                  <li key={t.trace_id}>
                    <button type="button" onClick={() => onOpenTrace(t.trace_id)} className="flex w-full items-center gap-3 rounded-md px-2 py-1.5 text-left text-xs transition-colors hover:bg-soc-card/70">
                      <StatusBadge status={t.status} />
                      <span className="font-mono text-cyan-300">{shortId(t.trace_id)}</span>
                      <span className="text-slate-300">{t.kind}</span>
                      <span className="flex-1 truncate text-soc-textMuted">{t.query}</span>
                      <span className="tabular-nums text-slate-100">{fmtMs(t.duration_ms)}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </Card>
          <Card title="Recent problems" subtitle="Errors and degraded answers (e.g. the LLM fell back to offline playbooks).">
            {m.recent_problems.length === 0 ? (
              <p className="text-sm text-emerald-400">Nothing degraded or failed in this window.</p>
            ) : (
              <ul className="space-y-1">
                {m.recent_problems.map((t) => (
                  <li key={t.trace_id}>
                    <button type="button" onClick={() => onOpenTrace(t.trace_id)} className="w-full rounded-md px-2 py-1.5 text-left text-xs transition-colors hover:bg-soc-card/70">
                      <span className="flex items-center gap-3">
                        <StatusBadge status={t.status} />
                        <span className="font-mono text-cyan-300">{shortId(t.trace_id)}</span>
                        <span className="text-slate-300">{t.kind}</span>
                        <span className="flex-1 truncate text-soc-textMuted">{t.query}</span>
                      </span>
                      {t.error && <span className="mt-0.5 block truncate text-red-300">{t.error}</span>}
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>

      {m.top_users.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 text-xs text-soc-textMuted">
          Most active:
          {m.top_users.map((u) => (
            <Badge key={u.username} variant="neutral">
              {u.username} · {u.traces}
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
};
