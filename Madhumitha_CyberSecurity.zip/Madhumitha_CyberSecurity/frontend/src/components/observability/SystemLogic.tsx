import React, { useEffect, useState } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Trash2 } from 'lucide-react';
import { Card } from '../common/Card';
import { Badge } from '../common/Badge';
import { LoadingSkeleton } from '../common/LoadingSkeleton';
import { ChartFrame } from '../common/ChartFrame';
import { Alert } from '../ui/Alert';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Modal } from '../ui/Modal';
import { observabilityService } from '../../services/observabilityService';
import { mlService } from '../../services/mlService';
import { authService } from '../../services/authService';
import { CHART, axisProps, tooltipProps } from '../../lib/chartTheme';
import type { SystemExplanation } from '../../types';
import { ComponentChip } from './shared';
import { colorFor } from './utils';

/** Compact, readable rendering of a parameter value (live configuration, so nothing here is static documentation). */
const renderValue = (v: unknown, depth = 0): string => {
  if (v === null || v === undefined) return 'n/a';
  if (Array.isArray(v)) return v.map((x) => renderValue(x, depth + 1)).join(', ');
  if (typeof v === 'object') {
    const e = Object.entries(v as Record<string, unknown>);
    if (depth >= 1) return `{${e.map(([k, x]) => `${k}: ${renderValue(x, depth + 1)}`).join(', ')}}`;
    return e.map(([k, x]) => `${k}: ${renderValue(x, depth + 1)}`).join(' · ');
  }
  return String(v);
};

const WeightBars: React.FC<{ weights: Record<string, number> }> = ({ weights }) => (
  <ul className="space-y-2">
    {Object.entries(weights).map(([k, w]) => (
      <li key={k}>
        <div className="mb-1 flex justify-between text-xs">
          <span className="capitalize text-soc-textMuted">{k.replace(/_/g, ' ')}</span>
          <span className="tabular-nums text-slate-100">{(w * 100).toFixed(0)}%</span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-soc-darkest" role="meter" aria-label={k.replace(/_/g, ' ')} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(w * 100)}>
          <div className="h-full rounded-full bg-orange-500" style={{ width: `${w * 100}%` }} />
        </div>
      </li>
    ))}
  </ul>
);

/** Replaces window.prompt / window.confirm, which are unstyled, blocking and not announced consistently. */
const PruneDialog: React.FC<{ open: boolean; defaultDays: number; onClose: () => void; onDone: (message: string) => void }> = ({ open, defaultDays, onClose, onDone }) => {
  const [days, setDays] = useState(String(defaultDays));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const value = Number(days);
  const valid = days.trim() !== '' && Number.isFinite(value) && value >= 0;

  const confirm = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await observabilityService.prune(value);
      onDone(`Removed ${r.removed} trace(s).`);
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Pruning failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Prune old traces"
      icon={Trash2}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="danger" loading={busy} disabled={!valid} onClick={confirm}>
            Delete permanently
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        {error && <Alert variant="error">{error}</Alert>}
        <Input
          label="Delete traces older than (days)"
          type="number"
          min={0}
          value={days}
          data-autofocus
          onChange={(e) => setDays(e.target.value)}
          hint="Enter 0 to delete every stored trace. This cannot be undone."
          error={days.trim() !== '' && !valid ? 'Enter a number of days, 0 or greater' : undefined}
        />
      </div>
    </Modal>
  );
};

export const SystemLogic: React.FC = () => {
  const [sys, setSys] = useState<SystemExplanation | null>(null);
  const [importance, setImportance] = useState<{ feature: string; value: number }[]>([]);
  const [version, setVersion] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [pruneMsg, setPruneMsg] = useState<string | null>(null);
  const [pruneOpen, setPruneOpen] = useState(false);
  const isAdmin = authService.isAdmin();

  useEffect(() => {
    let alive = true;
    observabilityService
      .explainSystem()
      .then((d) => alive && setSys(d))
      .catch((e: Error) => alive && setError(e.message));
    mlService
      .getProfiles()
      .then((p) => {
        if (!alive) return;
        setVersion(p.model_version);
        setImportance(
          Object.entries(p.global_feature_importance || {})
            .map(([feature, value]) => ({ feature, value }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 10),
        );
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, []);

  if (error) return <Alert variant="error" title="Could not load the system description">{error}</Alert>;
  if (!sys) return <LoadingSkeleton rows={4} height="h-24" />;
  const o = sys.observability;

  return (
    <div className="space-y-6">
      <p className="max-w-3xl text-sm text-soc-textMuted">
        Every number below is read from the running system (weights, thresholds, models), so this page cannot drift from what actually decides. Each stage lists the trace spans it writes: open any trace to see that stage&rsquo;s decision for a specific query.
      </p>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        {sys.pipeline.map((p) => (
          <Card key={p.id} title={p.title} badge={<ComponentChip component={p.component} />}>
            <div className="space-y-4">
              <p className="text-sm font-medium text-slate-100">{p.what}</p>
              <p className="text-sm leading-relaxed text-slate-300">{p.how}</p>
              {p.parameters.weights && <WeightBars weights={p.parameters.weights as Record<string, number>} />}
              <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1.5 text-xs">
                {Object.entries(p.parameters)
                  .filter(([k]) => k !== 'weights')
                  .map(([k, v]) => (
                    <React.Fragment key={k}>
                      <dt className="capitalize text-soc-textMuted">{k.replace(/_/g, ' ')}</dt>
                      <dd className="break-words text-slate-200">{renderValue(v)}</dd>
                    </React.Fragment>
                  ))}
              </dl>
              <ul className="flex flex-wrap gap-1.5 pt-1" aria-label="Trace spans written by this stage">
                {p.spans.map((s) => (
                  <li key={s} className="rounded border px-1.5 py-0.5 font-mono text-2xs text-slate-300" style={{ borderColor: `${colorFor(p.component)}80` }}>
                    {s}
                  </li>
                ))}
              </ul>
            </div>
          </Card>
        ))}
      </div>

      {importance.length > 0 && (
        <Card title="Global explanation: what the classifier looks at" subtitle={`Mean |SHAP| over the training sample · model ${version}`}>
          <ChartFrame label="Bar chart of the ten features the classifier relies on most." heightClass="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={importance} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 4 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" {...axisProps} />
                <YAxis type="category" dataKey="feature" width={180} {...axisProps} />
                <Tooltip {...tooltipProps} />
                <Bar dataKey="value" name="Mean |SHAP|" fill={CHART.positive} radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>
          <p className="mt-2 text-xs text-soc-textMuted">The per-flow version of this chart appears in every classification and investigation trace.</p>
        </Card>
      )}

      <Card title="Observability configuration" subtitle={o.note}>
        <ul className="mb-4 flex flex-wrap gap-2">
          <li>
            <Badge variant={o.tracing_enabled ? 'low' : 'critical'}>Tracing {o.tracing_enabled ? 'on' : 'off'}</Badge>
          </li>
          <li>
            <Badge variant="neutral">{o.traces_stored ?? '?'} traces stored</Badge>
          </li>
          <li>
            <Badge variant="neutral">Retention {o.retention_days} days</Badge>
          </li>
          <li>
            <Badge variant="neutral">Max {o.max_spans_per_trace} spans / trace</Badge>
          </li>
          <li>
            <Badge variant={o.store_payloads ? 'medium' : 'low'}>{o.store_payloads ? 'Prompt/response previews stored (scrubbed)' : 'Prompt/response text not stored'}</Badge>
          </li>
          <li>
            <Badge variant="neutral">{o.trace_all_requests ? 'All requests traced' : 'Analyst operations traced'}</Badge>
          </li>
        </ul>
        <p className="text-sm text-soc-textMuted">Traced operations: {o.traced_operations.join(', ')}.</p>
        <p className="mt-1 text-sm text-soc-textMuted">Secrets (API keys, tokens, passwords) are scrubbed before anything is stored; log lines carry the trace id so they can be joined to the trace.</p>
        {isAdmin && (
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <Button variant="danger" size="sm" icon={Trash2} onClick={() => setPruneOpen(true)}>
              Prune old traces…
            </Button>
            {pruneMsg && (
              <span role="status" className="text-sm text-slate-300">
                {pruneMsg}
              </span>
            )}
          </div>
        )}
      </Card>

      <PruneDialog open={pruneOpen} defaultDays={o.retention_days} onClose={() => setPruneOpen(false)} onDone={setPruneMsg} />
    </div>
  );
};
