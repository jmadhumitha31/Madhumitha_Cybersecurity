import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Check, Copy, Download, X } from 'lucide-react';
import { Card } from '../common/Card';
import { Badge } from '../common/Badge';
import { SeverityBadge } from '../common/SeverityBadge';
import { ScoreBar } from '../common/ScoreBar';
import { LoadingSkeleton } from '../common/LoadingSkeleton';
import { ContributionChart } from '../explain/ContributionChart';
import { Alert } from '../ui/Alert';
import { Button, IconButton } from '../ui/Button';
import { Table, TableWrap, Td, Th, Tr } from '../ui/Table';
import { observabilityService } from '../../services/observabilityService';
import { saveBlob } from '../../services/api';
import { cn } from '../../lib/cn';
import type { TraceDetail, TraceExplanation, TraceSpanRecord } from '../../types';
import { TraceWaterfall } from './TraceWaterfall';
import { ComponentChip, JsonBlock, Stat, StatusBadge, VerdictIcon } from './shared';
import { colorFor, fmtMs, fmtNum, fmtPct, fmtTime } from './utils';

type Evidence = TraceExplanation['evidence'];

// ------------------------------------------------------------------------------------------------ evidence blocks
const RetrievalEvidence: React.FC<{ ev: NonNullable<Evidence['retrieval']> }> = ({ ev }) => {
  const s = ev.stats || {};
  const alpha = ev.alpha ?? 0.6;
  return (
    <Card title="Retrieval evidence" subtitle={ev.formula}>
      <ul className="mb-4 flex flex-wrap gap-2">
        <li><Badge variant="neutral">Mode {ev.mode}</Badge></li>
        {ev.alpha != null && <li><Badge variant="neutral">alpha {ev.alpha}</Badge></li>}
        <li><Badge variant="neutral">Threshold {ev.threshold}</Badge></li>
        <li><Badge variant="neutral">{ev.n_candidates ?? '?'} of {ev.n_indexed ?? '?'} eligible</Badge></li>
        {s.pool_final != null && <li><Badge variant="cyan">Pool {s.pool_final}</Badge></li>}
        {(s.widenings ?? 0) > 0 && <li><Badge variant="medium">Widened ×{s.widenings}</Badge></li>}
        {s.dense_docs_tied_with_best > 1 && <li><Badge variant="purple">{s.dense_docs_tied_with_best} tied at top</Badge></li>}
        {s.exact_top_k && <li><Badge variant="low">Top-k exact</Badge></li>}
      </ul>
      {ev.query && (
        <p className="mb-3 break-words text-sm text-soc-textMuted">
          Query: <span className="text-slate-200">{ev.query}</span>
        </p>
      )}
      {Object.keys(ev.filters || {}).length > 0 && (
        <p className="mb-3 text-sm text-soc-textMuted">
          Filters: <span className="font-mono text-xs text-slate-200">{JSON.stringify(ev.filters)}</span>
        </p>
      )}
      {ev.results.length === 0 ? (
        <Alert variant="warning">No incident cleared the threshold: the system reported “no sufficiently similar historical incidents” rather than guessing.</Alert>
      ) : (
        <>
          <TableWrap>
            <Table caption="Retrieved incidents and how their scores were composed">
              <thead>
                <tr>
                  <Th numeric>#</Th>
                  <Th>Incident</Th>
                  <Th>Class</Th>
                  <Th className="w-44">Score = dense + BM25</Th>
                  <Th>Terms that earned the BM25 score</Th>
                </tr>
              </thead>
              <tbody>
                {ev.results.map((r, i) => (
                  <Tr key={r.incident_id} className="align-top">
                    <Td numeric className="text-soc-textMuted">{i + 1}</Td>
                    <Td>
                      <Link className="font-mono font-semibold text-cyan-300 hover:underline" to={`/incidents/${r.incident_id}`}>
                        #{r.incident_id}
                      </Link>
                    </Td>
                    <Td className="text-slate-200">{r.attack_type}</Td>
                    <Td>
                      <div className="tabular-nums text-slate-100">{fmtNum(r.score)}</div>
                      <div className="mt-1 flex h-2 overflow-hidden rounded-full bg-soc-darkest" title={`dense ${fmtNum(r.dense)} · BM25 ${fmtNum(r.bm25)}`}>
                        <div className="bg-cyan-500" style={{ width: `${Math.min(100, r.dense * alpha * 100)}%` }} />
                        <div className="bg-amber-500" style={{ width: `${Math.min(100, r.bm25 * (1 - alpha) * 100)}%` }} />
                      </div>
                      <div className="mt-0.5 text-2xs text-soc-textMuted">dense {fmtNum(r.dense)} · BM25 {fmtNum(r.bm25)}</div>
                    </Td>
                    <Td>
                      {r.matched_terms.length ? (
                        <div className="flex flex-wrap gap-1">
                          {r.matched_terms.map((t) => (
                            <span key={t.term} className="rounded border border-amber-800/40 bg-amber-950/40 px-1.5 py-0.5 text-amber-300" title={`tf ${t.tf} · idf ${t.idf}`}>
                              {t.term} +{(t.contribution * 100).toFixed(0)}%
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span className="text-soc-textMuted">Semantic match only</span>
                      )}
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          </TableWrap>
          <p className="mt-2 text-xs text-soc-textMuted">
            <span className="mr-1 inline-block h-2 w-2 rounded-sm bg-cyan-500" aria-hidden /> Weighted dense (Qdrant cosine) share ·
            <span className="mx-1 inline-block h-2 w-2 rounded-sm bg-amber-500" aria-hidden /> weighted BM25 share of the score.
          </p>
        </>
      )}
    </Card>
  );
};

const ModelEvidence: React.FC<{ ev: NonNullable<Evidence['model']> }> = ({ ev }) => (
  <Card title="Model decision" subtitle={`Classifier ${ev.model_version ?? ''} · explained with ${ev.explanation_method === 'shap-tree' ? 'SHAP' : (ev.explanation_method ?? 'n/a')}`}>
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="cyan" size="md">{ev.attack_type}</Badge>
          <span className="text-sm text-slate-200">{fmtPct(ev.confidence)} confidence</span>
          {ev.low_confidence && <Badge variant="medium">Low confidence</Badge>}
        </div>
        {ev.top_classes.map((c) => (
          <ScoreBar key={c.attack_type} label={c.attack_type} value={c.probability} tone={c.attack_type === ev.attack_type ? 'cyan' : 'purple'} />
        ))}
        <ScoreBar label="Intrusion probability (independent model)" value={ev.intrusion_probability} tone="red" />
        <ScoreBar label="Anomaly vs benign baseline" value={ev.anomaly_score} tone="amber" />
      </div>
      <div>
        {ev.contributions.length > 0 ? (
          <ContributionChart explanation={{ method: ev.explanation_method ?? 'shap-tree', target_class: ev.target_class ?? ev.attack_type ?? '', contributions: ev.contributions } as never} />
        ) : (
          <p className="text-sm text-soc-textMuted">No per-feature attribution was computed for this query.</p>
        )}
      </div>
    </div>
  </Card>
);

const RiskEvidence: React.FC<{ ev: NonNullable<Evidence['risk']> }> = ({ ev }) => {
  const rows = Object.keys(ev.weights).map((k) => ({ key: k, value: ev.components[k] ?? 0, weight: ev.weights[k], points: (ev.components[k] ?? 0) * ev.weights[k] * 100 }));
  const adj = (ev.components.retrieval_adjustment ?? 0) * 100;
  return (
    <Card
      title="Risk score"
      subtitle="score = 100 × Σ(weight × component) ± retrieval agreement, then policy floors"
      badge={ev.risk_level ? <SeverityBadge level={ev.risk_level} priority={ev.priority} /> : undefined}
    >
      <div className="space-y-3">
        {rows.map((r) => (
          <div key={r.key}>
            <div className="mb-1 flex justify-between gap-3 text-xs">
              <span className="capitalize text-soc-textMuted">{r.key.replace(/_/g, ' ')}</span>
              <span className="tabular-nums text-slate-200">
                {r.value.toFixed(3)} × {r.weight} = <strong>{r.points.toFixed(1)}</strong> pts
              </span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-soc-darkest">
              <div className="h-full rounded-full bg-orange-500" style={{ width: `${Math.min(100, r.points * 2.5)}%` }} />
            </div>
          </div>
        ))}
        {Math.abs(adj) > 0.05 && (
          <p className="text-sm text-slate-300">
            Retrieval agreement adjustment: {adj > 0 ? '+' : ''}
            {adj.toFixed(1)} pts
          </p>
        )}
        <p className="pt-1 text-sm text-slate-100">
          Total: <strong>{ev.risk_score}</strong> / 100{ev.policy_floor_applied && <span className="text-amber-300"> (raised by a policy floor)</span>}
        </p>
        <ul className="ml-4 list-disc space-y-0.5 text-xs text-slate-400">
          {ev.factors.slice(0, 8).map((f, i) => (
            <li key={i}>{f}</li>
          ))}
        </ul>
      </div>
    </Card>
  );
};

const LlmEvidence: React.FC<{ calls: NonNullable<Evidence['llm']> }> = ({ calls }) => (
  <Card title={`LLM ${calls.length > 1 ? `calls (${calls.length})` : 'call'}`} subtitle="Provider chain outcome, every attempt, token use and (when enabled) scrubbed prompt/response previews.">
    <div className="space-y-4">
      {calls.map((c, i) => (
        <div key={c.span_id ?? i} className="space-y-3 rounded-lg bg-soc-card/50 p-4">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <Badge variant={c.fallback_used ? 'medium' : 'low'}>
              <span className="font-mono">
                {c.provider}/{c.model}
              </span>
            </Badge>
            {c.fallback_used && <Badge variant="medium">Offline fallback: no LLM answered</Badge>}
            <span className="tabular-nums text-slate-300">{fmtMs(c.latency_ms)}</span>
            {c.mode && <span className="text-soc-textMuted">mode {c.mode}</span>}
            {c.usage && <span className="text-soc-textMuted">tokens {c.usage.prompt_tokens ?? '?'} in / {c.usage.completion_tokens ?? '?'} out</span>}
            {c.finish_reason && <span className="text-soc-textMuted">finish: {c.finish_reason}</span>}
            {c.status !== 'ok' && <Badge variant="critical">{c.status}: {c.error}</Badge>}
          </div>
          {c.chain.length > 0 && <p className="text-xs text-soc-textMuted">Chain: {c.chain.join(' → ')}</p>}
          {c.attempts.length > 0 && (
            <TableWrap>
              <Table caption="LLM attempts">
                <thead>
                  <tr>
                    <Th numeric>Attempt</Th>
                    <Th>Model</Th>
                    <Th>Result</Th>
                    <Th numeric>ms</Th>
                  </tr>
                </thead>
                <tbody>
                  {c.attempts.map((a, j) => (
                    <Tr key={j}>
                      <Td numeric>{j + 1}</Td>
                      <Td mono className="text-slate-300">
                        {a.provider}
                        {a.model ? `/${a.model}` : ''}
                      </Td>
                      <Td className={a.ok ? 'text-emerald-400' : 'text-red-400'}>{a.ok ? 'ok' : String(a.error ?? a.status ?? 'failed').slice(0, 90)}</Td>
                      <Td numeric className="text-slate-400">{a.latency_ms ?? ''}</Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
            </TableWrap>
          )}
          <p className="text-xs text-soc-textMuted">
            Prompt {c.prompt_chars} chars · sha256 <span className="font-mono">{c.prompt_sha256}</span> · temperature {c.temperature}
          </p>
          {c.prompt_preview != null ? (
            <div className="space-y-2">
              <JsonBlock label="System prompt preview" value={c.system_preview} />
              <details className="rounded-lg bg-soc-darkest/70">
                <summary className="cursor-pointer select-none px-3 py-2 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted hover:text-slate-200">Prompt preview</summary>
                <pre className="max-h-72 overflow-auto whitespace-pre-wrap break-words px-3 pb-3 font-mono text-xs text-slate-300">{c.prompt_preview}</pre>
              </details>
              <details className="rounded-lg bg-soc-darkest/70">
                <summary className="cursor-pointer select-none px-3 py-2 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted hover:text-slate-200">Response preview</summary>
                <pre className="max-h-72 overflow-auto whitespace-pre-wrap break-words px-3 pb-3 font-mono text-xs text-slate-300">{c.response_preview}</pre>
              </details>
            </div>
          ) : (
            <p className="text-xs text-soc-textMuted">Prompt/response text is not stored (TRACE_STORE_PAYLOADS=false): only the hash and sizes are kept.</p>
          )}
        </div>
      ))}
    </div>
  </Card>
);

const TimeBreakdown: React.FC<{ tb: TraceExplanation['time_breakdown'] }> = ({ tb }) => {
  const comps = Object.entries(tb.by_component);
  const sum = comps.reduce((a, [, v]) => a + v, 0) || 1;
  return (
    <Card title="Where the time went" subtitle="Self time per component (a span's duration minus its child spans).">
      <div className="flex h-3 overflow-hidden rounded-full" role="img" aria-label={`Time split across ${comps.length} components`}>
        {comps.map(([c, v]) => (
          <div key={c} style={{ width: `${(v / sum) * 100}%`, backgroundColor: colorFor(c) }} title={`${c}: ${fmtMs(v)}`} />
        ))}
      </div>
      <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5">
        {comps.map(([c, v]) => (
          <li key={c} className="flex items-center gap-2 text-xs tabular-nums text-slate-300">
            <ComponentChip component={c} /> {fmtMs(v)} ({((v / sum) * 100).toFixed(0)}%)
          </li>
        ))}
      </ul>
      <p className="mt-3 text-xs text-soc-textMuted">
        Total {fmtMs(tb.total_ms)} · database {fmtMs(tb.db_ms)} in {tb.db_queries} queries · slowest: {tb.slowest.slice(0, 3).map((s) => `${s.name} ${fmtMs(s.self_ms)}`).join(' · ')}
      </p>
    </Card>
  );
};

// ------------------------------------------------------------------------------------------------ panel
/** Keyed by trace id by the caller, so switching traces starts from a clean state. */
export const TraceDetailPanel: React.FC<{ traceId: string; onClose: () => void }> = ({ traceId, onClose }) => {
  const [detail, setDetail] = useState<TraceDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<TraceSpanRecord | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let alive = true;
    observabilityService
      .getTrace(traceId)
      .then((d) => alive && setDetail(d))
      .catch((e: Error) => alive && setError(e.message));
    return () => {
      alive = false;
    };
  }, [traceId]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(traceId);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard blocked */
    }
  };

  const t = detail?.trace;
  const ex = detail?.explanation;
  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="break-all font-mono text-sm font-semibold text-slate-50">{traceId}</h2>
            <IconButton label={copied ? 'Copied' : 'Copy trace id'} icon={copied ? Check : Copy} onClick={copy} className={cn(copied && 'text-emerald-400')} />
            {t && <StatusBadge status={t.status} />}
            {t && <Badge variant="purple">{t.kind}</Badge>}
          </div>
          {t && (
            <p className="mt-1 text-xs text-soc-textMuted">
              {fmtTime(t.started_at)} · {t.username ?? 'system'}
              {t.role ? ` (${t.role})` : ''} · {t.name}
              {t.incident_id != null && (
                <>
                  {' '}
                  ·{' '}
                  <Link className="text-cyan-300 hover:underline" to={`/incidents/${t.incident_id}`}>
                    incident #{t.incident_id}
                  </Link>
                </>
              )}
            </p>
          )}
        </div>
        <div className="flex shrink-0 gap-2">
          {detail && (
            <Button size="sm" icon={Download} onClick={() => saveBlob(new Blob([JSON.stringify(detail, null, 2)], { type: 'application/json' }), `trace_${traceId}.json`)}>
              JSON
            </Button>
          )}
          <IconButton label="Close trace" icon={X} variant="secondary" onClick={onClose} />
        </div>
      </div>

      {error && <Alert variant="error" title="Could not load this trace">{error}</Alert>}
      {!detail && !error && <LoadingSkeleton rows={5} height="h-16" />}

      {t && ex && (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
            <Stat label="Duration" value={fmtMs(t.duration_ms)} />
            <Stat label="Spans" value={t.n_spans} hint={t.dropped_spans ? `${t.dropped_spans} further spans were counted but not stored` : undefined} />
            <Stat label="DB queries" value={`${t.db_queries}`} hint={`${fmtMs(t.db_time_ms)} in the database`} />
            <Stat label="HTTP" value={t.http_status ?? '—'} />
            <Stat label="LLM calls" value={t.counters['llm.calls'] ?? 0} tone={t.counters['llm.fallbacks'] ? 'text-amber-300' : undefined} hint={t.counters['llm.fallbacks'] ? 'Answered by the offline rule engine' : undefined} />
          </div>

          {t.query_text && (
            <div className="rounded-lg bg-soc-darkest/70 p-4">
              <div className="mb-1 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Query</div>
              <p className="break-words text-sm text-slate-100">{t.query_text}</p>
            </div>
          )}
          {t.error && <Alert variant="error">{t.error}</Alert>}

          <Card title="Why this answer" subtitle="Derived deterministically from the recorded spans (no LLM involved).">
            <p className="mb-3 text-sm text-cyan-200">{ex.headline}</p>
            <ol className="space-y-1">
              {ex.steps.map((s) => {
                const sp = t.spans.find((x) => x.span_id === s.span_id) ?? null;
                return (
                  <li key={s.span_id}>
                    <button
                      type="button"
                      onClick={() => sp && setSelected(sp)}
                      className={cn('flex w-full items-start gap-2.5 rounded-md px-2 py-2 text-left transition-colors hover:bg-soc-card/70', selected?.span_id === s.span_id && 'bg-cyan-950/40')}
                    >
                      <VerdictIcon verdict={s.verdict} />
                      <span className="min-w-0">
                        <span className="flex items-center gap-2">
                          <ComponentChip component={s.component} />
                          <span className="text-2xs tabular-nums text-soc-textMuted">{fmtMs(s.duration_ms)}</span>
                        </span>
                        <span className="block break-words text-sm text-slate-200">{s.detail}</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ol>
          </Card>

          <Card title="Trace waterfall" subtitle={`${t.spans.length} span(s) · ${fmtMs(t.duration_ms)} end to end`}>
            <TraceWaterfall spans={t.spans} totalMs={t.duration_ms} selectedId={selected?.span_id} onSelect={setSelected} />
            {selected && (
              <div className="mt-4 space-y-2 rounded-lg bg-soc-darkest/60 p-4">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="font-mono text-sm font-semibold text-slate-100">{selected.name}</span>
                  <ComponentChip component={selected.component} />
                  <span className="text-xs tabular-nums text-soc-textMuted">
                    {fmtMs(selected.duration_ms)} (self {fmtMs(selected.self_ms)}) · starts {fmtMs(selected.start_offset_ms)}
                  </span>
                  {selected.status !== 'ok' && <Badge variant="critical">{selected.status}</Badge>}
                </div>
                {selected.error && <p className="break-words text-sm text-red-300">{selected.error}</p>}
                <JsonBlock label="Recorded attributes" value={selected.attributes} open />
              </div>
            )}
          </Card>

          {ex.evidence.guardrails && ex.evidence.guardrails.length > 0 && (
            <Card title="Guardrails" subtitle="Every guardrail decision taken for this query.">
              <ul className="space-y-2.5">
                {ex.evidence.guardrails.map((g, i) => (
                  <li key={i} className="flex items-start gap-2.5">
                    <VerdictIcon verdict={g.verdict} />
                    <div>
                      <span className="text-2xs font-semibold uppercase tracking-wide text-soc-textMuted">{g.name}</span>
                      <p className="text-sm text-slate-200">{g.detail}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </Card>
          )}
          {ex.evidence.retrieval && <RetrievalEvidence ev={ex.evidence.retrieval} />}
          {ex.evidence.model && <ModelEvidence ev={ex.evidence.model} />}
          {ex.evidence.risk && <RiskEvidence ev={ex.evidence.risk} />}
          {ex.evidence.llm && <LlmEvidence calls={ex.evidence.llm} />}
          {ex.evidence.checks && (
            <Card title="Output checks" subtitle={`${ex.evidence.checks.filter((c) => c.passed).length}/${ex.evidence.checks.length} passed before the analysis reached an analyst.`}>
              <ul className="space-y-2">
                {ex.evidence.checks.map((c) => (
                  <li key={c.check} className="flex items-start gap-2.5 text-sm text-slate-200">
                    <VerdictIcon verdict={c.passed ? 'ok' : 'warn'} />
                    <span>
                      <strong>{c.check}</strong> — {c.detail}
                    </span>
                  </li>
                ))}
              </ul>
            </Card>
          )}
          <TimeBreakdown tb={ex.time_breakdown} />

          <Card title="Audit trail and raw record" subtitle="Audit-log entries written during this query, and the stored input / output.">
            {detail.audit.length > 0 ? (
              <ul className="mb-4 space-y-1">
                {detail.audit.map((a, i) => (
                  <li key={i} className="text-sm text-slate-300">
                    {fmtTime(a.timestamp)} · <strong>{a.action}</strong> · {a.status}
                    {a.model_provider ? ` · ${a.model_provider}` : ''}
                    {a.fallback_used ? ' (fallback)' : ''}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mb-4 text-sm text-soc-textMuted">No audit-log entry was written during this query (read-only operation).</p>
            )}
            <div className="space-y-2">
              <JsonBlock label="Input" value={t.input} />
              <JsonBlock label="Output" value={t.output} />
              <JsonBlock label="Summary" value={t.summary} />
              <JsonBlock label="Counters" value={t.counters} />
            </div>
          </Card>
        </>
      )}
    </div>
  );
};
