import React, { useMemo } from 'react';
import { cn } from '../../lib/cn';
import type { TraceSpanRecord } from '../../types';
import { colorFor, fmtMs } from './utils';

interface Props {
  spans: TraceSpanRecord[];
  totalMs: number;
  selectedId?: string | null;
  onSelect: (span: TraceSpanRecord) => void;
}

/**
 * Waterfall of a trace: one row per span, indented by nesting depth, bar positioned by start offset and sized by
 * duration. The bar colour is the component; a solid inner strip shows the span's *self* time (its duration minus its
 * children), i.e. where the time was actually spent.
 */
export const TraceWaterfall: React.FC<Props> = ({ spans, totalMs, selectedId, onSelect }) => {
  const total = useMemo(() => Math.max(totalMs, ...spans.map((s) => s.start_offset_ms + s.duration_ms), 1), [spans, totalMs]);
  const components = useMemo(() => Array.from(new Set(spans.map((s) => s.component))), [spans]);
  const ticks = [0, 0.25, 0.5, 0.75, 1];

  if (!spans.length) return <p className="text-sm text-soc-textMuted">No spans were recorded for this trace.</p>;

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[36rem]">
        <ul className="mb-3 flex flex-wrap gap-x-4 gap-y-1" aria-label="Component colours">
          {components.map((c) => (
            <li key={c} className="inline-flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-wide text-slate-300">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: colorFor(c) }} aria-hidden />
              {c}
            </li>
          ))}
        </ul>
        <div className="mb-1 flex text-2xs tabular-nums text-soc-textMuted" aria-hidden>
          <div className="w-56 shrink-0 sm:w-72" />
          <div className="relative h-4 flex-1">
            {ticks.map((t) => (
              <span key={t} className="absolute -translate-x-1/2" style={{ left: `${t * 100}%` }}>
                {fmtMs(total * t)}
              </span>
            ))}
          </div>
          <div className="w-16 shrink-0" />
        </div>
        <ul className="divide-y divide-soc-border/60 overflow-hidden rounded-lg border border-soc-border" aria-label="Trace spans">
          {spans.map((s) => {
            const left = (s.start_offset_ms / total) * 100;
            const width = Math.max((s.duration_ms / total) * 100, 0.5);
            const selfWidth = s.duration_ms > 0 ? Math.min(100, (s.self_ms / s.duration_ms) * 100) : 0;
            const selected = selectedId === s.span_id;
            const bad = s.status !== 'ok';
            return (
              <li key={s.span_id}>
                <button
                  type="button"
                  onClick={() => onSelect(s)}
                  aria-pressed={selected}
                  title={`${s.name}\n${s.component} · ${fmtMs(s.duration_ms)} (self ${fmtMs(s.self_ms)}) · starts at ${fmtMs(s.start_offset_ms)}${s.error ? `\n${s.error}` : ''}`}
                  className={cn('flex h-8 w-full items-center text-left transition-colors hover:bg-soc-card/70 focus-visible:-outline-offset-2', selected && 'bg-cyan-950/40')}
                >
                  <span className="w-56 shrink-0 truncate pr-2 font-mono text-xs text-slate-300 sm:w-72" style={{ paddingLeft: 8 + s.depth * 14 }}>
                    {bad && (
                      <span className="mr-1 text-red-400" aria-label="Error">
                        !
                      </span>
                    )}
                    {s.name}
                  </span>
                  <span className="relative h-4 flex-1" aria-hidden>
                    <span className={cn('absolute top-0 h-4 rounded-sm', bad && 'ring-1 ring-red-500')} style={{ left: `${left}%`, width: `${width}%`, backgroundColor: colorFor(s.component), opacity: 0.45 }} />
                    <span className="absolute top-1 h-2 rounded-sm" style={{ left: `${left}%`, width: `${(width * selfWidth) / 100}%`, backgroundColor: colorFor(s.component) }} />
                  </span>
                  <span className="w-16 shrink-0 pr-2 text-right text-2xs tabular-nums text-slate-400">{fmtMs(s.duration_ms)}</span>
                </button>
              </li>
            );
          })}
        </ul>
        <p className="mt-2 text-xs text-soc-textMuted">Pale bar = span duration, solid strip = self time (without child spans). Select a span for its recorded attributes.</p>
      </div>
    </div>
  );
};
