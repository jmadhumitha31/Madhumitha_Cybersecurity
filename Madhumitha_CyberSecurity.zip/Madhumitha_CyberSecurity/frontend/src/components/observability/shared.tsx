import React from 'react';
import { AlertTriangle, Ban, CheckCircle2, Info } from 'lucide-react';
import { Badge } from '../common/Badge';
import { Metric } from '../ui/Metric';
import type { TraceStatus } from '../../types';
import { colorFor } from './utils';

const STATUS_LABEL: Record<TraceStatus, string> = { ok: 'OK', degraded: 'Degraded', rejected: 'Rejected', error: 'Error' };
const STATUS_VARIANT = { ok: 'low', degraded: 'medium', rejected: 'high', error: 'critical' } as const;

export const StatusBadge: React.FC<{ status: TraceStatus }> = ({ status }) => <Badge variant={STATUS_VARIANT[status]}>{STATUS_LABEL[status]}</Badge>;

export const ComponentChip: React.FC<{ component: string }> = ({ component }) => (
  <span className="inline-flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-wide text-slate-300">
    <span className="h-2 w-2 rounded-sm" style={{ backgroundColor: colorFor(component) }} aria-hidden />
    {component}
  </span>
);

export const VerdictIcon: React.FC<{ verdict: string }> = ({ verdict }) => {
  if (verdict === 'ok') return <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" aria-label="Passed" />;
  if (verdict === 'blocked') return <Ban className="h-4 w-4 shrink-0 text-red-400" aria-label="Blocked" />;
  if (verdict === 'warn') return <AlertTriangle className="h-4 w-4 shrink-0 text-amber-400" aria-label="Warning" />;
  return <Info className="h-4 w-4 shrink-0 text-slate-400" aria-label="Info" />;
};

/** Pretty-printed JSON that is rendered as text (never as HTML), collapsed by default. */
export const JsonBlock: React.FC<{ label: string; value: unknown; open?: boolean }> = ({ label, value, open = false }) => {
  const empty = value === null || value === undefined || (typeof value === 'object' && Object.keys(value as object).length === 0);
  if (empty) return null;
  return (
    <details open={open} className="rounded-lg bg-soc-darkest/70">
      <summary className="cursor-pointer select-none px-3 py-2 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted hover:text-slate-200">{label}</summary>
      <pre className="max-h-80 overflow-auto whitespace-pre-wrap break-all px-3 pb-3 font-mono text-xs text-slate-300">{JSON.stringify(value, null, 2)}</pre>
    </details>
  );
};

export const Stat: React.FC<{ label: string; value: React.ReactNode; hint?: string; tone?: string }> = ({ label, value, hint, tone }) => (
  <Metric label={label} value={value} hint={hint} tone={tone} />
);
