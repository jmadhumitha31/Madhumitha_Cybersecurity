import type { TraceStatus } from '../../types';

/** One colour per component, shared by the waterfall, the time breakdown and the metrics charts. */
export const COMPONENT_COLORS: Record<string, string> = {
  api: '#64748b',
  guardrail: '#f59e0b',
  ml: '#10b981',
  retrieval: '#06b6d4',
  embedding: '#38bdf8',
  llm: '#a855f7',
  agent: '#6366f1',
  risk: '#f97316',
  db: '#94a3b8',
  evaluation: '#ec4899',
  app: '#64748b',
};
export const colorFor = (component: string): string => COMPONENT_COLORS[component] ?? '#64748b';

export const STATUS_COLORS: Record<TraceStatus, string> = { ok: '#10b981', degraded: '#eab308', rejected: '#f97316', error: '#ef4444' };

export const fmtMs = (v?: number | null): string =>
  v === null || v === undefined || Number.isNaN(v) ? 'n/a' : v >= 1000 ? `${(v / 1000).toFixed(2)} s` : v >= 100 ? `${Math.round(v)} ms` : `${v.toFixed(1)} ms`;

export const fmtPct = (v?: number | null, digits = 1): string => (v === null || v === undefined ? 'n/a' : `${(v * 100).toFixed(digits)}%`);

export const fmtNum = (v?: number | null, digits = 3): string => (v === null || v === undefined || Number.isNaN(v) ? 'n/a' : Number(v).toFixed(digits));

/** The API returns naive UTC timestamps: tag them as UTC before formatting in the viewer's locale. */
export const fmtTime = (iso?: string | null): string => {
  if (!iso) return '';
  const d = new Date(/(Z|[+-]\d\d:?\d\d)$/.test(iso) ? iso : `${iso}Z`);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString();
};

export const shortId = (id: string): string => id.slice(0, 8);
