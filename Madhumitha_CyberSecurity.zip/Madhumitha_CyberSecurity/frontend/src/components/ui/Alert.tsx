import React from 'react';
import { AlertCircle, AlertTriangle, CheckCircle2, Info, X } from 'lucide-react';
import { cn } from '../../lib/cn';

export type AlertVariant = 'error' | 'warning' | 'success' | 'info';

const STYLE: Record<AlertVariant, { box: string; icon: string; Icon: React.ComponentType<{ className?: string }> }> = {
  error: { box: 'border-red-800/70 bg-red-950/50 text-red-100', icon: 'text-red-400', Icon: AlertCircle },
  warning: { box: 'border-amber-700/60 bg-amber-950/40 text-amber-100', icon: 'text-amber-400', Icon: AlertTriangle },
  success: { box: 'border-emerald-800/70 bg-emerald-950/40 text-emerald-100', icon: 'text-emerald-400', Icon: CheckCircle2 },
  info: { box: 'border-sky-800/70 bg-sky-950/40 text-sky-100', icon: 'text-sky-400', Icon: Info },
};

interface AlertProps {
  variant?: AlertVariant;
  title?: string;
  children: React.ReactNode;
  onDismiss?: () => void;
  action?: React.ReactNode;
  className?: string;
}

/** Inline message. Errors are announced to screen readers immediately (role=alert); the rest politely (role=status). */
export const Alert: React.FC<AlertProps> = ({ variant = 'info', title, children, onDismiss, action, className }) => {
  const { box, icon, Icon } = STYLE[variant];
  return (
    <div role={variant === 'error' ? 'alert' : 'status'} className={cn('flex items-start gap-3 rounded-lg border px-4 py-3 text-sm', box, className)}>
      <Icon className={cn('mt-0.5 h-4 w-4 shrink-0', icon)} />
      <div className="min-w-0 flex-1 space-y-0.5">
        {title && <p className="font-semibold">{title}</p>}
        <div className="leading-relaxed break-words">{children}</div>
      </div>
      {action}
      {onDismiss && (
        <button type="button" onClick={onDismiss} aria-label="Dismiss message" className="-m-1 rounded p-1 opacity-70 transition-opacity hover:opacity-100">
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  );
};
