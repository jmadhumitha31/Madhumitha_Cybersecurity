import React from 'react';
import { Loader2, type LucideIcon } from 'lucide-react';
import { cn } from '../../lib/cn';
import { buttonClasses, type ButtonSize, type ButtonVariant } from './buttonStyles';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: LucideIcon;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'secondary',
  size = 'md',
  loading = false,
  icon: Icon,
  type = 'button',
  disabled,
  className,
  children,
  ...rest
}) => (
  <button
    type={type}
    disabled={disabled || loading}
    aria-busy={loading || undefined}
    className={cn(buttonClasses(variant, size), className)}
    {...rest}
  >
    {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : Icon ? <Icon className="h-4 w-4" aria-hidden /> : null}
    {children}
  </button>
);

interface IconButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'aria-label'> {
  /** Required: icon-only buttons have no visible text, so the label is the accessible name and the tooltip. */
  label: string;
  icon: LucideIcon;
  variant?: ButtonVariant;
}

export const IconButton: React.FC<IconButtonProps> = ({ label, icon: Icon, variant = 'ghost', type = 'button', className, ...rest }) => (
  <button type={type} aria-label={label} title={label} className={cn(buttonClasses(variant, 'sm'), 'w-8 px-0', className)} {...rest}>
    <Icon className="h-4 w-4" aria-hidden />
  </button>
);
