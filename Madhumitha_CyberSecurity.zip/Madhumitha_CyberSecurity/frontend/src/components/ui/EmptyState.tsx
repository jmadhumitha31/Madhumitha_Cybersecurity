import React from 'react';
import { Inbox, type LucideIcon } from 'lucide-react';
import { cn } from '../../lib/cn';

interface EmptyStateProps {
  title: string;
  description?: React.ReactNode;
  icon?: LucideIcon;
  action?: React.ReactNode;
  className?: string;
}

/** The one "nothing here" treatment: icon, what is missing, and (when there is one) what to do about it. */
export const EmptyState: React.FC<EmptyStateProps> = ({ title, description, icon: Icon = Inbox, action, className }) => (
  <div className={cn('flex flex-col items-center px-4 py-10 text-center', className)}>
    <div className="mb-3 rounded-full bg-soc-card p-3 text-slate-400">
      <Icon className="h-5 w-5" aria-hidden />
    </div>
    <p className="text-sm font-medium text-slate-200">{title}</p>
    {description && <p className="mt-1 max-w-md text-xs text-soc-textMuted">{description}</p>}
    {action && <div className="mt-4">{action}</div>}
  </div>
);
