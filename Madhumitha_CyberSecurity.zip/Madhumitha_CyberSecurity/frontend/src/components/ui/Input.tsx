import React, { useId } from 'react';
import { ChevronDown, type LucideIcon } from 'lucide-react';
import { cn } from '../../lib/cn';

/**
 * Form controls with a real <label for>, optional hint and error text wired up through aria-describedby.
 * Every control in the app goes through these, so heights, borders and focus treatment are identical everywhere.
 */
interface FieldChrome {
  label: string;
  /** Keep the label for screen readers but do not show it (toolbar filters whose purpose is obvious from context). */
  hideLabel?: boolean;
  hint?: string;
  error?: string | null;
  /** 32px control for toolbars; the default is 36px. */
  compact?: boolean;
}

// Sentence case on purpose: uppercase turns "µs" into a Greek capital Mu, which reads as "MS" (milliseconds).
const LABEL = 'mb-1.5 block text-xs font-medium text-slate-300';

const base = (error: string | null | undefined) =>
  cn(
    'w-full rounded-md border bg-soc-card text-slate-100 transition-colors',
    'hover:border-soc-borderLight focus-visible:border-cyan-500',
    'disabled:cursor-not-allowed disabled:opacity-60',
    error ? 'border-red-700' : 'border-soc-border',
  );

const control = (compact: boolean | undefined, error: string | null | undefined) =>
  cn(base(error), compact ? 'h-8 px-2.5 text-xs' : 'h-9 px-3 text-sm');

const Frame: React.FC<{
  id: string;
  chrome: FieldChrome;
  className?: string;
  children: React.ReactNode;
}> = ({ id, chrome, className, children }) => (
  <div className={className}>
    <label htmlFor={id} className={chrome.hideLabel ? 'sr-only' : LABEL}>
      {chrome.label}
    </label>
    {children}
    {chrome.error ? (
      <p id={`${id}-error`} role="alert" className="mt-1 text-xs text-red-300">
        {chrome.error}
      </p>
    ) : chrome.hint ? (
      <p id={`${id}-hint`} className="mt-1 text-xs text-soc-textMuted">
        {chrome.hint}
      </p>
    ) : null}
  </div>
);

const describedBy = (id: string, chrome: FieldChrome) => (chrome.error ? `${id}-error` : chrome.hint ? `${id}-hint` : undefined);

interface InputProps extends FieldChrome, Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  icon?: LucideIcon;
  /** Interactive element placed inside the right edge of the field (e.g. a show-password toggle). */
  endAdornment?: React.ReactNode;
}

export const Input: React.FC<InputProps> = ({ label, hideLabel, hint, error, compact, icon: Icon, endAdornment, className, id, ...rest }) => {
  const uid = useId();
  const inputId = id ?? uid;
  const chrome = { label, hideLabel, hint, error, compact };
  return (
    <Frame id={inputId} chrome={chrome} className={className}>
      <div className="relative">
        {Icon && <Icon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />}
        <input
          id={inputId}
          aria-invalid={error ? true : undefined}
          aria-describedby={describedBy(inputId, chrome)}
          className={cn(control(compact, error), Icon && 'pl-9', endAdornment && 'pr-10')}
          {...rest}
        />
        {endAdornment && <div className="absolute right-1 top-1/2 -translate-y-1/2">{endAdornment}</div>}
      </div>
    </Frame>
  );
};

interface SelectProps extends FieldChrome, Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'size'> {}

export const Select: React.FC<SelectProps> = ({ label, hideLabel, hint, error, compact, className, id, children, ...rest }) => {
  const uid = useId();
  const selectId = id ?? uid;
  const chrome = { label, hideLabel, hint, error, compact };
  return (
    <Frame id={selectId} chrome={chrome} className={className}>
      <div className="relative">
        <select
          id={selectId}
          aria-invalid={error ? true : undefined}
          aria-describedby={describedBy(selectId, chrome)}
          className={cn(control(compact, error), 'cursor-pointer appearance-none pr-8')}
          {...rest}
        >
          {children}
        </select>
        <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
      </div>
    </Frame>
  );
};

interface TextareaProps extends FieldChrome, React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

export const Textarea: React.FC<TextareaProps> = ({ label, hideLabel, hint, error, className, id, ...rest }) => {
  const uid = useId();
  const areaId = id ?? uid;
  const chrome = { label, hideLabel, hint, error };
  return (
    <Frame id={areaId} chrome={chrome} className={className}>
      <textarea
        id={areaId}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy(areaId, chrome)}
        className={cn(base(error), 'min-h-[4.5rem] resize-y px-3 py-2 text-sm')}
        {...rest}
      />
    </Frame>
  );
};

interface CheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label: string;
}

export const Checkbox: React.FC<CheckboxProps> = ({ label, className, ...rest }) => (
  <label className={cn('inline-flex cursor-pointer items-center gap-2 text-xs text-slate-300 select-none', className)}>
    <input type="checkbox" className="h-4 w-4 cursor-pointer accent-cyan-500" {...rest} />
    {label}
  </label>
);
