import React from 'react';
import { cn } from '../../lib/cn';

interface MetricProps {
  label: string;
  value: React.ReactNode;
  /** Tailwind text colour class for the value. */
  tone?: string;
  /** Extra explanation; shown as a tooltip and exposed to screen readers. */
  hint?: string;
  className?: string;
}

/** A labelled number. Replaces four different hand-rolled tile styles (Evaluation, Observability, History, Settings). */
export const Metric: React.FC<MetricProps> = ({ label, value, tone = 'text-slate-50', hint, className }) => (
  <div className={cn('rounded-lg bg-soc-card/70 px-3.5 py-3', className)} title={hint}>
    <div className="text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">{label}</div>
    <div className={cn('mt-1 text-lg font-semibold tabular-nums break-words', tone)}>{value}</div>
    {hint && <span className="sr-only">{hint}</span>}
  </div>
);

interface DefinitionListProps {
  items: { label: string; value: React.ReactNode }[];
  /** Two columns from the `sm` breakpoint up. */
  columns?: 1 | 2;
  className?: string;
}

/** Label / value rows separated by hairlines (instead of a bordered tile around every value). */
export const DefinitionList: React.FC<DefinitionListProps> = ({ items, columns = 1, className }) => (
  <dl className={cn('grid gap-x-8 text-xs', columns === 2 && 'sm:grid-cols-2', className)}>
    {items.map((item) => (
      <div key={item.label} className="flex items-baseline justify-between gap-4 border-b border-soc-border/60 py-2">
        <dt className="text-soc-textMuted">{item.label}</dt>
        <dd className="text-right font-medium tabular-nums text-slate-100 break-words">{item.value}</dd>
      </div>
    ))}
  </dl>
);
