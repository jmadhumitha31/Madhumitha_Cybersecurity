import React, { useEffect, useId, useRef } from 'react';
import { createPortal } from 'react-dom';
import { X, type LucideIcon } from 'lucide-react';
import { cn } from '../../lib/cn';
import { IconButton } from './Button';

const FOCUSABLE = 'a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  icon?: LucideIcon;
  /** `right` renders a full-height drawer (the trace inspector); `top` sits near the top edge (command palette). */
  placement?: 'center' | 'right' | 'top';
  /** The drawer brings its own header; the title then only labels the dialog for assistive tech. */
  hideHeader?: boolean;
  footer?: React.ReactNode;
  /** Set false when the content supplies its own padding (the command palette). */
  padded?: boolean;
  children: React.ReactNode;
  className?: string;
}

/**
 * Accessible dialog: role=dialog + aria-modal, labelled by its title, closes on Escape or a backdrop click, traps Tab
 * inside, moves focus in on open (to `[data-autofocus]` if present) and gives it back to the opener on close.
 */
export const Modal: React.FC<ModalProps> = ({
  open,
  onClose,
  title,
  icon: Icon,
  placement = 'center',
  hideHeader,
  footer,
  padded = true,
  children,
  className,
}) => {
  const panelRef = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose);
  const titleId = useId();

  useEffect(() => {
    onCloseRef.current = onClose;
  }, [onClose]);

  useEffect(() => {
    if (!open) return;
    const opener = document.activeElement as HTMLElement | null;
    const panel = panelRef.current;
    const focusable = () =>
      panel ? Array.from(panel.querySelectorAll<HTMLElement>(FOCUSABLE)).filter((el) => !el.hasAttribute('disabled') && el.offsetParent !== null) : [];

    (panel?.querySelector<HTMLElement>('[data-autofocus]') ?? focusable()[0] ?? panel)?.focus();

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onCloseRef.current();
        return;
      }
      if (e.key !== 'Tab' || !panel) return;
      const items = focusable();
      if (items.length === 0) {
        e.preventDefault();
        return;
      }
      const first = items[0];
      const last = items[items.length - 1];
      const active = document.activeElement;
      if (!panel.contains(active) || (e.shiftKey && active === first)) {
        e.preventDefault();
        (e.shiftKey ? last : first).focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      opener?.focus?.();
    };
  }, [open]);

  if (!open) return null;

  const drawer = placement === 'right';
  return createPortal(
    <div
      className={cn(
        'fixed inset-0 z-50 flex animate-fade-in',
        drawer ? 'justify-end' : placement === 'top' ? 'items-start justify-center p-4 pt-[12vh]' : 'items-center justify-center p-4',
      )}
    >
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} aria-hidden />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className={cn(
          'relative flex flex-col shadow-2xl',
          drawer
            ? 'h-full w-full overflow-y-auto border-l border-soc-border bg-soc-dark p-5 lg:w-[72%] xl:w-[64%]'
            : 'max-h-[calc(100dvh-2rem)] w-full max-w-md animate-pop-in rounded-xl border border-soc-border bg-soc-surface',
          className,
        )}
      >
        {hideHeader ? (
          <h2 id={titleId} className="sr-only">
            {title}
          </h2>
        ) : (
          <div className="flex items-center justify-between gap-3 border-b border-soc-border px-5 py-4">
            <div className="flex items-center gap-2.5">
              {Icon && <Icon className="h-4 w-4 text-cyan-400" aria-hidden />}
              <h2 id={titleId} className="text-sm font-semibold text-slate-50">
                {title}
              </h2>
            </div>
            <IconButton label="Close dialog" icon={X} onClick={onClose} />
          </div>
        )}
        <div className={cn(!drawer && 'overflow-y-auto', !drawer && padded && 'p-5')}>{children}</div>
        {footer && <div className="flex items-center justify-end gap-3 border-t border-soc-border px-5 py-4">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
};
