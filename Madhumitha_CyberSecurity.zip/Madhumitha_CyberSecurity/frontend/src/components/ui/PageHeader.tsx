import React from 'react';
import { routeFor } from '../../lib/routes';
import { usePageTitle } from '../../lib/usePageTitle';
import type { LucideIcon } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  description?: React.ReactNode;
  icon?: LucideIcon;
  actions?: React.ReactNode;
}

/** The page's single <h1>. Also sets the browser tab title. */
export const PageHeader: React.FC<PageHeaderProps> = ({ title, description, icon: Icon, actions }) => {
  usePageTitle(title);
  return (
    <header className="flex flex-wrap items-start justify-between gap-x-6 gap-y-3">
      <div className="min-w-0">
        <h1 className="flex items-center gap-2.5 text-xl font-semibold tracking-tight text-slate-50">
          {Icon && <Icon className="h-5 w-5 shrink-0 text-cyan-400" aria-hidden />}
          {title}
        </h1>
        {description && <p className="mt-1 max-w-3xl text-sm text-soc-textMuted">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </header>
  );
};

/** Header whose title, icon and default description come from the route table, i.e. exactly what the sidebar shows. */
export const RoutePageHeader: React.FC<{ path: string; description?: React.ReactNode; actions?: React.ReactNode }> = ({
  path,
  description,
  actions,
}) => {
  const route = routeFor(path);
  return <PageHeader title={route.title} icon={route.icon} description={description ?? route.description} actions={actions} />;
};
