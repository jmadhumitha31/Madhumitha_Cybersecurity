import React from 'react';
import { cn } from '../../lib/cn';

interface SwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
  className?: string;
}

/** On/off toggle (role=switch) with a visible label and state. */
export const Switch: React.FC<SwitchProps> = ({ checked, onChange, label, className }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    onClick={() => onChange(!checked)}
    className={cn('inline-flex items-center gap-2 rounded-md text-xs font-medium text-slate-300 transition-colors hover:text-white', className)}
  >
    <span aria-hidden className={cn('relative h-5 w-9 shrink-0 rounded-full border transition-colors', checked ? 'border-cyan-500 bg-cyan-700' : 'border-soc-borderLight bg-soc-card')}>
      <span className={cn('absolute top-0.5 h-3.5 w-3.5 rounded-full bg-white transition-all', checked ? 'left-[1.1rem]' : 'left-0.5')} />
    </span>
    <span>
      {label}: <span className={checked ? 'text-cyan-200' : 'text-slate-400'}>{checked ? 'on' : 'off'}</span>
    </span>
  </button>
);
