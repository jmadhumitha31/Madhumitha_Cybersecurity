import React from 'react';
import { useNavigate } from 'react-router-dom';
import { cn } from '../../lib/cn';

/**
 * Table primitives. One header treatment, one cell padding, sticky headers inside a scroll container, numeric columns
 * right-aligned with tabular figures, and rows that are reachable and activatable from the keyboard.
 */
export const TableWrap: React.FC<{ children: React.ReactNode; maxHeight?: string; className?: string }> = ({ children, maxHeight, className }) => (
  <div className={cn('overflow-auto rounded-lg', className)} style={maxHeight ? { maxHeight } : undefined}>
    {children}
  </div>
);

export const Table: React.FC<{ children: React.ReactNode; className?: string; caption?: string }> = ({ children, className, caption }) => (
  <table className={cn('w-full border-separate border-spacing-0 text-left text-xs', className)}>
    {caption && <caption className="sr-only">{caption}</caption>}
    {children}
  </table>
);

interface CellProps extends React.TdHTMLAttributes<HTMLTableCellElement> {
  /** Right-align and use tabular figures (numbers, durations, scores). */
  numeric?: boolean;
  /** Monospace for identifiers (IPs, flow ids, hashes) only. */
  mono?: boolean;
}

export const Th: React.FC<Omit<CellProps, 'mono'> & { children?: React.ReactNode }> = ({ children, numeric, className, ...rest }) => (
  <th
    scope="col"
    className={cn(
      'sticky top-0 z-[1] whitespace-nowrap border-b border-soc-border bg-soc-surface px-3 py-2.5',
      'text-2xs font-semibold uppercase tracking-wider text-soc-textMuted',
      numeric && 'text-right',
      className,
    )}
    {...rest}
  >
    {children}
  </th>
);

export const Td: React.FC<CellProps> = ({ children, numeric, mono, className, ...rest }) => (
  <td
    className={cn('border-b border-soc-border/60 px-3 py-2.5 align-middle', numeric && 'text-right tabular-nums', mono && 'font-mono', className)}
    {...rest}
  >
    {children}
  </td>
);

interface RowProps {
  children: React.ReactNode;
  /** Navigate here on click / Enter / Space. */
  to?: string;
  onActivate?: () => void;
  selected?: boolean;
  className?: string;
}

export const Tr: React.FC<RowProps> = ({ children, to, onActivate, selected, className }) => {
  const navigate = useNavigate();
  const interactive = Boolean(to || onActivate);
  const activate = () => {
    if (onActivate) onActivate();
    else if (to) navigate(to);
  };
  return (
    <tr
      tabIndex={interactive ? 0 : undefined}
      onClick={interactive ? activate : undefined}
      onKeyDown={
        interactive
          ? (e) => {
              if (e.target !== e.currentTarget) return;
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                activate();
              }
            }
          : undefined
      }
      className={cn(
        interactive && 'cursor-pointer transition-colors hover:bg-soc-card/70 focus-visible:bg-soc-card/70 focus-visible:-outline-offset-2',
        selected && 'bg-cyan-950/30',
        className,
      )}
    >
      {children}
    </tr>
  );
};
