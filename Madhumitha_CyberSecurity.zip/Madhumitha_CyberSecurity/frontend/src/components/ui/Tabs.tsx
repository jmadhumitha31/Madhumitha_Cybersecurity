import React from 'react';
import { cn } from '../../lib/cn';

export interface TabItem<T extends string> {
  id: T;
  label: string;
  count?: number;
}

interface TabsProps<T extends string> {
  tabs: TabItem<T>[];
  value: T;
  onChange: (id: T) => void;
  /** Prefix for the generated ids that link each tab to its panel. */
  idPrefix: string;
  label: string;
}

/** The one tab style (underline). Roving tabindex + Arrow/Home/End keys per the WAI-ARIA tabs pattern. */
export function Tabs<T extends string>({ tabs, value, onChange, idPrefix, label }: TabsProps<T>) {
  const onKeyDown = (e: React.KeyboardEvent) => {
    const index = tabs.findIndex((t) => t.id === value);
    let next = index;
    if (e.key === 'ArrowRight') next = (index + 1) % tabs.length;
    else if (e.key === 'ArrowLeft') next = (index - 1 + tabs.length) % tabs.length;
    else if (e.key === 'Home') next = 0;
    else if (e.key === 'End') next = tabs.length - 1;
    else return;
    e.preventDefault();
    onChange(tabs[next].id);
    document.getElementById(`${idPrefix}-tab-${tabs[next].id}`)?.focus();
  };

  return (
    // Wraps instead of scrolling: `overflow-x-auto` also forces a vertical scrollbar (the active underline overlaps the border by 1px).
    <div role="tablist" aria-label={label} onKeyDown={onKeyDown} className="flex flex-wrap gap-1 border-b border-soc-border">
      {tabs.map((t) => {
        const selected = t.id === value;
        return (
          <button
            key={t.id}
            type="button"
            role="tab"
            id={`${idPrefix}-tab-${t.id}`}
            aria-selected={selected}
            aria-controls={`${idPrefix}-panel-${t.id}`}
            tabIndex={selected ? 0 : -1}
            onClick={() => onChange(t.id)}
            className={cn(
              '-mb-px whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors',
              selected ? 'border-cyan-400 text-cyan-200' : 'border-transparent text-slate-400 hover:text-slate-100',
            )}
          >
            {t.label}
            {t.count !== undefined && <span className="ml-2 rounded-full bg-soc-card px-1.5 py-0.5 text-2xs tabular-nums text-slate-300">{t.count}</span>}
          </button>
        );
      })}
    </div>
  );
}

/** Content of one tab; renders nothing unless it is the active one. */
export const TabPanel: React.FC<{ idPrefix: string; id: string; active: boolean; children: React.ReactNode; className?: string }> = ({
  idPrefix,
  id,
  active,
  children,
  className,
}) =>
  active ? (
    <div role="tabpanel" id={`${idPrefix}-panel-${id}`} aria-labelledby={`${idPrefix}-tab-${id}`} className={className}>
      {children}
    </div>
  ) : null;

interface SegmentedProps<T extends string> {
  options: { id: T; label: string }[];
  value: T;
  onChange: (id: T) => void;
  label: string;
}

/** Compact single-choice toggle (time windows, view modes). */
export function Segmented<T extends string>({ options, value, onChange, label }: SegmentedProps<T>) {
  return (
    <div role="group" aria-label={label} className="inline-flex rounded-md border border-soc-border bg-soc-card p-0.5">
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          aria-pressed={o.id === value}
          onClick={() => onChange(o.id)}
          className={cn(
            'rounded px-2.5 py-1 text-xs font-medium transition-colors',
            o.id === value ? 'bg-cyan-700 text-white' : 'text-slate-300 hover:bg-soc-raised hover:text-white',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
