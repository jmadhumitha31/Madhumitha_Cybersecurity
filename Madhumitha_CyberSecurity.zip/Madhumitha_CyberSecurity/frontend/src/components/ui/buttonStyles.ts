import { cn } from '../../lib/cn';

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md';

// cyan-700 + white is 5.4:1 (the old cyan-600 was 3.7:1, below WCAG AA for small text).
const VARIANT: Record<ButtonVariant, string> = {
  primary: 'bg-cyan-700 text-white border border-transparent hover:bg-cyan-600 active:bg-cyan-800',
  secondary: 'bg-soc-card text-slate-100 border border-soc-border hover:border-soc-borderLight hover:bg-soc-raised',
  ghost: 'bg-transparent text-slate-300 border border-transparent hover:bg-soc-card hover:text-white',
  danger: 'bg-transparent text-red-300 border border-red-900 hover:bg-red-950/50 hover:text-red-200',
};

// Two sizes only. Every control in a toolbar shares a height, so rows line up.
const SIZE: Record<ButtonSize, string> = {
  sm: 'h-8 px-3 text-xs gap-1.5',
  md: 'h-9 px-4 text-sm gap-2',
};

/** Class string for anything that should look like a button (e.g. a router <Link>). */
export const buttonClasses = (variant: ButtonVariant = 'secondary', size: ButtonSize = 'md'): string =>
  cn(
    'inline-flex shrink-0 items-center justify-center rounded-md font-medium whitespace-nowrap transition-colors',
    'disabled:cursor-not-allowed disabled:opacity-50',
    VARIANT[variant],
    SIZE[size],
  );
