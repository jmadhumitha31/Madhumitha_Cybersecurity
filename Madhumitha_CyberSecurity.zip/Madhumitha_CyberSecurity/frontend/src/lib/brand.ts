/** One product name, used by the sidebar, login screen, page titles and the copilot. */
export const BRAND = {
  name: 'SOC Sentinel',
  tagline: 'AI incident response',
  copilot: 'SOC Copilot',
} as const;
