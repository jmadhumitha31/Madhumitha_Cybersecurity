import type { CSSProperties } from 'react';

/** One palette and one set of axis / tooltip props for every Recharts chart (each page used to hard-code its own). */
export const CHART = {
  primary: '#22d3ee',
  secondary: '#a78bfa',
  warm: '#f59e0b',
  positive: '#34d399',
  negative: '#f87171',
  grid: '#263149',
  axis: '#94a3b8',
  axisLine: '#384a6b',
} as const;

export const SEVERITY_COLORS: Record<string, string> = {
  Critical: '#ef4444',
  High: '#f97316',
  Medium: '#eab308',
  Low: '#10b981',
};

const tick = { fill: CHART.axis, fontSize: 11 };

/** Spread onto <XAxis> / <YAxis>. */
export const axisProps = {
  stroke: CHART.axisLine,
  tick,
  tickLine: false,
} as const;

const contentStyle: CSSProperties = {
  backgroundColor: '#222d44',
  border: '1px solid #384a6b',
  borderRadius: 8,
  fontSize: 12,
  color: '#e2e8f0',
  boxShadow: '0 8px 24px rgb(0 0 0 / 0.4)',
};

/** Spread onto <Tooltip>. */
export const tooltipProps = {
  contentStyle,
  labelStyle: { color: '#f1f5f9', fontWeight: 600, marginBottom: 4 } as CSSProperties,
  itemStyle: { color: '#e2e8f0' } as CSSProperties,
  cursor: { fill: 'rgb(148 163 184 / 0.08)' },
} as const;

/** "DDoS (1,204), Port Scan (880), ..." for chart aria-labels: the few biggest values, as text. */
export const topSummary = <T,>(items: T[], name: (i: T) => string, value: (i: T) => number, n = 3): string =>
  [...items]
    .sort((a, b) => value(b) - value(a))
    .slice(0, n)
    .map((i) => `${name(i)} (${value(i).toLocaleString()})`)
    .join(', ');

/** Spread onto <Legend>. */
export const legendProps = {
  wrapperStyle: { fontSize: 12, color: CHART.axis } as CSSProperties,
} as const;
