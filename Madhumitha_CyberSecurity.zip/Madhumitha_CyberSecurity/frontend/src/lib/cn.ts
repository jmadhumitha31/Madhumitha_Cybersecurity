import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** Merge class names, letting later Tailwind utilities override earlier ones (so `className` props can customise). */
export const cn = (...inputs: ClassValue[]): string => twMerge(clsx(inputs));
