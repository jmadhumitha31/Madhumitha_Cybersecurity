import type { SystemHealthData } from '../types';
import { shortModel } from './format';

export type EngineTone = 'ok' | 'warn' | 'off' | 'unknown';

export interface EngineStatus {
  tone: EngineTone;
  /** Short status word for a badge: "Online", "Degraded", "Offline", "Checking". */
  badge: string;
  /** What is actually answering, e.g. "NVIDIA NIM · llama-3.2-3b-instruct". */
  label: string;
}

/**
 * What the copilot is really running on, derived from /health instead of being hard-coded in the UI
 * (the chat header used to say "ONLINE" and "LLaMA-3.2" regardless of the backend).
 */
export function describeEngine(health: SystemHealthData | null): EngineStatus {
  if (!health) return { tone: 'unknown', badge: 'Checking', label: 'Checking LLM status...' };
  const aic = health.components?.aicredits_llm;
  if (aic?.configured && aic.status === 'Healthy') {
    return { tone: 'ok', badge: 'Online', label: `AICredits${aic.model ? ` · ${shortModel(aic.model)}` : ''}` };
  }
  const nim = health.components?.nvidia_llm;
  if (nim?.configured && nim.status === 'Healthy') {
    return { tone: 'ok', badge: 'Online', label: `NVIDIA NIM${nim.model ? ` · ${shortModel(nim.model)}` : ''}` };
  }
  if (aic?.configured || nim?.configured) {
    return { tone: 'warn', badge: 'Degraded', label: 'LLM unreachable, falling back' };
  }
  return { tone: 'off', badge: 'Offline mode', label: 'No LLM key: offline playbooks only' };
}

export const ENGINE_DOT: Record<EngineTone, string> = {
  ok: 'bg-emerald-400',
  warn: 'bg-amber-400',
  off: 'bg-slate-400',
  unknown: 'bg-slate-500',
};
