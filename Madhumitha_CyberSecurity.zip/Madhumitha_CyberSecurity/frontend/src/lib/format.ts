import type { IncidentStatus } from '../types';

/** "FALSE_POSITIVE" -> "False positive" (raw enums should never reach the screen). */
export const statusLabel = (s: IncidentStatus | string): string => {
  const text = s.replace(/_/g, ' ').toLowerCase();
  return text.charAt(0).toUpperCase() + text.slice(1);
};

export const protoName = (p: number): string => (p === 6 ? 'TCP' : p === 17 ? 'UDP' : p === 1 ? 'ICMP' : String(p));

/** Ratio (0..1) as a percentage; "N/A" when the value is genuinely missing (never a made-up default). */
export const pct = (v: number | null | undefined, digits = 1): string =>
  v === null || v === undefined || Number.isNaN(v) ? 'N/A' : `${(v * 100).toFixed(digits)}%`;

/** Plain number or "N/A". */
export const num = (v: number | null | undefined, digits = 1): string =>
  v === null || v === undefined || Number.isNaN(v) ? 'N/A' : Number(v).toLocaleString(undefined, { maximumFractionDigits: digits });

export const fixed = (v: number | null | undefined, digits = 3): string =>
  v === null || v === undefined || Number.isNaN(v) ? 'N/A' : v.toFixed(digits);

/** Compact human number for chart ticks and contribution values. */
export const compact = (v: number): string => {
  if (Math.abs(v) >= 1e6) return `${(v / 1e6).toFixed(2)}M`;
  if (Math.abs(v) >= 1e4) return `${(v / 1e3).toFixed(1)}k`;
  return Number.isInteger(v) ? v.toLocaleString() : v.toFixed(2);
};

/** ISO timestamp -> "2017-07-05 09:12:41 UTC". */
export const utcStamp = (iso?: string | null): string =>
  iso ? `${new Date(iso).toISOString().replace('T', ' ').slice(0, 19)} UTC` : '';

/** "meta/llama-3.2-3b-instruct" -> "llama-3.2-3b-instruct". */
export const shortModel = (name?: string | null): string => (name ? name.split('/').pop() || name : '');

/** Human name for an LLM provider id as reported by the API. */
export const providerLabel = (provider?: string | null): string => {
  if (!provider) return '';
  if (provider === 'heuristic_rule_engine') return 'Offline rule engine';
  if (provider.toLowerCase() === 'nvidia') return 'NVIDIA NIM';
  if (provider.toLowerCase() === 'aicredits') return 'AICredits';
  return provider.charAt(0).toUpperCase() + provider.slice(1);
};
