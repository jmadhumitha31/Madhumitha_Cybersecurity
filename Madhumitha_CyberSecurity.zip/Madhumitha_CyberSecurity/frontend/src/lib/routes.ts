import {
  Activity,
  AlertTriangle,
  BarChart3,
  Bot,
  CheckCircle2,
  GitBranch,
  History,
  LayoutDashboard,
  PlusCircle,
  Search,
  Settings,
  type LucideIcon,
} from 'lucide-react';

export type NavGroupId = 'triage' | 'ai' | 'insight';

export interface AppRoute {
  path: string;
  /** Used verbatim as the sidebar label, the page <h1> and the browser tab title, so they can never disagree. */
  title: string;
  description: string;
  icon: LucideIcon;
  group: NavGroupId;
  /** Extra words the command palette matches on. */
  keywords?: string[];
}

export const NAV_GROUPS: { id: NavGroupId; label: string }[] = [
  { id: 'triage', label: 'Triage' },
  { id: 'ai', label: 'AI assistance' },
  { id: 'insight', label: 'Insight & governance' },
];

export const ROUTES: AppRoute[] = [
  {
    path: '/dashboard',
    title: 'Dashboard',
    description: 'Open incidents ranked by risk, with attack, severity and port trends from the stored telemetry.',
    icon: LayoutDashboard,
    group: 'triage',
    keywords: ['overview', 'home', 'queue'],
  },
  {
    path: '/incidents',
    title: 'Incidents',
    description: 'Every stored network flow, filterable by classification, severity, status and label source.',
    icon: AlertTriangle,
    group: 'triage',
    keywords: ['flows', 'alerts', 'repository'],
  },
  {
    path: '/add-incident',
    title: 'Add incident',
    description: 'Submit CIC-IDS2017 flow features. The flow is validated, ML-triaged immediately and indexed for retrieval.',
    icon: PlusCircle,
    group: 'triage',
    keywords: ['ingest', 'create', 'new flow'],
  },
  {
    path: '/chat',
    title: 'SOC Copilot',
    description: 'Ask questions grounded in the labelled incident knowledge base. Every answer shows which model produced it.',
    icon: Bot,
    group: 'ai',
    keywords: ['chat', 'assistant', 'ask'],
  },
  {
    path: '/ai-search',
    title: 'Incident search',
    description: 'Embedding similarity plus BM25 keyword matching over historical incidents, narrowed by metadata filters.',
    icon: Search,
    group: 'ai',
    keywords: ['retrieval', 'rag', 'similar', 'hybrid'],
  },
  {
    path: '/investigation',
    title: 'AI investigation',
    description: 'Detection, analysis (hybrid RAG), risk assessment, response and output validation, run on one incident.',
    icon: GitBranch,
    group: 'ai',
    keywords: ['langgraph', 'agents', 'workflow'],
  },
  {
    path: '/analytics',
    title: 'Analytics',
    description: 'Aggregates over stored incidents, plus the model’s global explanation of what characterises each attack family.',
    icon: BarChart3,
    group: 'insight',
    keywords: ['charts', 'distribution', 'shap'],
  },
  {
    path: '/observability',
    title: 'Traces & explainability',
    description: 'Every analyst query leaves a trace: what each component decided, how long it took and why the system answered as it did.',
    icon: Activity,
    group: 'insight',
    keywords: ['observability', 'logs', 'latency', 'spans'],
  },
  {
    path: '/evaluation',
    title: 'Evaluation',
    description: 'Every number comes from a real run. If a judge LLM or dataset is unavailable, the card says so instead of showing a score.',
    icon: CheckCircle2,
    group: 'insight',
    keywords: ['metrics', 'deepeval', 'judge', 'accuracy'],
  },
  {
    path: '/history',
    title: 'Feedback & audit',
    description: 'Analyst verdicts relabel incidents, enter the knowledge base immediately and are folded into the next model retraining.',
    icon: History,
    group: 'insight',
    keywords: ['retrain', 'audit log', 'verdicts'],
  },
  {
    path: '/settings',
    title: 'System status',
    description: 'Everything below is read from the running backend: nothing on this page is static text.',
    icon: Settings,
    group: 'insight',
    keywords: ['health', 'settings', 'diagnostics', 'models'],
  },
];

export const routeFor = (path: string): AppRoute => {
  const found = ROUTES.find((r) => r.path === path);
  if (!found) throw new Error(`Unknown route ${path}`);
  return found;
};
