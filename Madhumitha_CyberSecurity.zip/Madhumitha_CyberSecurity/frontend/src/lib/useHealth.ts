import { useEffect, useSyncExternalStore } from 'react';
import { healthService } from '../services/mlService';
import { SystemHealthData } from '../types';

/**
 * Shared, cached view of GET /health. The sidebar, the data-source banner, the chat pages and the copilot launcher
 * all need it; they used to fire one request each on every mount.
 */
interface HealthState {
  data: SystemHealthData | null;
  error: string | null;
  loading: boolean;
  loadedAt: number;
}

const TTL_MS = 30_000;
let state: HealthState = { data: null, error: null, loading: false, loadedAt: 0 };
let inflight: Promise<void> | null = null;
const listeners = new Set<() => void>();

const publish = (patch: Partial<HealthState>) => {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
};

export function refreshHealth(force = false): Promise<void> {
  if (inflight) return inflight;
  if (!force && state.data && Date.now() - state.loadedAt < TTL_MS) return Promise.resolve();
  publish({ loading: true });
  inflight = healthService
    .get()
    .then((data) => publish({ data, error: null, loadedAt: Date.now(), loading: false }))
    .catch((e: Error) => publish({ error: e.message, loading: false }))
    .finally(() => {
      inflight = null;
    });
  return inflight;
}

/** Called on sign-out so the next session starts from a clean state. */
export function resetHealth(): void {
  publish({ data: null, error: null, loading: false, loadedAt: 0 });
}

const subscribe = (listener: () => void) => {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
};

export function useHealth() {
  const snapshot = useSyncExternalStore(subscribe, () => state);
  useEffect(() => {
    void refreshHealth();
  }, []);
  return {
    health: snapshot.data,
    error: snapshot.error,
    loading: snapshot.loading,
    refresh: () => refreshHealth(true),
  };
}
