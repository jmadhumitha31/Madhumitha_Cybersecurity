import { useEffect } from 'react';
import { BRAND } from './brand';

/** Sets the browser tab title ("Incidents · SOC Sentinel") so tabs and history entries are distinguishable. */
export function usePageTitle(title: string): void {
  useEffect(() => {
    document.title = `${title} · ${BRAND.name}`;
  }, [title]);
}
