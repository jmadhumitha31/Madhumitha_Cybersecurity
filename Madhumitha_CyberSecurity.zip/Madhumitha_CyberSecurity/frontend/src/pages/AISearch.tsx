import React, { useEffect, useId, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Activity, CheckCircle2, MinusCircle, Search, SearchX, SlidersHorizontal } from 'lucide-react';
import { searchService } from '../services/searchService';
import { ATTACK_CLASSES, type SearchResponseData } from '../types';
import { cn } from '../lib/cn';
import { pct, utcStamp } from '../lib/format';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { LoadingSkeleton } from '../components/common/LoadingSkeleton';
import { Alert } from '../components/ui/Alert';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { Input, Select } from '../components/ui/Input';
import { RoutePageHeader } from '../components/ui/PageHeader';

const EXAMPLES = [
  'credential guessing against remote shell',
  'denial of service flooding a web server',
  'reconnaissance probing many ports',
  'SQL injection against a web application',
  'bot beaconing to command and control',
];

const StrategyChip: React.FC<{ on: boolean; text: string }> = ({ on, text }) => (
  <span
    className={cn(
      'inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs',
      on ? 'border-emerald-800 bg-emerald-950/50 text-emerald-300' : 'border-soc-border bg-soc-card text-slate-400',
    )}
  >
    {on ? <CheckCircle2 className="h-3.5 w-3.5" aria-label="Applied" /> : <MinusCircle className="h-3.5 w-3.5" aria-label="Not applied" />}
    {text}
  </span>
);

interface SearchViewProps {
  initialQuery: string;
}

const SearchView: React.FC<SearchViewProps> = ({ initialQuery }) => {
  const [query, setQuery] = useState(initialQuery);
  const [searchType, setSearchType] = useState<'hybrid' | 'semantic' | 'keyword'>('hybrid');
  const [threshold, setThreshold] = useState(0.2);
  const [topK, setTopK] = useState(8);
  const [showFilters, setShowFilters] = useState(false);
  const [f, setF] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(Boolean(initialQuery));
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<SearchResponseData | null>(null);
  const sliderId = useId();

  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));
  const activeFilters = Object.values(f).filter((v) => v.trim() !== '').length;

  const execute = (text: string) => {
    const filters: Record<string, unknown> = {};
    if (f.attack_type) filters.attack_type = f.attack_type;
    if (f.protocol) filters.protocol = parseInt(f.protocol);
    if (f.source_ip?.trim()) filters.source_ip = f.source_ip.trim();
    if (f.destination_ip?.trim()) filters.destination_ip = f.destination_ip.trim();
    if (f.source_port) filters.source_port = parseInt(f.source_port);
    if (f.destination_port) filters.destination_port = parseInt(f.destination_port);
    if (f.start_time) filters.start_time = new Date(f.start_time).toISOString();
    if (f.end_time) filters.end_time = new Date(f.end_time).toISOString();
    if (f.min_confidence) filters.min_confidence = parseFloat(f.min_confidence) / 100;
    return searchService.search({
      query: text.trim() || undefined,
      search_type: searchType,
      filters: Object.keys(filters).length ? filters : undefined,
      top_k: topK,
      similarity_threshold: threshold,
    });
  };

  // Arriving from the command palette (?q=...) runs the search straight away.
  useEffect(() => {
    if (!initialQuery) return;
    let alive = true;
    execute(initialQuery)
      .then((res) => alive && setData(res))
      .catch((err: Error) => alive && setError(err.message))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
    // Runs once per mount: the page is re-keyed when the ?q= value changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSearch = async (e?: React.FormEvent, override?: string) => {
    e?.preventDefault();
    setLoading(true);
    setError(null);
    try {
      setData(await execute(override ?? query));
    } catch (err) {
      setData(null);
      setError(err instanceof Error ? err.message : 'Search failed');
    } finally {
      setLoading(false);
    }
  };

  const s = data?.search_strategy;

  return (
    <div className="space-y-6">
      <RoutePageHeader path="/ai-search" />

      <Card>
        <form onSubmit={handleSearch} role="search" className="space-y-4">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
            <Input
              label="Describe an attack or traffic pattern"
              icon={Search}
              type="search"
              className="flex-1"
              placeholder="e.g. credential guessing against remote shell"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              autoFocus={!initialQuery}
            />
            <Button type="submit" variant="primary" loading={loading}>
              {loading ? 'Searching…' : 'Search'}
            </Button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-soc-textMuted">Try:</span>
            {EXAMPLES.map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => {
                  setQuery(ex);
                  void handleSearch(undefined, ex);
                }}
                className="rounded-full border border-soc-border bg-soc-card px-3 py-1 text-xs text-slate-300 transition-colors hover:border-cyan-700 hover:text-cyan-200"
              >
                {ex}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 items-end gap-4 border-t border-soc-border pt-4 md:grid-cols-4">
            <Select label="Search mode" value={searchType} onChange={(e) => setSearchType(e.target.value as typeof searchType)}>
              <option value="hybrid">Hybrid (semantic + BM25)</option>
              <option value="semantic">Semantic only</option>
              <option value="keyword">Keyword (BM25) only</option>
            </Select>
            <div>
              <label htmlFor={sliderId} className="mb-1.5 block text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">
                Minimum score: <span className="tabular-nums text-slate-200">{(threshold * 100).toFixed(0)}%</span>
              </label>
              <input id={sliderId} type="range" min="0" max="0.9" step="0.05" value={threshold} onChange={(e) => setThreshold(parseFloat(e.target.value))} className="h-9 w-full cursor-pointer accent-cyan-500" />
            </div>
            <Select label="Results (top-K)" value={topK} onChange={(e) => setTopK(parseInt(e.target.value))}>
              {[5, 8, 15, 25, 50].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </Select>
            <Button icon={SlidersHorizontal} aria-expanded={showFilters} onClick={() => setShowFilters((v) => !v)}>
              Metadata filters{activeFilters > 0 ? ` (${activeFilters})` : ''}
            </Button>
          </div>

          {showFilters && (
            <div className="grid grid-cols-1 gap-4 border-t border-soc-border pt-4 sm:grid-cols-2 lg:grid-cols-4">
              <Select label="Attack type" value={f.attack_type || ''} onChange={(e) => set('attack_type', e.target.value)}>
                <option value="">Any</option>
                {ATTACK_CLASSES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </Select>
              <Select label="Protocol" value={f.protocol || ''} onChange={(e) => set('protocol', e.target.value)}>
                <option value="">Any</option>
                <option value="6">TCP (6)</option>
                <option value="17">UDP (17)</option>
                <option value="1">ICMP (1)</option>
              </Select>
              <Input label="Source IP" placeholder="172.16.0.1" value={f.source_ip || ''} onChange={(e) => set('source_ip', e.target.value)} />
              <Input label="Destination IP" placeholder="192.168.10.50" value={f.destination_ip || ''} onChange={(e) => set('destination_ip', e.target.value)} />
              <Input label="Source port" type="number" min={0} max={65535} value={f.source_port || ''} onChange={(e) => set('source_port', e.target.value)} />
              <Input label="Destination port" type="number" min={0} max={65535} placeholder="80, 22, 445" value={f.destination_port || ''} onChange={(e) => set('destination_port', e.target.value)} />
              <Input label="From (UTC)" type="datetime-local" value={f.start_time || ''} onChange={(e) => set('start_time', e.target.value)} />
              <Input label="To (UTC)" type="datetime-local" value={f.end_time || ''} onChange={(e) => set('end_time', e.target.value)} />
              <Input label="Min model confidence %" type="number" min={0} max={100} value={f.min_confidence || ''} onChange={(e) => set('min_confidence', e.target.value)} />
              <div className="flex items-end sm:col-span-2 lg:col-span-3">
                <Button variant="ghost" onClick={() => setF({})} disabled={activeFilters === 0}>
                  Clear filters
                </Button>
              </div>
            </div>
          )}
        </form>
      </Card>

      {error && <Alert variant="error" title="Search failed">{error}</Alert>}

      {data && s && (
        <div className="flex flex-wrap items-center gap-3 rounded-xl border border-soc-border bg-soc-surface px-4 py-3 text-xs">
          <span className="font-semibold text-soc-textMuted">Applied</span>
          <StrategyChip on={s.semantic_search} text={`Semantic (${s.embedding_backend === 'fastembed' ? 'MiniLM embeddings' : s.embedding_backend})`} />
          <StrategyChip on={s.keyword_search} text="BM25 keyword" />
          <StrategyChip on={s.metadata_filtering} text={`Metadata filters (${Object.keys(data.filters_applied).length})`} />
          <span className="ml-auto tabular-nums text-slate-300">
            {data.total_matches} match{data.total_matches === 1 ? '' : 'es'}
            {data.similarity_threshold_used != null && ` ≥ ${(data.similarity_threshold_used * 100).toFixed(0)}%`}
            {s.indexed_documents != null && ` of ${s.indexed_documents.toLocaleString()} indexed`}
          </span>
          {data.trace_id && (
            <Link to={`/observability?trace=${data.trace_id}`} className="inline-flex items-center gap-1 text-cyan-300 hover:underline" title="Open the full trace of this query">
              <Activity className="h-3.5 w-3.5" aria-hidden />
              Trace {data.trace_id.slice(0, 8)}
            </Link>
          )}
        </div>
      )}

      {loading ? (
        <LoadingSkeleton rows={4} height="h-24" />
      ) : data && data.results.length === 0 ? (
        <Card>
          <EmptyState icon={SearchX} title="No similar incidents found" description={data.message || 'Nothing cleared the similarity threshold. Lower the minimum score or rephrase the query.'} />
        </Card>
      ) : data ? (
        <ul className="space-y-3">
          {data.results.map((item) => (
            // The whole card is clickable through the stretched title link; "Why this result?" sits above it.
            <li key={item.incident_id} className="relative rounded-xl border border-soc-border bg-soc-surface p-4 transition-colors focus-within:border-soc-borderLight hover:border-soc-borderLight">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2.5">
                  <Link to={`/incidents/${item.incident_id}`} className="font-mono text-sm font-semibold text-cyan-300 after:absolute after:inset-0 after:content-[''] hover:text-cyan-200">
                    #{item.incident_id}
                  </Link>
                  <span className="font-semibold text-slate-100">{item.attack_type}</span>
                  <SeverityBadge level={item.risk_level} priority={item.priority} />
                  {item.label_source && <Badge variant="neutral">{item.label_source}</Badge>}
                </div>
                {data.search_type_used !== 'metadata' && (
                  <div className="flex items-center gap-2 text-xs tabular-nums">
                    <Badge variant="cyan" size="md">
                      Score {pct(item.hybrid_score, 1)}
                    </Badge>
                    <span className="text-soc-textMuted">semantic {pct(item.semantic_score, 1)}</span>
                    <span className="text-soc-textMuted">BM25 {pct(item.keyword_score, 1)}</span>
                  </div>
                )}
              </div>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-soc-border pt-3 text-xs text-soc-textMuted">
                <span className="font-mono">
                  {item.source_ip} → {item.destination_ip}:{item.destination_port} (proto {item.protocol}){item.timestamp ? ` · ${utcStamp(item.timestamp)}` : ''}
                </span>
                <span className="text-slate-300">{item.shared_characteristics.join(' · ')}</span>
              </div>
              {item.explanation && data.search_type_used !== 'metadata' && (
                <details className="relative z-10 mt-3 text-xs">
                  <summary className="cursor-pointer select-none text-soc-textMuted hover:text-cyan-300">Why this result?</summary>
                  <div className="mt-2 space-y-2 rounded-lg bg-soc-darkest/60 p-3">
                    <p className="font-mono text-slate-300">{item.explanation.formula}</p>
                    {item.explanation.matched_terms.length > 0 ? (
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-soc-textMuted">Terms that earned the BM25 score:</span>
                        {item.explanation.matched_terms.map((t) => (
                          <span key={t.term} className="rounded border border-amber-800/40 bg-amber-950/40 px-1.5 py-0.5 text-amber-300" title={`appears ${t.tf}× in this incident · idf ${t.idf}`}>
                            {t.term} +{(t.contribution * 100).toFixed(0)}%
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-soc-textMuted">No query term matched literally: this hit comes from embedding similarity alone.</p>
                    )}
                  </div>
                </details>
              )}
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
};

/** Re-keyed on ?q=, so following a palette search link while already on this page starts a fresh search. */
export const AISearch: React.FC = () => {
  const [params] = useSearchParams();
  const q = params.get('q') ?? '';
  return <SearchView key={q} initialQuery={q} />;
};
