import React, { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Eye, Lock, RotateCcw, Zap } from 'lucide-react';
import { incidentService } from '../services/incidentService';
import { authService } from '../services/authService';
import { SAMPLE_FLOWS } from '../data/sampleFlows';
import type { AttackPrediction, RiskAssessment } from '../types';
import { cn } from '../lib/cn';
import { pct } from '../lib/format';
import { Card } from '../components/common/Card';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { Alert } from '../components/ui/Alert';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { Input, Select } from '../components/ui/Input';
import { DefinitionList } from '../components/ui/Metric';
import { RoutePageHeader } from '../components/ui/PageHeader';

type FormState = Record<string, string | number>;

const IDENTITY = [
  { key: 'source_ip', label: 'Source IP', type: 'text', placeholder: '172.16.0.1' },
  { key: 'source_port', label: 'Source port', type: 'number' },
  { key: 'destination_ip', label: 'Destination IP', type: 'text', placeholder: '192.168.10.50' },
  { key: 'destination_port', label: 'Destination port', type: 'number' },
];
const METRIC_GROUPS: { title: string; fields: { key: string; label: string }[] }[] = [
  {
    title: '2. Duration, volume & rate',
    fields: [
      { key: 'flow_duration', label: 'Flow duration (µs)' },
      { key: 'total_fwd_packets', label: 'Total forward packets' },
      { key: 'total_bwd_packets', label: 'Total backward packets' },
      { key: 'total_length_fwd', label: 'Total length fwd (B)' },
      { key: 'total_length_bwd', label: 'Total length bwd (B)' },
      { key: 'flow_bytes_per_sec', label: 'Flow bytes / s' },
      { key: 'flow_packets_per_sec', label: 'Flow packets / s' },
    ],
  },
  {
    title: '3. Timing, flags & packet size',
    fields: [
      { key: 'flow_iat_mean', label: 'Flow IAT mean (µs)' },
      { key: 'packet_length_mean', label: 'Packet length mean (B)' },
      { key: 'average_packet_size', label: 'Average packet size (B)' },
      { key: 'active_mean', label: 'Active mean (µs)' },
      { key: 'idle_mean', label: 'Idle mean (µs)' },
      { key: 'syn_count', label: 'SYN flag count' },
      { key: 'rst_count', label: 'RST flag count' },
      { key: 'ack_count', label: 'ACK flag count' },
    ],
  },
];
const METRIC_KEYS = METRIC_GROUPS.flatMap((g) => g.fields.map((f) => f.key));
const NUMERIC_KEYS = [...IDENTITY.filter((f) => f.type === 'number').map((f) => f.key), 'protocol', ...METRIC_KEYS];

const EMPTY: FormState = {
  source_ip: '',
  source_port: 0,
  destination_ip: '',
  destination_port: 0,
  protocol: 6,
  ...Object.fromEntries(METRIC_KEYS.map((k) => [k, 0])),
};

// Class colour dots on the presets (the name is always printed next to it).
const PRESET_DOT: Record<string, string> = {
  Benign: 'bg-emerald-400',
  DDoS: 'bg-red-400',
  DoS: 'bg-red-400',
  'Port Scan': 'bg-yellow-400',
  'FTP/SSH Brute Force': 'bg-orange-400',
  'Web Attack': 'bg-orange-400',
  Botnet: 'bg-purple-400',
  Infiltration: 'bg-red-400',
  Heartbleed: 'bg-red-400',
};

const IPV4 = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;
const isIp = (v: string) => IPV4.test(v) || (v.includes(':') && /^[0-9a-f:.]+$/i.test(v));

/** Client-side checks so obvious mistakes are caught next to the field; the API still validates authoritatively. */
const validate = (f: FormState): Record<string, string> => {
  const errors: Record<string, string> = {};
  (['source_ip', 'destination_ip'] as const).forEach((k) => {
    const v = String(f[k]).trim();
    if (!v) errors[k] = 'Required';
    else if (!isIp(v)) errors[k] = 'Enter a valid IPv4 or IPv6 address';
  });
  (['source_port', 'destination_port'] as const).forEach((k) => {
    const n = Number(f[k]);
    if (!Number.isInteger(n) || n < 0 || n > 65535) errors[k] = 'Whole number from 0 to 65535';
  });
  METRIC_KEYS.forEach((k) => {
    const n = Number(f[k]);
    if (Number.isNaN(n) || n < 0) errors[k] = 'Must be 0 or greater';
  });
  return errors;
};

export const AddIncident: React.FC = () => {
  const navigate = useNavigate();
  const formRef = useRef<HTMLFormElement>(null);
  const [formData, setFormData] = useState<FormState>({ ...EMPTY });
  const [presetLabel, setPresetLabel] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [previewing, setPreviewing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [submitted, setSubmitted] = useState(false);
  const [preview, setPreview] = useState<{ prediction: AttackPrediction; risk: RiskAssessment } | null>(null);

  const errors = validate(formData);
  const errorFor = (key: string) => (submitted || touched[key] ? errors[key] : undefined);

  if (!authService.canWrite()) {
    const role = authService.getStoredUser()?.role;
    return (
      <div className="max-w-5xl space-y-6">
        <RoutePageHeader path="/add-incident" />
        <Card>
          <EmptyState icon={Lock} title="Read-only access" description={`Your role${role ? ` (${role.charAt(0) + role.slice(1).toLowerCase()})` : ''} cannot submit network flows. Ask an analyst or administrator.`} />
        </Card>
      </div>
    );
  }

  const applyPreset = (key: string) => {
    setFormData({ ...EMPTY, ...SAMPLE_FLOWS[key].flow });
    setPresetLabel(key);
    setPreview(null);
    setTouched({});
    setSubmitted(false);
  };

  const reset = () => {
    setFormData({ ...EMPTY });
    setPresetLabel(null);
    setPreview(null);
    setTouched({});
    setSubmitted(false);
    setError(null);
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: NUMERIC_KEYS.includes(field) ? (value === '' ? 0 : Number(value)) : value }));
    setPreview(null);
  };

  // Returns true when the form is valid; otherwise reveals every error and moves focus to the first one.
  const guard = (): boolean => {
    if (Object.keys(errors).length === 0) return true;
    setSubmitted(true);
    requestAnimationFrame(() => formRef.current?.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus());
    return false;
  };

  const handlePreview = async () => {
    if (!guard()) return;
    setPreviewing(true);
    setError(null);
    try {
      setPreview(await incidentService.classifyFlow(formData));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Classification failed');
    } finally {
      setPreviewing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!guard()) return;
    setSubmitting(true);
    setError(null);
    try {
      const created = await incidentService.createIncident(formData as never);
      navigate(`/incidents/${created.id}`);
    } catch (err) {
      setError(err instanceof Error && err.message ? err.message : 'Failed to submit incident');
      setSubmitting(false);
    }
  };

  const numberField = (key: string, label: string, extra?: Partial<React.ComponentProps<typeof Input>>) => (
    <Input
      key={key}
      label={label}
      type="number"
      inputMode="decimal"
      min={0}
      step="any"
      value={formData[key]}
      onChange={(e) => handleChange(key, e.target.value)}
      onFocus={(e) => e.currentTarget.select()}
      onBlur={() => setTouched((t) => ({ ...t, [key]: true }))}
      error={errorFor(key)}
      {...extra}
    />
  );

  return (
    <div className="max-w-5xl space-y-6">
      <RoutePageHeader path="/add-incident" />

      <Card title="Start from a real flow" subtitle="Load a held-out CIC-IDS2017 flow the model never saw in training. The dataset label is shown for reference only and is never sent to the API: the model must classify the telemetry itself.">
        <div className="mb-3 flex items-center gap-2 text-xs text-soc-textMuted">
          <Zap className="h-3.5 w-3.5 text-cyan-400" aria-hidden />
          Presets
        </div>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
          {Object.keys(SAMPLE_FLOWS).map((k) => (
            <button
              key={k}
              type="button"
              aria-pressed={presetLabel === k}
              onClick={() => applyPreset(k)}
              className={cn(
                'rounded-lg border bg-soc-card/60 p-3 text-left transition-colors hover:border-soc-borderLight hover:bg-soc-card',
                presetLabel === k ? 'border-cyan-500 bg-cyan-950/30' : 'border-soc-border',
              )}
            >
              <span className="flex items-center gap-2 text-sm font-semibold text-slate-100">
                <span className={cn('h-2 w-2 rounded-full', PRESET_DOT[k] ?? 'bg-slate-400')} aria-hidden />
                {k}
              </span>
              <span className="mt-1 block text-xs text-soc-textMuted">Dataset label: {SAMPLE_FLOWS[k].originalLabel}</span>
            </button>
          ))}
        </div>
      </Card>

      <form ref={formRef} onSubmit={handleSubmit} noValidate className="space-y-6">
        {error && <Alert variant="error" onDismiss={() => setError(null)}>{error}</Alert>}

        <Card title="1. Network path identity">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            {IDENTITY.map((f) =>
              f.type === 'number' ? (
                numberField(f.key, f.label, { min: 0, max: 65535, step: 1 })
              ) : (
                <Input
                  key={f.key}
                  label={f.label}
                  required
                  placeholder={f.placeholder}
                  autoComplete="off"
                  spellCheck={false}
                  value={formData[f.key]}
                  onChange={(e) => handleChange(f.key, e.target.value)}
                  onBlur={() => setTouched((t) => ({ ...t, [f.key]: true }))}
                  error={errorFor(f.key)}
                />
              ),
            )}
            <Select label="Transport protocol" value={formData.protocol} onChange={(e) => handleChange('protocol', e.target.value)}>
              <option value={6}>6 (TCP)</option>
              <option value={17}>17 (UDP)</option>
              <option value={1}>1 (ICMP)</option>
            </Select>
          </div>
        </Card>

        {METRIC_GROUPS.map((g) => (
          <Card key={g.title} title={g.title}>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">{g.fields.map((f) => numberField(f.key, f.label))}</div>
          </Card>
        ))}

        {preview && (
          <Card
            title="Classification preview"
            subtitle="Not stored: this only shows what the model would say."
            badge={<SeverityBadge level={preview.risk.risk_level} priority={preview.risk.priority} />}
          >
            <DefinitionList
              columns={2}
              items={[
                { label: 'Predicted class', value: `${preview.prediction.attack_type} (${pct(preview.prediction.confidence, 1)})` },
                { label: 'Intrusion probability', value: pct(preview.prediction.intrusion_probability ?? 0, 1) },
                { label: 'Anomaly score', value: (preview.prediction.anomaly_score ?? 0).toFixed(2) },
                { label: 'Risk score', value: preview.risk.risk_score ?? 'N/A' },
              ]}
            />
            {preview.prediction.indicators.length > 0 && (
              <ul className="mt-3 space-y-1 text-sm text-soc-textMuted">
                {preview.prediction.indicators.slice(0, 3).map((i, k) => (
                  <li key={k}>• {i}</li>
                ))}
              </ul>
            )}
          </Card>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3">
          <Button variant="ghost" icon={RotateCcw} onClick={reset}>
            Reset form
          </Button>
          <div className="flex flex-wrap items-center gap-3">
            <Button icon={Eye} loading={previewing} onClick={handlePreview}>
              {previewing ? 'Classifying…' : 'Preview classification'}
            </Button>
            <Button type="submit" variant="primary" loading={submitting}>
              {submitting ? 'Validating & triaging…' : 'Create incident'}
              {!submitting && <ArrowRight className="h-4 w-4" aria-hidden />}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
};
