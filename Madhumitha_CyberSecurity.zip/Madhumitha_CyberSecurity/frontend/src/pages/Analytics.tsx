import React, { useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { analyticsService } from '../services/analyticsService';
import { mlService } from '../services/mlService';
import type { AttackDistributionItem, AttackProfile, PortDistributionItem, ProtocolDistributionItem, SeverityDistributionItem } from '../types';
import { CHART, axisProps, tooltipProps, topSummary } from '../lib/chartTheme';
import { compact } from '../lib/format';
import { Card } from '../components/common/Card';
import { ChartFrame } from '../components/common/ChartFrame';
import { SeverityDonut } from '../components/common/SeverityDonut';
import { Alert } from '../components/ui/Alert';
import { Button } from '../components/ui/Button';
import { Select } from '../components/ui/Input';
import { RoutePageHeader } from '../components/ui/PageHeader';
import { Table, TableWrap, Td, Th, Tr } from '../components/ui/Table';

interface AnalyticsData {
  attacks: AttackDistributionItem[];
  severity: SeverityDistributionItem[];
  protocols: ProtocolDistributionItem[];
  ports: PortDistributionItem[];
}

export const Analytics: React.FC = () => {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [profiles, setProfiles] = useState<Record<string, AttackProfile>>({});
  const [profileClass, setProfileClass] = useState('Port Scan');
  const [profileModel, setProfileModel] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [reloadTick, setReloadTick] = useState(0);

  useEffect(() => {
    let alive = true;
    Promise.all([analyticsService.getAttacks(), analyticsService.getSeverity(), analyticsService.getProtocols(), analyticsService.getPorts()])
      .then(([attacks, severity, protocols, ports]) => {
        if (!alive) return;
        setData({ attacks, severity, protocols, ports });
        setError(null);
        // Global per-family explanation is optional: the charts above are useful without it.
        mlService
          .getProfiles()
          .then((p) => {
            if (!alive) return;
            setProfiles(p.profiles);
            setProfileModel(p.model_version);
            setProfileClass((current) => (p.profiles[current] ? current : Object.keys(p.profiles)[0] || ''));
          })
          .catch(() => undefined);
      })
      .catch((e: unknown) => alive && setError(e instanceof Error ? e.message : 'Failed to load analytics'))
      .finally(() => {
        if (!alive) return;
        setLoading(false);
        setRefreshing(false);
      });
    return () => {
      alive = false;
    };
  }, [reloadTick]);

  const reload = () => {
    setRefreshing(true);
    setReloadTick((t) => t + 1);
  };

  const profile = profiles[profileClass];
  const attacksSorted = data ? [...data.attacks].sort((a, b) => b.count - a.count) : [];

  return (
    <div className="space-y-6">
      <RoutePageHeader
        path="/analytics"
        actions={
          <Button size="sm" icon={RefreshCw} loading={refreshing} onClick={reload}>
            Refresh
          </Button>
        }
      />

      {error && (
        <Alert
          variant="error"
          title={data ? 'Could not refresh. Showing the last data received.' : 'Could not load analytics'}
          action={
            <Button size="sm" onClick={reload}>
              Retry
            </Button>
          }
        >
          {error}
        </Alert>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card title="Attack classification frequencies">
          <ChartFrame
            label={`Bar chart of incidents by attack type. Highest: ${topSummary(attacksSorted, (a) => a.attack_type, (a) => a.count)}.`}
            loading={loading}
            empty={!!data && data.attacks.length === 0}
            heightClass="h-72"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={attacksSorted} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" {...axisProps} allowDecimals={false} />
                <YAxis type="category" dataKey="attack_type" width={140} {...axisProps} />
                <Tooltip {...tooltipProps} />
                <Bar dataKey="count" name="Incidents" fill={CHART.primary} radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>
        </Card>

        <Card title="Threat severity" subtitle="Incidents by risk level.">
          <SeverityDonut data={data?.severity ?? []} loading={loading} />
        </Card>

        <Card title="Transport-layer protocols">
          <ChartFrame
            label={`Bar chart of incidents by protocol. Highest: ${topSummary(data?.protocols ?? [], (p) => p.protocol, (p) => p.count)}.`}
            loading={loading}
            empty={!!data && data.protocols.length === 0}
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data?.protocols ?? []} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="protocol" {...axisProps} />
                <YAxis {...axisProps} allowDecimals={false} />
                <Tooltip {...tooltipProps} />
                <Bar dataKey="count" name="Incidents" fill={CHART.positive} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>
        </Card>

        <Card title="Target ports" subtitle="Most frequent destination ports.">
          <ChartFrame
            label={`Bar chart of the most targeted destination ports. Highest: ${topSummary(data?.ports ?? [], (p) => String(p.port), (p) => p.count)}.`}
            loading={loading}
            empty={!!data && data.ports.length === 0}
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data?.ports ?? []} layout="vertical" margin={{ top: 4, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" {...axisProps} allowDecimals={false} />
                <YAxis type="category" dataKey="port" width={56} {...axisProps} />
                <Tooltip {...tooltipProps} />
                <Bar dataKey="count" name="Incidents" fill={CHART.warm} radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>
        </Card>

        {/* Explainability, global view: what does each attack family look like on the wire? */}
        {profile && (
          <Card
            title="Traffic features vs attack type"
            subtitle={`How each attack family differs from benign traffic (model ${profileModel}).`}
            className="lg:col-span-2"
            action={
              <Select compact hideLabel label="Attack family" className="w-72" value={profileClass} onChange={(e) => setProfileClass(e.target.value)}>
                {Object.keys(profiles).map((c) => (
                  <option key={c} value={c}>
                    {c} ({profiles[c].n_train.toLocaleString()} training flows)
                  </option>
                ))}
              </Select>
            }
          >
            <div className="grid grid-cols-1 gap-8 xl:grid-cols-2">
              <div>
                <h3 className="mb-2 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Most distinguishing features (median vs benign median)</h3>
                <TableWrap>
                  <Table caption={`Features that distinguish ${profileClass} from benign traffic`}>
                    <thead>
                      <tr>
                        <Th>Feature</Th>
                        <Th numeric>{profileClass}</Th>
                        <Th numeric>Benign</Th>
                        <Th>Direction</Th>
                      </tr>
                    </thead>
                    <tbody>
                      {profile.top_features.map((f) => (
                        <Tr key={f.feature}>
                          <Td className="text-slate-200">{f.label}</Td>
                          <Td numeric className="font-semibold text-cyan-300">
                            {compact(f.median)}
                          </Td>
                          <Td numeric className="text-soc-textMuted">
                            {compact(f.benign_median)}
                          </Td>
                          <Td className={f.direction === 'higher' ? 'text-orange-300' : 'text-sky-300'}>
                            <span aria-hidden>{f.direction === 'higher' ? '▲' : '▼'}</span> {f.direction}
                          </Td>
                        </Tr>
                      ))}
                    </tbody>
                  </Table>
                </TableWrap>
              </div>
              <div>
                <h3 className="mb-2 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Features the model relies on for this class (mean |SHAP|)</h3>
                <ChartFrame
                  label={`Bar chart of the features the model relies on most to recognise ${profileClass}. Highest: ${topSummary(profile.shap_importance, (s) => s.label, (s) => s.mean_abs_shap)}.`}
                  heightClass="h-64"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={profile.shap_importance} layout="vertical" margin={{ top: 4, right: 12, left: 8, bottom: 4 }}>
                      <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" {...axisProps} />
                      <YAxis type="category" dataKey="label" width={170} {...axisProps} />
                      <Tooltip {...tooltipProps} />
                      <Bar dataKey="mean_abs_shap" name="mean |SHAP|" fill={CHART.secondary} radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartFrame>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};
