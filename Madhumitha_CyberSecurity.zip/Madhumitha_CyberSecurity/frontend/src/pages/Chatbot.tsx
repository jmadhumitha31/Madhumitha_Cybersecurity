import React, { useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, Bot, Database, Search, ShieldCheck, Sparkles, Trash2, X } from 'lucide-react';
import { incidentService } from '../services/incidentService';
import type { Incident } from '../types';
import { BRAND } from '../lib/brand';
import { cn } from '../lib/cn';
import { ENGINE_DOT, describeEngine } from '../lib/engine';
import { shortModel } from '../lib/format';
import { useHealth } from '../lib/useHealth';
import { usePageTitle } from '../lib/usePageTitle';
import { Card } from '../components/common/Card';
import { ChatComposer } from '../components/chat/ChatComposer';
import { MessageBubble, TypingIndicator } from '../components/chat/MessageBubble';
import { useChat } from '../components/chat/useChat';
import { Button, IconButton } from '../components/ui/Button';
import { buttonClasses } from '../components/ui/buttonStyles';
import { Input } from '../components/ui/Input';
import { DefinitionList } from '../components/ui/Metric';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { Switch } from '../components/ui/Switch';

export const Chatbot: React.FC = () => {
  usePageTitle(BRAND.copilot);
  const [searchParams] = useSearchParams();
  const initialId = Number(searchParams.get('incidentId'));
  const { messages, isLoading, suggestions, send, clear } = useChat();
  const { health } = useHealth();
  const engine = describeEngine(health);

  const [selectedIncidentId, setSelectedIncidentId] = useState<number | null>(Number.isInteger(initialId) && initialId > 0 ? initialId : null);
  const [bindInput, setBindInput] = useState('');
  const [useRAG, setUseRAG] = useState(true);
  // Keyed by id, so a stale response for a previously bound incident can never show up as the current one.
  const [loaded, setLoaded] = useState<{ id: number; incident: Incident | null } | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  const selectedIncident = selectedIncidentId !== null && loaded?.id === selectedIncidentId ? loaded.incident : null;
  const bindFailed = selectedIncidentId !== null && loaded?.id === selectedIncidentId && loaded.incident === null;

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
    if (selectedIncidentId === null) return;
    let alive = true;
    incidentService
      .getIncidentDetails(selectedIncidentId)
      .then((res) => alive && setLoaded({ id: selectedIncidentId, incident: res.incident }))
      .catch(() => alive && setLoaded({ id: selectedIncidentId, incident: null }));
    return () => {
      alive = false;
    };
  }, [selectedIncidentId]);

  const bind = (e: React.FormEvent) => {
    e.preventDefault();
    const n = Number(bindInput);
    if (Number.isInteger(n) && n > 0) {
      setSelectedIncidentId(n);
      setBindInput('');
    }
  };

  const comp = health?.components;
  const vector = comp?.vector_index;
  const alpha = comp?.rag_pipeline?.alpha;

  return (
    <div className="h-page-fill flex gap-6">
      <section aria-labelledby="copilot-title" className="flex min-w-0 flex-1 flex-col overflow-hidden rounded-xl border border-soc-border bg-soc-dark">
        <div className="flex shrink-0 flex-wrap items-center justify-between gap-x-4 gap-y-2 border-b border-soc-border bg-soc-surface px-5 py-3">
          <div className="flex min-w-0 items-center gap-3">
            <div className="rounded-lg border border-cyan-800 bg-cyan-950/70 p-2 text-cyan-300">
              <Bot className="h-5 w-5" aria-hidden />
            </div>
            <div className="min-w-0">
              <h1 id="copilot-title" className="text-base font-semibold text-slate-50">
                {BRAND.copilot}
              </h1>
              <p className="flex items-center gap-1.5 text-xs text-soc-textMuted">
                <span className={cn('h-2 w-2 shrink-0 rounded-full', ENGINE_DOT[engine.tone])} aria-hidden />
                <span className="font-medium text-slate-300">{engine.badge}</span>
                <span className="truncate">· {engine.label}</span>
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {selectedIncidentId !== null ? (
              <div className="flex items-center gap-2 rounded-md border border-cyan-800 bg-cyan-950/50 py-1 pl-3 pr-1 text-xs text-cyan-100">
                <span>
                  Bound to <strong>#{selectedIncidentId}</strong>
                  {selectedIncident ? ` (${selectedIncident.attack_type})` : bindFailed ? ' (not found)' : '…'}
                </span>
                <IconButton label="Clear incident context" icon={X} onClick={() => setSelectedIncidentId(null)} />
              </div>
            ) : (
              <form onSubmit={bind} className="flex items-end gap-2">
                <Input compact hideLabel label="Incident number to bind" type="number" min={1} inputMode="numeric" placeholder="Incident #" className="w-28" value={bindInput} onChange={(e) => setBindInput(e.target.value)} />
                <Button size="sm" type="submit" disabled={!bindInput.trim()}>
                  Bind
                </Button>
              </form>
            )}
            <Switch checked={useRAG} onChange={setUseRAG} label="Knowledge base (RAG)" />
            <IconButton label="Clear conversation" icon={Trash2} onClick={clear} />
          </div>
        </div>

        <div role="log" aria-live="polite" aria-label="Conversation" className="flex-1 space-y-5 overflow-y-auto p-5">
          {messages.map((m, i) => (
            <MessageBubble key={i} message={m} />
          ))}
          {isLoading && <TypingIndicator />}
          <div ref={endRef} />
        </div>

        {suggestions.length > 0 && messages.length <= 2 && (
          <div className="flex shrink-0 items-center gap-2 overflow-x-auto border-t border-soc-border bg-soc-surface/60 px-5 py-2.5">
            <span className="flex shrink-0 items-center gap-1.5 text-xs text-soc-textMuted">
              <Sparkles className="h-3.5 w-3.5 text-cyan-400" aria-hidden />
              Try asking
            </span>
            {suggestions.slice(0, 4).map((s) => (
              <button
                key={s.id}
                type="button"
                disabled={isLoading}
                onClick={() => void send(s.prompt, { incidentId: selectedIncidentId, useRag: useRAG })}
                className="shrink-0 rounded-full border border-soc-border bg-soc-card px-3 py-1 text-xs text-slate-300 transition-colors hover:border-cyan-700 hover:text-cyan-200 disabled:opacity-50"
              >
                {s.title}
              </button>
            ))}
          </div>
        )}

        <div className="shrink-0 border-t border-soc-border bg-soc-surface p-4">
          <ChatComposer
            busy={isLoading}
            onSend={(t) => void send(t, { incidentId: selectedIncidentId, useRag: useRAG })}
            placeholder={selectedIncident ? `Ask about incident #${selectedIncident.id} (${selectedIncident.attack_type})…` : 'Ask about a flow signature, a playbook, or an incident…'}
          />
        </div>
      </section>

      {/* Context rail: only where there is room; the essentials (binding, engine, RAG) are in the header above. */}
      <aside aria-label="Copilot context" className="hidden w-80 shrink-0 flex-col gap-4 overflow-y-auto xl:flex">
        <Card title="Incident focus" badge={selectedIncident ? <span className="rounded bg-cyan-950 px-1.5 py-0.5 text-2xs font-semibold text-cyan-200">#{selectedIncident.id}</span> : undefined}>
          {selectedIncident ? (
            <div className="space-y-3">
              <DefinitionList
                items={[
                  { label: 'Flow', value: <span className="font-mono text-xs break-all">{selectedIncident.flow_id}</span> },
                  { label: 'Classification', value: selectedIncident.attack_type },
                  { label: 'Severity', value: <SeverityBadge level={selectedIncident.risk_level} priority={selectedIncident.priority} /> },
                  { label: 'Source', value: <span className="font-mono text-xs">{selectedIncident.source_ip}:{selectedIncident.source_port}</span> },
                  { label: 'Destination', value: <span className="font-mono text-xs">{selectedIncident.destination_ip}:{selectedIncident.destination_port}</span> },
                ]}
              />
              <Link to={`/incidents/${selectedIncident.id}`} className={cn(buttonClasses('secondary', 'sm'), 'w-full')}>
                Open full incident
                <ArrowRight className="h-4 w-4" aria-hidden />
              </Link>
            </div>
          ) : (
            <div className="py-3 text-center text-sm text-soc-textMuted">
              <Search className="mx-auto mb-2 h-5 w-5 text-slate-400" aria-hidden />
              <p>No incident bound.</p>
              <p className="mt-1 text-xs">Enter an incident number above, or use “Ask copilot” on any incident page.</p>
            </div>
          )}
        </Card>

        <Card title="Copilot engine">
          <div className="space-y-4 text-xs">
            <div>
              <p className="mb-1 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Language model</p>
              <p className="flex items-center gap-2 text-slate-200">
                <span className={cn('h-2 w-2 shrink-0 rounded-full', ENGINE_DOT[engine.tone])} aria-hidden />
                {engine.label}
              </p>
              {comp?.ollama_llm && <p className="mt-1 text-soc-textMuted">Local fallback: {comp.ollama_llm.status === 'Healthy' ? `Ollama ${shortModel(comp.ollama_llm.model)}` : 'Ollama not reachable'}</p>}
            </div>
            <div>
              <p className="mb-1 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Knowledge base</p>
              <p className="flex items-center gap-2 text-slate-200">
                <Database className="h-3.5 w-3.5 text-cyan-400" aria-hidden />
                {vector?.documents != null ? `${vector.documents.toLocaleString()} labelled flows` : '—'}
              </p>
              {comp?.embeddings?.dimension && (
                <p className="mt-1 text-soc-textMuted">
                  {comp.embeddings.dimension}-d {comp.embeddings.model}
                  {vector?.engine === 'qdrant' ? ` · Qdrant (${vector.store_mode === 'local' ? 'on-device' : vector.store_mode})` : ''}
                </p>
              )}
            </div>
            <div>
              <p className="mb-1 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Hybrid scoring</p>
              <p className="font-mono text-xs text-slate-300">{alpha != null ? `score = ${alpha}·dense + ${(1 - alpha).toFixed(2)}·BM25` : '—'}</p>
            </div>
            <div>
              <p className="mb-1.5 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Applied to every message</p>
              <ul className="space-y-1.5 text-slate-300">
                {['Prompt-injection filter', 'Cyber-domain boundary', 'Human approval for containment'].map((g) => (
                  <li key={g} className="flex items-center gap-2">
                    <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-slate-400" aria-hidden />
                    {g}
                  </li>
                ))}
              </ul>
              <p className="mt-2 text-soc-textMuted">Answers cite only retrieved incidents.</p>
            </div>
          </div>
        </Card>
      </aside>
    </div>
  );
};
