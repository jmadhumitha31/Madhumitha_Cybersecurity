import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, AlertTriangle, ArrowRight, CheckCircle2, Flame, RefreshCw, ShieldAlert } from 'lucide-react';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { StatCard } from '../components/common/StatCard';
import { Card } from '../components/common/Card';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { TableSkeleton, StatGridSkeleton } from '../components/common/LoadingSkeleton';
import { DataSourceBanner } from '../components/common/DataSourceBanner';
import { ChartFrame } from '../components/common/ChartFrame';
import { SeverityDonut } from '../components/common/SeverityDonut';
import { Alert } from '../components/ui/Alert';
import { Button } from '../components/ui/Button';
import { buttonClasses } from '../components/ui/buttonStyles';
import { EmptyState } from '../components/ui/EmptyState';
import { RoutePageHeader } from '../components/ui/PageHeader';
import { Table, TableWrap, Td, Th, Tr } from '../components/ui/Table';
import { analyticsService } from '../services/analyticsService';
import { incidentService } from '../services/incidentService';
import { CHART, SEVERITY_COLORS, axisProps, legendProps, tooltipProps, topSummary } from '../lib/chartTheme';
import { pct } from '../lib/format';
import type { AnalyticsOverview, AttackDistributionItem, Incident, PortDistributionItem, SeverityDistributionItem, TrendItem } from '../types';

interface DashboardData {
  overview: AnalyticsOverview;
  attacks: AttackDistributionItem[];
  severity: SeverityDistributionItem[];
  ports: PortDistributionItem[];
  trends: TrendItem[];
  queue: Incident[];
}

export const Dashboard: React.FC = () => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);

  const [reloadTick, setReloadTick] = useState(0);

  // State is only set after the awaited requests, so a refresh keeps showing the previous numbers instead of blanking.
  useEffect(() => {
    let alive = true;
    Promise.all([
      analyticsService.getOverview(),
      analyticsService.getAttacks(),
      analyticsService.getSeverity(),
      analyticsService.getPorts(),
      analyticsService.getTrends(),
      incidentService.getQueue(8),
    ])
      .then(([overview, attacks, severity, ports, trends, queue]) => {
        if (!alive) return;
        setData({ overview, attacks, severity, ports, trends, queue });
        setError(null);
        setUpdatedAt(new Date());
      })
      .catch((err: unknown) => alive && setError(err instanceof Error ? err.message : 'Failed to load dashboard data'))
      .finally(() => {
        if (!alive) return;
        setLoading(false);
        setRefreshing(false);
      });
    return () => {
      alive = false;
    };
  }, [reloadTick]);

  const refresh = () => {
    setRefreshing(true);
    setReloadTick((t) => t + 1);
  };

  const ov = data?.overview;
  const conf = ov?.mean_model_confidence;
  // A failed request must read as "unknown", never as a confident "0".
  const val = (n: number | undefined) => (n === undefined ? '—' : n.toLocaleString());
  const attacksSorted = data ? [...data.attacks].sort((a, b) => b.count - a.count) : [];
  const initialLoad = loading && !data;

  return (
    <div className="space-y-6">
      <RoutePageHeader
        path="/dashboard"
        actions={
          <>
            {updatedAt && <span className="text-xs text-soc-textMuted">Updated {updatedAt.toLocaleTimeString()}</span>}
            <Button size="sm" icon={RefreshCw} onClick={refresh} loading={refreshing}>
              Refresh
            </Button>
          </>
        }
      />

      <DataSourceBanner />
      {error && (
        <Alert
          variant="error"
          title={data ? 'Could not refresh. Showing the last data received.' : 'Could not load the dashboard'}
          action={
            <Button size="sm" onClick={refresh}>
              Retry
            </Button>
          }
        >
          {error}
        </Alert>
      )}

      {initialLoad ? (
        <StatGridSkeleton count={5} />
      ) : (
        <div className="grid grid-cols-[repeat(auto-fit,minmax(13rem,1fr))] gap-4">
          <StatCard
            label="Total incidents"
            value={val(ov?.total_incidents)}
            change={ov ? `${ov.knowledge_base_size.toLocaleString()} labelled in the knowledge base` : undefined}
            icon={ShieldAlert}
            variant="cyan"
            to="/incidents"
          />
          <StatCard
            label="Open P1 (critical)"
            value={val(ov?.p1_open)}
            change={ov ? `${ov.critical_incidents.toLocaleString()} critical in total` : undefined}
            icon={Flame}
            variant="red"
            to="/incidents?sort=risk&risk_level=Critical"
          />
          <StatCard
            label="High severity"
            value={val(ov?.high_incidents)}
            change={ov ? 'Elevated impact (P2)' : undefined}
            icon={AlertTriangle}
            variant="orange"
            to="/incidents?sort=risk&risk_level=High"
          />
          <StatCard
            label="Under investigation"
            value={val(ov?.investigations_in_progress)}
            change={ov ? `${ov.open_incidents.toLocaleString()} open in total` : undefined}
            icon={Activity}
            variant="yellow"
            to="/incidents?status=INVESTIGATING"
          />
          <StatCard
            label="Mean model confidence"
            value={ov ? pct(conf) : '—'}
            change={ov ? (conf == null ? 'No model-scored incidents yet' : `Over ${ov.model_scored_incidents.toLocaleString()} model-scored alerts`) : undefined}
            icon={CheckCircle2}
            variant="emerald"
          />
        </div>
      )}

      {/* Prioritised triage queue: answers "which suspicious activity should be investigated first?" */}
      <Card
        title="Priority triage queue"
        subtitle="Open incidents ranked by risk score: class severity × confidence, intrusion model, anomaly and traffic indicators."
        padded={false}
        action={
          <Link to="/incidents?sort=risk&status=NEW" className={buttonClasses('ghost', 'sm')}>
            Full queue
            <ArrowRight className="h-4 w-4" aria-hidden />
          </Link>
        }
      >
        {initialLoad ? (
          <div className="p-5">
            <TableSkeleton rows={5} />
          </div>
        ) : !data ? (
          <EmptyState icon={AlertTriangle} title="The queue could not be loaded" description="See the error above, then retry." />
        ) : data.queue.length === 0 ? (
          <EmptyState icon={CheckCircle2} title="No open scored incidents" description="Nothing is waiting for triage right now." />
        ) : (
          <TableWrap>
            <Table caption="Open incidents ranked by risk score">
              <thead>
                <tr>
                  <Th numeric>#</Th>
                  <Th>Priority</Th>
                  <Th numeric>Risk</Th>
                  <Th>Predicted class</Th>
                  <Th numeric>Confidence</Th>
                  <Th numeric>Intrusion P</Th>
                  <Th>Network path</Th>
                  <Th>
                    <span className="sr-only">Action</span>
                  </Th>
                </tr>
              </thead>
              <tbody>
                {data.queue.map((inc, i) => (
                  <Tr key={inc.id} to={`/incidents/${inc.id}`}>
                    <Td numeric className="text-soc-textMuted">
                      {i + 1}
                    </Td>
                    <Td>
                      <SeverityBadge level={inc.risk_level} priority={inc.priority} />
                    </Td>
                    <Td numeric className="font-semibold text-slate-50">
                      {inc.risk_score != null ? inc.risk_score.toFixed(1) : 'N/A'}
                    </Td>
                    <Td className="text-slate-200">{inc.attack_type}</Td>
                    <Td numeric>{inc.prediction_confidence != null ? pct(inc.prediction_confidence, 0) : 'N/A'}</Td>
                    <Td numeric>{inc.intrusion_probability != null ? pct(inc.intrusion_probability, 0) : 'N/A'}</Td>
                    <Td mono className="whitespace-nowrap text-soc-textMuted">
                      {inc.source_ip} → {inc.destination_ip}:{inc.destination_port}
                    </Td>
                    <Td className="text-right">
                      <Link to={`/incidents/${inc.id}`} className="inline-flex items-center gap-1 font-medium text-cyan-300 hover:text-cyan-200" onClick={(e) => e.stopPropagation()}>
                        Investigate
                        <ArrowRight className="h-3.5 w-3.5" aria-hidden />
                      </Link>
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          </TableWrap>
        )}
      </Card>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card title="Incident volume by day" subtitle="Flow event time, not ingestion time." className="xl:col-span-2">
          <ChartFrame
            label={`Area chart of daily incident volume, ${data?.trends.length ?? 0} days, with critical incidents overlaid.`}
            loading={initialLoad}
            empty={!!data && data.trends.length === 0}
          >
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data?.trends ?? []} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                <defs>
                  <linearGradient id="trendGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={CHART.primary} stopOpacity={0.35} />
                    <stop offset="95%" stopColor={CHART.primary} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="date" {...axisProps} />
                <YAxis {...axisProps} allowDecimals={false} />
                <Tooltip {...tooltipProps} />
                <Legend {...legendProps} />
                <Area type="monotone" dataKey="total" name="All incidents" stroke={CHART.primary} strokeWidth={2} fill="url(#trendGradient)" />
                <Area type="monotone" dataKey="critical" name="Critical" stroke={SEVERITY_COLORS.Critical} strokeWidth={1.75} fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartFrame>
        </Card>

        <Card title="Threat severity" subtitle="Incidents by risk level.">
          <SeverityDonut data={data?.severity ?? []} loading={initialLoad} />
        </Card>

        <Card title="Attack classification" subtitle="Classification in force: dataset label or model prediction." className="xl:col-span-2">
          <ChartFrame
            label={`Bar chart of incidents by attack type. Highest: ${topSummary(attacksSorted, (a) => a.attack_type, (a) => a.count)}.`}
            loading={initialLoad}
            empty={!!data && data.attacks.length === 0}
            heightClass="h-72"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={attacksSorted} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" {...axisProps} allowDecimals={false} />
                <YAxis type="category" dataKey="attack_type" width={140} {...axisProps} />
                <Tooltip {...tooltipProps} />
                <Bar dataKey="count" name="Incidents" fill={CHART.primary} radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>
        </Card>

        <Card title="Target ports" subtitle="Most frequent destination ports.">
          <ChartFrame
            label={`Bar chart of the most targeted destination ports. Highest: ${topSummary(data?.ports ?? [], (p) => String(p.port), (p) => p.count)}.`}
            loading={initialLoad}
            empty={!!data && data.ports.length === 0}
            heightClass="h-72"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data?.ports ?? []} layout="vertical" margin={{ top: 4, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid stroke={CHART.grid} strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" {...axisProps} allowDecimals={false} />
                <YAxis type="category" dataKey="port" width={56} {...axisProps} />
                <Tooltip {...tooltipProps} />
                <Bar dataKey="count" name="Incidents" fill={CHART.warm} radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartFrame>
        </Card>
      </div>
    </div>
  );
};
