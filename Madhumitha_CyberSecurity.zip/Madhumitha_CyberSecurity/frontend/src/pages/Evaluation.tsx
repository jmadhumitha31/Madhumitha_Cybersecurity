import React, { useEffect, useRef, useState } from 'react';
import { AlertTriangle, Gauge, Loader2, RefreshCw } from 'lucide-react';
import { evaluationService } from '../services/evaluationService';
import { authService } from '../services/authService';
import type { DeepEvalMetrics, EvaluationRunRecord, LLMJudgeBatch, LLMJudgeResult, MLEvaluationMetrics, RetrievalMetrics } from '../types';
import { cn } from '../lib/cn';
import { fixed as f3, pct } from '../lib/format';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { LoadingSkeleton } from '../components/common/LoadingSkeleton';
import { DataSourceBanner } from '../components/common/DataSourceBanner';
import { Alert } from '../components/ui/Alert';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { DefinitionList, Metric } from '../components/ui/Metric';
import { RoutePageHeader } from '../components/ui/PageHeader';
import { Table, TableWrap, Td, Th, Tr } from '../components/ui/Table';

type SectionId = 'ml' | 'retrieval' | 'deepeval' | 'judge';

/** One at-a-glance tile; clicking it scrolls to the section with the detail. */
const ScoreLink: React.FC<{ target: SectionId; label: string; value: string; note: string; ran: boolean }> = ({ target, label, value, note, ran }) => (
  <button
    type="button"
    onClick={() => document.getElementById(target)?.scrollIntoView({ block: 'start', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' })}
    className="rounded-lg bg-soc-card/70 px-3.5 py-3 text-left transition-colors hover:bg-soc-card"
  >
    <span className="block text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">{label}</span>
    <span className={cn('mt-1 block text-lg font-semibold tabular-nums', ran ? 'text-slate-50' : 'text-slate-400')}>{value}</span>
    <span className="block text-xs text-soc-textMuted">{note}</span>
  </button>
);

export const Evaluation: React.FC = () => {
  const canRun = authService.canWrite();
  const [ml, setMl] = useState<MLEvaluationMetrics | null>(null);
  const [retr, setRetr] = useState<RetrievalMetrics | null>(null);
  const [de, setDe] = useState<DeepEvalMetrics | null>(null);
  const [judge, setJudge] = useState<LLMJudgeBatch | null>(null);
  const [runs, setRuns] = useState<EvaluationRunRecord[]>([]);
  const [busy, setBusy] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const poll = useRef<number | undefined>(undefined);

  const startPolling = () => {
    window.clearInterval(poll.current);
    poll.current = window.setInterval(async () => {
      const d = await evaluationService.getDeepEval().catch(() => null);
      if (d) setDe(d);
      if (!d || d.run_status !== 'running') {
        window.clearInterval(poll.current);
        setBusy((b) => ({ ...b, de: false }));
        evaluationService.getEvaluationRuns().then(setRuns).catch(() => undefined);
      }
    }, 4000);
  };

  const load = async () => {
    try {
      const [m, r, d, j, rs] = await Promise.all([
        evaluationService.getMLEvaluation().catch(() => null),
        evaluationService.getRetrieval().catch(() => null),
        evaluationService.getDeepEval().catch(() => null),
        evaluationService.getJudge().catch(() => null),
        evaluationService.getEvaluationRuns().catch(() => []),
      ]);
      setMl(m && m.status !== 'unavailable' ? m : null);
      setRetr(r && r.status !== 'not_executed' ? r : null);
      setDe(d);
      setJudge(j && j.status !== 'not_executed' && 'cases' in j ? (j as LLMJudgeBatch) : null);
      setRuns(rs || []);
      if (d?.run_status === 'running') startPolling();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    return () => window.clearInterval(poll.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const run = async (key: string, fn: () => Promise<void>) => {
    setBusy((b) => ({ ...b, [key]: true }));
    setError(null);
    try {
      await fn();
      evaluationService.getEvaluationRuns().then(setRuns).catch(() => undefined);
    } catch (e) {
      setError(`${key}: ${e instanceof Error ? e.message : 'failed'}`);
    } finally {
      if (key !== 'de') setBusy((b) => ({ ...b, [key]: false }));
    }
  };

  const synthetic = !!ml?.synthetic;
  const deRunning = de?.run_status === 'running';
  const retrOk = !!retr?.with_endpoints;
  const deOk = de?.status === 'ok';
  const judgeOk = !!judge && judge.n_scored > 0;
  const hybrid = retr?.with_endpoints?.hybrid;

  return (
    <div className="space-y-6">
      <RoutePageHeader
        path="/evaluation"
        actions={
          <Button
            size="sm"
            icon={RefreshCw}
            loading={loading}
            onClick={() => {
              setLoading(true);
              void load();
            }}
          >
            Refresh
          </Button>
        }
      />

      <DataSourceBanner />
      {error && <Alert variant="error" onDismiss={() => setError(null)}>{error}</Alert>}

      <Card title="At a glance" subtitle="The headline number from each suite. Select one to jump to its detail.">
        {loading && !ml && !retr && !de && !judge ? (
          <LoadingSkeleton rows={1} height="h-20" />
        ) : (
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <ScoreLink target="ml" label="Classifier macro-F1" value={ml ? pct(ml.f1_macro) : 'Not run'} note={ml ? `${ml.samples_evaluated.toLocaleString()} held-out flows` : 'No model loaded'} ran={!!ml} />
            <ScoreLink target="retrieval" label="Retrieval precision@5" value={retrOk ? f3(hybrid?.precision_at_5) : 'Not run'} note={retrOk ? `Hybrid · ${retr?.queries ?? '?'} queries` : 'Run the benchmark'} ran={retrOk} />
            <ScoreLink target="deepeval" label="Faithfulness (DeepEval)" value={deOk ? pct(de?.faithfulness) : 'Not run'} note={deOk ? `${de?.n_cases ?? '?'} investigation(s)` : deRunning ? 'Running…' : 'Run DeepEval'} ran={deOk} />
            <ScoreLink target="judge" label="Judge correctness" value={judgeOk ? pct(judge?.mean_correctness, 0) : 'Not run'} note={judgeOk ? `${judge?.n_scored} case(s) scored` : 'Judge the latest cases'} ran={judgeOk} />
          </div>
        )}
      </Card>

      {/* ---------------------------------------------------------------- ML */}
      <Card
        id="ml"
        className="scroll-mt-4"
        title="1. Machine-learning models (held-out evaluation)"
        subtitle={ml ? `Model ${ml.model_version} · trained on ${ml.n_train?.toLocaleString()} flows · evaluated on ${ml.samples_evaluated.toLocaleString()} unseen flows · data: ${ml.dataset_source}` : 'Attack-type classifier, intrusion-risk model, anomaly detector.'}
        badge={ml?.recomputed ? <Badge variant="low">Re-scored just now</Badge> : undefined}
        action={
          <Button size="sm" loading={!!busy.ml} disabled={!canRun} onClick={() => run('ml', async () => setMl(await evaluationService.runMLEvaluation()))}>
            {busy.ml ? 'Scoring…' : 'Re-score on held-out split'}
          </Button>
        }
      >
        {ml ? (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
              <Metric label="Accuracy" value={pct(ml.accuracy)} tone="text-emerald-400" />
              <Metric label="Macro F1" value={pct(ml.f1_macro)} tone="text-cyan-300" hint="Unweighted mean over classes: exposes weak rare classes" />
              <Metric label="Macro precision" value={pct(ml.precision_macro)} />
              <Metric label="Macro recall" value={pct(ml.recall_macro)} />
              <Metric label="3-fold CV macro-F1" value={ml.cv ? pct(ml.cv.f1_macro) : 'N/A'} hint={ml.cv ? `on a ${ml.cv.subsample.toLocaleString()}-flow subsample of the training split` : undefined} />
            </div>

            <TableWrap>
              <Table caption="Per-class precision, recall and F1">
                <thead>
                  <tr>
                    <Th>Class</Th>
                    <Th numeric>Precision</Th>
                    <Th numeric>Recall</Th>
                    <Th numeric>F1</Th>
                    <Th numeric>Test support</Th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(ml.per_class_metrics).map(([c, m]) => (
                    <Tr key={c}>
                      <Td className="font-medium text-slate-100">{c}</Td>
                      <Td numeric>{pct(m.precision)}</Td>
                      <Td numeric>{pct(m.recall)}</Td>
                      <Td numeric className={cn('font-semibold', m.f1 < 0.9 ? 'text-amber-300' : 'text-emerald-400')}>
                        {pct(m.f1)}
                      </Td>
                      <Td numeric className="text-soc-textMuted">
                        {m.low_support && (
                          <span className="mr-2 inline-flex items-center gap-1 text-amber-300" title="Fewer than 30 test flows: statistically unreliable">
                            <AlertTriangle className="h-3.5 w-3.5" aria-hidden />
                            Low support
                          </span>
                        )}
                        {m.support.toLocaleString()}
                      </Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
            </TableWrap>

            {ml.top_confusions && ml.top_confusions.length > 0 && (
              <p className="text-sm text-soc-textMuted">
                <span className="font-medium text-slate-300">Top confusions:</span> {ml.top_confusions.slice(0, 4).map((c) => `${c.true} → ${c.predicted} (${c.count})`).join(' · ')}
              </p>
            )}

            <div className="grid grid-cols-1 gap-6 border-t border-soc-border pt-6 md:grid-cols-2">
              <div>
                <h3 className="mb-1 text-sm font-semibold text-slate-100">Intrusion-risk model</h3>
                <p className="mb-2 text-xs text-soc-textMuted">Calibrated, benign vs attack.</p>
                <DefinitionList
                  items={[
                    { label: 'ROC-AUC', value: f3(ml.intrusion_model?.roc_auc) },
                    { label: 'Average precision', value: f3(ml.intrusion_model?.average_precision) },
                    { label: 'Brier score', value: f3(ml.intrusion_model?.brier) },
                    ...(ml.intrusion_model?.tpr_at_1pct_fpr !== undefined ? [{ label: 'Detection rate at 1% false positives', value: pct(ml.intrusion_model.tpr_at_1pct_fpr) }] : []),
                  ]}
                />
              </div>
              <div>
                <h3 className="mb-1 text-sm font-semibold text-slate-100">Anomaly detector</h3>
                <p className="mb-2 text-xs text-soc-textMuted">Isolation Forest, trained on benign traffic only.</p>
                <DefinitionList
                  items={[
                    { label: 'ROC-AUC vs unseen attacks', value: f3(ml.anomaly_model?.roc_auc_attack_vs_benign) },
                    ...(ml.anomaly_model?.median_score_attack !== undefined
                      ? [
                          { label: 'Median score: attack', value: f3(ml.anomaly_model.median_score_attack) },
                          { label: 'Median score: benign', value: f3(ml.anomaly_model.median_score_benign) },
                        ]
                      : []),
                  ]}
                />
              </div>
            </div>
            {ml.caveat && <Alert variant="info">{ml.caveat}</Alert>}
            {synthetic && <Alert variant="warning">These metrics come from synthetic demo data and say nothing about real traffic.</Alert>}
          </div>
        ) : (
          !loading && (
            <EmptyState icon={AlertTriangle} title="No trained model loaded" description={<>Train one with <code className="rounded bg-soc-card px-1.5 py-0.5 font-mono text-xs">python -m app.ml.training</code>.</>} />
          )
        )}
      </Card>

      {/* ---------------------------------------------------------------- Retrieval */}
      <Card
        id="retrieval"
        className="scroll-mt-4"
        title="2. Hybrid retrieval quality (leave-one-out)"
        subtitle="Does the RAG layer retrieve incidents of the same attack family? The query is telemetry only, never the label."
        action={
          <Button size="sm" loading={!!busy.retr} disabled={!canRun} onClick={() => run('retr', async () => setRetr(await evaluationService.runRetrieval()))}>
            {busy.retr ? 'Benchmarking…' : 'Run retrieval benchmark'}
          </Button>
        }
      >
        {retr && retr.with_endpoints ? (
          <div className="space-y-5">
            <TableWrap>
              <Table caption="Retrieval quality by method">
                <thead>
                  <tr>
                    <Th>Method</Th>
                    <Th numeric>P@1</Th>
                    <Th numeric>P@5</Th>
                    <Th numeric>Hit@5</Th>
                    <Th numeric>MRR</Th>
                    <Th numeric>nDCG@5</Th>
                  </tr>
                </thead>
                <tbody>
                  {(
                    [
                      ['Hybrid (deployed)', retr.with_endpoints.hybrid],
                      ['Semantic only', retr.with_endpoints.semantic_only],
                      ['BM25 only', retr.with_endpoints.keyword_only],
                      ['Hybrid, IPs removed', retr.without_ip_addresses?.hybrid],
                    ] as [string, Record<string, number> | undefined][]
                  ).map(
                    ([name, m]) =>
                      m && (
                        <Tr key={name}>
                          <Td className="font-medium text-slate-100">{name}</Td>
                          <Td numeric>{f3(m.precision_at_1)}</Td>
                          <Td numeric className="font-semibold text-cyan-300">
                            {f3(m.precision_at_5)}
                          </Td>
                          <Td numeric>{f3(m.hit_at_5)}</Td>
                          <Td numeric>{f3(m.mrr)}</Td>
                          <Td numeric>{f3(m.ndcg_at_5)}</Td>
                        </Tr>
                      ),
                  )}
                  <Tr>
                    <Td className="text-soc-textMuted">Random retrieval</Td>
                    <Td colSpan={5} className="text-soc-textMuted">
                      Precision {f3(retr.random_retrieval_precision)}
                    </Td>
                  </Tr>
                </tbody>
              </Table>
            </TableWrap>
            <p className="text-sm text-soc-textMuted">
              {retr.queries} queries over {retr.knowledge_base_size?.toLocaleString()} labelled incidents · embeddings {retr.embedding_model} · α = {retr.hybrid_alpha} · threshold {retr.similarity_threshold}
              {retr.operating_point && ` → answers ${pct(retr.operating_point.coverage, 0)} of queries at ${pct(retr.operating_point.precision_at_1_when_answered, 0)} precision@1`}
            </p>
            <div>
              <p className="mb-2 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Precision@k by attack family</p>
              <ul className="flex flex-wrap gap-2">
                {Object.entries(retr.with_endpoints.per_class_precision_at_k).map(([c, v]) => (
                  <li key={c} className={cn('rounded-md border px-2.5 py-1 text-xs tabular-nums', v < 0.8 ? 'border-amber-800 bg-amber-950/30 text-amber-300' : 'border-soc-border bg-soc-card text-slate-300')}>
                    {c}: {pct(v, 0)}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ) : (
          !loading && <EmptyState icon={Gauge} title="Retrieval benchmark not executed" description="Run it to measure how well similar-incident retrieval matches attack families." />
        )}
      </Card>

      {/* ---------------------------------------------------------------- DeepEval */}
      <Card
        id="deepeval"
        className="scroll-mt-4"
        title="3. DeepEval (independent judge LLM)"
        subtitle="Answer relevancy, faithfulness, hallucination and a custom recommendation-safety rubric."
        badge={de?.judge_model ? <Badge variant="purple">Judge: {de.judge_model}</Badge> : undefined}
        action={
          <Button
            size="sm"
            loading={!!busy.de || deRunning}
            disabled={!canRun}
            onClick={() =>
              run('de', async () => {
                await evaluationService.startDeepEval(4);
                setDe({ status: 'running', run_status: 'running' });
                startPolling();
              })
            }
          >
            {busy.de || deRunning ? 'Running (several minutes)…' : 'Run DeepEval'}
          </Button>
        }
      >
        {deRunning ? (
          <Alert variant="info" title="DeepEval is running">
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              Dozens of judge-LLM calls over the latest investigations. This page updates automatically.
            </span>
          </Alert>
        ) : deOk && de ? (
          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <Metric label="Answer relevancy" value={pct(de.answer_relevancy)} tone="text-emerald-400" />
              <Metric label="Faithfulness" value={pct(de.faithfulness)} tone="text-cyan-300" hint="Claims supported by telemetry, ML output and retrieved evidence" />
              <Metric label="Hallucination (lower is better)" value={pct(de.hallucination)} tone="text-yellow-400" />
              <Metric label="Recommendation quality" value={pct(de.recommendation_quality)} />
            </div>
            <DefinitionList
              columns={2}
              items={[
                { label: 'Investigations judged', value: de.n_cases ?? 'N/A' },
                { label: 'Judge LLM calls', value: de.judge_llm_calls ?? 'N/A' },
                { label: 'Metric errors', value: `${de.n_metric_errors ?? 0} / ${de.n_metric_calls ?? 0}` },
                { label: 'Duration', value: de.duration_s != null ? `${de.duration_s}s` : 'N/A' },
                { label: 'Judge independent of generator', value: de.judge_independent_of_generator ? 'Yes' : 'No' },
              ]}
            />
            {de.deterministic_checks && (
              <Alert variant="info" title="Deterministic guardrail checks (no LLM)">
                Unsafe-automation rate {pct(de.deterministic_checks.unsafe_automated_action_rate)} · containment steps with a human gate {pct(de.deterministic_checks.containment_with_human_gate_rate)} ({de.deterministic_checks.containment_steps} steps)
              </Alert>
            )}
            {de.cases?.slice(0, 3).map((c) => (
              <details key={c.incident_id} className="rounded-lg bg-soc-card/60 p-3 text-sm">
                <summary className="cursor-pointer text-slate-200">
                  Incident #{c.incident_id} <span className="text-soc-textMuted">(written by {c.generator})</span>
                </summary>
                <ul className="mt-2 space-y-1.5 text-xs">
                  {Object.entries(c.metrics).map(([k, m]) => (
                    <li key={k}>
                      <span className="font-medium text-cyan-300">{k}</span>:{' '}
                      {m.score === null ? (
                        <span className="text-red-300">error: {m.error}</span>
                      ) : (
                        <>
                          {pct(m.score)} <span className="text-soc-textMuted">— {m.reason}</span>
                        </>
                      )}
                    </li>
                  ))}
                </ul>
              </details>
            ))}
          </div>
        ) : de?.status === 'unavailable' ? (
          <Alert variant="warning">No judge LLM could be reached ({de.reason || 'unavailable'}). No scores were produced.</Alert>
        ) : de && (de.status === 'failed' || de.status === 'no_data') ? (
          <Alert variant="warning">
            DeepEval {de.status}: {de.reason || de.error || ''}
          </Alert>
        ) : (
          !loading && <EmptyState icon={Gauge} title="DeepEval has not been executed" description="Run at least one AI investigation first, then start DeepEval." />
        )}
      </Card>

      {/* ---------------------------------------------------------------- LLM-as-Judge */}
      <Card
        id="judge"
        className="scroll-mt-4"
        title="4. LLM-as-judge (validation of analyses and recommendations)"
        subtitle="An independent model grades the latest investigations; individual incidents can be judged from their own page."
        badge={judge?.judge_model ? <Badge variant="purple">Judge: {judge.judge_model}</Badge> : undefined}
        action={
          <Button size="sm" loading={!!busy.judge} disabled={!canRun} onClick={() => run('judge', async () => setJudge(await evaluationService.runJudgeBatch(5)))}>
            {busy.judge ? 'Judging…' : 'Judge latest 5'}
          </Button>
        }
      >
        {judge && judge.n_scored > 0 ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
              <Metric label="Correctness" value={pct(judge.mean_correctness, 0)} tone="text-emerald-400" />
              <Metric label="Relevance" value={pct(judge.mean_relevance, 0)} />
              <Metric label="Reasoning" value={pct(judge.mean_reasoning_quality, 0)} />
              <Metric label="Recommendations" value={pct(judge.mean_recommendation_quality, 0)} />
              <Metric
                label="Verdicts"
                value={
                  Object.entries(judge.verdicts || {})
                    .filter(([, n]) => n)
                    .map(([v, n]) => `${n} ${v.replace('_', ' ').toLowerCase()}`)
                    .join(', ') || 'N/A'
                }
                className="[&>div:nth-child(2)]:text-sm"
              />
            </div>
            <ul className="space-y-2">
              {judge.cases.map(
                (c: LLMJudgeResult, i) =>
                  c.scores && (
                    <li key={i} className="rounded-lg bg-soc-card/60 p-3 text-sm">
                      <p className="text-slate-200">
                        #{c.incident_id} <span className="text-soc-textMuted">written by {c.generator_model}</span> → <strong>{c.scores.verdict}</strong>
                      </p>
                      <p className="mt-0.5 text-soc-textMuted">{c.scores.critique}</p>
                    </li>
                  ),
              )}
            </ul>
          </div>
        ) : judge?.status === 'unavailable' ? (
          <Alert variant="warning">No judge LLM could be reached. No scores were produced.</Alert>
        ) : (
          !loading && <EmptyState icon={Gauge} title="No batch judging yet" description="Judge the latest investigations to see how an independent model rates them." />
        )}
      </Card>

      {/* ---------------------------------------------------------------- history */}
      <Card title="Evaluation run history" subtitle="Complete record of stored runs, including failed and unavailable ones." padded={false}>
        {runs.length === 0 ? (
          <EmptyState title="No evaluation run has been recorded" />
        ) : (
          <TableWrap maxHeight="min(60dvh, 32rem)">
            <Table caption="Stored evaluation runs">
              <thead>
                <tr>
                  <Th>Run</Th>
                  <Th>Suite</Th>
                  <Th>Status</Th>
                  <Th>Model / judge</Th>
                  <Th>Headline</Th>
                  <Th numeric>When</Th>
                </tr>
              </thead>
              <tbody>
                {runs.map((r) => {
                  const m = r.metrics || {};
                  const headline =
                    r.eval_type === 'ML' && m.accuracy != null
                      ? `accuracy ${pct(m.accuracy)} · macro-F1 ${pct(m.f1_macro)}`
                      : r.eval_type === 'RETRIEVAL' && m.with_endpoints
                        ? `P@5 ${f3(m.with_endpoints.hybrid?.precision_at_5)} · MRR ${f3(m.with_endpoints.hybrid?.mrr)}`
                        : r.eval_type === 'DEEPEVAL' && m.faithfulness != null
                          ? `faithfulness ${pct(m.faithfulness)}`
                          : r.eval_type === 'LLM_JUDGE' && (m.scores?.correctness != null || m.mean_correctness != null)
                            ? `correctness ${pct(m.scores?.correctness ?? m.mean_correctness, 0)}`
                            : '—';
                  const tone = r.status === 'completed' ? 'text-emerald-400' : r.status === 'running' ? 'text-cyan-300' : 'text-amber-300';
                  return (
                    <Tr key={r.id}>
                      <Td numeric className="font-mono text-cyan-300">
                        #{r.id}
                      </Td>
                      <Td className="font-semibold text-slate-100">{r.eval_type}</Td>
                      <Td className={tone}>{r.status}</Td>
                      <Td className="max-w-[14rem] truncate text-soc-textMuted" title={r.model_version}>
                        {r.model_version}
                      </Td>
                      <Td className="text-slate-300">{headline}</Td>
                      <Td numeric className="whitespace-nowrap text-soc-textMuted">
                        {new Date(r.created_at).toLocaleString()}
                      </Td>
                    </Tr>
                  );
                })}
              </tbody>
            </Table>
          </TableWrap>
        )}
      </Card>
    </div>
  );
};
