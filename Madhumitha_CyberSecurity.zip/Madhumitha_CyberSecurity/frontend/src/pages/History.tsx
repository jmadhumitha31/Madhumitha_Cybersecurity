import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, ChevronLeft, ChevronRight, Circle, Inbox, RefreshCw, Repeat } from 'lucide-react';
import { authService } from '../services/authService';
import { auditService, feedbackService, mlService } from '../services/mlService';
import type { AuditEntry, FeedbackRecord, FeedbackStats, ModelInfo, RetrainStatus } from '../types';
import { pct } from '../lib/format';
import { cn } from '../lib/cn';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { TableSkeleton } from '../components/common/LoadingSkeleton';
import { fmtTime } from '../components/observability/utils';
import { Alert } from '../components/ui/Alert';
import { Button, IconButton } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { Select } from '../components/ui/Input';
import { Metric } from '../components/ui/Metric';
import { RoutePageHeader } from '../components/ui/PageHeader';
import { Table, TableWrap, Td, Th, Tr } from '../components/ui/Table';
import { TabPanel, Tabs } from '../components/ui/Tabs';

type Tab = 'feedback' | 'audit';
const AUDIT_PAGE_SIZE = 25;
const AUDIT_ACTIONS = ['LOGIN_SUCCESS', 'LOGIN_FAILED', 'INCIDENT_CREATED', 'INCIDENT_ANALYZED', 'INCIDENT_SEARCH', 'FEEDBACK_SUBMITTED', 'MODEL_RETRAIN_REQUESTED', 'CHAT_COPILOT_QUERY', 'USER_CREATED'];

export const History: React.FC = () => {
  const isAdmin = authService.isAdmin();
  const [tab, setTab] = useState<Tab>('feedback');
  const [stats, setStats] = useState<FeedbackStats | null>(null);
  const [feedback, setFeedback] = useState<FeedbackRecord[]>([]);
  const [model, setModel] = useState<ModelInfo | null>(null);
  const [retrain, setRetrain] = useState<RetrainStatus | null>(null);
  const [audit, setAudit] = useState<{ total: number; items: AuditEntry[] } | null>(null);
  const [auditPage, setAuditPage] = useState(1);
  const [auditAction, setAuditAction] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const timer = useRef<number | undefined>(undefined);

  const watchRetrain = useCallback(() => {
    window.clearInterval(timer.current);
    timer.current = window.setInterval(async () => {
      const r = await mlService.getRetrainStatus().catch(() => null);
      if (r) setRetrain(r);
      if (!r || r.status !== 'running') {
        window.clearInterval(timer.current);
        void loadFeedback().catch(() => undefined);
      }
    }, 2500);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadFeedback = useCallback(async () => {
    const [s, f, m, r] = await Promise.all([
      feedbackService.stats(),
      feedbackService.list(100),
      mlService.getModel().catch(() => null),
      mlService.getRetrainStatus().catch(() => null),
    ]);
    setStats(s);
    setFeedback(f);
    setModel(m);
    setRetrain(r);
    if (r?.status === 'running') watchRetrain();
  }, [watchRetrain]);

  const loadAudit = useCallback(async () => {
    if (!isAdmin) return;
    setAudit(await auditService.list({ page: auditPage, page_size: AUDIT_PAGE_SIZE, action: auditAction || undefined }));
  }, [isAdmin, auditPage, auditAction]);

  const loadAll = useCallback(async () => {
    try {
      await Promise.all([loadFeedback(), loadAudit()]);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [loadFeedback, loadAudit]);

  useEffect(() => {
    void loadAll();
    return () => window.clearInterval(timer.current);
    // Initial load only; the audit tab reloads itself when its page or filter changes (below).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (tab !== 'audit') return;
    loadAudit().catch((e: Error) => setError(e.message));
  }, [tab, loadAudit]);

  const startRetrain = async () => {
    setError(null);
    try {
      setRetrain(await mlService.startRetrain());
      watchRetrain();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Retraining could not be started');
    }
  };

  const res = retrain?.result;
  const tabs = [
    { id: 'feedback' as const, label: 'Feedback & retraining' },
    ...(isAdmin ? [{ id: 'audit' as const, label: 'Audit log', count: audit?.total }] : []),
  ];
  const auditPages = Math.max(1, Math.ceil((audit?.total ?? 0) / AUDIT_PAGE_SIZE));

  return (
    <div className="space-y-6">
      <RoutePageHeader
        path="/history"
        actions={
          <Button
            size="sm"
            icon={RefreshCw}
            loading={refreshing}
            onClick={() => {
              setRefreshing(true);
              void loadAll();
            }}
          >
            Refresh
          </Button>
        }
      />

      <Tabs tabs={tabs} value={tab} onChange={setTab} idPrefix="history" label="Feedback and audit" />
      {error && <Alert variant="error" onDismiss={() => setError(null)}>{error}</Alert>}

      <TabPanel idPrefix="history" id="feedback" active={tab === 'feedback'} className="space-y-6">
        {loading && !stats ? (
          <TableSkeleton rows={4} />
        ) : (
          stats && (
            <>
              <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                <Metric label="Feedback records" value={stats.total.toLocaleString()} />
                <Metric label="Analyst agreement with model" value={pct(stats.analyst_agreement_rate)} />
                <Metric label="Confirmed labels awaiting retrain" value={stats.pending_for_training.toLocaleString()} />
                <Metric label="Active model" value={model?.version ? model.version.slice(0, 24) : 'None'} />
              </div>

              <Card
                title="Continuous improvement: retrain with analyst feedback"
                subtitle="Candidate model = base dataset + all analyst-confirmed incidents. It is promoted only if macro-F1 does not regress (more than 1 point) on the same held-out split."
                action={
                  isAdmin ? (
                    <Button variant="primary" size="sm" icon={Repeat} loading={retrain?.status === 'running'} onClick={startRetrain}>
                      {retrain?.status === 'running' ? 'Retraining…' : 'Retrain model now'}
                    </Button>
                  ) : (
                    <span className="text-xs text-soc-textMuted">Administrators can trigger retraining</span>
                  )
                }
              >
                <div className="space-y-4 text-sm">
                  {retrain?.status === 'running' && (
                    <Alert variant="info" title="Retraining in progress">
                      {retrain.step}
                    </Alert>
                  )}
                  {res && retrain?.status !== 'running' && (
                    <Alert variant={res.decision === 'promoted' ? 'success' : 'warning'} title={`${res.decision.charAt(0).toUpperCase()}${res.decision.slice(1)}${res.candidate_version ? ` · ${res.candidate_version}` : ''}`}>
                      {res.reason && <p>{res.reason}</p>}
                      {res.candidate && (
                        <p className="mt-1 tabular-nums">
                          Candidate: accuracy {pct(res.candidate.accuracy, 2)}, macro-F1 {pct(res.candidate.f1_macro, 2)}
                          {res.previous && ` · previous: accuracy ${pct(res.previous.accuracy, 2)}, macro-F1 ${pct(res.previous.f1_macro, 2)}`} · {res.feedback_incidents_used} analyst-confirmed incident(s) used · {res.duration_s}s
                        </p>
                      )}
                      {res.rule && <p className="mt-1 text-xs opacity-80">{res.rule}</p>}
                    </Alert>
                  )}
                  {model?.versions && model.versions.length > 0 && (
                    <div>
                      <p className="mb-2 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Model versions</p>
                      <ul className="divide-y divide-soc-border/60 text-xs">
                        {model.versions.map((v) => (
                          <li key={v.version} className="flex flex-wrap items-center justify-between gap-2 py-2">
                            <span className={cn('flex items-center gap-2 font-mono', v.active ? 'text-emerald-300' : 'text-slate-400')}>
                              {v.active ? <CheckCircle2 className="h-3.5 w-3.5" aria-label="Active" /> : <Circle className="h-3.5 w-3.5" aria-label="Inactive" />}
                              {v.version}
                            </span>
                            <span className="text-soc-textMuted">
                              {v.trigger} · {v.dataset_source} · macro-F1 {pct(v.macro_f1)}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </Card>

              {stats.top_corrections.length > 0 && (
                <Card title="Most frequent analyst corrections" subtitle="Where the model is wrong according to the people who investigate.">
                  <div className="flex flex-wrap gap-2">
                    {stats.top_corrections.map((c) => (
                      <Badge key={c.correction} variant="medium">
                        {c.correction} × {c.count}
                      </Badge>
                    ))}
                  </div>
                </Card>
              )}

              <Card title="Feedback records" subtitle="Newest first." padded={false}>
                {feedback.length === 0 ? (
                  <EmptyState icon={Inbox} title="No feedback yet" description="Open an incident and use “Submit feedback” to record a verdict." />
                ) : (
                  <TableWrap maxHeight="min(70dvh, 40rem)">
                    <Table caption="Analyst feedback records">
                      <thead>
                        <tr>
                          <Th>Incident</Th>
                          <Th>Type</Th>
                          <Th>Model said</Th>
                          <Th>Analyst confirmed</Th>
                          <Th>By</Th>
                          <Th>Applied</Th>
                          <Th numeric>When</Th>
                        </tr>
                      </thead>
                      <tbody>
                        {feedback.map((f) => (
                          <Tr key={f.id} to={`/incidents/${f.incident_id}`}>
                            <Td>
                              <Link to={`/incidents/${f.incident_id}`} onClick={(e) => e.stopPropagation()} className="font-mono font-semibold text-cyan-300 hover:text-cyan-200">
                                #{f.incident_id}
                              </Link>
                            </Td>
                            <Td className="text-slate-200">{f.feedback_type}</Td>
                            <Td className="text-soc-textMuted">{f.prediction}</Td>
                            <Td className={f.prediction !== f.actual_label ? 'font-medium text-amber-300' : 'text-slate-300'}>{f.actual_label}</Td>
                            <Td className="text-soc-textMuted">{f.username}</Td>
                            <Td>{f.applied ? <Badge variant="low">Yes</Badge> : <span className="text-soc-textMuted">No</span>}</Td>
                            <Td numeric className="whitespace-nowrap text-soc-textMuted">
                              {new Date(f.created_at).toLocaleString()}
                            </Td>
                          </Tr>
                        ))}
                      </tbody>
                    </Table>
                  </TableWrap>
                )}
              </Card>
            </>
          )
        )}
      </TabPanel>

      <TabPanel idPrefix="history" id="audit" active={tab === 'audit' && isAdmin}>
        <Card
          title="Audit log"
          subtitle={`${(audit?.total ?? 0).toLocaleString()} events: logins, investigations, searches, feedback, retraining.`}
          padded={false}
          action={
            <Select compact hideLabel label="Filter by action" className="w-56" value={auditAction} onChange={(e) => { setAuditAction(e.target.value); setAuditPage(1); }}>
              <option value="">All actions</option>
              {AUDIT_ACTIONS.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </Select>
          }
        >
          {!audit ? (
            <div className="p-5">
              <TableSkeleton rows={6} />
            </div>
          ) : audit.items.length === 0 ? (
            <EmptyState icon={Inbox} title="No audit events" description="Nothing matches this filter." />
          ) : (
            <TableWrap maxHeight="min(70dvh, 40rem)">
              <Table caption="Audit log">
                <thead>
                  <tr>
                    <Th>Time</Th>
                    <Th>User</Th>
                    <Th>Action</Th>
                    <Th>Incident</Th>
                    <Th>Provider</Th>
                    <Th>Status</Th>
                    <Th>IP</Th>
                    <Th>Details</Th>
                  </tr>
                </thead>
                <tbody>
                  {audit.items.map((a) => (
                    <Tr key={a.id}>
                      <Td className="whitespace-nowrap text-soc-textMuted">{fmtTime(a.timestamp)}</Td>
                      <Td className="text-slate-300">{a.username}</Td>
                      <Td mono className="text-cyan-300">
                        {a.action}
                      </Td>
                      <Td numeric>{a.incident_id ?? ''}</Td>
                      <Td className="text-soc-textMuted">
                        {a.model_provider}
                        {a.fallback_used ? ' (fallback)' : ''}
                      </Td>
                      <Td className={a.status === 'SUCCESS' ? 'text-emerald-400' : 'text-red-400'}>{a.status}</Td>
                      <Td mono className="text-soc-textMuted">
                        {a.ip_address}
                      </Td>
                      <Td className="max-w-[16rem] text-soc-textMuted">
                        <div className="truncate" title={a.details ? JSON.stringify(a.details) : undefined}>
                          {a.details ? JSON.stringify(a.details) : ''}
                        </div>
                        {a.details?.trace_id && (
                          <Link to={`/observability?trace=${a.details.trace_id}`} className="text-cyan-300 hover:underline">
                            Trace {String(a.details.trace_id).slice(0, 8)}
                          </Link>
                        )}
                      </Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
            </TableWrap>
          )}
          {audit && audit.total > 0 && (
            <nav aria-label="Audit log pagination" className="flex items-center justify-between border-t border-soc-border px-5 py-3 text-xs">
              <span className="tabular-nums text-soc-textMuted">
                Page {auditPage} of {auditPages.toLocaleString()}
              </span>
              <div className="flex gap-2">
                <IconButton label="Previous page" icon={ChevronLeft} variant="secondary" disabled={auditPage <= 1} onClick={() => setAuditPage((p) => p - 1)} />
                <IconButton label="Next page" icon={ChevronRight} variant="secondary" disabled={auditPage >= auditPages} onClick={() => setAuditPage((p) => p + 1)} />
              </div>
            </nav>
          )}
        </Card>
      </TabPanel>
    </div>
  );
};
