import React, { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Activity, AlertTriangle, ArrowLeft, Bot, CheckCircle2, ClipboardList, Cpu, FileSearch, Play, Scale, XCircle } from 'lucide-react';
import { incidentService } from '../services/incidentService';
import { evaluationService } from '../services/evaluationService';
import { authService } from '../services/authService';
import type { AnalysisResponse, AttackPrediction, FeedbackRecord, Incident, IncidentStatus, LLMJudgeResult } from '../types';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { IncidentStatusBadge } from '../components/common/IncidentStatusBadge';
import { ScoreBar } from '../components/common/ScoreBar';
import { LoadingSkeleton } from '../components/common/LoadingSkeleton';
import { WorkflowTimeline } from '../components/investigation/WorkflowTimeline';
import { FeedbackModal } from '../components/feedback/FeedbackModal';
import { ContributionChart } from '../components/explain/ContributionChart';
import { MarkdownContent } from '../components/chat/MarkdownContent';
import { Alert } from '../components/ui/Alert';
import { Button } from '../components/ui/Button';
import { buttonClasses } from '../components/ui/buttonStyles';
import { EmptyState } from '../components/ui/EmptyState';
import { Select } from '../components/ui/Input';
import { DefinitionList, Metric } from '../components/ui/Metric';
import { usePageTitle } from '../lib/usePageTitle';
import { num, pct, protoName, providerLabel, shortModel, statusLabel, utcStamp } from '../lib/format';

const SOURCE_TEXT: Record<string, string> = { dataset: 'Dataset ground truth', analyst: 'Analyst-confirmed', model: 'Model prediction', none: 'Unclassified' };
const STATUSES: IncidentStatus[] = ['NEW', 'INVESTIGATING', 'RESOLVED', 'FALSE_POSITIVE'];

const IncidentView: React.FC<{ id: number }> = ({ id }) => {
  const canWrite = authService.canWrite();
  const [incident, setIncident] = useState<Incident | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null);
  const [liveExplain, setLiveExplain] = useState<AttackPrediction | null>(null);
  const [feedback, setFeedback] = useState<FeedbackRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [judgeResult, setJudgeResult] = useState<LLMJudgeResult | null>(null);
  const [judging, setJudging] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [notice, setNotice] = useState<{ kind: 'success' | 'error'; text: string } | null>(null);

  usePageTitle(incident ? `Incident #${incident.id}` : 'Incident');

  const apply = useCallback((data: Awaited<ReturnType<typeof incidentService.getIncidentDetails>>) => {
    setIncident(data.incident);
    setFeedback(data.feedback || []);
    setAnalysis(data.latest_analysis ? (data.latest_analysis as AnalysisResponse) : null);
    setLoadError(null);
    incidentService
      .explain(data.incident.id)
      .then(setLiveExplain)
      .catch(() => setLiveExplain(null));
  }, []);

  useEffect(() => {
    let alive = true;
    incidentService
      .getIncidentDetails(id)
      .then((data) => alive && apply(data))
      .catch((err: unknown) => alive && setLoadError(err instanceof Error ? err.message : 'Incident could not be loaded'))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [id, apply]);

  /** Re-read the incident after an action changed it (new analysis, feedback). */
  const reload = useCallback(async () => {
    try {
      apply(await incidentService.getIncidentDetails(id));
    } catch (err) {
      setNotice({ kind: 'error', text: err instanceof Error ? err.message : 'Incident could not be refreshed' });
    }
  }, [id, apply]);

  const handleRunInvestigation = async () => {
    if (!incident) return;
    setAnalyzing(true);
    setNotice(null);
    try {
      setAnalysis(await incidentService.analyzeIncident(incident.id));
      await reload();
    } catch (err) {
      setNotice({ kind: 'error', text: `Investigation failed: ${err instanceof Error ? err.message : 'unknown error'}` });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleRunJudge = async () => {
    if (!incident) return;
    setJudging(true);
    try {
      setJudgeResult(await evaluationService.runLLMJudge(incident.id));
    } catch (err) {
      setNotice({ kind: 'error', text: `LLM-as-judge error: ${err instanceof Error ? err.message : 'unknown error'}` });
    } finally {
      setJudging(false);
    }
  };

  const handleStatus = async (status: string) => {
    if (!incident) return;
    try {
      setIncident(await incidentService.updateStatus(incident.id, status));
    } catch (err) {
      setNotice({ kind: 'error', text: err instanceof Error ? err.message : 'Status could not be updated' });
    }
  };

  if (loading && !incident) return <LoadingSkeleton rows={8} height="h-16" />;
  if (!incident) {
    return (
      <div className="space-y-4">
        <Link to="/incidents" className={buttonClasses('ghost', 'sm')}>
          <ArrowLeft className="h-4 w-4" aria-hidden />
          Back to incidents
        </Link>
        <Alert variant="error" title="Incident not found">
          {loadError || `There is no incident #${id}.`}
        </Alert>
      </div>
    );
  }

  const pred: AttackPrediction | null = analysis?.attack_prediction ?? liveExplain;
  const explanation = liveExplain?.explanation ?? analysis?.attack_prediction?.explanation ?? null;
  const risk = analysis?.risk_assessment;
  const mismatch = !!incident.ground_truth_label && !!incident.predicted_attack_type && incident.ground_truth_label !== incident.predicted_attack_type;
  const failedAttempts = (analysis?.llm_attempts || []).filter((a) => !a.ok);
  const telemetry: { label: string; value: string }[] = [
    { label: 'Duration', value: `${num(incident.flow_duration, 0)} µs` },
    { label: 'Packets / s', value: num(incident.flow_packets_per_sec) },
    { label: 'Bytes / s', value: num(incident.flow_bytes_per_sec) },
    { label: 'Fwd / Bwd packets', value: `${num(incident.total_fwd_packets, 0)} / ${num(incident.total_bwd_packets, 0)}` },
    { label: 'Fwd / Bwd bytes', value: `${num(incident.total_length_fwd, 0)} / ${num(incident.total_length_bwd, 0)}` },
    { label: 'SYN / RST / ACK', value: `${incident.syn_count} / ${incident.rst_count} / ${incident.ack_count}` },
    { label: 'Mean packet length', value: `${num(incident.packet_length_mean)} B` },
    { label: 'Mean inter-arrival', value: `${num(incident.flow_iat_mean, 0)} µs` },
    { label: 'Active / idle mean', value: `${num(incident.active_mean, 0)} / ${num(incident.idle_mean, 0)}` },
  ];

  return (
    <div className="space-y-6">
      <Link to="/incidents" className="inline-flex items-center gap-1.5 text-sm text-soc-textMuted transition-colors hover:text-cyan-300">
        <ArrowLeft className="h-4 w-4" aria-hidden />
        Back to incidents
      </Link>

      {/* Identity: what is this, how bad is it, and where did the classification come from */}
      <header className="flex flex-wrap items-start justify-between gap-4 rounded-xl border border-soc-border bg-soc-surface p-5">
        <div className="min-w-0 space-y-2">
          <h1 className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
            <span className="break-all font-mono text-lg font-semibold text-cyan-300">{incident.flow_id}</span>
            <span className="text-lg font-semibold text-slate-50">{incident.attack_type}</span>
          </h1>
          <div className="flex flex-wrap items-center gap-2">
            <SeverityBadge level={incident.risk_level} priority={incident.priority} size="md" />
            {incident.risk_score != null && <Badge variant="cyan" size="md">Risk {incident.risk_score.toFixed(1)}</Badge>}
            <IncidentStatusBadge status={incident.status} />
            <Badge variant="neutral">{SOURCE_TEXT[incident.label_source] || incident.label_source}</Badge>
            {incident.data_source === 'synthetic-demo' && <Badge variant="medium">Synthetic demo data</Badge>}
          </div>
          <p className="font-mono text-xs text-soc-textMuted">
            {incident.source_ip}:{incident.source_port} → {incident.destination_ip}:{incident.destination_port} · {protoName(incident.protocol)}
            {incident.timestamp ? ` · ${utcStamp(incident.timestamp)}` : ''}
          </p>
          {incident.original_label && <p className="text-xs text-soc-textMuted">Original dataset label: {incident.original_label}</p>}
        </div>

        {analysis && (
          <div className="flex items-center gap-3 rounded-lg bg-soc-card/70 px-4 py-3 text-xs">
            <Cpu className="h-4 w-4 text-cyan-400" aria-hidden />
            <div>
              <p className="font-semibold text-slate-100">{providerLabel(analysis.llm_provider)}</p>
              {analysis.llm_model && analysis.llm_provider !== 'heuristic_rule_engine' && <p className="text-soc-textMuted">{shortModel(analysis.llm_model)}</p>}
            </div>
            {analysis.fallback_used && <Badge variant="high">Fallback</Badge>}
            {analysis.trace_id && (
              <Link to={`/observability?trace=${analysis.trace_id}`} className="inline-flex items-center gap-1 text-cyan-300 hover:underline" title="Why this analysis? Open its full trace">
                <Activity className="h-3.5 w-3.5" aria-hidden />
                Trace {analysis.trace_id.slice(0, 8)}
              </Link>
            )}
          </div>
        )}
      </header>

      {/* Actions stay in reach while reading a long investigation */}
      <div
        role="toolbar"
        aria-label="Incident actions"
        className="z-20 flex flex-wrap items-end justify-between gap-3 rounded-xl border border-soc-border bg-soc-surface/95 p-3 shadow-lg shadow-black/30 backdrop-blur lg:sticky lg:top-0"
      >
        <div className="flex flex-wrap items-center gap-2">
          <Link to={`/chat?incidentId=${incident.id}`} className={buttonClasses('secondary', 'sm')}>
            <Bot className="h-4 w-4" aria-hidden />
            Ask copilot
          </Link>
          <Link to={`/observability?incident=${incident.id}`} className={buttonClasses('secondary', 'sm')} title="Every query made about this incident">
            <Activity className="h-4 w-4" aria-hidden />
            Traces
          </Link>
          {canWrite && (
            <>
              <Button size="sm" icon={ClipboardList} onClick={() => setFeedbackOpen(true)}>
                Submit feedback
              </Button>
              {analysis && (
                <Button size="sm" icon={Scale} loading={judging} onClick={handleRunJudge}>
                  {judging ? 'Judging…' : 'Run LLM-as-judge'}
                </Button>
              )}
            </>
          )}
        </div>
        {canWrite && (
          <div className="flex flex-wrap items-end gap-3">
            <Select compact label="Status" className="w-44" value={incident.status} onChange={(e) => void handleStatus(e.target.value)}>
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {statusLabel(s)}
                </option>
              ))}
            </Select>
            <Button variant="primary" icon={Play} loading={analyzing} onClick={handleRunInvestigation}>
              {analyzing ? 'Running agents…' : analysis ? 'Re-run AI investigation' : 'Run AI investigation'}
            </Button>
          </div>
        )}
      </div>

      {notice && (
        <Alert variant={notice.kind} onDismiss={() => setNotice(null)}>
          {notice.text}
        </Alert>
      )}

      {mismatch && (
        <Alert variant="warning" title="Model disagrees with the recorded label">
          Ground truth is <strong>{incident.ground_truth_label}</strong>, the model predicted <strong>{incident.predicted_attack_type}</strong>
          {incident.prediction_confidence != null ? ` (${pct(incident.prediction_confidence, 0)})` : ''}. The ground truth was kept.
        </Alert>
      )}

      {judgeResult && (
        <Card title="LLM-as-judge" badge={judgeResult.judge_model ? <Badge variant="purple">Judge: {judgeResult.judge_model}</Badge> : undefined}>
          {judgeResult.status === 'ok' && judgeResult.scores ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
                <Metric label="Correctness" value={pct(judgeResult.scores.correctness, 0)} tone="text-emerald-400" />
                <Metric label="Relevance" value={pct(judgeResult.scores.relevance, 0)} tone="text-emerald-400" />
                <Metric label="Reasoning" value={pct(judgeResult.scores.reasoning_quality, 0)} tone="text-emerald-400" />
                <Metric label="Recommendations" value={pct(judgeResult.scores.recommendation_quality, 0)} tone="text-emerald-400" />
                <Metric
                  label="Verdict"
                  value={judgeResult.scores.verdict}
                  tone={judgeResult.scores.verdict === 'ACCEPTED' ? 'text-emerald-400' : judgeResult.scores.verdict === 'REJECTED' ? 'text-red-400' : 'text-amber-400'}
                />
              </div>
              <div className="space-y-2 border-l-2 border-purple-700 pl-4 text-sm text-slate-300">
                <p>
                  <span className="mr-2 font-semibold text-purple-300">Critique</span>
                  {judgeResult.scores.critique}
                </p>
                {judgeResult.scores.unsupported_claims && judgeResult.scores.unsupported_claims.length > 0 && (
                  <p className="text-amber-300">Unsupported claims: {judgeResult.scores.unsupported_claims.join(' | ')}</p>
                )}
                <p className="text-xs text-soc-textMuted">
                  Generator: {judgeResult.generator_model} · independent judge: {judgeResult.independent ? 'yes' : 'no (same model)'}
                </p>
              </div>
            </div>
          ) : (
            <p className="text-sm text-amber-300">
              {judgeResult.status === 'unavailable' ? 'No judge LLM is reachable, so no scores were produced (none are invented).' : 'The judge returned an unparsable verdict; no scores were produced.'}
              {judgeResult.error && <span className="mt-1 block text-soc-textMuted">{judgeResult.error}</span>}
            </p>
          )}
        </Card>
      )}

      <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_22rem]">
        {/* ------------------------------------------------------------- main: what to read and do, in that order */}
        <div className="min-w-0 space-y-6">
          <Card
            title="SOC technical analysis"
            subtitle="Evidence-grounded reasoning with mandatory analyst review."
            badge={analysis ? <Badge variant="cyan">{providerLabel(analysis.llm_provider)}</Badge> : undefined}
          >
            {analysis?.analysis ? (
              <MarkdownContent content={analysis.analysis} />
            ) : (
              <EmptyState
                icon={FileSearch}
                title="No investigation has been run yet"
                description={canWrite ? 'Run the AI investigation to get an evidence-grounded analysis and recommended actions.' : 'An analyst has not run an investigation for this incident yet.'}
                action={
                  canWrite ? (
                    <Button variant="primary" icon={Play} loading={analyzing} onClick={handleRunInvestigation}>
                      Run AI investigation
                    </Button>
                  ) : undefined
                }
              />
            )}
          </Card>

          <Card title="Recommended analyst actions" subtitle="Human in the loop: containment steps are proposals that require your approval.">
            {analysis?.recommendations && analysis.recommendations.length > 0 ? (
              <ol className="space-y-2">
                {analysis.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start gap-3 rounded-lg bg-soc-card/60 p-3 text-sm text-slate-200">
                    <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-cyan-900 text-2xs font-bold text-cyan-100" aria-hidden>
                      {i + 1}
                    </span>
                    <span className="leading-relaxed">{rec}</span>
                  </li>
                ))}
              </ol>
            ) : (
              <p className="py-4 text-center text-sm text-soc-textMuted">Recommendations appear once an investigation has run.</p>
            )}
          </Card>

          <Card title="Why this verdict?" subtitle="Per-flow SHAP attribution and the evidence statements behind the model's call.">
            {explanation ? <ContributionChart explanation={explanation} /> : <p className="py-4 text-sm text-soc-textMuted">Explanation unavailable (no model loaded).</p>}
            {pred?.indicators && pred.indicators.length > 0 && (
              <ul className="mt-4 space-y-1.5 border-t border-soc-border pt-4 text-sm text-slate-300">
                {pred.indicators.map((ind, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="text-cyan-400" aria-hidden>
                      •
                    </span>
                    <span>{ind}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card title="Similar historical incidents" subtitle="Hybrid retrieval (sentence embeddings + BM25) over labelled history; the query is built from telemetry only.">
            {analysis ? (
              analysis.historical_matches?.length > 0 ? (
                <ul className="space-y-2">
                  {analysis.historical_matches.map((m) => (
                    <li key={m.incident_id}>
                      <Link
                        to={`/incidents/${m.incident_id}`}
                        className="block rounded-lg border border-soc-border bg-soc-card/50 p-3 transition-colors hover:border-soc-borderLight hover:bg-soc-card"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="break-all font-mono text-xs font-semibold text-cyan-300">{m.flow_id}</span>
                          <span className="flex items-center gap-2 text-sm">
                            <span className="text-slate-200">{m.attack_type}</span>
                            <Badge variant="cyan">{pct(m.hybrid_score ?? m.similarity_score ?? 0, 1)}</Badge>
                          </span>
                        </div>
                        <p className="mt-1.5 text-xs text-soc-textMuted">
                          Semantic {pct(m.semantic_score ?? 0, 0)} · keyword {pct(m.keyword_score ?? 0, 0)}
                          {m.shared_characteristics?.length ? ` · ${m.shared_characteristics.join('; ')}` : ''}
                        </p>
                      </Link>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="py-4 text-center text-sm text-soc-textMuted">No sufficiently similar historical incidents were found.</p>
              )
            ) : (
              <p className="py-4 text-center text-sm text-soc-textMuted">Run the AI investigation to retrieve similar incidents.</p>
            )}
          </Card>

          {/* Provenance for people who want to audit the run; collapsed so it does not bury the analysis */}
          <Card
            title="How this was produced"
            subtitle="LangGraph stages: detection → analysis (RAG) → risk → response → output validation."
            badge={<Badge variant="cyan">{analysis?.execution_trace?.length || 0} stages</Badge>}
            collapsible
            defaultOpen={false}
          >
            <WorkflowTimeline trace={analysis?.execution_trace || []} totalTimeMs={analysis?.execution_time_ms} />
            {failedAttempts.length > 0 && (
              <Alert variant="warning" title="LLM failover log" className="mt-4">
                <ul className="space-y-0.5 text-xs">
                  {failedAttempts.map((a, i) => (
                    <li key={i}>
                      {a.provider}
                      {a.model ? ` / ${a.model}` : ''}: {a.status ? `HTTP ${a.status} ` : ''}
                      {String(a.error || '').slice(0, 120)}
                    </li>
                  ))}
                </ul>
              </Alert>
            )}
            {analysis?.quality_checks && analysis.quality_checks.length > 0 && (
              <ul className="mt-4 grid grid-cols-1 gap-2 border-t border-soc-border pt-4 md:grid-cols-2">
                {analysis.quality_checks.map((c) => (
                  <li key={c.check} className="flex items-start gap-2 text-xs" title={c.detail}>
                    {c.passed ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" aria-label="Passed" /> : <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-400" aria-label="Failed" />}
                    <span className={c.passed ? 'text-slate-300' : 'text-red-300'}>
                      <span className="font-medium">{c.check.replace(/_/g, ' ')}</span>: <span className="text-soc-textMuted">{c.detail}</span>
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {feedback.length > 0 && (
            <Card title="Analyst feedback history">
              <ul className="divide-y divide-soc-border/60 text-sm">
                {feedback.map((f) => (
                  <li key={f.id} className="py-3 first:pt-0 last:pb-0">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <span className="text-slate-200">
                        <strong>{f.feedback_type}</strong> → {f.actual_label} <span className="text-soc-textMuted">(model said {f.prediction})</span>
                      </span>
                      <span className="text-xs text-soc-textMuted">
                        {f.username} · {new Date(f.created_at).toLocaleString()}
                      </span>
                    </div>
                    {f.analyst_feedback && <p className="mt-1 text-soc-textMuted">{f.analyst_feedback}</p>}
                    {f.applied && <p className="mt-1 text-xs text-emerald-400">Applied as ground truth</p>}
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>

        {/* ------------------------------------------------------------- rail: the numbers behind the call */}
        <div className="min-w-0 space-y-6">
          <Card title="Model verdict" subtitle={pred?.model_version ? `Model ${pred.model_version}` : 'ML triage'}>
            {incident.predicted_attack_type || pred ? (
              <div className="space-y-4 text-sm">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-soc-textMuted">Predicted class</span>
                  <span className="text-right font-semibold text-slate-50">{incident.predicted_attack_type ?? pred?.attack_type}</span>
                </div>
                <ScoreBar label="Class confidence" value={incident.prediction_confidence ?? pred?.confidence} tone="cyan" />
                <ScoreBar label="Intrusion probability" value={incident.intrusion_probability ?? pred?.intrusion_probability} tone="red" hint="Independent calibrated binary model: P(flow is malicious)" />
                <ScoreBar label="Anomaly vs benign baseline" value={incident.anomaly_score ?? pred?.anomaly_score} tone="amber" hint="Isolation Forest fitted on benign traffic only; share of benign flows that look less unusual" />
                {pred?.low_confidence && (
                  <p className="flex items-start gap-2 text-xs text-amber-300">
                    <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
                    Low classifier confidence: treat the label as a hypothesis.
                  </p>
                )}
                {pred?.top_classes && pred.top_classes.length > 0 && (
                  <div className="border-t border-soc-border pt-3">
                    <p className="mb-1 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Class probabilities</p>
                    <DefinitionList items={pred.top_classes.slice(0, 4).map((t) => ({ label: t.attack_type, value: pct(t.probability, 1) }))} />
                  </div>
                )}
              </div>
            ) : (
              <p className="text-sm text-soc-textMuted">No model output stored for this incident yet. Run the AI investigation.</p>
            )}
          </Card>

          <Card title="Risk & priority" subtitle="Transparent multi-factor score (0–100).">
            <DefinitionList
              items={[
                { label: 'Severity', value: <SeverityBadge level={incident.risk_level} /> },
                { label: 'SOC priority', value: incident.priority },
                { label: 'Risk score', value: incident.risk_score != null ? incident.risk_score.toFixed(1) : 'N/A' },
              ]}
            />
            {risk?.components && (
              <div className="mt-3">
                <p className="mb-1 text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Components</p>
                <DefinitionList items={Object.entries(risk.components).map(([k, v]) => ({ label: k.replace(/_/g, ' '), value: Number(v).toFixed(3) }))} />
              </div>
            )}
            {risk?.factors && risk.factors.length > 0 && (
              <ul className="mt-3 space-y-1 border-t border-soc-border pt-3 text-xs text-slate-300">
                {risk.factors.map((f, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="text-cyan-400" aria-hidden>
                      •
                    </span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card title="Network flow telemetry" subtitle="CIC-IDS2017 flow features.">
            <DefinitionList items={telemetry} />
          </Card>
        </div>
      </div>

      <FeedbackModal
        incidentId={incident.id}
        currentPrediction={incident.predicted_attack_type || incident.attack_type}
        isOpen={feedbackOpen}
        onClose={() => setFeedbackOpen(false)}
        onSuccess={(m) => {
          setNotice({ kind: 'success', text: m });
          void reload();
        }}
      />
    </div>
  );
};

/** Keyed by id, so navigating between incidents (e.g. via "similar incidents") starts from a clean state. */
export const IncidentDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const numeric = Number(id);
  if (!id || !Number.isInteger(numeric) || numeric < 1) {
    return (
      <Alert variant="error" title="Invalid incident id">
        “{id}” is not a valid incident number.
      </Alert>
    );
  }
  return <IncidentView key={numeric} id={numeric} />;
};
