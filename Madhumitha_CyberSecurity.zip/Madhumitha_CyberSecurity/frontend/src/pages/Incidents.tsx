import React, { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Plus, Search, SearchX, X } from 'lucide-react';
import { incidentService, type IncidentQuery } from '../services/incidentService';
import { authService } from '../services/authService';
import { ATTACK_CLASSES, type Incident } from '../types';
import { Card } from '../components/common/Card';
import { Badge, type BadgeVariant } from '../components/common/Badge';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { IncidentStatusBadge } from '../components/common/IncidentStatusBadge';
import { TableSkeleton } from '../components/common/LoadingSkeleton';
import { Alert } from '../components/ui/Alert';
import { Button, IconButton } from '../components/ui/Button';
import { buttonClasses } from '../components/ui/buttonStyles';
import { EmptyState } from '../components/ui/EmptyState';
import { Input, Select } from '../components/ui/Input';
import { RoutePageHeader } from '../components/ui/PageHeader';
import { Table, TableWrap, Td, Th, Tr } from '../components/ui/Table';
import { cn } from '../lib/cn';
import { num, statusLabel } from '../lib/format';

const PAGE_SIZE = 15;
const SORTS = ['risk', 'priority', 'timestamp', 'created_at'] as const;
type Sort = (typeof SORTS)[number];
const SORT_LABEL: Record<Sort, string> = { risk: 'Risk score', priority: 'Priority', timestamp: 'Flow time', created_at: 'Ingestion time' };
const SORT_SENTENCE: Record<Sort, string> = {
  risk: 'risk score (triage order)',
  priority: 'priority',
  timestamp: 'flow time',
  created_at: 'ingestion time',
};

const LABEL_SOURCE: Record<string, { text: string; variant: BadgeVariant }> = {
  dataset: { text: 'Dataset label', variant: 'neutral' },
  analyst: { text: 'Analyst-confirmed', variant: 'low' },
  model: { text: 'Model prediction', variant: 'cyan' },
  none: { text: 'Unclassified', variant: 'neutral' },
};

const FILTER_KEYS = ['attack_type', 'risk_level', 'status', 'label_source', 'search'] as const;
type FilterKey = (typeof FILTER_KEYS)[number];
const FILTER_NAME: Record<FilterKey, string> = {
  attack_type: 'Attack type',
  risk_level: 'Severity',
  status: 'Status',
  label_source: 'Label source',
  search: 'Search',
};

interface Result {
  key: string;
  items: Incident[];
  total: number;
  totalPages: number;
  error: string | null;
}

export const Incidents: React.FC = () => {
  const [params, setParams] = useSearchParams();
  const canWrite = authService.canWrite();
  const [result, setResult] = useState<Result | null>(null);
  const [reloadTick, setReloadTick] = useState(0);

  // The URL is the single source of truth for filters, sort and page, so views are linkable and survive Back.
  const page = Math.max(1, Number(params.get('page')) || 1);
  const rawSort = params.get('sort');
  const sort: Sort = (SORTS as readonly string[]).includes(rawSort ?? '') ? (rawSort as Sort) : 'risk';
  const filters = {
    attack_type: params.get('attack_type') ?? '',
    risk_level: params.get('risk_level') ?? '',
    status: params.get('status') ?? '',
    label_source: params.get('label_source') ?? '',
    search: params.get('search') ?? '',
  };
  const queryKey = `${params.toString()}#${reloadTick}`;

  const update = (patch: Record<string, string>) => {
    const next = new URLSearchParams(params);
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    if (!('page' in patch)) next.delete('page');
    setParams(next, { replace: true });
  };

  // Typing updates the box immediately but the URL (and therefore the request) only after a short pause.
  const [searchInput, setSearchInput] = useState(filters.search);
  useEffect(() => {
    if (searchInput.trim() === filters.search) return;
    const t = window.setTimeout(() => {
      const next = new URLSearchParams(params);
      if (searchInput.trim()) next.set('search', searchInput.trim());
      else next.delete('search');
      next.delete('page');
      setParams(next, { replace: true });
    }, 350);
    return () => window.clearTimeout(t);
  }, [searchInput, filters.search, params, setParams]);

  useEffect(() => {
    let alive = true;
    const query: IncidentQuery = {
      page,
      page_size: PAGE_SIZE,
      sort,
      search: filters.search || undefined,
      attack_type: filters.attack_type || undefined,
      risk_level: filters.risk_level || undefined,
      status: filters.status || undefined,
      label_source: filters.label_source || undefined,
    };
    incidentService
      .getIncidents(query)
      .then((res) => alive && setResult({ key: queryKey, items: res.items, total: res.pagination.total, totalPages: res.pagination.total_pages, error: null }))
      .catch((err: Error) => alive && setResult((prev) => ({ key: queryKey, items: prev?.items ?? [], total: prev?.total ?? 0, totalPages: prev?.totalPages ?? 1, error: err.message })));
    return () => {
      alive = false;
    };
    // `filters` is derived from `params`, which `queryKey` already captures.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queryKey]);

  const loading = result?.key !== queryKey;
  const items = result?.items ?? [];
  const total = result?.total ?? 0;
  const totalPages = Math.max(1, result?.totalPages ?? 1);
  const active = FILTER_KEYS.filter((k) => filters[k]);
  const firstShown = total === 0 ? 0 : (page - 1) * PAGE_SIZE + 1;
  const lastShown = Math.min(total, page * PAGE_SIZE);

  const clearAll = () => {
    setSearchInput('');
    const next = new URLSearchParams(params);
    FILTER_KEYS.forEach((k) => next.delete(k));
    next.delete('page');
    setParams(next, { replace: true });
  };

  const chipValue = (k: FilterKey): string => (k === 'status' ? statusLabel(filters[k]) : k === 'label_source' ? (LABEL_SOURCE[filters[k]]?.text ?? filters[k]) : filters[k]);

  return (
    <div className="space-y-6">
      <RoutePageHeader
        path="/incidents"
        description={
          result
            ? `${total.toLocaleString()} flow record${total === 1 ? '' : 's'} match the current filters, sorted by ${SORT_SENTENCE[sort]}.`
            : 'Every stored network flow, filterable by classification, severity, status and label source.'
        }
        actions={
          canWrite && (
            <Link to="/add-incident" className={buttonClasses('primary', 'md')}>
              <Plus className="h-4 w-4" aria-hidden />
              Add network flow
            </Link>
          )
        }
      />

      <Card>
        <form
          role="search"
          aria-label="Filter incidents"
          onSubmit={(e) => {
            e.preventDefault();
            update({ search: searchInput.trim() });
          }}
          className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-[minmax(14rem,2fr)_repeat(5,minmax(0,1fr))]"
        >
          <Input
            label="Search"
            icon={Search}
            type="search"
            className="sm:col-span-2 lg:col-span-3 xl:col-span-1"
            placeholder="Flow ID, IP address, attack category…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
          <Select label="Attack type" value={filters.attack_type} onChange={(e) => update({ attack_type: e.target.value })}>
            <option value="">All types</option>
            {ATTACK_CLASSES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </Select>
          <Select label="Severity" value={filters.risk_level} onChange={(e) => update({ risk_level: e.target.value })}>
            <option value="">All severities</option>
            <option value="Critical">Critical (P1)</option>
            <option value="High">High (P2)</option>
            <option value="Medium">Medium (P3)</option>
            <option value="Low">Low (P4)</option>
          </Select>
          <Select label="Status" value={filters.status} onChange={(e) => update({ status: e.target.value })}>
            <option value="">All statuses</option>
            {(['NEW', 'INVESTIGATING', 'RESOLVED', 'FALSE_POSITIVE'] as const).map((s) => (
              <option key={s} value={s}>
                {statusLabel(s)}
              </option>
            ))}
          </Select>
          <Select label="Label source" value={filters.label_source} onChange={(e) => update({ label_source: e.target.value })}>
            <option value="">Any source</option>
            <option value="dataset">Dataset ground truth</option>
            <option value="model">Model-classified</option>
            <option value="analyst">Analyst-confirmed</option>
          </Select>
          <Select label="Sort by" value={sort} onChange={(e) => update({ sort: e.target.value })}>
            {SORTS.map((s) => (
              <option key={s} value={s}>
                {SORT_LABEL[s]}
              </option>
            ))}
          </Select>
        </form>

        {active.length > 0 && (
          <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-soc-border pt-4">
            <span className="text-xs text-soc-textMuted">Active filters:</span>
            {active.map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => {
                  if (k === 'search') setSearchInput('');
                  update({ [k]: '' });
                }}
                aria-label={`Remove filter ${FILTER_NAME[k]}: ${chipValue(k)}`}
                className="inline-flex items-center gap-1.5 rounded-full border border-cyan-800/60 bg-cyan-950/50 py-1 pl-3 pr-2 text-xs text-cyan-100 transition-colors hover:border-cyan-600"
              >
                <span className="text-cyan-300/80">{FILTER_NAME[k]}:</span> {chipValue(k)}
                <X className="h-3.5 w-3.5" aria-hidden />
              </button>
            ))}
            <Button variant="ghost" size="sm" onClick={clearAll}>
              Clear all
            </Button>
          </div>
        )}
      </Card>

      {result?.error && (
        <Alert
          variant="error"
          title="Could not load incidents"
          action={
            <Button size="sm" onClick={() => setReloadTick((t) => t + 1)}>
              Retry
            </Button>
          }
        >
          {result.error}
        </Alert>
      )}

      <Card padded={false}>
        {!result ? (
          <div className="p-5">
            <TableSkeleton rows={8} />
          </div>
        ) : items.length === 0 && !result.error ? (
          <EmptyState
            icon={SearchX}
            title="No incidents match these filters"
            description="Try removing a filter or searching for a different term."
            action={
              active.length > 0 ? (
                <Button size="sm" onClick={clearAll}>
                  Clear all filters
                </Button>
              ) : undefined
            }
          />
        ) : (
          <>
            <div className={cn('transition-opacity', loading && 'opacity-60')} aria-busy={loading}>
              <TableWrap maxHeight="min(70dvh, 52rem)">
                <Table caption="Incidents">
                  <thead>
                    <tr>
                      <Th>Flow</Th>
                      <Th>Classification</Th>
                      <Th>Severity</Th>
                      <Th numeric>Risk</Th>
                      <Th>Source</Th>
                      <Th>Destination</Th>
                      <Th numeric>Pkts/s</Th>
                      <Th>Status</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((inc) => {
                      const source = LABEL_SOURCE[inc.label_source] ?? LABEL_SOURCE.none;
                      return (
                        <Tr key={inc.id} to={`/incidents/${inc.id}`}>
                          <Td mono className="max-w-[16rem]">
                            <Link to={`/incidents/${inc.id}`} onClick={(e) => e.stopPropagation()} title={inc.flow_id} className="block truncate font-semibold text-cyan-300 hover:text-cyan-200">
                              #{inc.id} {inc.flow_id}
                            </Link>
                          </Td>
                          <Td>
                            <div className="font-medium text-slate-100">{inc.attack_type}</div>
                            <Badge variant={source.variant} className="mt-1">
                              {source.text}
                            </Badge>
                          </Td>
                          <Td>
                            <SeverityBadge level={inc.risk_level} priority={inc.priority} />
                          </Td>
                          <Td numeric className="font-semibold text-slate-100">
                            {inc.risk_score != null ? inc.risk_score.toFixed(1) : 'N/A'}
                          </Td>
                          <Td mono className="whitespace-nowrap text-soc-textMuted">
                            {inc.source_ip}:{inc.source_port}
                          </Td>
                          <Td mono className="whitespace-nowrap text-soc-textMuted">
                            {inc.destination_ip}:{inc.destination_port}
                          </Td>
                          <Td numeric>{num(Number(inc.flow_packets_per_sec), 1)}</Td>
                          <Td>
                            <IncidentStatusBadge status={inc.status} />
                          </Td>
                        </Tr>
                      );
                    })}
                  </tbody>
                </Table>
              </TableWrap>
            </div>

            <nav aria-label="Pagination" className="flex flex-wrap items-center justify-between gap-3 border-t border-soc-border px-5 py-3 text-xs">
              <span className="tabular-nums text-soc-textMuted">
                Showing {firstShown.toLocaleString()}–{lastShown.toLocaleString()} of {total.toLocaleString()}
              </span>
              <div className="flex items-center gap-2">
                <span className="tabular-nums text-soc-textMuted">
                  Page {page} of {totalPages.toLocaleString()}
                </span>
                <IconButton label="Previous page" icon={ChevronLeft} variant="secondary" disabled={page <= 1 || loading} onClick={() => update({ page: String(page - 1) })} />
                <IconButton label="Next page" icon={ChevronRight} variant="secondary" disabled={page >= totalPages || loading} onClick={() => update({ page: String(page + 1) })} />
              </div>
            </nav>
          </>
        )}
      </Card>
    </div>
  );
};
