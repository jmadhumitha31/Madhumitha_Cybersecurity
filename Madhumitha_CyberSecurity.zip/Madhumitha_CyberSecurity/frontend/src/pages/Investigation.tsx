import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink, Play } from 'lucide-react';
import { incidentService } from '../services/incidentService';
import { authService } from '../services/authService';
import type { AnalysisResponse, Incident } from '../types';
import { pct, providerLabel, shortModel } from '../lib/format';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { ScoreBar } from '../components/common/ScoreBar';
import { LoadingSkeleton } from '../components/common/LoadingSkeleton';
import { WorkflowTimeline } from '../components/investigation/WorkflowTimeline';
import { ContributionChart } from '../components/explain/ContributionChart';
import { MarkdownContent } from '../components/chat/MarkdownContent';
import { Alert } from '../components/ui/Alert';
import { Button } from '../components/ui/Button';
import { buttonClasses } from '../components/ui/buttonStyles';
import { EmptyState } from '../components/ui/EmptyState';
import { Select } from '../components/ui/Input';
import { RoutePageHeader } from '../components/ui/PageHeader';

export const Investigation: React.FC = () => {
  const canWrite = authService.canWrite();
  const [incidents, setIncidents] = useState<Incident[] | null>(null);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    incidentService
      .getQueue(30)
      .then((q) => {
        if (!alive) return;
        setIncidents(q);
        if (q.length) setSelectedId(q[0].id);
      })
      .catch((e: Error) => {
        if (!alive) return;
        setIncidents([]);
        setError(e.message);
      });
    return () => {
      alive = false;
    };
  }, []);

  const run = async () => {
    if (!selectedId) return;
    setRunning(true);
    setError(null);
    try {
      setAnalysis(await incidentService.analyzeIncident(selectedId));
    } catch (e) {
      setError(`Investigation failed: ${e instanceof Error ? e.message : 'unknown error'}`);
    } finally {
      setRunning(false);
    }
  };

  const sel = incidents?.find((i) => i.id === selectedId);
  const pred = analysis?.attack_prediction;

  return (
    <div className="space-y-6">
      <RoutePageHeader path="/investigation" />

      <Card>
        {incidents === null ? (
          <LoadingSkeleton rows={1} height="h-9" />
        ) : incidents.length === 0 ? (
          <EmptyState title="No open incidents to investigate" description="Everything in the queue has been handled, or the queue could not be loaded." />
        ) : (
          <div className="flex flex-wrap items-end justify-between gap-4">
            <Select
              label="Open incident (highest risk first)"
              className="min-w-[18rem] flex-1"
              value={selectedId ?? ''}
              onChange={(e) => {
                setSelectedId(parseInt(e.target.value));
                setAnalysis(null);
              }}
            >
              {incidents.map((inc) => (
                <option key={inc.id} value={inc.id}>
                  #{inc.id} [{inc.priority} {inc.risk_score?.toFixed(0)}] {inc.attack_type} · {inc.source_ip} → {inc.destination_ip}:{inc.destination_port}
                </option>
              ))}
            </Select>
            {canWrite ? (
              <Button variant="primary" icon={Play} loading={running} disabled={!selectedId} onClick={run}>
                {running ? 'Running agents…' : 'Execute workflow'}
              </Button>
            ) : (
              <p className="text-sm text-soc-textMuted">Your role is read-only: investigations cannot be started.</p>
            )}
          </div>
        )}
      </Card>

      {error && <Alert variant="error" onDismiss={() => setError(null)}>{error}</Alert>}

      {sel && !analysis && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-soc-border bg-soc-surface px-5 py-4 text-sm">
          <div>
            <Link to={`/incidents/${sel.id}`} className="font-mono font-semibold text-cyan-300 hover:underline">
              #{sel.id}
            </Link>
            <span className="ml-3 font-mono text-xs text-slate-300">
              {sel.source_ip} → {sel.destination_ip}:{sel.destination_port}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-soc-textMuted">
              ML triage: {sel.attack_type} ({sel.prediction_confidence != null ? pct(sel.prediction_confidence, 0) : '?'})
            </span>
            <SeverityBadge level={sel.risk_level} suffix={sel.risk_score != null ? `score ${sel.risk_score.toFixed(1)}` : undefined} />
          </div>
        </div>
      )}

      {analysis && pred && (
        <>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <SeverityBadge level={analysis.risk_assessment.risk_level} priority={analysis.risk_assessment.priority} size="md" suffix={`· ${analysis.risk_assessment.risk_score}`} />
              <span className="font-semibold text-slate-50">{pred.attack_type}</span>
              <Badge variant="cyan">
                {providerLabel(analysis.llm_provider)}
                {analysis.llm_provider !== 'heuristic_rule_engine' && analysis.llm_model ? ` · ${shortModel(analysis.llm_model)}` : ''}
              </Badge>
              {analysis.label_mismatch && <Badge variant="medium">Differs from ground truth: {analysis.ground_truth_label}</Badge>}
            </div>
            <Link to={`/incidents/${analysis.incident_id}`} className={buttonClasses('ghost', 'sm')}>
              Open full incident report
              <ExternalLink className="h-4 w-4" aria-hidden />
            </Link>
          </div>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="space-y-6">
              <Card title="LangGraph step trace" subtitle="Per-node latency." badge={<Badge variant="cyan">{analysis.execution_trace.length} nodes</Badge>}>
                <WorkflowTimeline trace={analysis.execution_trace} totalTimeMs={analysis.execution_time_ms} />
              </Card>
              <Card title="Model verdict">
                <div className="space-y-4">
                  <ScoreBar label="Class confidence" value={pred.confidence} tone="cyan" />
                  <ScoreBar label="Intrusion probability" value={pred.intrusion_probability} tone="red" />
                  <ScoreBar label="Anomaly vs benign" value={pred.anomaly_score} tone="amber" />
                  {pred.explanation && <ContributionChart explanation={pred.explanation} />}
                </div>
              </Card>
            </div>
            <div className="space-y-6">
              <Card title="Agentic analysis" subtitle={`${analysis.historical_matches.length} historical incident(s) retrieved.`}>
                <MarkdownContent content={analysis.analysis} />
              </Card>
              <Card title="Analyst action directives" subtitle="Containment is proposed, never executed automatically.">
                <ol className="space-y-2">
                  {analysis.recommendations.map((rec, i) => (
                    <li key={i} className="flex items-start gap-3 rounded-lg bg-soc-card/60 p-3 text-sm text-slate-200">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-cyan-900 text-2xs font-bold text-cyan-100" aria-hidden>
                        {i + 1}
                      </span>
                      <span className="leading-relaxed">{rec}</span>
                    </li>
                  ))}
                </ol>
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
