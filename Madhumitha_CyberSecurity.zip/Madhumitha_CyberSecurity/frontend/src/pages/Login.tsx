import React, { useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { ArrowRight, Eye, EyeOff, Lock, ShieldAlert, User as UserIcon } from 'lucide-react';
import { authService } from '../services/authService';
import { BRAND } from '../lib/brand';
import { usePageTitle } from '../lib/usePageTitle';
import { Alert } from '../components/ui/Alert';
import { Button, IconButton } from '../components/ui/Button';
import { Input } from '../components/ui/Input';

// Seeded demo logins are offered only in development builds: `import.meta.env.DEV` is a compile-time constant, so the
// credentials are stripped from the production bundle instead of shipping to every visitor.
const DEMO_ACCOUNTS: { label: string; username: string; password: string }[] = import.meta.env.DEV
  ? [
      { label: 'Analyst', username: 'analyst', password: 'analyst123!' },
      { label: 'Admin', username: 'admin', password: 'admin123!' },
      { label: 'Viewer', username: 'viewer', password: 'viewer123!' },
    ]
  : [];

export const Login: React.FC = () => {
  usePageTitle('Sign in');
  const navigate = useNavigate();
  const location = useLocation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (authService.isAuthenticated()) return <Navigate to="/dashboard" replace />;

  // Send people back to the page that bounced them to the login screen.
  const from = (location.state as { from?: string } | null)?.from;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await authService.login(username, password);
      navigate(from && from !== '/login' ? from : '/dashboard', { replace: true });
    } catch (err) {
      setError(err instanceof Error && err.message ? err.message : 'Sign-in failed. Check your credentials and try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="soc-grid-bg flex min-h-dvh w-full items-center justify-center bg-soc-darkest p-4">
      <div className="w-full max-w-md overflow-hidden rounded-2xl border border-soc-border bg-soc-surface shadow-2xl shadow-black/50">
        <div className="border-b border-soc-border bg-soc-dark/70 px-8 py-7 text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl border border-cyan-700/60 bg-cyan-950/70 text-cyan-300">
            <ShieldAlert className="h-6 w-6" aria-hidden />
          </div>
          <h1 className="text-xl font-semibold tracking-tight text-slate-50">{BRAND.name}</h1>
          <p className="mt-1 text-sm text-soc-textMuted">Sign in to triage and investigate incidents.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4 px-8 py-7">
          {error && <Alert variant="error">{error}</Alert>}

          <Input
            label="Username"
            icon={UserIcon}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="username"
            autoCapitalize="none"
            spellCheck={false}
            required
            autoFocus
          />

          <Input
            label="Password"
            icon={Lock}
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            required
            endAdornment={
              <IconButton
                label={showPassword ? 'Hide password' : 'Show password'}
                icon={showPassword ? EyeOff : Eye}
                onClick={() => setShowPassword((v) => !v)}
                aria-pressed={showPassword}
              />
            }
          />

          <Button type="submit" variant="primary" loading={loading} className="w-full">
            {loading ? 'Signing in…' : 'Sign in'}
            {!loading && <ArrowRight className="h-4 w-4" aria-hidden />}
          </Button>

          {DEMO_ACCOUNTS.length > 0 && (
            <div className="border-t border-soc-border pt-4">
              <p className="mb-2 text-center text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Development demo accounts</p>
              <div className="grid grid-cols-3 gap-2">
                {DEMO_ACCOUNTS.map((a) => (
                  <Button
                    key={a.label}
                    size="sm"
                    onClick={() => {
                      setUsername(a.username);
                      setPassword(a.password);
                    }}
                  >
                    {a.label}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </form>
      </div>
    </main>
  );
};
