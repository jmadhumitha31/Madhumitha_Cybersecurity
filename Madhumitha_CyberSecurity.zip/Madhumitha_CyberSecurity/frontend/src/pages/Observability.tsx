import React, { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Download, RefreshCw, Search, SearchX } from 'lucide-react';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { TableSkeleton } from '../components/common/LoadingSkeleton';
import { TraceDetailPanel } from '../components/observability/TraceDetailPanel';
import { MetricsView } from '../components/observability/MetricsView';
import { SystemLogic } from '../components/observability/SystemLogic';
import { StatusBadge } from '../components/observability/shared';
import { fmtMs, fmtTime, shortId } from '../components/observability/utils';
import { Alert } from '../components/ui/Alert';
import { Button, IconButton } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { Checkbox, Input, Select } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { RoutePageHeader } from '../components/ui/PageHeader';
import { Table, TableWrap, Td, Th, Tr } from '../components/ui/Table';
import { TabPanel, Tabs } from '../components/ui/Tabs';
import { observabilityService, type TraceFilters } from '../services/observabilityService';
import { authService } from '../services/authService';
import { cn } from '../lib/cn';
import type { TraceList, TraceSummary } from '../types';

type Tab = 'traces' | 'metrics' | 'logic';
const TABS: { id: Tab; label: string }[] = [
  { id: 'traces', label: 'Query traces' },
  { id: 'metrics', label: 'Metrics' },
  { id: 'logic', label: 'How decisions are made' },
];
const SINCE: Record<string, number | null> = { all: null, '1h': 1, '24h': 24, '7d': 24 * 7, '30d': 24 * 30 };
const PAGE_SIZE = 20;

/** One-line outcome of a trace, from the summary facts recorded by the endpoint. */
const outcome = (t: TraceSummary): string => {
  const s = t.summary || {};
  if (t.status === 'rejected' && t.kind !== 'feedback') return s.blocked_by ? `blocked by ${s.blocked_by}` : t.error ? 'rejected' : 'rejected by a guardrail';
  switch (true) {
    case t.kind === 'search':
      return s.empty ? 'no result above threshold' : `${s.n_results ?? '?'} result(s)`;
    case t.kind.startsWith('chat'):
      return s.route && String(s.route).startsWith('canned') ? 'canned reply' : s.fallback_used ? `offline engine · ${s.n_citations ?? 0} cited` : `${s.llm_provider ?? '?'} · ${s.n_citations ?? 0} cited`;
    case t.kind === 'incident.analyze':
      return `${s.attack_type ?? '?'} · ${s.risk_level ?? '?'} · ${s.llm_provider ?? '?'}`;
    case t.kind === 'classify' || t.kind === 'incident.explain':
      return `${s.attack_type ?? '?'}${s.risk_level ? ` · ${s.risk_level}` : ''}`;
    case t.kind === 'incident.create':
      return `${s.attack_type ?? '?'} · ${s.risk_level ?? '?'}`;
    case t.kind === 'feedback':
      return `${s.predicted ?? '?'} → ${s.actual ?? '?'}`;
    case t.kind.startsWith('model.retrain'):
      return s.decision ?? 'requested';
    case t.kind.startsWith('evaluation'):
      return s.status ?? '';
    default:
      return '';
  }
};

interface Filters {
  q: string;
  kind: string;
  status: string;
  username: string;
  since: string;
  min: string;
  sort: 'newest' | 'slowest';
  system: boolean;
  incident: string;
}

interface Loaded {
  key: string;
  list: TraceList | null;
  error: string | null;
}

export const Observability: React.FC = () => {
  const [params, setParams] = useSearchParams();
  const tab: Tab = (TABS.some((t) => t.id === params.get('tab')) ? params.get('tab') : 'traces') as Tab;
  const openTrace = params.get('trace');
  const isViewer = authService.getStoredUser()?.role === 'VIEWER';

  const [filters, setFilters] = useState<Filters>({
    q: params.get('q') || '',
    kind: '',
    status: '',
    username: '',
    since: 'all',
    min: '',
    sort: 'newest',
    system: false,
    incident: params.get('incident') || '',
  });
  const [page, setPage] = useState(1);
  const [loaded, setLoaded] = useState<Loaded | null>(null);
  const [reloadTick, setReloadTick] = useState(0);
  const [live, setLive] = useState(false);
  const [exporting, setExporting] = useState<string | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);

  const apiFilters = useMemo<TraceFilters>(() => {
    const hours = SINCE[filters.since];
    return {
      page,
      page_size: PAGE_SIZE,
      q: filters.q || undefined,
      kind: filters.kind || undefined,
      status: filters.status || undefined,
      username: filters.username || undefined,
      incident_id: filters.incident || undefined,
      min_duration_ms: filters.min || undefined,
      since: hours ? new Date(Date.now() - hours * 3600_000).toISOString() : undefined,
      sort: filters.sort,
      include_system: filters.system,
    };
  }, [filters, page]);

  // `since` is relative to "now", so it is deliberately left out of the key; changing the selection changes `filters`.
  const key = `${JSON.stringify({ ...filters })}|${page}|${reloadTick}`;

  useEffect(() => {
    if (tab !== 'traces') return;
    let alive = true;
    const fetchList = (quiet: boolean) =>
      observabilityService
        .listTraces(apiFilters)
        .then((list) => alive && setLoaded({ key, list, error: null }))
        .catch((e: Error) => alive && !quiet && setLoaded({ key, list: null, error: e.message }));
    void fetchList(false);
    // "Live" refreshes the same query in place, without flashing the table back to a loading state.
    const timer = live ? window.setInterval(() => void fetchList(true), 8000) : undefined;
    return () => {
      alive = false;
      window.clearInterval(timer);
    };
    // `key` already captures every input of `apiFilters` that matters.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, tab, live]);

  const setTab = (t: Tab) => {
    const p = new URLSearchParams(params);
    p.set('tab', t);
    p.delete('trace');
    setParams(p);
  };
  const open = (id: string) => {
    const p = new URLSearchParams(params);
    p.set('trace', id);
    setParams(p);
  };
  const close = () => {
    const p = new URLSearchParams(params);
    p.delete('trace');
    setParams(p);
  };
  const update = (patch: Partial<Filters>) => {
    setFilters((f) => ({ ...f, ...patch }));
    setPage(1);
  };

  const loading = loaded?.key !== key;
  const list = loaded?.list ?? null;
  const maxMs = useMemo(() => Math.max(1, ...(list?.items.map((t) => t.duration_ms) ?? [1])), [list]);
  const totalPages = list ? Math.max(1, Math.ceil(list.total / list.page_size)) : 1;

  const doExport = async (format: 'csv' | 'json') => {
    setExporting(format);
    setExportError(null);
    try {
      await observabilityService.exportTraces(format, apiFilters);
    } catch (e) {
      setExportError(e instanceof Error ? e.message : 'Export failed');
    } finally {
      setExporting(null);
    }
  };

  return (
    <div className="space-y-6">
      <RoutePageHeader path="/observability" />

      <Tabs tabs={TABS} value={tab} onChange={setTab} idPrefix="obs" label="Observability views" />

      <TabPanel idPrefix="obs" id="metrics" active={tab === 'metrics'}>
        <MetricsView onOpenTrace={open} />
      </TabPanel>
      <TabPanel idPrefix="obs" id="logic" active={tab === 'logic'}>
        <SystemLogic />
      </TabPanel>

      <TabPanel idPrefix="obs" id="traces" active={tab === 'traces'} className="space-y-4">
        <Card>
          <form
            role="search"
            aria-label="Filter traces"
            className="grid grid-cols-2 items-end gap-3 md:grid-cols-4 xl:grid-cols-8"
            onSubmit={(e) => {
              e.preventDefault();
              setReloadTick((n) => n + 1);
            }}
          >
            <Input compact label="Search" icon={Search} className="col-span-2" placeholder="Query text, user, trace id…" value={filters.q} onChange={(e) => update({ q: e.target.value })} />
            <Select compact label="Kind" value={filters.kind} onChange={(e) => update({ kind: e.target.value })}>
              <option value="">All</option>
              {Object.entries(list?.facets.kinds ?? {}).map(([k, n]) => (
                <option key={k} value={k}>
                  {k} ({n})
                </option>
              ))}
            </Select>
            <Select compact label="Outcome" value={filters.status} onChange={(e) => update({ status: e.target.value })}>
              <option value="">All</option>
              {['ok', 'degraded', 'rejected', 'error'].map((s) => (
                <option key={s} value={s}>
                  {s} ({list?.facets.statuses[s] ?? 0})
                </option>
              ))}
            </Select>
            <Select compact label="When" value={filters.since} onChange={(e) => update({ since: e.target.value })}>
              {Object.keys(SINCE).map((s) => (
                <option key={s} value={s}>
                  {s === 'all' ? 'Any time' : `Last ${s}`}
                </option>
              ))}
            </Select>
            <Input compact label="Min duration (ms)" type="number" min={0} value={filters.min} onChange={(e) => update({ min: e.target.value })} />
            <Select compact label="Sort" value={filters.sort} onChange={(e) => update({ sort: e.target.value as Filters['sort'] })}>
              <option value="newest">Newest</option>
              <option value="slowest">Slowest</option>
            </Select>
            <Input compact label="Incident #" inputMode="numeric" value={filters.incident} onChange={(e) => update({ incident: e.target.value.replace(/\D/g, '') })} />
          </form>
          <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-3 border-t border-soc-border pt-4">
            <Button size="sm" icon={RefreshCw} loading={loading} onClick={() => setReloadTick((n) => n + 1)}>
              Refresh
            </Button>
            <Checkbox label="Live (every 8 s)" checked={live} onChange={(e) => setLive(e.target.checked)} />
            <Checkbox label="Include system traces" checked={filters.system} onChange={(e) => update({ system: e.target.checked })} />
            <div className="flex-1" />
            {!isViewer && (
              <>
                <Button size="sm" icon={Download} disabled={!!exporting} loading={exporting === 'csv'} onClick={() => doExport('csv')}>
                  Export CSV
                </Button>
                <Button size="sm" icon={Download} disabled={!!exporting} loading={exporting === 'json'} onClick={() => doExport('json')}>
                  Export JSON (with spans)
                </Button>
              </>
            )}
          </div>
        </Card>

        {loaded?.error && <Alert variant="error" title="Could not load traces">{loaded.error}</Alert>}
        {exportError && <Alert variant="error" title="Export failed" onDismiss={() => setExportError(null)}>{exportError}</Alert>}

        <Card title="Queries" subtitle={list ? `${list.total.toLocaleString()} trace(s)${isViewer ? ' (your own)' : ''}` : undefined} padded={false}>
          {!loaded ? (
            <div className="p-5">
              <TableSkeleton rows={6} />
            </div>
          ) : list && list.items.length === 0 ? (
            <EmptyState icon={SearchX} title="No traces match these filters" description="Run a search, a chat message or an investigation, then refresh." />
          ) : list ? (
            <div className={cn('transition-opacity', loading && 'opacity-60')} aria-busy={loading}>
              <TableWrap maxHeight="min(70dvh, 48rem)">
                <Table caption="Query traces. Select a row to open its trace.">
                  <thead>
                    <tr>
                      <Th>Time</Th>
                      <Th>Kind</Th>
                      <Th>Outcome</Th>
                      <Th>User</Th>
                      <Th>Query</Th>
                      <Th>Result</Th>
                      <Th className="w-32">Duration</Th>
                      <Th numeric>Spans</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {list.items.map((t) => (
                      <Tr key={t.trace_id} onActivate={() => open(t.trace_id)} selected={openTrace === t.trace_id}>
                        <Td className="whitespace-nowrap text-slate-400">{fmtTime(t.started_at)}</Td>
                        <Td className="whitespace-nowrap">
                          <Badge variant="purple">{t.kind}</Badge>
                        </Td>
                        <Td>
                          <StatusBadge status={t.status} />
                        </Td>
                        <Td className="text-slate-300">{t.username ?? 'system'}</Td>
                        <Td className="max-w-xs">
                          <div className="truncate text-slate-200" title={t.query}>
                            {t.query || <span className="text-soc-textMuted">—</span>}
                          </div>
                          <div className="text-2xs text-soc-textMuted">
                            <span className="font-mono">{shortId(t.trace_id)}</span>
                            {t.incident_id != null && (
                              <>
                                {' · '}
                                <Link to={`/incidents/${t.incident_id}`} onClick={(e) => e.stopPropagation()} className="text-cyan-300 hover:underline">
                                  incident #{t.incident_id}
                                </Link>
                              </>
                            )}
                          </div>
                        </Td>
                        <Td className="max-w-[14rem] truncate text-slate-300">{outcome(t)}</Td>
                        <Td>
                          <div className="tabular-nums text-slate-100">{fmtMs(t.duration_ms)}</div>
                          <div className="mt-1 h-1 rounded-full bg-soc-darkest" aria-hidden>
                            <div className="h-full rounded-full bg-cyan-600" style={{ width: `${Math.max(2, (t.duration_ms / maxMs) * 100)}%` }} />
                          </div>
                        </Td>
                        <Td numeric className="text-slate-400">
                          {t.n_spans}
                        </Td>
                      </Tr>
                    ))}
                  </tbody>
                </Table>
              </TableWrap>
              {list.total > PAGE_SIZE && (
                <nav aria-label="Trace pagination" className="flex items-center justify-between border-t border-soc-border px-5 py-3 text-xs">
                  <span className="tabular-nums text-soc-textMuted">
                    Page {page} of {totalPages.toLocaleString()}
                  </span>
                  <div className="flex gap-2">
                    <IconButton label="Previous page" icon={ChevronLeft} variant="secondary" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} />
                    <IconButton label="Next page" icon={ChevronRight} variant="secondary" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)} />
                  </div>
                </nav>
              )}
            </div>
          ) : (
            <EmptyState icon={SearchX} title="Traces could not be loaded" description="See the error above, then refresh." />
          )}
        </Card>
      </TabPanel>

      <Modal open={!!openTrace} onClose={close} title="Trace details" placement="right" hideHeader>
        {openTrace && <TraceDetailPanel key={openTrace} traceId={openTrace} onClose={close} />}
      </Modal>
    </div>
  );
};
