import React, { useEffect, useState } from 'react';
import { Activity, RefreshCw } from 'lucide-react';
import { healthService, mlService } from '../services/mlService';
import type { ModelInfo, SystemHealthData } from '../types';
import { fixed, pct } from '../lib/format';
import { Card } from '../components/common/Card';
import { Badge } from '../components/common/Badge';
import { HealthBadge } from '../components/common/HealthBadge';
import { LoadingSkeleton } from '../components/common/LoadingSkeleton';
import { Alert } from '../components/ui/Alert';
import { Button } from '../components/ui/Button';
import { Metric } from '../components/ui/Metric';
import { RoutePageHeader } from '../components/ui/PageHeader';

const LABELS: Record<string, string> = {
  database: 'Database',
  embeddings: 'Embedding model',
  vector_index: 'Vector index (Qdrant + BM25)',
  ml_model: 'ML models',
  aicredits_llm: 'AICredits (primary LLM)',
  nvidia_llm: 'NVIDIA NIM (fallback LLM)',
  ollama_llm: 'Ollama (local fallback)',
  evaluation_services: 'Evaluation suites',
  rag_pipeline: 'RAG pipeline',
};

export const Settings: React.FC = () => {
  const [health, setHealth] = useState<SystemHealthData | null>(null);
  const [model, setModel] = useState<ModelInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [probing, setProbing] = useState(false);
  const [deep, setDeep] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [probeTick, setProbeTick] = useState(0);

  // Always a live probe: the backend actually calls NVIDIA / Ollama instead of reporting cached state.
  useEffect(() => {
    let alive = true;
    Promise.all([healthService.get(true), mlService.getModel().catch(() => null)])
      .then(([h, m]) => {
        if (!alive) return;
        setHealth(h);
        setModel(m);
        setDeep(true);
        setError(null);
      })
      .catch((e: unknown) => alive && setError(e instanceof Error ? e.message : 'Failed to read system status'))
      .finally(() => {
        if (!alive) return;
        setLoading(false);
        setProbing(false);
      });
    return () => {
      alive = false;
    };
  }, [probeTick]);

  const c = health?.components;
  const alpha = c?.rag_pipeline?.alpha;

  return (
    <div className="max-w-5xl space-y-6">
      <RoutePageHeader
        path="/settings"
        actions={
          <Button
            size="sm"
            icon={RefreshCw}
            loading={probing}
            onClick={() => {
              setProbing(true);
              setProbeTick((t) => t + 1);
            }}
          >
            Run live probe
          </Button>
        }
      />

      {error && <Alert variant="error">{error}</Alert>}
      {loading && !health && <LoadingSkeleton rows={4} height="h-14" />}

      {health && (
        <>
          <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-soc-border bg-soc-surface p-5">
            <div className="flex items-center gap-4">
              <div className="rounded-lg bg-soc-card p-3 text-cyan-400">
                <Activity className="h-5 w-5" aria-hidden />
              </div>
              <div>
                <p className="text-xs text-soc-textMuted">
                  Platform status · v{health.version}
                  {health.environment ? ` · ${health.environment}` : ''}
                </p>
                <p className="text-base font-semibold text-slate-50">{health.app_name}</p>
              </div>
            </div>
            <HealthBadge status={health.status} />
          </div>

          <Card title="Components" subtitle={deep ? 'Including live NVIDIA / Ollama probes.' : 'Cached view.'}>
            <ul className="divide-y divide-soc-border/60">
              {Object.entries(health.components).map(([key, comp]) => (
                <li key={key} className="flex flex-wrap items-center justify-between gap-4 py-3 first:pt-0 last:pb-0">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-100">{LABELS[key] || key}</p>
                    {comp.details && <p className="mt-0.5 text-xs text-soc-textMuted">{comp.details}</p>}
                    {comp.model && (
                      <p className="mt-0.5 text-xs text-cyan-300">
                        Model: {comp.model}
                        {comp.dimension ? ` · ${comp.dimension}-d` : ''}
                        {comp.judge_model ? ` · judge: ${comp.judge_model}` : ''}
                        {comp.latency_ms ? ` · ${comp.latency_ms} ms` : ''}
                      </p>
                    )}
                  </div>
                  <HealthBadge status={comp.status} />
                </li>
              ))}
            </ul>
          </Card>

          {model?.loaded && model.metrics && (
            <Card title="Active ML model" subtitle={model.version}>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                <Metric label="Data source" value={model.dataset_source || 'N/A'} />
                <Metric label="Trained" value={model.trained_at ? new Date(model.trained_at).toLocaleString() : 'N/A'} className="[&>div:nth-child(2)]:text-sm" />
                <Metric label="Training flows" value={model.n_train?.toLocaleString() || 'N/A'} />
                <Metric label="Analyst-feedback rows" value={String(model.n_feedback_rows ?? 0)} />
                <Metric label="Held-out accuracy" value={pct(model.metrics.accuracy, 2)} />
                <Metric label="Held-out macro-F1" value={pct(model.metrics.f1_macro, 2)} />
                <Metric label="Intrusion-model AUC" value={fixed(model.metrics.intrusion_model?.roc_auc, 4)} />
                <Metric label="Anomaly AUC" value={fixed(model.metrics.anomaly_model?.roc_auc_attack_vs_benign, 4)} />
              </div>
            </Card>
          )}

          <Card title="Retrieval configuration" subtitle="Calibrated on the real dataset with the retrieval benchmark (see Evaluation).">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <Metric label="Hybrid weight" value={alpha != null ? `α = ${alpha}` : 'N/A'} hint={alpha != null ? `${(alpha * 100).toFixed(0)}% dense / ${(100 - alpha * 100).toFixed(0)}% BM25` : undefined} />
              <Metric label="Incident → history threshold" value={c?.rag_pipeline?.threshold ?? 'N/A'} hint="Below this score: “No sufficiently similar historical incidents were found”." />
              <div className="rounded-lg bg-soc-card/70 px-3.5 py-3">
                <div className="text-2xs font-semibold uppercase tracking-wider text-soc-textMuted">Indexed documents</div>
                <div className="mt-1 text-lg font-semibold tabular-nums text-slate-50">{c?.vector_index?.documents?.toLocaleString() ?? 'N/A'}</div>
                {c?.embeddings?.model && (
                  <Badge variant="neutral" className="mt-1.5">
                    {c.embeddings.model}
                  </Badge>
                )}
              </div>
            </div>
            {alpha != null && (
              <p className="mt-3 text-xs text-soc-textMuted">
                {(alpha * 100).toFixed(0)}% dense / {(100 - alpha * 100).toFixed(0)}% BM25. Below the threshold the system answers “No sufficiently similar historical incidents were found” instead of guessing.
              </p>
            )}
          </Card>
        </>
      )}
    </div>
  );
};
