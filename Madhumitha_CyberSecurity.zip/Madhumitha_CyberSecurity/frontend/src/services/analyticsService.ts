import { request } from './api';
import {
  AnalyticsOverview,
  AttackDistributionItem,
  PortDistributionItem,
  ProtocolDistributionItem,
  SeverityDistributionItem,
  TrendItem,
} from '../types';

export const analyticsService = {
  getOverview: () => request<AnalyticsOverview>('/analytics/overview'),
  getAttacks: () => request<AttackDistributionItem[]>('/analytics/attacks'),
  getSeverity: () => request<SeverityDistributionItem[]>('/analytics/severity'),
  getProtocols: () => request<ProtocolDistributionItem[]>('/analytics/protocols'),
  getPorts: () => request<PortDistributionItem[]>('/analytics/ports'),
  getTrends: () => request<TrendItem[]>('/analytics/trends'),
};
