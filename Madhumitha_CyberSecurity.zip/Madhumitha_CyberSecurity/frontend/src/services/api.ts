const API_BASE_URL = (import.meta.env.VITE_API_URL as string | undefined) || '/api/v1';

export class ApiError extends Error {
  status: number;
  details?: unknown;
  constructor(message: string, status: number, details?: unknown) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

export function clearSession() {
  localStorage.removeItem('soc_token');
  localStorage.removeItem('soc_user');
}

function errorMessage(data: any, status: number): string {
  const err = data?.error;
  if (err?.details && Array.isArray(err.details) && err.details.length) {
    return `${err.message || 'Request failed'}: ${err.details.slice(0, 4).join('; ')}`;
  }
  if (err?.details?.errors && Array.isArray(err.details.errors)) {
    return `${err.message || 'Validation failed'}: ${err.details.errors.slice(0, 4).join('; ')}`;
  }
  const msg = err?.message || data?.detail;
  if (typeof msg === 'string') return msg;
  if (msg) return JSON.stringify(msg);
  return `Request failed (HTTP ${status})`;
}

/** Low-level call: returns the parsed JSON body (the full envelope). Handles auth expiry centrally. */
export async function requestEnvelope(endpoint: string, options: RequestInit = {}): Promise<any> {
  const token = localStorage.getItem('soc_token');
  const headers = new Headers(options.headers || {});
  headers.set('Content-Type', 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);

  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}${endpoint}`, { ...options, headers });
  } catch {
    throw new ApiError('Cannot reach the SOC backend. Is the API running?', 0);
  }
  const body = await response.json().catch(() => ({}));

  if (response.status === 401 && !endpoint.startsWith('/auth/login')) {
    clearSession();
    if (!window.location.pathname.startsWith('/login')) window.location.assign('/login');
    throw new ApiError('Session expired. Please sign in again.', 401);
  }
  if (!response.ok) throw new ApiError(errorMessage(body, response.status), response.status, body?.error?.details);
  return body;
}

/** Returns the `data` payload of the standard `{success, data, error}` envelope. */
export async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const body = await requestEnvelope(endpoint, options);
  if (body && typeof body === 'object' && 'success' in body && 'data' in body) return body.data as T;
  return body as T;
}

export interface Pagination {
  page: number;
  page_size: number;
  total: number;
  total_pages: number;
}

export async function requestPaged<T>(endpoint: string): Promise<{ items: T[]; pagination: Pagination }> {
  const body = await requestEnvelope(endpoint);
  return {
    items: (body.data || []) as T[],
    pagination: body.pagination || { page: 1, page_size: 20, total: 0, total_pages: 1 },
  };
}

export function qs(params: Record<string, string | number | boolean | undefined | null>): string {
  const q = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') q.set(k, String(v));
  });
  const s = q.toString();
  return s ? `?${s}` : '';
}

/** Authenticated file download (the export endpoints need the bearer token, so a plain <a href> would not work). */
export async function downloadFile(endpoint: string, filename: string): Promise<void> {
  const token = localStorage.getItem('soc_token');
  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}${endpoint}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
  } catch {
    throw new ApiError('Cannot reach the SOC backend. Is the API running?', 0);
  }
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new ApiError(errorMessage(body, response.status), response.status);
  }
  saveBlob(await response.blob(), filename);
}

/** Save in-memory data as a file download. */
export function saveBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
