import { clearSession, request } from './api';
import { UserProfile } from '../types';

export interface StoredUser {
  username: string;
  role: 'ADMIN' | 'ANALYST' | 'VIEWER';
}

function tokenExpired(token: string): boolean {
  try {
    const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    return typeof payload.exp === 'number' && payload.exp * 1000 < Date.now();
  } catch {
    return true;
  }
}

export const authService = {
  login: async (username: string, password: string) => {
    const data = await request<{ access_token: string; role: StoredUser['role']; username: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
    localStorage.setItem('soc_token', data.access_token);
    localStorage.setItem('soc_user', JSON.stringify({ username: data.username, role: data.role }));
    return data;
  },

  getCurrentUser: async () => request<UserProfile>('/auth/me'),

  logout: () => clearSession(),

  isAuthenticated: (): boolean => {
    const t = localStorage.getItem('soc_token');
    return !!t && !tokenExpired(t);
  },

  /** The signed-in user, or null. (The previous version silently pretended to be an analyst.) */
  getStoredUser: (): StoredUser | null => {
    try {
      const raw = localStorage.getItem('soc_user');
      return raw ? (JSON.parse(raw) as StoredUser) : null;
    } catch {
      return null;
    }
  },

  canWrite: (): boolean => {
    const u = authService.getStoredUser();
    return !!u && (u.role === 'ADMIN' || u.role === 'ANALYST');
  },

  isAdmin: (): boolean => authService.getStoredUser()?.role === 'ADMIN',
};
