import { request } from './api';
import { ChatQueryRequest, ChatQueryResponse, ChatSuggestion } from '../types';

export const chatService = {
  async sendMessage(payload: ChatQueryRequest): Promise<ChatQueryResponse> {
    return request<ChatQueryResponse>('/chat/message', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async getSuggestions(): Promise<ChatSuggestion[]> {
    return request<ChatSuggestion[]>('/chat/suggestions');
  },

  async sendIncidentMessage(incidentId: number, payload: ChatQueryRequest): Promise<ChatQueryResponse> {
    return request<ChatQueryResponse>(`/chat/incident/${incidentId}`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
};
