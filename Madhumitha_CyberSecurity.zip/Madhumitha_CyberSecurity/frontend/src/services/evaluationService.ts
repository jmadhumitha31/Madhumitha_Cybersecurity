import { request } from './api';
import {
  DeepEvalMetrics,
  EvaluationRunRecord,
  LLMJudgeBatch,
  LLMJudgeResult,
  MLEvaluationMetrics,
  RetrievalMetrics,
} from '../types';

export const evaluationService = {
  getMLEvaluation: () => request<MLEvaluationMetrics>('/evaluation/ml'),
  runMLEvaluation: () => request<MLEvaluationMetrics>('/evaluation/ml', { method: 'POST' }),

  getRetrieval: () => request<RetrievalMetrics>('/evaluation/retrieval'),
  runRetrieval: () => request<RetrievalMetrics>('/evaluation/retrieval', { method: 'POST' }),

  getDeepEval: () => request<DeepEvalMetrics>('/evaluation/deepeval'),
  startDeepEval: (limit = 4) => request<{ status: string; run_id: number }>(`/evaluation/deepeval?limit=${limit}`, { method: 'POST' }),

  getJudge: () => request<LLMJudgeBatch | LLMJudgeResult>('/evaluation/judge'),
  runLLMJudge: (incidentId: number) => request<LLMJudgeResult>(`/evaluation/judge?incident_id=${incidentId}`, { method: 'POST' }),
  runJudgeBatch: (limit = 5) => request<LLMJudgeBatch>(`/evaluation/judge/batch?limit=${limit}`, { method: 'POST' }),

  getEvaluationRuns: () => request<EvaluationRunRecord[]>('/evaluation/runs'),
};
