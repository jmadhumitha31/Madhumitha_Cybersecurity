import { qs, request, requestPaged } from './api';
import { AnalysisResponse, AttackPrediction, FeedbackRecord, Incident, RiskAssessment } from '../types';

export interface IncidentQuery {
  page?: number;
  page_size?: number;
  attack_type?: string;
  risk_level?: string;
  status?: string;
  search?: string;
  label_source?: string;
  sort?: 'created_at' | 'timestamp' | 'risk' | 'priority';
}

export const incidentService = {
  getIncidents: (params: IncidentQuery = {}) => requestPaged<Incident>(`/incidents${qs({ ...params })}`),

  getQueue: (limit = 25) => request<Incident[]>(`/incidents/queue${qs({ limit })}`),

  getIncidentDetails: (id: number) =>
    request<{ incident: Incident; latest_analysis: any; feedback: FeedbackRecord[] }>(`/incidents/${id}`),

  createIncident: (incidentData: Partial<Incident>) =>
    request<Incident>('/incidents', { method: 'POST', body: JSON.stringify(incidentData) }),

  classifyFlow: (flow: Record<string, any>) =>
    request<{ prediction: AttackPrediction; risk: RiskAssessment }>('/incidents/classify', { method: 'POST', body: JSON.stringify(flow) }),

  explain: (id: number) => request<AttackPrediction>(`/incidents/${id}/explain`),

  analyzeIncident: (id: number) => request<AnalysisResponse>(`/incidents/${id}/analyze`, { method: 'POST' }),

  submitFeedback: (id: number, feedback: { feedback_type: string; actual_label?: string; analyst_feedback?: string }) =>
    request<FeedbackRecord>(`/incidents/${id}/feedback`, { method: 'POST', body: JSON.stringify(feedback) }),

  updateStatus: (id: number, status: string) =>
    request<Incident>(`/incidents/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
};
