import { qs, request } from './api';
import { AttackProfile, AuditEntry, FeedbackRecord, FeedbackStats, ModelInfo, RetrainStatus, SystemHealthData } from '../types';

export const mlService = {
  getModel: () => request<ModelInfo>('/ml/model'),
  getProfiles: () =>
    request<{ model_version: string; profiles: Record<string, AttackProfile>; global_feature_importance: Record<string, number> }>('/ml/profiles'),
  startRetrain: () => request<RetrainStatus>('/ml/retrain', { method: 'POST' }),
  getRetrainStatus: () => request<RetrainStatus>('/ml/retrain/status'),
};

export const feedbackService = {
  list: (limit = 100) => request<FeedbackRecord[]>(`/feedback${qs({ limit })}`),
  stats: () => request<FeedbackStats>('/feedback/stats'),
};

export const auditService = {
  list: (params: { page?: number; page_size?: number; action?: string; username?: string } = {}) =>
    request<{ total: number; page: number; page_size: number; items: AuditEntry[] }>(`/audit${qs({ ...params })}`),
};

export const healthService = {
  get: (deep = false) => request<SystemHealthData>(`/health${deep ? '?deep=true' : ''}`),
};
