import { downloadFile, qs, request } from './api';
import { ObservabilityMetrics, SystemExplanation, TraceDetail, TraceList } from '../types';

export interface TraceFilters {
  page?: number;
  page_size?: number;
  kind?: string;
  status?: string;
  username?: string;
  incident_id?: number | string;
  q?: string;
  since?: string;
  until?: string;
  min_duration_ms?: number | string;
  sort?: 'newest' | 'slowest';
  include_system?: boolean;
}

export const observabilityService = {
  listTraces: (f: TraceFilters = {}) => request<TraceList>(`/observability/traces${qs({ ...f })}`),
  getTrace: (traceId: string) => request<TraceDetail>(`/observability/traces/${encodeURIComponent(traceId)}`),
  metrics: (window: string) => request<ObservabilityMetrics>(`/observability/metrics${qs({ window })}`),
  explainSystem: () => request<SystemExplanation>('/observability/explain/system'),
  exportTraces: (format: 'csv' | 'json', f: TraceFilters = {}) => {
    const { page: _p, page_size: _s, sort: _o, include_system: _i, ...rest } = f;
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    return downloadFile(`/observability/traces/export${qs({ format, ...rest })}`, `soc_traces_${stamp}.${format}`);
  },
  prune: (olderThanDays: number) => request<{ removed: number; older_than_days: number }>(`/observability/traces${qs({ older_than_days: olderThanDays })}`, { method: 'DELETE' }),
};
