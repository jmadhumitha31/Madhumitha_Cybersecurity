import { request } from './api';
import { SearchResponseData } from '../types';

export interface SearchPayload {
  query?: string;
  search_type: 'hybrid' | 'semantic' | 'keyword';
  filters?: Record<string, any>;
  top_k?: number;
  similarity_threshold?: number;
}

export const searchService = {
  search: (payload: SearchPayload) => request<SearchResponseData>('/search', { method: 'POST', body: JSON.stringify(payload) }),
};
