export type Severity = 'Critical' | 'High' | 'Medium' | 'Low';
export type Priority = 'P1' | 'P2' | 'P3' | 'P4';
export type IncidentStatus = 'NEW' | 'INVESTIGATING' | 'RESOLVED' | 'FALSE_POSITIVE';
export type LabelSource = 'dataset' | 'analyst' | 'model' | 'none';

export const ATTACK_CLASSES = [
  'Benign',
  'DDoS',
  'DoS',
  'Port Scan',
  'FTP/SSH Brute Force',
  'Web Attack',
  'Botnet',
  'Infiltration',
  'Heartbleed',
] as const;

export interface Incident {
  id: number;
  flow_id: string;
  source_ip: string;
  source_port: number;
  destination_ip: string;
  destination_port: number;
  protocol: number;
  timestamp?: string;
  flow_duration: number;
  total_fwd_packets: number;
  total_bwd_packets: number;
  total_length_fwd: number;
  total_length_bwd: number;
  flow_bytes_per_sec: number;
  flow_packets_per_sec: number;
  flow_iat_mean: number;
  packet_length_mean: number;
  syn_count: number;
  rst_count: number;
  ack_count: number;
  average_packet_size: number;
  active_mean: number;
  idle_mean: number;
  attack_type: string;
  ground_truth_label?: string | null;
  original_label?: string | null;
  label_source: LabelSource;
  data_source: string;
  predicted_attack_type?: string | null;
  prediction_confidence?: number | null;
  intrusion_probability?: number | null;
  anomaly_score?: number | null;
  risk_score?: number | null;
  risk_level: Severity;
  priority: Priority;
  status: IncidentStatus;
  created_at: string;
  updated_at: string;
}

export interface Contribution {
  feature: string;
  label: string;
  value: number;
  contribution: number;
  benign_median: number;
  benign_p95: number;
  ratio_to_benign: number;
  direction: 'supports' | 'opposes';
}

export interface Explanation {
  method: 'shap-tree' | 'occlusion';
  target_class: string;
  base_value?: number | null;
  contributions: Contribution[];
}

export interface AttackPrediction {
  status?: string;
  attack_type: string;
  confidence: number;
  suspicious: boolean;
  intrusion_probability?: number | null;
  anomaly_score?: number | null;
  low_confidence?: boolean;
  top_classes?: { attack_type: string; probability: number }[];
  indicators: string[];
  feature_importance?: Record<string, number>;
  explanation?: Explanation | null;
  model_version?: string | null;
}

export interface RiskAssessment {
  risk_level: Severity;
  priority: Priority;
  risk_score?: number;
  confidence: number;
  factors: string[];
  anomaly_score?: number | null;
  intrusion_probability?: number | null;
  components?: Record<string, number>;
}

export interface HistoricalMatch {
  incident_id: number;
  flow_id: string;
  attack_type: string;
  label_source?: string;
  risk_level?: string;
  similarity_score?: number;
  hybrid_score?: number;
  semantic_score?: number;
  keyword_score?: number;
  protocol: number;
  destination_port: number;
  destination_ip?: string;
  source_ip?: string;
  shared_characteristics: string[];
  timestamp?: string;
}

export interface ExecutionTraceItem {
  step: string;
  status: string;
  timestamp: string;
  duration_ms: number;
  details: string;
}

export interface LlmAttempt {
  provider: string;
  model?: string;
  ok: boolean;
  status?: number;
  error?: string;
  latency_ms?: number;
}

export interface QualityCheck {
  check: string;
  passed: boolean;
  detail: string;
}

export interface AnalysisResponse {
  incident_id: number;
  attack_prediction: AttackPrediction;
  risk_assessment: RiskAssessment;
  historical_matches: HistoricalMatch[];
  analysis: string;
  recommendations: string[];
  llm_provider: string;
  llm_model?: string | null;
  llm_attempts?: LlmAttempt[];
  fallback_used: boolean;
  quality_checks?: QualityCheck[];
  requires_analyst_review?: boolean;
  ground_truth_label?: string | null;
  label_mismatch?: boolean;
  execution_trace: ExecutionTraceItem[];
  execution_time_ms: number;
  trace_id?: string | null;
}

export interface FeedbackRecord {
  id: number;
  incident_id: number;
  username?: string | null;
  prediction: string;
  actual_label: string;
  feedback_type: string;
  analyst_feedback?: string | null;
  applied: boolean;
  created_at: string;
}

export interface FeedbackStats {
  total: number;
  by_type: Record<string, number>;
  judged: number;
  analyst_agreement_rate: number | null;
  top_corrections: { correction: string; count: number }[];
  pending_for_training: number;
}

export interface SearchResultItem {
  incident_id: number;
  flow_id: string;
  attack_type: string;
  label_source?: string;
  risk_level: Severity;
  priority: Priority;
  source_ip: string;
  destination_ip: string;
  destination_port: number;
  protocol: number;
  timestamp?: string;
  hybrid_score: number;
  semantic_score: number;
  keyword_score: number;
  shared_characteristics: string[];
  matched_features: Record<string, any>;
  explanation?: {
    mode: string;
    alpha?: number | null;
    dense: number;
    bm25: number;
    score: number;
    formula: string;
    matched_terms: { term: string; tf: number; idf: number; contribution: number }[];
  } | null;
}

export interface SearchResponseData {
  trace_id?: string | null;
  total_matches: number;
  results: SearchResultItem[];
  query_applied?: string | null;
  search_type_used: string;
  filters_applied: Record<string, any>;
  similarity_threshold_used?: number | null;
  message?: string | null;
  search_strategy: {
    semantic_search: boolean;
    keyword_search: boolean;
    metadata_filtering: boolean;
    alpha?: number | null;
    embedding_backend?: string;
    embedding_model?: string;
    indexed_documents?: number;
  };
}

export interface AnalyticsOverview {
  total_incidents: number;
  open_incidents: number;
  critical_incidents: number;
  high_incidents: number;
  p1_open: number;
  investigations_in_progress: number;
  model_scored_incidents: number;
  mean_model_confidence: number | null;
  analyst_confirmed: number;
  knowledge_base_size: number;
  data_sources: Record<string, number>;
}

export interface AttackDistributionItem { attack_type: string; count: number }
export interface SeverityDistributionItem { risk_level: string; count: number }
export interface ProtocolDistributionItem { protocol: string; count: number }
export interface PortDistributionItem { port: number; count: number }
export interface TrendItem { date: string; total: number; critical: number; high: number }

export interface PerClassMetric { precision: number; recall: number; f1: number; support: number; low_support?: boolean }

export interface MLEvaluationMetrics {
  status?: string;
  reason?: string;
  model_version: string;
  dataset_source: string;
  synthetic?: boolean;
  trained_at?: string;
  n_train?: number;
  n_test?: number;
  n_feedback_rows?: number;
  accuracy: number;
  precision_macro: number;
  recall_macro: number;
  f1_macro: number;
  f1_weighted?: number;
  samples_evaluated: number;
  per_class_metrics: Record<string, PerClassMetric>;
  confusion_matrix: { labels: string[]; matrix: number[][] };
  top_confusions?: { true: string; predicted: string; count: number }[];
  cv?: { folds: number; subsample: number; accuracy: number; f1_macro: number };
  intrusion_model?: Record<string, number>;
  anomaly_model?: Record<string, any>;
  feature_importances: Record<string, number>;
  caveat?: string;
  recomputed?: boolean;
  evaluated_at: string;
}

export interface RetrievalVariant {
  hybrid: Record<string, number>;
  semantic_only: Record<string, number>;
  keyword_only: Record<string, number>;
  per_class_precision_at_k: Record<string, number>;
  threshold_sweep: { threshold: number; coverage: number; precision_at_1_when_answered: number | null }[];
}

export interface RetrievalMetrics {
  status: string;
  message?: string;
  reason?: string;
  method?: string;
  k?: number;
  embedding_model?: string;
  hybrid_alpha?: number;
  similarity_threshold?: number;
  knowledge_base_size?: number;
  queries?: number;
  random_retrieval_precision?: number;
  with_endpoints?: RetrievalVariant;
  without_ip_addresses?: RetrievalVariant;
  operating_point?: { threshold: number; coverage: number; precision_at_1_when_answered: number | null } | null;
  evaluated_at?: string;
}

export interface DeepEvalCase {
  incident_id: number;
  flow_id: string;
  generator?: string;
  metrics: Record<string, { score: number | null; passed?: boolean; reason?: string; error?: string }>;
}

export interface DeepEvalMetrics {
  status: string; // ok | running | unavailable | failed | not_executed | no_data
  run_status?: string;
  message?: string;
  reason?: string;
  error?: string;
  library?: string;
  judge_model?: string;
  judge_independent_of_generator?: boolean;
  answer_relevancy?: number | null;
  faithfulness?: number | null;
  hallucination?: number | null;
  recommendation_quality?: number | null;
  n_cases?: number;
  n_metric_errors?: number;
  n_metric_calls?: number;
  judge_llm_calls?: number;
  cases?: DeepEvalCase[];
  deterministic_checks?: Record<string, any>;
  duration_s?: number;
  evaluated_at?: string;
  interpretation?: string;
}

export interface JudgeScores {
  correctness: number;
  relevance: number;
  reasoning_quality: number;
  recommendation_quality: number;
  verdict: string;
  critique: string;
  unsupported_claims?: string[];
}

export interface LLMJudgeResult {
  status: string; // ok | unavailable | parse_failed
  incident_id?: number;
  flow_id?: string;
  scores: JudgeScores | null;
  judge_model?: string;
  generator_model?: string;
  independent?: boolean;
  error?: string;
  evaluated_at?: string;
}

export interface LLMJudgeBatch {
  status: string;
  n_cases: number;
  n_scored: number;
  mean_correctness?: number;
  mean_relevance?: number;
  mean_reasoning_quality?: number;
  mean_recommendation_quality?: number;
  verdicts?: Record<string, number>;
  judge_model?: string;
  cases: LLMJudgeResult[];
}

export interface EvaluationRunRecord {
  id: number;
  eval_type: string;
  model_version: string;
  dataset_version: string;
  status: string;
  metrics: any;
  created_at: string;
}

export interface ModelInfo {
  loaded: boolean;
  version?: string;
  dataset_source?: string;
  trained_at?: string;
  trigger?: string;
  n_train?: number;
  n_test?: number;
  n_feedback_rows?: number;
  classes?: string[];
  metrics?: MLEvaluationMetrics;
  versions?: { version: string; active: boolean; trained_at?: string; dataset_source?: string; trigger?: string; macro_f1?: number; accuracy?: number }[];
  message?: string;
}

export interface AttackProfile {
  n_train: number;
  top_features: { feature: string; label: string; median: number; benign_median: number; ratio_to_benign: number; separation: number; direction: 'higher' | 'lower' }[];
  shap_importance: { feature: string; label: string; mean_abs_shap: number }[];
}

export interface RetrainStatus {
  status: 'idle' | 'running' | 'completed' | 'failed';
  step?: string;
  started?: boolean;
  triggered_by?: string;
  result?: {
    decision: string;
    reason?: string;
    candidate_version?: string;
    previous_version?: string | null;
    feedback_incidents_used?: number;
    feedback_class_counts?: Record<string, number>;
    candidate?: { accuracy: number; f1_macro: number };
    previous?: { accuracy: number; f1_macro: number } | null;
    rule?: string;
    duration_s?: number;
  } | null;
}

export interface AuditEntry {
  id: number;
  timestamp: string;
  username?: string | null;
  action: string;
  incident_id?: number | null;
  endpoint?: string | null;
  model_provider?: string | null;
  fallback_used: boolean;
  status: string;
  ip_address?: string | null;
  details?: Record<string, any> | null;
}

export interface HealthComponent {
  status: 'Healthy' | 'Degraded' | 'Unavailable';
  details?: string;
  model?: string;
  model_version?: string;
  dataset_source?: string;
  judge_model?: string;
  configured?: boolean;
  dimension?: number;
  documents?: number;
  engine?: string;                          // vector_index: "qdrant"
  store_mode?: 'local' | 'memory' | 'server';
  store_location?: string;
  qdrant_points?: number | null;
  incidents?: number;
  latency_ms?: number;
  suites?: string[];
  threshold?: number;
  alpha?: number;
}

export interface SystemHealthData {
  status: 'Healthy' | 'Degraded' | 'Unavailable';
  app_name: string;
  version: string;
  environment?: string;
  components: Record<string, HealthComponent>;
}

export interface UserProfile {
  id: number;
  username: string;
  email: string;
  role: 'ADMIN' | 'ANALYST' | 'VIEWER';
  is_active: boolean;
  created_at: string;
}

export interface ChatCitation {
  incident_id: number;
  flow_id: string;
  attack_type: string;
  similarity_score: number;
  source_ip: string;
  destination_ip: string;
  destination_port: number;
  protocol: number;
}

export interface ChatMessage {
  id?: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp?: string;
  citations?: ChatCitation[];
  incident_context?: Record<string, any>;
  llm_provider?: string;
  model_name?: string;
  fallback_used?: boolean;
  llm_attempts?: LlmAttempt[];
  trace_id?: string | null;
  /** Set on locally generated failure messages so the UI can style them as errors. */
  isError?: boolean;
}

export interface ChatQueryRequest {
  message: string;
  history?: { role: string; content: string }[];
  incident_id?: number;
  use_rag?: boolean;
  filters?: Record<string, any>;
}

export interface ChatQueryResponse {
  reply: string;
  citations: ChatCitation[];
  incident_context?: Record<string, any>;
  llm_provider: string;
  model_name: string;
  fallback_used: boolean;
  llm_attempts?: LlmAttempt[];
  guardrails: Record<string, any>;
  execution_time_ms: number;
  trace_id?: string | null;
}

export interface ChatSuggestion {
  id: string;
  title: string;
  prompt: string;
  category: string;
}

// ---------------------------------------------------------------------------------------------- observability
export type TraceStatus = 'ok' | 'degraded' | 'rejected' | 'error';

export interface TraceSummary {
  trace_id: string;
  kind: string;
  name?: string | null;
  status: TraceStatus;
  http_status?: number | null;
  username?: string | null;
  role?: string | null;
  incident_id?: number | null;
  query: string;
  started_at: string;
  duration_ms: number;
  db_time_ms: number;
  db_queries: number;
  n_spans: number;
  summary: Record<string, any>;
  error?: string | null;
}

export interface TraceList {
  total: number;
  page: number;
  page_size: number;
  items: TraceSummary[];
  facets: { kinds: Record<string, number>; statuses: Record<string, number> };
}

export interface TraceSpanRecord {
  span_id: string;
  parent_id?: string | null;
  name: string;
  component: string;
  status: 'ok' | 'error' | 'rejected';
  start_offset_ms: number;
  duration_ms: number;
  self_ms: number;
  depth: number;
  attributes: Record<string, any>;
  error?: string | null;
}

export interface TraceFull extends TraceSummary {
  query_text?: string | null;
  input: Record<string, any>;
  output: Record<string, any>;
  counters: Record<string, number>;
  request_id?: string | null;
  dropped_spans: number;
  spans: TraceSpanRecord[];
}

export interface ExplanationStep {
  order: number;
  title: string;
  component: string;
  verdict: 'ok' | 'blocked' | 'warn' | 'info';
  detail: string;
  span_id: string;
  duration_ms: number;
}

export interface TraceExplanation {
  headline: string;
  steps: ExplanationStep[];
  evidence: {
    retrieval?: {
      query?: string; mode?: string; alpha?: number; threshold?: number; filters?: Record<string, any>; n_indexed?: number; n_candidates?: number;
      n_results?: number; empty?: boolean; formula?: string; stats: Record<string, any>;
      results: { incident_id: number; flow_id: string; attack_type: string; score: number; dense: number; bm25: number; matched_terms: { term: string; tf: number; idf: number; contribution: number }[] }[];
    };
    model?: {
      attack_type?: string; confidence?: number; model_version?: string; low_confidence?: boolean; intrusion_probability?: number; anomaly_score?: number;
      top_classes: { attack_type: string; probability: number }[]; explanation_method?: string; target_class?: string;
      contributions: { feature: string; label: string; value: number; contribution: number; benign_median: number }[];
    };
    risk?: { risk_score?: number; risk_level?: Severity; priority?: Priority; components: Record<string, number>; weights: Record<string, number>; factors: string[]; policy_floor_applied?: boolean };
    llm?: {
      span_id: string; mode?: string; provider?: string; model?: string; fallback_used?: boolean; latency_ms?: number; usage?: Record<string, number> | null;
      finish_reason?: string | null; attempts: Record<string, any>[]; chain: string[]; prompt_chars?: number; prompt_sha256?: string; temperature?: number;
      prompt_preview?: string | null; system_preview?: string | null; response_preview?: string | null; status: string; error?: string | null;
    }[];
    checks?: { check: string; passed: boolean; detail: string }[];
    guardrails?: { name: string; verdict: string; detail: string }[];
  };
  time_breakdown: {
    total_ms: number; db_ms: number; db_queries: number; by_component: Record<string, number>;
    slowest: { name: string; component: string; self_ms: number; duration_ms: number }[];
  };
}

export interface TraceDetail {
  trace: TraceFull;
  explanation: TraceExplanation;
  audit: { action: string; status: string; timestamp: string; model_provider?: string | null; fallback_used?: boolean }[];
}

export interface Percentiles { p50: number | null; p95: number | null; p99: number | null; max: number | null; avg: number | null }

export interface ObservabilityMetrics {
  window: string;
  windows: string[];
  since: string;
  until: string;
  totals: {
    traces: number; by_status: Record<TraceStatus, number>; error_rate: number | null; degraded_rate: number | null; rejected_rate: number | null;
    interactive_latency_ms: Percentiles; avg_db_ms: number | null; avg_db_queries: number | null;
  };
  per_kind: Record<string, { count: number; ok: number; degraded: number; rejected: number; error: number; avg_db_ms: number; avg_db_queries: number } & Percentiles>;
  timeseries: { t: string; total: number; ok: number; degraded: number; rejected: number; error: number; avg_ms: number | null }[];
  llm: { calls: number; fallbacks: number; fallback_rate: number | null; failed_attempts: number; prompt_tokens: number; completion_tokens: number; latency_ms: Percentiles;
         models: Record<string, { calls: number; avg_latency_ms: number | null }> };
  retrieval: { searches: number; empty: number; empty_rate: number | null; pool_widenings: number; avg_candidates_scored: number | null; avg_dense_ties_at_top: number | null };
  guardrails: { blocked_security: number; blocked_relevance: number; validation_failed: number; output_checks: number; output_checks_failed: number; output_check_pass_rate: number | null };
  ml: { predictions: number; low_confidence: number; low_confidence_rate: number | null };
  time_by_component: Record<string, { self_ms: number; spans: number }>;
  top_spans: { name: string; component: string; count: number; avg_ms: number; max_ms: number; self_ms_total: number; errors: number }[];
  slowest_traces: { trace_id: string; kind: string; duration_ms: number; query: string; status: TraceStatus }[];
  recent_problems: { trace_id: string; kind: string; status: TraceStatus; started_at: string; query: string; error: string }[];
  top_users: { username: string; traces: number }[];
}

export interface SystemExplanation {
  pipeline: { id: string; title: string; component: string; what: string; how: string; parameters: Record<string, any>; spans: string[] }[];
  observability: {
    tracing_enabled: boolean; trace_all_requests: boolean; retention_days: number; store_payloads: boolean; max_spans_per_trace: number;
    traces_stored: number | null; traced_operations: string[]; note: string;
  };
  data: { classes?: string[]; dataset_source?: string; model_version?: string };
}
