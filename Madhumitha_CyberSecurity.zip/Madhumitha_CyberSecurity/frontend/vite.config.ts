import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// The API is called through a relative `/api/v1` path: in development Vite proxies it to the FastAPI backend,
// in Docker nginx proxies it. No hard-coded host/port anywhere in the app.
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': { target: process.env.VITE_BACKEND_URL || 'http://127.0.0.1:8000', changeOrigin: true },
    },
  },
})
