@echo off
rem Build a clean, portable zip of this project (see package_project.py --help). Needs any Python 3.8+.
rem   package.bat                   zip with your .env files and local database
rem   package.bat --no-secrets      zip without the .env files (no API key inside)
rem   package.bat --include-dataset also ship the 240 MB dataset (setup then needs no download)
setlocal
cd /d "%~dp0"
set "PYRUN="
call :try py -3
if not defined PYRUN call :try python
if not defined PYRUN call :try "%USERPROFILE%\.soc-venv\Scripts\python.exe"
if not defined PYRUN call :try "%~dp0.venv\Scripts\python.exe"
if not defined PYRUN (
  echo Python 3 was not found. Install it from https://www.python.org/downloads/ or run setup.bat once ^(it installs Python^).
  pause
  exit /b 1
)
%PYRUN% "%~dp0package_project.py" %*
set RC=%ERRORLEVEL%
if not "%RC%"=="0" pause
exit /b %RC%

:try
%* -c "import sys; sys.exit(0 if sys.version_info[:2] >= (3, 8) else 1)" >nul 2>nul
if not errorlevel 1 set "PYRUN=%*"
exit /b 0
