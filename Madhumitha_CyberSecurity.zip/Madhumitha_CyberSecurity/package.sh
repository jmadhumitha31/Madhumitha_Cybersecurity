#!/usr/bin/env bash
# Build a clean, portable zip of this project (see package_project.py --help). Needs any Python 3.8+.
#   bash package.sh                   zip with your .env files and local database
#   bash package.sh --no-secrets      zip without the .env files (no API key inside)
#   bash package.sh --include-dataset also ship the 240 MB dataset (setup then needs no download)
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info[:2] >= (3, 8) else 1)' 2>/dev/null; then
    exec "$c" package_project.py "$@"
  fi
done
echo "Python 3 was not found. Install Python 3.11 (https://www.python.org/downloads/) or run bash setup.sh once." >&2
exit 1
