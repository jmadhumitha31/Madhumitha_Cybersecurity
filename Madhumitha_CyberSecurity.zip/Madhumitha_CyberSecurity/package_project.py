#!/usr/bin/env python3
"""Build a clean, portable zip of the project that runs on another computer after ``setup.bat`` / ``bash setup.sh``.

    package.bat                      Windows       (or: python package_project.py)
    bash package.sh                  macOS / Linux

What goes in
    * all source code, docs, the setup scripts, ``frontend/package-lock.json`` and ``backend/constraints.txt``
    * ``.env`` and ``backend/.env`` (your NVIDIA key and settings) - a NEW random JWT_SECRET is written into the copies in the zip
    * ``backend/soc_assistant.db``: a consistent snapshot of the local database (earlier analyses, searches, audit log, traces)

What stays out (rebuilt by setup on the other computer)
    node_modules, virtual environments, trained models, the Qdrant index, the embedding-model cache, the CIC-IDS2017 download,
    logs, caches, stale database copies and backups.  Use --include-dataset to add the 240 MB dataset (works fully offline).

The finished zip is verified: every member is checked against the exclusion rules, line endings are normalised
(``*.sh`` LF, ``*.bat`` CRLF), and every file is scanned for the secrets found in your .env (API keys appear only in the
two .env files, and not at all with --no-secrets). Secret values are never printed.

Standard library only; runs on Python 3.8+.
"""
from __future__ import annotations

import argparse
import datetime as dt
import getpass
import os
import re
import secrets
import sqlite3
import stat
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Dict, Iterator, List, Optional, Sequence, Tuple

ROOT = Path(__file__).resolve().parent
ROOT_NAME = ROOT.name
RELEASE_DIR = ROOT / "release"
DB_REL = "backend/soc_assistant.db"
ENV_RELS = (".env", "backend/.env")

# directories skipped wherever they appear
SKIP_DIR_NAMES = {"node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".hypothesis", ".git", ".venv", "venv",
                  ".idea", ".vscode", ".claude"}
# paths (relative to the project root, posix) skipped entirely
SKIP_PATHS = {"logs", ".setup", ".tools", "release", ".deepeval", "backend/.deepeval", "frontend/dist",
              "backend/models/versions", "backend/models/embedding_cache", "backend/models/_legacy_synthetic", "backend/models/active_model.json",
              "backend/models/.locks", "backend/models/models--Qdrant--all-MiniLM-L6-v2-onnx",
              "backend/data/qdrant", "backend/data/_legacy", "backend/data/synthetic_demo_sample.csv", "backend/data/cicids2017"}
SKIP_SUFFIXES = (".pyc", ".pyo", ".log", ".pid", ".bak", ".tmp", ".zip", ".pem", ".key", ".pfx", ".p12")
SKIP_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini"}
DATASET_REL = "backend/data/cicids2017"

MUST_HAVE = ["START_HERE.txt", "README.md", "setup.bat", "setup.ps1", "setup.sh", "setup_project.py", "start.bat", "start.sh", "stop.bat",
             "package_project.py", "docker-compose.yml", ".env.example", "backend/.env.example", "backend/requirements.txt",
             "backend/constraints.txt", "backend/app/main.py", "backend/scripts/bootstrap.py", "backend/scripts/build_index.py",
             "backend/scripts/download_cicids2017.py", "frontend/package.json", "frontend/package-lock.json", "frontend/index.html",
             "frontend/src/main.tsx"]

SECRET_KEY_RE = re.compile(r"(KEY|SECRET|TOKEN|PASSWORD)", re.I)
PLACEHOLDER_RE = re.compile(r"^(change-?me|changeme|your[-_ ].*|xxx+|<.*>|none|null|false|true)$", re.I)
GENERIC_PATTERNS = {
    "an NVIDIA API key": re.compile(rb"nvapi-[A-Za-z0-9_\-]{40,}"),  # real keys are ~64 chars after the prefix; test fixtures are shorter
    "an AICredits API key": re.compile(rb"sk-live-[A-Za-z0-9_\-]{20,}"),
    "a private key block": re.compile(rb"-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----"),
}
MAX_SCAN_BYTES = 80 * 1024 * 1024


# ------------------------------------------------------------------------------------------------ helpers
def say(msg: str = "") -> None:
    print(msg, flush=True)


def posix(p: Path) -> str:
    return p.relative_to(ROOT).as_posix()


def parse_env(text: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for line in text.splitlines():
        m = re.match(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$", line)
        if m and not line.lstrip().startswith("#"):
            out[m.group(1)] = m.group(2).strip().strip("'\"")
    return out


def secret_values(env_files: Sequence[Path]) -> Dict[str, str]:
    """{label: value} for every secret-looking setting with a real value. Labels never contain the value."""
    found: Dict[str, str] = {}
    for f in env_files:
        if not f.exists():
            continue
        for k, v in parse_env(f.read_text(encoding="utf-8", errors="replace")).items():
            if SECRET_KEY_RE.search(k) and len(v) >= 12 and not PLACEHOLDER_RE.match(v):
                found[f"{k} from {f.relative_to(ROOT).as_posix()}"] = v
    return found


def is_skipped(rel: str, include_dataset: bool) -> bool:
    if include_dataset and (rel == DATASET_REL or rel.startswith(DATASET_REL + "/")):
        return False
    return any(rel == p or rel.startswith(p + "/") for p in SKIP_PATHS)


def walk_project(include_dataset: bool) -> Iterator[Path]:
    for dirpath, dirnames, filenames in os.walk(ROOT):
        d = Path(dirpath)
        dirnames[:] = sorted(n for n in dirnames if n not in SKIP_DIR_NAMES and not is_skipped(posix(d / n), include_dataset))
        for name in sorted(filenames):
            f = d / name
            rel = posix(f)
            lower = name.lower()
            if name in SKIP_NAMES or lower.endswith(SKIP_SUFFIXES) or is_skipped(rel, include_dataset):
                continue
            if lower.startswith(".env") and name != ".env.example":
                continue  # real env files are added explicitly (or not at all)
            if re.search(r"\.db($|[.-])", lower):
                continue  # databases are added explicitly as a consistent snapshot
            yield f


def normalise(rel: str, data: bytes) -> bytes:
    """*.sh must be LF (CRLF breaks bash) and *.bat/*.cmd must be CRLF; leave everything else byte-for-byte."""
    low = rel.lower()
    if low.endswith(".sh"):
        return data.replace(b"\r\n", b"\n")
    if low.endswith((".bat", ".cmd")):
        return data.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
    return data


def snapshot_database(src: Path, dst: Path) -> Tuple[bool, str, Dict[str, int]]:
    """Consistent copy through SQLite's online-backup API (safe even if the app is running), then integrity-check it."""
    ro = sqlite3.connect(f"file:{src.as_posix()}?mode=ro", uri=True, timeout=30)
    try:
        out = sqlite3.connect(str(dst))
        try:
            ro.backup(out)
            out.commit()
            verdict = out.execute("PRAGMA integrity_check").fetchone()[0]
            tables = [r[0] for r in out.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
            counts = {t: out.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0] for t in tables}
        finally:
            out.close()
    finally:
        ro.close()
    return verdict == "ok", verdict, counts


def zip_info(arcname: str, mtime: float, executable: bool) -> zipfile.ZipInfo:
    t = dt.datetime.fromtimestamp(max(mtime, 315532800))  # zip cannot store dates before 1980
    zi = zipfile.ZipInfo(arcname, date_time=(t.year, t.month, t.day, t.hour, t.minute, t.second))
    zi.compress_type = zipfile.ZIP_DEFLATED
    zi.create_system = 3  # Unix: lets unzip on macOS/Linux restore the executable bit
    zi.external_attr = ((stat.S_IFREG | (0o755 if executable else 0o644)) & 0xFFFF) << 16
    return zi


def human(n: float) -> str:
    return f"{n / 1e6:,.1f} MB" if n >= 1e6 else f"{n / 1e3:,.0f} KB"


# ------------------------------------------------------------------------------------------------ verification
def verify_zip(zip_path: Path, secrets_in: Dict[str, str], *, expect_env: bool, expect_db: bool, expect_dataset: bool = False) -> Tuple[List[str], List[str]]:
    """Return (problems, warnings). Problems mean the zip must not be shared."""
    problems: List[str] = []
    warnings: List[str] = []
    prefix = ROOT_NAME + "/"
    env_members = {prefix + r for r in ENV_RELS}
    local_markers = [m for m in {getpass.getuser(), str(Path.home())} if m and len(m) > 3]
    forbidden = re.compile(r"(^|/)(node_modules|__pycache__|\.pytest_cache|\.venv|venv|\.git)/|\.pyc$|\.db-(wal|shm|journal)$|\.bak$|\.zip$"
                           rf"|^{re.escape(prefix)}(logs|\.setup|\.tools|release|\.deepeval)/"
                           rf"|^{re.escape(prefix)}backend/models/(versions|embedding_cache|_legacy_synthetic|active_model\.json|\.locks|models--)"
                           rf"|^{re.escape(prefix)}backend/data/(qdrant|_legacy)|^{re.escape(prefix)}frontend/dist/")
    with zipfile.ZipFile(zip_path) as z:
        bad = z.testzip()
        if bad:
            problems.append(f"corrupt member: {bad}")
        names = z.namelist()
        nameset = set(names)
        for rel in MUST_HAVE:
            if prefix + rel not in nameset:
                problems.append(f"missing required file: {rel}")
        for n in names:
            if not n.startswith(prefix):
                problems.append(f"member outside the {ROOT_NAME}/ folder: {n}")
            if forbidden.search(n):
                problems.append(f"member that must not be shipped: {n}")
            if not expect_dataset and "backend/data/cicids2017/" in n:
                problems.append(f"dataset file in a zip built without --include-dataset: {n}")
            low = n.lower()
            if (low.endswith(".db") or ".db." in low) and n != prefix + DB_REL:
                problems.append(f"unexpected database file: {n}")
            base = n.rsplit("/", 1)[-1].lower()
            if base.startswith(".env") and base != ".env.example" and n not in env_members:
                problems.append(f"unexpected env file: {n}")
        if expect_db and prefix + DB_REL not in nameset:
            problems.append(f"missing the database snapshot {DB_REL}")
        if not expect_db and prefix + DB_REL in nameset:
            problems.append("database present although --no-database was given")
        for e in env_members:
            if expect_env and e not in nameset:
                problems.append(f"missing {e[len(prefix):]} (expected: the zip is built with the env files)")
            if not expect_env and e in nameset:
                problems.append(f"{e[len(prefix):]} present although --no-secrets was given")
        for n in names:
            if n.endswith(".sh"):
                if b"\r" in z.read(n):
                    problems.append(f"CRLF line endings in {n} (bash would fail)")
                if not ((z.getinfo(n).external_attr >> 16) & 0o100):
                    warnings.append(f"{n} has no executable bit (run it with: bash {n.rsplit('/', 1)[-1]})")
            if n.endswith(".bat") and b"\r\n" not in z.read(n) and len(z.read(n)) > 40:
                problems.append(f"LF-only line endings in {n}")
        # secret scan: every member, byte-for-byte
        for n in names:
            info = z.getinfo(n)
            low = n.lower()
            if info.file_size > MAX_SCAN_BYTES or (low.endswith((".csv", ".parquet")) and info.file_size > 1_000_000):
                continue
            data = z.read(n)
            allowed_env = n in env_members
            for label, value in secrets_in.items():
                if value.encode() in data:
                    is_jwt = label.startswith("JWT_SECRET")
                    if is_jwt or not allowed_env or not expect_env:
                        problems.append(f"secret ({label.split(' from ')[0]}) found in {n}")
            for label, pat in GENERIC_PATTERNS.items():
                if pat.search(data) and not (allowed_env and expect_env and ("NVIDIA" in label or "AICredits" in label)):
                    problems.append(f"{label} found in {n}")
            for m in local_markers:
                if m.encode() in data and n.endswith((".db", ".json", ".txt", ".cfg", ".ini", ".env")):
                    warnings.append(f"{n} mentions this computer's user/home path ({'user name' if m == getpass.getuser() else 'home folder'})")
                    break
    return problems, warnings


# ------------------------------------------------------------------------------------------------ build
def build(args: argparse.Namespace) -> int:
    include_env = not args.no_secrets
    include_db = not args.no_database
    env_paths = [ROOT / r for r in ENV_RELS]
    secrets_in = secret_values(env_paths)

    files = list(walk_project(args.include_dataset))
    total = sum(f.stat().st_size for f in files)
    say(f"Project: {ROOT}")
    say(f"Files:   {len(files):,} source/doc/script files ({human(total)} before compression)")
    if args.list:
        for f in files:
            say("  " + posix(f))
        return 0

    stamp = dt.date.today().strftime("%Y%m%d")
    out = Path(args.out).resolve() if args.out else RELEASE_DIR / f"{ROOT_NAME}-{stamp}.zip"
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp_zip = out.with_suffix(".zip.partial")
    new_jwt = secrets.token_urlsafe(48)

    with tempfile.TemporaryDirectory(prefix="soc-pack-") as td:
        notes: List[str] = []
        extra: List[Tuple[str, bytes, float, bool]] = []
        if include_env:
            for r in ENV_RELS:
                p = ROOT / r
                if not p.exists():
                    notes.append(f"{r} not found - the other computer will create it from .env.example during setup")
                    continue
                text = p.read_text(encoding="utf-8")
                replaced = re.subn(r"(?m)^(\s*JWT_SECRET\s*=).*$", lambda m: m.group(1) + new_jwt, text)
                text = replaced[0] if replaced[1] else text
                extra.append((r, text.encode("utf-8"), p.stat().st_mtime, False))
            notes.append("env files included (your NVIDIA key travels with the zip); a fresh JWT_SECRET was generated for the copies")
        else:
            notes.append("--no-secrets: no .env files; the other computer is asked for an NVIDIA key (Enter = offline playbooks)")
        if include_db:
            src = ROOT / DB_REL
            if src.exists():
                snap = Path(td) / "soc_assistant.db"
                ok, verdict, counts = snapshot_database(src, snap)
                if not ok:
                    say(f"[xx] The database failed its integrity check ({verdict}); not packaging it. Fix or use --no-database.")
                    return 2
                extra.append((DB_REL, snap.read_bytes(), src.stat().st_mtime, False))
                rows = ", ".join(f"{k} {v}" for k, v in counts.items() if v and k not in ("incidents", "incident_embeddings"))
                notes.append(f"database snapshot included (integrity ok): {counts.get('incidents', 0):,} incidents; {rows}")
            else:
                notes.append(f"{DB_REL} not found - setup builds a fresh database")
        else:
            notes.append("--no-database: setup builds a fresh database with the demo accounts")

        say(f"Writing: {out}")
        try:
            with zipfile.ZipFile(tmp_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
                for f in files:
                    rel = posix(f)
                    data = normalise(rel, f.read_bytes())
                    z.writestr(zip_info(f"{ROOT_NAME}/{rel}", f.stat().st_mtime, rel.endswith(".sh")), data)
                for rel, data, mtime, exe in extra:
                    z.writestr(zip_info(f"{ROOT_NAME}/{rel}", mtime, exe), data)
        except BaseException:
            tmp_zip.unlink(missing_ok=True)
            raise

    say("Verifying the zip ...")
    problems, warnings = verify_zip(tmp_zip, secrets_in, expect_env=include_env, expect_db=include_db, expect_dataset=args.include_dataset)
    if problems:
        tmp_zip.unlink(missing_ok=True)
        say("")
        for p in problems:
            say(f"[xx] {p}")
        say("The zip was NOT created.")
        return 1
    if out.exists():
        out.unlink()
    tmp_zip.replace(out)
    say("")
    say(f"[ok] {out}")
    say(f"     {human(out.stat().st_size)} ({len(files) + len(extra):,} files), top folder {ROOT_NAME}/")
    for n in notes:
        say(f"     - {n}")
    for w in warnings:
        say(f"[!!] {w}")
    if include_env:
        say("")
        say("[!!] This zip contains your NVIDIA API key (in .env and backend/.env). Share it only with people you trust,")
        say("     and rotate the key at https://build.nvidia.com when you are done. Use --no-secrets for a key-free zip.")
    say("")
    say("On the other computer: unzip (a SHORT folder such as C:\\soc is best), then double-click setup.bat (Windows)")
    say("or run `bash setup.sh` (macOS/Linux). START_HERE.txt in the zip explains the rest.")
    return 0


def main(argv: Optional[Sequence[str]] = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            pass
    p = argparse.ArgumentParser(description="Build a clean portable zip of the project.", formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    p.add_argument("--out", help=f"zip path (default: release/{ROOT_NAME}-<date>.zip)")
    p.add_argument("--no-secrets", action="store_true", help="leave the .env files out (the other computer is asked for an NVIDIA key)")
    p.add_argument("--no-database", action="store_true", help="leave the local database out (setup builds a fresh one)")
    p.add_argument("--include-dataset", action="store_true", help="also ship the CIC-IDS2017 files (+240 MB) so setup needs no download")
    p.add_argument("--list", action="store_true", help="list the files that would be packaged and exit")
    p.add_argument("--verify", metavar="ZIP", help="only verify an existing zip")
    args = p.parse_args(argv)
    if args.verify:
        problems, warnings = verify_zip(Path(args.verify), secret_values([ROOT / r for r in ENV_RELS]), expect_env=not args.no_secrets,
                                        expect_db=not args.no_database, expect_dataset=args.include_dataset)
        for x in problems:
            say(f"[xx] {x}")
        for x in warnings:
            say(f"[!!] {x}")
        say("[ok] zip verified" if not problems else "zip NOT ok")
        return 1 if problems else 0
    return build(args)


if __name__ == "__main__":
    sys.exit(main())
