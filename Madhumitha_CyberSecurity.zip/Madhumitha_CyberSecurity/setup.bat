@echo off
rem Double-click to set up and run the SOC Incident Response Assistant (installs Python / Node.js if missing).
rem Extra arguments are passed on, e.g.  setup.bat -Yes   or   setup.bat --dataset synthetic
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
set RC=%ERRORLEVEL%
if "%~1"=="" if not "%RC%"=="0" pause
exit /b %RC%
