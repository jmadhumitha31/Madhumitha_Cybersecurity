<#
.SYNOPSIS
  Set up and run the SOC Incident Response Assistant on a Windows computer (first run on a new laptop).

.DESCRIPTION
  1. Makes sure Python 3.11/3.12 and Node.js (20.19+ or 22.12+, which Vite 8 requires) are installed. If one is missing it is installed
     (winget first; python.org installer / portable Node.js zip as fallbacks) after you confirm.
  2. Hands over to setup_project.py, which creates the virtual environment, installs the backend and frontend
     packages, downloads the CIC-IDS2017 dataset (~240 MB), trains the models, builds the search index and starts
     the API and the web UI. Every step is skipped when it is already done, so re-running only repeats what is missing.

  Normally started by double-clicking setup.bat. Everything is logged to logs\setup-<time>.log.

.PARAMETER Yes        Answer yes to every question (installing Python/Node, resetting data ...).
.PARAMETER CheckOnly  Dry run: report what is installed and what would be done; change nothing.
.PARAMETER Fast       Already set up: skip the dependency and data checks and just start the servers.
.PARAMETER Stop       Stop servers left running by a previous run.

  Any other argument is passed to setup_project.py, for example:
    .\setup.ps1 -Yes --dataset synthetic          offline demo with generated data
    .\setup.ps1 --no-run                          prepare everything, do not start the servers
    .\setup.ps1 --reset-data                      rebuild database, models and index (dataset is kept)
    .\setup.ps1 --nvidia-key nvapi-...            store an NVIDIA NIM key (or set $env:NVIDIA_API_KEY first: safer)
  Run  python setup_project.py --help  for the complete list.
#>
[CmdletBinding()]
param(
    [switch]$Yes,
    [switch]$CheckOnly,
    [switch]$Fast,
    [switch]$Stop,
    [Parameter(ValueFromRemainingArguments = $true)] [string[]]$PassThru
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Tools = Join-Path $Root '.tools'
$LogDir = Join-Path $Root 'logs'
$null = New-Item -ItemType Directory -Force -Path $LogDir
$Log = Join-Path $LogDir ("setup-bootstrap-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))

# Pinned versions for the fallbacks (used only when winget is unavailable or fails)
$PythonVersion = '3.11.9'
$NodeVersion = 'v22.12.0'

function Test-NodeVersion([version]$v) {
    # Vite 8 (rolldown) declares node ^20.19.0 || >=22.12.0. On an older Node, npm silently skips its native binding and the UI cannot start.
    return ($v.Major -ge 23) -or ($v.Major -eq 22 -and $v.Minor -ge 12) -or ($v.Major -eq 20 -and $v.Minor -ge 19)
}

try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }

function Log([string]$m) { Add-Content -Path $Log -Value ("{0} {1}" -f (Get-Date -Format 'HH:mm:ss'), $m) -Encoding UTF8 }
function Say([string]$m, [string]$color = 'Gray') { Write-Host $m -ForegroundColor $color; Log $m }
function Ok([string]$m) { Say "  [ok] $m" 'Green' }
function Warn([string]$m) { Say "  [!!] $m" 'Yellow' }
function Fail([string]$m) { Say "  [xx] $m" 'Red' }

function Update-SessionPath {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = (@($machine, $user, $env:Path) | Where-Object { $_ }) -join ';'
}

function Confirm-Action([string]$question) {
    if ($Yes) { return $true }
    if (-not [Environment]::UserInteractive -or [Console]::IsInputRedirected) { return $false }
    $a = Read-Host "  $question [Y/n]"
    return ([string]::IsNullOrWhiteSpace($a) -or $a.Trim().ToLower().StartsWith('y'))
}

function Invoke-Quiet([string]$exe, [string[]]$arguments) {
    # Runs a program and returns its trimmed stdout, or $null when it fails (never throws, never opens a window).
    $ErrorActionPreference = 'Continue'   # Windows PowerShell 5.1 raises on native stderr even when it is redirected
    try {
        $out = & $exe @arguments 2>$null
        if ($LASTEXITCODE -ne 0) { return $null }
        return ($out | Out-String).Trim()
    } catch { return $null }
}

function Get-Download([string]$url, [string]$outFile, [string]$manualHint) {
    try {
        Invoke-WebRequest -Uri $url -OutFile $outFile -UseBasicParsing
    } catch {
        $msg = $_.Exception.Message
        if ($msg.Length -gt 160) { $msg = $msg.Substring(0, 160) }
        throw "Could not download $url ($msg). Your network may block this site. $manualHint Then run setup again."
    }
}

# --------------------------------------------------------------------------------------------- Python
function Test-PythonExe([string]$exe, [string[]]$prefix = @()) {
    # -> full path of a supported interpreter (3.11 / 3.12) or $null. Skips the Microsoft Store stub (it opens the Store).
    if ($exe -match '\\WindowsApps\\') { return $null }
    # No double quotes in the one-liner: Windows PowerShell 5.1 strips them from native arguments.
    $code = 'import sys; print(sys.executable); print(sys.version_info[0], sys.version_info[1])'
    $out = Invoke-Quiet $exe ($prefix + @('-c', $code))
    if (-not $out) { return $null }
    $lines = $out -split "`r?`n"
    if ($lines.Count -lt 2) { return $null }
    if ($lines[1].Trim() -in @('3 11', '3 12')) { return $lines[0].Trim() }
    return $null
}

function Find-Python {
    $candidates = @()
    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($py) { foreach ($v in '-3.11', '-3.12') { $r = Test-PythonExe $py.Source @($v); if ($r) { return $r } } }
    foreach ($name in 'python3.11', 'python3.12', 'python3', 'python') {
        $c = Get-Command "$name.exe" -ErrorAction SilentlyContinue
        if ($c) { $r = Test-PythonExe $c.Source; if ($r) { return $r } }
    }
    foreach ($d in "$env:LOCALAPPDATA\Programs\Python\Python311", "$env:LOCALAPPDATA\Programs\Python\Python312", "$env:ProgramFiles\Python311", "$env:ProgramFiles\Python312") {
        $exe = Join-Path $d 'python.exe'
        if (Test-Path $exe) { $r = Test-PythonExe $exe; if ($r) { return $r } }
    }
    return $null
}

function Install-Python {
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'amd64' }
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        Say "  Installing Python 3.11 with winget (current user, no administrator rights needed) ..."
        & winget.exe install -e --id Python.Python.3.11 --scope user --silent --accept-package-agreements --accept-source-agreements --disable-interactivity 2>&1 | ForEach-Object { Log "    winget: $_" }
        Update-SessionPath
        $p = Find-Python
        if ($p) { return $p }
        Warn "winget did not produce a usable Python (exit code $LASTEXITCODE); trying the python.org installer"
    }
    $url = "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-$arch.exe"
    $file = Join-Path $env:TEMP "python-$PythonVersion-$arch.exe"
    Say "  Downloading $url ..."
    Get-Download $url $file "Install Python 3.11 manually from the Microsoft Store or from python.org (tick 'Add python.exe to PATH')."
    $sig = Get-AuthenticodeSignature -FilePath $file
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
        Remove-Item $file -Force -ErrorAction SilentlyContinue
        throw "The downloaded Python installer is not signed by the Python Software Foundation (status: $($sig.Status)). Not running it."
    }
    Ok "installer signature verified (Python Software Foundation)"
    Say "  Running the installer silently (current user) ..."
    $proc = Start-Process -FilePath $file -ArgumentList '/quiet', 'InstallAllUsers=0', 'PrependPath=1', 'Include_launcher=0', 'Include_test=0', 'Include_doc=0' -Wait -PassThru
    Remove-Item $file -Force -ErrorAction SilentlyContinue
    if ($proc.ExitCode -ne 0) { throw "The Python installer failed with exit code $($proc.ExitCode)." }
    Update-SessionPath
    return (Find-Python)
}

# --------------------------------------------------------------------------------------------- Node.js
function Get-NodeVersion([string]$dir) {
    $exe = if ($dir) { Join-Path $dir 'node.exe' } else { $null }
    if (-not $exe) { $c = Get-Command node.exe -ErrorAction SilentlyContinue; if ($c) { $exe = $c.Source } }
    if (-not $exe -or -not (Test-Path $exe)) { return $null }
    $out = Invoke-Quiet $exe @('--version')
    if ($out -match '(\d+)\.(\d+)\.(\d+)') { return [version]"$($Matches[1]).$($Matches[2]).$($Matches[3])" }
    return $null
}

function Find-Node {
    # -> @{ Dir = <directory to put on PATH or $null when already on PATH>; Version = <version> } or $null
    $v = Get-NodeVersion $null
    if ($v -and (Test-NodeVersion $v)) { return @{ Dir = $null; Version = $v } }
    $dirs = @("$env:ProgramFiles\nodejs", "$env:LOCALAPPDATA\Programs\nodejs")
    if (Test-Path $Tools) { $dirs += (Get-ChildItem -Path $Tools -Directory -Filter 'node-*' -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName }) }
    foreach ($d in $dirs) {
        $v = Get-NodeVersion $d
        if ($v -and (Test-NodeVersion $v)) { return @{ Dir = $d; Version = $v } }
    }
    return $null
}

function Install-Node {
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        Say "  Installing Node.js LTS with winget (Windows may ask for administrator approval) ..."
        & winget.exe install -e --id OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements --disable-interactivity 2>&1 | ForEach-Object { Log "    winget: $_" }
        Update-SessionPath
        $n = Find-Node
        if ($n) { return $n }
        Warn "winget did not produce a usable Node.js (exit code $LASTEXITCODE); using the portable download instead"
    }
    $name = "node-$NodeVersion-win-$arch"
    $base = "https://nodejs.org/dist/$NodeVersion"
    $zip = Join-Path $env:TEMP "$name.zip"
    Say "  Downloading $base/$name.zip (about 30 MB) ..."
    $hint = "Install Node.js LTS manually (https://nodejs.org/ or the Microsoft Store 'Node.js' package)."
    Get-Download "$base/$name.zip" $zip $hint
    $sumsFile = Join-Path $env:TEMP 'node-SHASUMS256.txt'
    Get-Download "$base/SHASUMS256.txt" $sumsFile $hint
    $sums = Get-Content -Raw -Path $sumsFile
    Remove-Item $sumsFile -Force -ErrorAction SilentlyContinue
    $expected = ($sums -split "`n" | Where-Object { $_ -match "$name\.zip" } | Select-Object -First 1) -replace '\s+.*$', ''
    $actual = (Get-FileHash -Algorithm SHA256 -Path $zip).Hash.ToLower()
    if (-not $expected -or $actual -ne $expected.Trim().ToLower()) {
        Remove-Item $zip -Force -ErrorAction SilentlyContinue
        throw "Checksum mismatch for $name.zip (expected $expected, got $actual). Not extracting it."
    }
    Ok "SHA-256 checksum verified"
    $null = New-Item -ItemType Directory -Force -Path $Tools
    Expand-Archive -Path $zip -DestinationPath $Tools -Force
    Remove-Item $zip -Force -ErrorAction SilentlyContinue
    $dir = Join-Path $Tools $name
    $v = Get-NodeVersion $dir
    if (-not $v) { throw "Node.js was extracted to $dir but does not run." }
    return @{ Dir = $dir; Version = $v }
}

# --------------------------------------------------------------------------------------------- main
Say ""
Say "SOC Incident Response Assistant - setup (Windows)" 'Cyan'
Log "args: Yes=$Yes CheckOnly=$CheckOnly Fast=$Fast Stop=$Stop PassThru=$($PassThru -join ' ')"
if ($PSVersionTable.PSVersion.Major -lt 5) { Fail "PowerShell 5.1 or newer is required."; exit 1 }

Update-SessionPath
$python = Find-Python
$node = Find-Node

if ($python) { Ok "Python found: $python" } else { Warn "Python 3.11 / 3.12 not found" }
if ($node) { Ok ("Node.js {0} found" -f $node.Version) } else {
    $old = Get-NodeVersion $null
    if ($old) { Warn ("Node.js {0} is too old for the web UI (Vite 8 needs 20.19+ or 22.12+): a newer one will be installed next to it" -f $old) } else { Warn "Node.js 20.19+ / 22.12+ not found" }
}

if ($Stop) {
    if ($python) { & $python (Join-Path $Root 'setup_project.py') --stop; exit $LASTEXITCODE }
    Say "Nothing to stop."; exit 0
}

if ($CheckOnly) {
    if (-not $python) { Say "  Would install: Python $PythonVersion (winget Python.Python.3.11, or the signed python.org installer)" 'Yellow' }
    if (-not $node) { Say "  Would install: Node.js LTS (winget OpenJS.NodeJS.LTS, or the portable zip $NodeVersion with checksum verification)" 'Yellow' }
    if ($python) {
        $a = @('--check'); if ($node -and $node.Dir) { $a += @('--node-dir', $node.Dir) }
        & $python (Join-Path $Root 'setup_project.py') @a @PassThru
        exit $LASTEXITCODE
    }
    exit 0
}

try {
    if (-not $python) {
        if (-not (Confirm-Action "Install Python $PythonVersion now?")) { Fail "Python is required. Install Python 3.11 from https://www.python.org/downloads/ or re-run with -Yes."; exit 1 }
        $python = Install-Python
        if (-not $python) { Fail "Python was installed but is not visible yet. Close this window, open a new one and run setup.bat again."; exit 1 }
        Ok "Python installed: $python"
    }
    if (-not $node) {
        if (-not (Confirm-Action "Install Node.js LTS now?")) { Fail "Node.js is required for the web UI. Install it from https://nodejs.org/ or re-run with -Yes."; exit 1 }
        $node = Install-Node
        if (-not $node) { Fail "Node.js was installed but is not visible yet. Close this window, open a new one and run setup.bat again."; exit 1 }
        Ok ("Node.js {0} installed" -f $node.Version)
    }
} catch {
    Fail $_.Exception.Message
    Say "  Log: $Log"
    exit 1
}

$argsOut = @()
if ($Yes) { $argsOut += '--yes' }
if ($Fast) { $argsOut += '--fast' }
if ($node.Dir) { $argsOut += @('--node-dir', $node.Dir) }
if ($PassThru) { $argsOut += $PassThru }

Log "starting: $python setup_project.py $($argsOut -join ' ')"
& $python (Join-Path $Root 'setup_project.py') @argsOut
exit $LASTEXITCODE
