#!/usr/bin/env bash
# Set up and run the SOC Incident Response Assistant on macOS / Linux (first run on a new computer).
#
#   ./setup.sh                 install Python / Node.js if missing, then set up everything and start the app
#   ./setup.sh --yes           answer yes to every question
#   ./setup.sh --check         dry run: report what is installed and what would be done
#   ./setup.sh --fast          already set up: just start            (same as ./start.sh)
#   ./setup.sh --stop          stop servers left running by a previous run
#   ./setup.sh --dataset synthetic --no-run   ...any other option is passed to setup_project.py (see --help there)
#
# NOTE: written for macOS and mainstream Linux but only syntax-checked and dry-run on Windows by its author:
# the Windows path (setup.bat) is the tested one. Please report problems with the log in logs/.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TOOLS="$ROOT/.tools"
LOGDIR="$ROOT/logs"
mkdir -p "$LOGDIR"
LOG="$LOGDIR/setup-bootstrap-$(date +%Y%m%d-%H%M%S).log"
NODE_VERSION="v22.12.0"

YES=0; CHECK=0; FAST=0; STOP=0
PASS=()
for a in "$@"; do
  case "$a" in
    -y|--yes) YES=1; PASS+=("--yes") ;;
    --check) CHECK=1 ;;
    --fast) FAST=1 ;;
    --stop) STOP=1 ;;
    -h|--help) sed -n '2,12p' "${BASH_SOURCE[0]}"; exit 0 ;;
    *) PASS+=("$a") ;;
  esac
done

log() { printf '%s %s\n' "$(date +%H:%M:%S)" "$*" >>"$LOG"; }
say() { printf '%s\n' "$*" >&2; log "$*"; }   # stderr: callers such as NODE_DIR="$(install_node)" capture stdout
ok() { say "  [ok] $*"; }
warn() { say "  [!!] $*"; }
die() { say "  [xx] $*"; say "  Log: $LOG"; exit 1; }

confirm() {
  [ "$YES" = 1 ] && return 0
  [ -t 0 ] || return 1
  read -r -p "  $1 [Y/n] " ans || return 1
  case "${ans:-y}" in [Yy]*) return 0 ;; *) return 1 ;; esac
}

SUDO=""
if [ "$(id -u)" != 0 ] && command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi

# ---------------------------------------------------------------------------------------------- Python
python_ok() {  # prints the interpreter path if it is Python 3.11 or 3.12
  local c="$1" v
  command -v "$c" >/dev/null 2>&1 || return 1
  v="$("$c" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null)" || return 1
  case "$v" in 3.11|3.12) command -v "$c" ;; *) return 1 ;; esac
}
find_python() {
  local c p
  for c in python3.11 python3.12 python3 python /opt/homebrew/bin/python3.11 /usr/local/bin/python3.11; do
    if p="$(python_ok "$c")"; then printf '%s' "$p"; return 0; fi
  done
  return 1
}
install_python() {
  local os; os="$(uname -s)"
  if [ "$os" = Darwin ]; then
    command -v brew >/dev/null 2>&1 || die "Homebrew is needed to install Python on macOS: https://brew.sh (then run this again)."
    say "  Installing Python 3.11 with Homebrew ..."; brew install python@3.11 >>"$LOG" 2>&1
    export PATH="$(brew --prefix python@3.11)/bin:$PATH"
  elif command -v apt-get >/dev/null 2>&1; then
    say "  Installing Python with apt (sudo) ..."
    $SUDO apt-get update >>"$LOG" 2>&1 || true
    $SUDO apt-get install -y python3.11 python3.11-venv >>"$LOG" 2>&1 || $SUDO apt-get install -y python3.12 python3.12-venv >>"$LOG" 2>&1 \
      || die "apt has no python3.11/3.12 (older Ubuntu: add the deadsnakes PPA, or install Python 3.11 from https://www.python.org/downloads/)."
  elif command -v dnf >/dev/null 2>&1; then
    say "  Installing Python 3.11 with dnf (sudo) ..."; $SUDO dnf install -y python3.11 >>"$LOG" 2>&1 || die "dnf could not install python3.11."
  else
    die "Cannot install Python automatically on this system. Install Python 3.11 or 3.12 and run this again."
  fi
  find_python
}

# ---------------------------------------------------------------------------------------------- Node.js
node_ok() {  # $1 = path to node; success if 20.19+ or 22.12+ (Vite 8 requires it: on older Node npm silently skips rolldown's native binding)
  local v major minor
  v="$("$1" --version 2>/dev/null)" || return 1
  v="${v#v}"; major="${v%%.*}"; minor="${v#*.}"; minor="${minor%%.*}"
  [ "$major" -ge 23 ] || { [ "$major" -eq 22 ] && [ "$minor" -ge 12 ]; } || { [ "$major" -eq 20 ] && [ "$minor" -ge 19 ]; }
}
find_node() {  # prints the directory containing node ("" when it is already on PATH)
  local d
  if command -v node >/dev/null 2>&1 && node_ok "$(command -v node)"; then printf 'PATH'; return 0; fi
  for d in "$TOOLS"/node-*/bin; do
    [ -x "$d/node" ] && node_ok "$d/node" && { printf '%s' "$d"; return 0; }
  done
  return 1
}
sha256() { if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | cut -d' ' -f1; else shasum -a 256 "$1" | cut -d' ' -f1; fi; }
install_node() {
  local os arch name base tgz expected actual
  case "$(uname -s)" in Darwin) os=darwin ;; Linux) os=linux ;; *) die "Unsupported OS for the portable Node.js download." ;; esac
  case "$(uname -m)" in x86_64|amd64) arch=x64 ;; arm64|aarch64) arch=arm64 ;; *) die "Unsupported CPU for the portable Node.js download." ;; esac
  name="node-$NODE_VERSION-$os-$arch"; base="https://nodejs.org/dist/$NODE_VERSION"; tgz="$(mktemp -t node.XXXXXX).tar.gz"
  say "  Downloading $base/$name.tar.gz (about 30-40 MB) ..."
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$base/$name.tar.gz" -o "$tgz"; expected="$(curl -fsSL "$base/SHASUMS256.txt" | grep " $name.tar.gz\$" | cut -d' ' -f1)"
  elif command -v wget >/dev/null 2>&1; then
    wget -q "$base/$name.tar.gz" -O "$tgz"; expected="$(wget -qO- "$base/SHASUMS256.txt" | grep " $name.tar.gz\$" | cut -d' ' -f1)"
  else die "curl or wget is needed to download Node.js."; fi
  actual="$(sha256 "$tgz")"
  [ -n "$expected" ] && [ "$actual" = "$expected" ] || { rm -f "$tgz"; die "Checksum mismatch for $name.tar.gz (expected $expected, got $actual). Not extracting it."; }
  ok "SHA-256 checksum verified"
  mkdir -p "$TOOLS"; tar -xzf "$tgz" -C "$TOOLS"; rm -f "$tgz"
  printf '%s' "$TOOLS/$name/bin"
}

# ---------------------------------------------------------------------------------------------- main
say ""
say "SOC Incident Response Assistant - setup ($(uname -s))"
PY="$(find_python || true)"
NODE_DIR="$(find_node || true)"
if [ -n "$PY" ]; then ok "Python found: $PY"; else warn "Python 3.11 / 3.12 not found"; fi
if [ -n "$NODE_DIR" ]; then ok "Node.js found"; else warn "Node.js 20.19+ / 22.12+ not found (Vite 8 needs it)"; fi

if [ "$STOP" = 1 ]; then
  [ -n "$PY" ] && exec "$PY" "$ROOT/setup_project.py" --stop
  say "Nothing to stop."; exit 0
fi

if [ "$CHECK" = 1 ]; then
  [ -n "$PY" ] || say "  Would install: Python 3.11 (Homebrew / apt / dnf)"
  [ -n "$NODE_DIR" ] || say "  Would install: portable Node.js $NODE_VERSION (checksum verified) into .tools/"
  if [ -n "$PY" ]; then
    EXTRA=(); [ -n "$NODE_DIR" ] && [ "$NODE_DIR" != PATH ] && EXTRA=(--node-dir "$NODE_DIR")
    exec "$PY" "$ROOT/setup_project.py" --check ${EXTRA[@]+"${EXTRA[@]}"} ${PASS[@]+"${PASS[@]}"}
  fi
  exit 0
fi

if [ -z "$PY" ]; then
  confirm "Install Python 3.11 now?" || die "Python 3.11 or 3.12 is required. Install it, or re-run with --yes."
  PY="$(install_python)" || die "Python was installed but is not visible yet. Open a new terminal and run ./setup.sh again."
  ok "Python installed: $PY"
fi
if [ -z "$NODE_DIR" ]; then
  confirm "Download a portable Node.js $NODE_VERSION into .tools/ now?" || die "Node.js is required for the web UI. Install it from https://nodejs.org/ or re-run with --yes."
  NODE_DIR="$(install_node)"
  ok "Node.js installed in $NODE_DIR"
fi

ARGS=()
[ "$FAST" = 1 ] && ARGS+=(--fast)
[ -n "$NODE_DIR" ] && [ "$NODE_DIR" != PATH ] && ARGS+=(--node-dir "$NODE_DIR")
log "starting: $PY setup_project.py ${ARGS[*]:-} ${PASS[*]:-}"
exec "$PY" "$ROOT/setup_project.py" ${ARGS[@]+"${ARGS[@]}"} ${PASS[@]+"${PASS[@]}"}
