#!/usr/bin/env python3
"""
One-command setup and first run of the SOC Incident Response Assistant (standard library only).

Normally started through ``setup.bat`` / ``setup.ps1`` (Windows) or ``setup.sh`` (macOS / Linux), which first make sure that
Python 3.11-3.12 and Node.js are installed and then hand over to this script. It can also be run directly:

    python setup_project.py                  # set everything up, then start the API and the UI
    python setup_project.py --check          # dry run: show what is installed / what would be done
    python setup_project.py --fast           # already set up: just start (skips the dependency and data checks)
    python setup_project.py --stop           # stop servers left running by a previous run

What it does (each step first checks whether it is already done, so re-running only repeats what is missing):

    1  preflight        disk space, network reachability
    2  python env       virtual environment (in a short path on Windows when the project path is long)
    3  python packages  backend/requirements.txt, pinned with backend/constraints.txt (versions the project was tested with)
    4  configuration    backend/.env with a generated JWT secret, optional NVIDIA key
    5  frontend         npm ci
    6  dataset          real CIC-IDS2017 (~240 MB) via backend/scripts/download_cicids2017.py
    7  database/models  backend/scripts/bootstrap.py: tables, demo users, train the models, ingest incidents, embeddings
    8  index            backend/scripts/build_index.py: embeddings + on-device Qdrant index, verified with a probe query
    9  run              start the API and the UI, wait until healthy, run a search smoke test, open the browser

Everything is logged to ``logs/setup-<time>.log``. Secrets are never printed or logged.
"""
from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
import platform
import re
import secrets
import shutil
import socket
import sqlite3
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "backend"
FRONTEND = ROOT / "frontend"
STATE_DIR = ROOT / ".setup"
STATE_FILE = STATE_DIR / "state.json"
PID_FILE = STATE_DIR / "pids.json"
LOG_DIR = ROOT / "logs"
IS_WIN = os.name == "nt"

PY_MIN, PY_MAX = (3, 11), (3, 13)        # supported: 3.11 and 3.12 (3.11 is the tested one)
LONGEST_VENV_PATH = 144 + 24             # longest file path inside the installed environment (measured: 144) + pip temp margin
WIN_MAX_PATH = 259
MIN_FREE_GB = 6.0
DEFAULT_DEMO_PASSWORDS = {"admin": "admin123!", "analyst": "analyst123!", "viewer": "viewer123!"}
TLS_ERRORS = ("CERTIFICATE_VERIFY_FAILED", "SSLError", "self signed certificate", "unable to get local issuer", "SSLCertVerificationError")
RESOLUTION_ERRORS = ("ResolutionImpossible", "No matching distribution", "conflicting dependencies", "Could not find a version")


# ============================================================================================================
# pure helpers (unit-tested in backend/tests/test_setup_project.py)
# ============================================================================================================
def parse_version(text: str) -> Optional[Tuple[int, ...]]:
    m = re.search(r"(\d+)\.(\d+)(?:\.(\d+))?", text or "")
    return tuple(int(x) for x in m.groups() if x is not None) if m else None


def python_supported(v: Optional[Sequence[int]]) -> bool:
    return bool(v) and PY_MIN <= tuple(v[:2]) < PY_MAX


def node_supported(v: Optional[Sequence[int]]) -> bool:
    """Vite 8 / rolldown declare ``node: ^20.19.0 || >=22.12.0``. This is a hard requirement, not a recommendation: on an older
    Node, ``npm ci`` silently skips rolldown's optional native binding (an engine mismatch makes an optional package 'unsupported')
    and the dev server then crashes with "Cannot find native binding"."""
    if not v or len(v) < 2:
        return False
    major, minor = v[0], v[1]
    return major >= 23 or (major == 22 and minor >= 12) or (major == 20 and minor >= 19)


def venv_path_ok(path: Path, windows: bool = IS_WIN) -> bool:
    """On Windows a path deeper than 259 characters fails to install packages (deepeval, onnxruntime, ... have deep trees)."""
    return (not windows) or len(str(path)) + LONGEST_VENV_PATH <= WIN_MAX_PATH


def choose_venv_dir(root: Path, override: Optional[str], remembered: Optional[str], windows: bool = IS_WIN, home: Optional[Path] = None) -> Tuple[Path, str]:
    """-> (venv directory, reason). Remembered/explicit choices win; otherwise ``<project>/.venv`` unless the path is too long."""
    if override:
        return Path(override).expanduser().resolve(), "chosen with --venv-dir"
    if remembered and Path(remembered).exists():
        return Path(remembered), "reused from the previous run"
    default = root / ".venv"
    if venv_path_ok(default, windows):
        return default, "inside the project"
    short = (home or Path.home()) / ".soc-venv"
    return short, f"the project path is too long for Windows ({len(str(default)) + LONGEST_VENV_PATH} > {WIN_MAX_PATH} characters)"


def venv_python(venv: Path, windows: bool = IS_WIN) -> Path:
    return venv / ("Scripts/python.exe" if windows else "bin/python")


def combined_hash(paths: Sequence[Path]) -> str:
    h = hashlib.sha256()
    for p in paths:
        h.update(p.name.encode())
        h.update(p.read_bytes() if p.exists() else b"<missing>")
    return h.hexdigest()


_ENV_LINE = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=(.*)$")


def env_value(text: str, key: str) -> str:
    """Value of ``key`` in .env text (inline ``# comments`` and quotes stripped); '' when unset."""
    for line in text.splitlines():
        m = _ENV_LINE.match(line)
        if m and m.group(1) == key:
            return m.group(2).split(" #")[0].strip().strip('"').strip("'")
    return ""


def edit_env_text(text: str, updates: Dict[str, str], only_if_empty: Sequence[str] = ()) -> Tuple[str, List[str]]:
    """Set keys in .env text, keeping every other line and comment. Keys in ``only_if_empty`` are left alone when they already
    have a value. Returns (new text, keys that changed)."""
    lines = text.splitlines()
    seen: set = set()
    changed: List[str] = []
    for i, line in enumerate(lines):
        m = _ENV_LINE.match(line)
        if not m or m.group(1) not in updates:
            continue
        key = m.group(1)
        seen.add(key)
        if key in only_if_empty and env_value(line, key):
            continue
        lines[i] = f"{key}={updates[key]}"
        changed.append(key)
    for key, value in updates.items():
        if key not in seen:
            lines.append(f"{key}={value}")
            changed.append(key)
    return "\n".join(lines) + "\n", changed


def port_free(port: int, host: str = "127.0.0.1") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE if IS_WIN and hasattr(socket, "SO_EXCLUSIVEADDRUSE") else socket.SO_REUSEADDR, 1)
        try:
            s.bind((host, port))
            return True
        except OSError:
            return False


def pick_port(preferred: int, avoid: Sequence[int] = (), tries: int = 20) -> int:
    for p in range(preferred, preferred + tries):
        if p not in avoid and port_free(p):
            return p
    raise RuntimeError(f"no free port found in {preferred}-{preferred + tries - 1}")


def redact(text: str, secret_values: Sequence[str]) -> str:
    for s in secret_values:
        if s and len(s) >= 6:
            text = text.replace(s, "[REDACTED]")
    return re.sub(r"(nvapi-)[A-Za-z0-9_\-]{8,}", r"\1[REDACTED]", text)


def progress_snippet(line: str, width: int = 80) -> str:
    """One readable line for the heartbeat: the message of a JSON log record, or the text itself (progress bars are squeezed)."""
    line = line.strip()
    if line.startswith("{"):
        try:
            rec = json.loads(line)
            line = str(rec.get("message") or line)
        except ValueError:
            pass
    return re.sub(r"\s+", " ", line)[:width]


def fmt_duration(seconds: float) -> str:
    seconds = int(seconds)
    return f"{seconds // 60}m{seconds % 60:02d}s" if seconds >= 60 else f"{seconds}s"


# ============================================================================================================
# console + logging
# ============================================================================================================
class Console:
    def __init__(self, log_path: Optional[Path] = None):
        self.tty = sys.stdout.isatty()
        self.log_path = log_path
        self._log = None
        self.secrets: List[str] = []
        if IS_WIN:
            os.system("")  # enables ANSI escape processing in the Windows console
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                pass
        if log_path:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            self._log = open(log_path, "a", encoding="utf-8")

    def _c(self, code: str, text: str) -> str:
        return f"\033[{code}m{text}\033[0m" if self.tty else text

    def raw(self, text: str) -> None:
        if self._log:
            self._log.write(redact(text, self.secrets) + "\n")
            self._log.flush()

    def out(self, text: str = "") -> None:
        print(redact(text, self.secrets), flush=True)
        self.raw(re.sub(r"\033\[[0-9;]*m", "", text))

    def step(self, n: int, total: int, title: str) -> None:
        self.out()
        self.out(self._c("1;36", f"[{n}/{total}] {title}"))

    def ok(self, text: str) -> None:
        self.out("  " + self._c("32", "[ok]") + " " + text)

    def skip(self, text: str) -> None:
        self.out("  " + self._c("90", "[--]") + " " + text)

    def info(self, text: str) -> None:
        self.out("      " + text)

    def warn(self, text: str) -> None:
        self.out("  " + self._c("33", "[!!]") + " " + text)

    def err(self, text: str) -> None:
        self.out("  " + self._c("1;31", "[xx]") + " " + text)

    def close(self) -> None:
        if self._log:
            self._log.close()


class SetupError(Exception):
    def __init__(self, message: str, hint: str = "", tail: Sequence[str] = ()):
        super().__init__(message)
        self.hint, self.tail = hint, list(tail)


def run_logged(con: Console, cmd: Sequence[str], desc: str, cwd: Optional[Path] = None, env: Optional[Dict[str, str]] = None,
               heartbeat: float = 20.0) -> Tuple[int, List[str]]:
    """Run a command, stream its output to the log file, print a heartbeat so a long step never looks hung. -> (exit code, last lines)."""
    shown = " ".join(str(c) for c in cmd)
    con.raw(f"$ {shown}   (cwd={cwd or ROOT})")
    t0 = time.time()
    full_env = {**os.environ, "PYTHONUNBUFFERED": "1", "PYTHONUTF8": "1", "PIP_DISABLE_PIP_VERSION_CHECK": "1", "PIP_NO_INPUT": "1", **(env or {})}
    try:
        proc = subprocess.Popen(list(map(str, cmd)), cwd=str(cwd or ROOT), env=full_env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding="utf-8", errors="replace", bufsize=1)
    except FileNotFoundError as e:
        return 127, [f"command not found: {cmd[0]} ({e})"]
    tail: List[str] = []
    last = {"line": ""}

    def pump() -> None:
        assert proc.stdout is not None
        for line in proc.stdout:
            line = line.rstrip("\r\n")
            con.raw("  | " + line)
            if line.strip():
                last["line"] = line.strip()
                tail.append(line)
                del tail[:-40]

    t = threading.Thread(target=pump, daemon=True)
    t.start()
    while True:
        try:
            proc.wait(timeout=heartbeat)  # wait on the process, not the reader thread: that ends as soon as the child closes stdout, which would spin this loop
            break
        except subprocess.TimeoutExpired:
            snippet = redact(progress_snippet(last["line"]), con.secrets)
            con.info(f"... {desc} ({fmt_duration(time.time() - t0)})" + (f"  {snippet}" if snippet else ""))
    t.join(timeout=5)
    return proc.returncode, tail


def http_get(url: str, timeout: float = 8.0, data: Optional[bytes] = None, headers: Optional[Dict[str, str]] = None) -> Tuple[int, bytes]:
    req = urllib.request.Request(url, data=data, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


# ============================================================================================================
# state
# ============================================================================================================
class State:
    def __init__(self) -> None:
        self.data: Dict[str, object] = {}
        try:
            self.data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            self.data = {}

    def get(self, key: str, default=None):
        return self.data.get(key, default)

    def set(self, **kw) -> None:
        self.data.update(kw)
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(self.data, indent=2), encoding="utf-8")


# ============================================================================================================
# setup context and steps
# ============================================================================================================
class Setup:
    def __init__(self, args: argparse.Namespace, con: Console, state: State):
        self.a, self.con, self.st = args, con, state
        self.python_exe = Path(sys.executable)
        self.node_dir = Path(args.node_dir).resolve() if args.node_dir else None
        venv_dir, why = choose_venv_dir(ROOT, args.venv_dir, state.get("venv_dir"))  # type: ignore[arg-type]
        self.venv, self.venv_reason = venv_dir, why
        self.vpy = venv_python(self.venv)
        self.bp = args.backend_port
        self.fp = args.frontend_port
        self.procs: List[subprocess.Popen] = []

    # ---- environment for node tools
    def env_with_node(self) -> Dict[str, str]:
        env = dict(os.environ)
        if self.node_dir:
            env["PATH"] = str(self.node_dir) + os.pathsep + env.get("PATH", "")
        return env

    def tool(self, name: str) -> Optional[str]:
        return shutil.which(name, path=self.env_with_node().get("PATH"))

    def node_version(self) -> Optional[Tuple[int, ...]]:
        exe = self.tool("node")
        if not exe:
            return None
        try:
            out = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=20, env=self.env_with_node()).stdout
        except Exception:  # noqa: BLE001
            return None
        return parse_version(out)

    def prompt_ok(self, question: str, default: bool = False) -> bool:
        if self.a.yes:
            return True
        if self.a.no_prompt or not sys.stdin.isatty():
            return default
        ans = input(f"  {question} [{'Y/n' if default else 'y/N'}] ").strip().lower()
        return default if not ans else ans.startswith("y")

    # ---- 1 preflight
    def preflight(self) -> None:
        con = self.con
        v = sys.version_info[:3]
        if not python_supported(v):
            raise SetupError(f"This script runs on Python {v[0]}.{v[1]}, which is not supported (need 3.11 or 3.12).",
                             "Start it through setup.bat / setup.sh, which install a supported Python first.")
        con.ok(f"Python {v[0]}.{v[1]}.{v[2]} ({self.python_exe})")
        nv = self.node_version()
        if nv is None or not node_supported(nv):
            raise SetupError("Node.js 20.19+ or 22.12+ is required for the web UI (Vite 8) and was not found." if nv is None
                             else f"Node.js {'.'.join(map(str, nv))} is too old: the web UI's bundler needs 20.19+ or 22.12+ (npm would silently skip its native binding).",
                             "Start it through setup.bat / setup.sh, which install a suitable Node.js first (or install Node.js 22 LTS yourself).")
        con.ok(f"Node.js {'.'.join(map(str, nv))}")
        free = shutil.disk_usage(ROOT).free / 1e9
        if free < MIN_FREE_GB:
            raise SetupError(f"Only {free:.1f} GB free on the project drive; about {MIN_FREE_GB:.0f} GB are needed (packages ~1 GB, "
                             "models and data ~1 GB, node_modules ~0.3 GB, temporary download files).", "Free some disk space and re-run.")
        con.ok(f"{free:.0f} GB free disk space")
        for name, url in (("PyPI", "https://pypi.org/simple/pip/"), ("npm registry", "https://registry.npmjs.org/vite"),
                          ("Hugging Face (dataset + embedding model)", "https://huggingface.co/api/models/sentence-transformers/all-MiniLM-L6-v2")):
            try:
                code, _ = http_get(url, timeout=10)
                (con.ok if code < 400 else con.warn)(f"{name} reachable (HTTP {code})")
            except Exception as e:  # noqa: BLE001
                reason = getattr(e, "reason", e)
                if isinstance(reason, ssl.SSLError):
                    con.warn(f"{name}: TLS certificate error. Behind a TLS-inspecting proxy the OS certificate store is used by pip, npm and "
                             "the app; if a download fails see 'TLS inspection' under Operational notes in README.md.")
                else:
                    con.warn(f"{name} not reachable ({reason.__class__.__name__}: {str(reason)[:70]}). Downloads for this step will fail without internet access.")

    # ---- 2 python env
    def venv_done(self) -> Tuple[bool, str]:
        if not self.vpy.exists():
            return False, "no virtual environment yet"
        try:
            out = subprocess.run([str(self.vpy), "--version"], capture_output=True, text=True, timeout=30).stdout
        except Exception:  # noqa: BLE001
            return False, "virtual environment is broken"
        return (python_supported(parse_version(out)), f"{self.venv} ({out.strip()})")

    def make_venv(self) -> None:
        con = self.con
        done, detail = self.venv_done()
        if done:
            con.skip(f"virtual environment exists: {detail}")
        else:
            con.info(f"creating the virtual environment in {self.venv} ({self.venv_reason})")
            if self.venv.exists():
                shutil.rmtree(self.venv, ignore_errors=True)
            rc, tail = run_logged(con, [self.python_exe, "-m", "venv", self.venv], "creating the virtual environment")
            if rc != 0 or not self.vpy.exists():
                raise SetupError("Could not create the virtual environment.", "On Debian/Ubuntu install the venv module: sudo apt install python3-venv", tail)
            con.ok("virtual environment created")
        self.st.set(venv_dir=str(self.venv))

    # ---- 3 python packages
    def pip_hash(self) -> str:
        return combined_hash([BACKEND / "requirements.txt", BACKEND / "constraints.txt"])

    def packages_done(self) -> Tuple[bool, str]:
        if not self.vpy.exists():
            return False, "needs the virtual environment"
        if self.st.get("pip_hash") != self.pip_hash():
            return False, "not installed yet (or requirements changed)"
        probe = "import fastapi, uvicorn, sklearn, shap, qdrant_client, fastembed, langgraph, deepeval, sqlalchemy"
        try:
            ok = subprocess.run([str(self.vpy), "-c", probe], capture_output=True, timeout=120).returncode == 0
        except Exception:  # noqa: BLE001
            ok = False
        return ok, "all backend packages import" if ok else "some packages are missing"

    def install_packages(self) -> None:
        con = self.con
        done, detail = self.packages_done()
        if done:
            con.skip(detail)
            return
        con.info("installing the backend packages (scikit-learn, SHAP, fastembed, Qdrant, LangGraph, DeepEval ... about 1 GB; 3-10 minutes)")
        rc, tail = run_logged(con, [self.vpy, "-m", "pip", "install", "--upgrade", "pip"], "upgrading pip")
        if rc != 0:
            con.warn("could not upgrade pip; continuing with the bundled version")
        req, cons = BACKEND / "requirements.txt", BACKEND / "constraints.txt"
        use_cons = cons.exists() and not self.a.no_constraints
        base = [self.vpy, "-m", "pip", "install", "--prefer-binary", "-r", req]
        attempts: List[Tuple[str, List[str]]] = []
        attempts.append(("tested versions" if use_cons else "latest versions", base + (["-c", cons] if use_cons else [])))
        rc, tail = run_logged(con, attempts[0][1], f"pip install ({attempts[0][0]})")
        text = "\n".join(tail)
        if rc != 0 and any(t in text for t in TLS_ERRORS):
            con.warn("TLS certificate error: retrying with the operating-system certificate store (pip --use-feature=truststore)")
            rc, tail = run_logged(con, attempts[0][1] + ["--use-feature=truststore"], "pip install (OS certificate store)")
            text = "\n".join(tail)
        if rc != 0 and use_cons and any(t in text for t in RESOLUTION_ERRORS):
            con.warn("the tested versions could not be installed on this platform/Python: retrying with the newest compatible versions")
            rc, tail = run_logged(con, base, "pip install (latest versions)")
        if rc != 0:
            raise SetupError("pip could not install the backend packages.", "See the last lines above and the setup log. On Windows, a project path longer "
                             "than ~95 characters needs --venv-dir with a short path; behind a proxy set PIP_CERT or HTTPS_PROXY.", tail)
        rc, tail = run_logged(con, [self.vpy, "-m", "pip", "check"], "pip check")
        (con.ok if rc == 0 else con.warn)("packages installed" + ("" if rc == 0 else " (pip reports dependency warnings; see the log)"))
        self.st.set(pip_hash=self.pip_hash())

    # ---- 4 configuration
    def configure(self) -> None:
        con = self.con
        env_path = BACKEND / ".env"
        example = BACKEND / ".env.example"
        if not env_path.exists():
            if not example.exists():
                raise SetupError("backend/.env.example is missing; cannot create backend/.env.")
            env_path.write_text(example.read_text(encoding="utf-8"), encoding="utf-8")
            con.ok("created backend/.env from .env.example")
        text = env_path.read_text(encoding="utf-8")
        updates: Dict[str, str] = {"JWT_SECRET": secrets.token_urlsafe(48)}
        only_if_empty = ["JWT_SECRET"]
        key = self.a.nvidia_key or os.environ.get("NVIDIA_API_KEY", "")
        existing_key = env_value(text, "NVIDIA_API_KEY")
        if key:
            updates["NVIDIA_API_KEY"] = key.strip()
            if not self.a.nvidia_key:
                only_if_empty.append("NVIDIA_API_KEY")  # from the environment: never overwrite a key already in .env
        elif not existing_key and not self.a.no_prompt and sys.stdin.isatty() and not self.st.get("asked_nvidia"):
            con.info("An NVIDIA NIM API key (https://build.nvidia.com) enables LLM-written analyses and the copilot.")
            con.info("Press Enter to skip: the app then answers with its built-in offline playbooks (you can add the key to backend/.env later).")
            try:
                typed = getpass.getpass("      NVIDIA API key (input hidden): ").strip()
            except (EOFError, KeyboardInterrupt):
                typed = ""
            if typed:
                updates["NVIDIA_API_KEY"] = typed
            self.st.set(asked_nvidia=True)
        con.secrets.extend(v for k, v in updates.items() if k in ("JWT_SECRET", "NVIDIA_API_KEY"))
        new_text, changed = edit_env_text(text, updates, only_if_empty)
        if changed:
            env_path.write_text(new_text, encoding="utf-8")
        bits = [k for k in changed if k == "JWT_SECRET"] and ["generated a unique JWT secret"] or []
        if "NVIDIA_API_KEY" in changed:
            bits.append("stored the NVIDIA API key")
        con.ok(("backend/.env: " + ", ".join(bits)) if bits else "backend/.env already configured")
        has_key = bool(env_value(env_path.read_text(encoding="utf-8"), "NVIDIA_API_KEY"))
        if not has_key:
            con.warn("no NVIDIA API key: LLM analyses and the copilot use the labelled offline playbooks")

    # ---- 5 frontend packages
    def npm_hash(self) -> str:
        return combined_hash([FRONTEND / "package.json", FRONTEND / "package-lock.json"])

    def vite_loads(self) -> Tuple[bool, str]:
        """Import Vite the way the dev server does. Catches a missing platform-native binding (rolldown) right after install."""
        node = self.tool("node")
        if not node or not (FRONTEND / "node_modules" / "vite").exists():
            return False, "vite is not installed"
        code = "import('vite').then(() => process.exit(0), (e) => { console.error(String(e && e.message).slice(0, 240)); process.exit(1); })"
        try:
            r = subprocess.run([node, "--input-type=module", "-e", code], cwd=str(FRONTEND), capture_output=True, text=True, timeout=90, env=self.env_with_node())
        except Exception as e:  # noqa: BLE001
            return False, f"could not run node ({e.__class__.__name__})"
        return r.returncode == 0, (r.stderr.strip().splitlines() or [""])[0]

    def frontend_done(self) -> Tuple[bool, str]:
        if not ((FRONTEND / "node_modules" / "vite").exists() and self.st.get("npm_hash") == self.npm_hash()):
            return False, "frontend packages not installed"
        ok, why = self.vite_loads()
        return ok, "node_modules is current and Vite loads" if ok else f"installed packages are unusable: {why}"

    def install_frontend(self) -> None:
        con = self.con
        done, detail = self.frontend_done()
        if done:
            con.skip(detail)
            return
        npm = self.tool("npm")
        if not npm:
            raise SetupError("npm was not found.", "Install Node.js (setup.bat / setup.sh do this).")
        cmd = [npm, "ci", "--no-audit", "--no-fund"] if (FRONTEND / "package-lock.json").exists() else [npm, "install", "--no-audit", "--no-fund"]
        con.info("installing the web UI packages (about 300 MB; 1-3 minutes)")
        rc, tail = run_logged(con, cmd, "npm ci", cwd=FRONTEND, env=self.env_with_node())
        if rc != 0 and any(t in "\n".join(tail) for t in TLS_ERRORS + ("UNABLE_TO_GET_ISSUER_CERT", "SELF_SIGNED_CERT")):
            con.warn("TLS certificate error: retrying with the operating-system certificate store (NODE_OPTIONS=--use-system-ca)")
            env = self.env_with_node()
            env["NODE_OPTIONS"] = "--use-system-ca"
            rc, tail = run_logged(con, cmd, "npm ci (OS certificate store)", cwd=FRONTEND, env=env)
        if rc != 0:
            raise SetupError("npm could not install the web UI packages.", "See the lines above; behind a proxy set HTTPS_PROXY or NODE_EXTRA_CA_CERTS.", tail)
        ok, why = self.vite_loads()
        if not ok:
            con.warn(f"Vite does not load after the install ({why}); retrying with optional dependencies forced (npm bug 4828)")
            shutil.rmtree(FRONTEND / "node_modules", ignore_errors=True)
            rc, tail = run_logged(con, cmd + ["--include=optional"], "npm ci --include=optional", cwd=FRONTEND, env=self.env_with_node())
            ok, why = self.vite_loads()
        if not ok:
            nv = self.node_version()
            raise SetupError(f"The web UI packages installed but Vite cannot start: {why}",
                             f"Node.js is {'.'.join(map(str, nv)) if nv else 'unknown'}; Vite 8 needs 20.19+ or 22.12+ (older versions make npm skip its native binding). "
                             "Install Node.js 22 LTS, delete frontend/node_modules and run this again.", tail)
        con.ok("web UI packages installed and Vite loads")
        self.st.set(npm_hash=self.npm_hash())

    # ---- 6 dataset
    def dataset_done(self) -> Tuple[bool, str]:
        if self.a.dataset != "real":
            return True, f"dataset mode '{self.a.dataset}' (no download)"
        if not self.vpy.exists():
            return False, "needs the virtual environment"
        rc = subprocess.run([str(self.vpy), str(BACKEND / "scripts" / "download_cicids2017.py"), "--check"], capture_output=True, text=True,
                            cwd=str(BACKEND), timeout=120, env={**os.environ, "PYTHONUTF8": "1"})
        return rc.returncode == 0, (rc.stdout.strip().splitlines() or [""])[0]

    def get_dataset(self) -> None:
        con = self.con
        if self.a.dataset == "synthetic":
            con.warn("--dataset synthetic: using a generated SYNTHETIC demo dataset. Every metric and UI banner will say so; it is not representative.")
            return
        if self.a.dataset == "skip":
            con.skip("--dataset skip: no dataset download (bootstrap falls back to the synthetic demo set if no real data is present)")
            return
        done, detail = self.dataset_done()
        if done:
            con.skip(detail)
            return
        con.info("downloading the real CIC-IDS2017 flows: 7 Parquet files, about 240 MB, from the Hugging Face dataset bvsam/cic-ids-2017")
        env = {"HF_HUB_DISABLE_SYMLINKS_WARNING": "1"}
        if self.a.dataset_mirror:
            env["HF_ENDPOINT"] = self.a.dataset_mirror
        script = BACKEND / "scripts" / "download_cicids2017.py"
        rc, tail = 1, []
        for attempt in range(1, 4):
            rc, tail = run_logged(con, [self.vpy, script], f"downloading the dataset (attempt {attempt}/3)", cwd=BACKEND, env=env)
            if rc == 0:
                break
            con.warn(f"download attempt {attempt} failed; interrupted files resume where they stopped")
            time.sleep(3 * attempt)
        done, detail = self.dataset_done()
        if rc != 0 or not done:
            if self.a.dataset == "real" and self.prompt_ok("The dataset could not be downloaded. Continue with the SYNTHETIC demo dataset instead?", default=False):
                con.warn("continuing with the synthetic demo dataset (clearly labelled in the UI). Re-run with internet access and --reset-data for real data.")
                self.a.dataset = "synthetic"
                return
            raise SetupError("The dataset download failed.", "Check your internet connection / proxy and re-run (finished files are kept). "
                             "Use --dataset-mirror <url> for a Hugging Face mirror, or --dataset synthetic for an offline demo.", tail)
        con.ok(detail)

    # ---- 7 database + models
    def bootstrap_done(self) -> Tuple[bool, str]:
        model = BACKEND / "models" / "active_model.json"
        db = BACKEND / "soc_assistant.db"
        if not model.exists() or not db.exists():
            return False, "models / database not built yet"
        try:
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            n = con.execute("SELECT COUNT(*) FROM incidents").fetchone()[0]
            con.close()
        except Exception:  # noqa: BLE001
            return False, "database not initialised"
        return n > 0, f"{n:,} incidents and a trained model are present"

    def reset_data(self) -> None:
        targets = [BACKEND / "soc_assistant.db", BACKEND / "models" / "active_model.json", BACKEND / "models" / "versions", BACKEND / "data" / "qdrant"]
        if not self.prompt_ok("--reset-data deletes the database, the trained models and the search index (the dataset is kept). Continue?", default=False):
            raise SetupError("Aborted: nothing was deleted.")
        for t in targets:
            if t.is_dir():
                shutil.rmtree(t, ignore_errors=True)
            elif t.exists():
                t.unlink()
        self.st.set(complete=False)
        self.con.ok("previous database, models and index removed")

    def bootstrap(self) -> None:
        con = self.con
        if self.a.reset_data:
            self.reset_data()
        done, detail = self.bootstrap_done()
        if done:
            con.skip(detail)
            return
        con.info("creating tables and demo users, training the classifier / intrusion / anomaly models, ingesting the knowledge base and alerts")
        con.info("this is the longest step (about 5-15 minutes on a laptop); progress lines appear every 20 s and in the log")
        rc, tail = run_logged(con, [self.vpy, BACKEND / "scripts" / "bootstrap.py"], "bootstrap (train + ingest)", cwd=BACKEND)
        if rc != 0:
            raise SetupError("bootstrap failed.", "See the last lines above and the setup log.", tail)
        done, detail = self.bootstrap_done()
        con.ok(detail)

    # ---- 8 index
    def build_index(self) -> Dict[str, object]:
        con = self.con
        con.info("embedding every incident and building the on-device Qdrant index (the first run downloads the ~90 MB embedding model)")
        rc, tail = run_logged(con, [self.vpy, BACKEND / "scripts" / "build_index.py", "--json"], "building the index", cwd=BACKEND)
        summary: Dict[str, object] = {}
        for line in reversed(tail):
            if line.startswith("{"):
                try:
                    summary = json.loads(line)
                    break
                except ValueError:
                    pass
        if rc != 0 or not summary:
            raise SetupError("The retrieval index could not be built.", "See the setup log. Re-running setup repeats only this step.", tail)
        con.ok(f"{summary.get('incidents'):,} incidents embedded, {summary.get('qdrant_points'):,} points in Qdrant "
               f"({summary.get('embedding_model')}, {summary.get('seconds')} s)")
        if not summary.get("semantic"):
            con.warn("the sentence-embedding model could not be downloaded (offline?): search runs on the hashing fallback with no semantic "
                     "matching. Re-run setup with internet access to build the real index.")
        if not summary.get("probe_results"):
            con.warn("the probe query returned no result")
        return summary

    # ---- 9 run
    def stop_previous(self) -> None:
        try:
            pids = json.loads(PID_FILE.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return
        for name, pid in pids.items():
            kill_tree(int(pid))
        PID_FILE.unlink(missing_ok=True)

    def start(self, no_browser: bool) -> int:
        con = self.con
        self.stop_previous()
        self.bp = pick_port(self.a.backend_port)
        self.fp = pick_port(self.a.frontend_port, avoid=(self.bp,))
        if self.bp != self.a.backend_port:
            con.warn(f"port {self.a.backend_port} is busy: the API uses {self.bp}")
        if self.fp != self.a.frontend_port:
            con.warn(f"port {self.a.frontend_port} is busy: the UI uses {self.fp}")
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        flags = (subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW) if IS_WIN else 0  # type: ignore[attr-defined]
        popen_kw = {"creationflags": flags} if IS_WIN else {"start_new_session": True}
        bl, fl = LOG_DIR / "backend.log", LOG_DIR / "frontend.log"
        be = subprocess.Popen([str(self.vpy), "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(self.bp)], cwd=str(BACKEND),
                              stdout=open(bl, "w", encoding="utf-8"), stderr=subprocess.STDOUT, env={**os.environ, "PYTHONUNBUFFERED": "1", "PYTHONUTF8": "1"}, **popen_kw)
        npm = self.tool("npm")
        fe_env = self.env_with_node()
        fe_env["VITE_BACKEND_URL"] = f"http://127.0.0.1:{self.bp}"
        fe = subprocess.Popen([npm, "run", "dev", "--", "--host", "127.0.0.1", "--port", str(self.fp), "--strictPort"], cwd=str(FRONTEND),
                              stdout=open(fl, "w", encoding="utf-8"), stderr=subprocess.STDOUT, env=fe_env, **popen_kw)
        self.procs = [be, fe]
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        PID_FILE.write_text(json.dumps({"backend": be.pid, "frontend": fe.pid}), encoding="utf-8")
        con.info(f"API starting on http://127.0.0.1:{self.bp}  (log: {bl})")
        con.info(f"UI starting on  http://127.0.0.1:{self.fp}  (log: {fl})")

        health = f"http://127.0.0.1:{self.bp}/api/v1/health"
        deadline = time.time() + 240
        while time.time() < deadline:
            if be.poll() is not None:
                raise SetupError("The API stopped during start-up.", f"See {bl}", bl.read_text(encoding="utf-8", errors="replace").splitlines()[-25:])
            try:
                if http_get(health, timeout=5)[0] == 200:
                    break
            except Exception:  # noqa: BLE001
                pass
            time.sleep(2)
        else:
            raise SetupError("The API did not become healthy within 4 minutes.", f"See {bl}")
        con.ok("API is healthy")
        while time.time() < deadline:
            if fe.poll() is not None:
                raise SetupError("The web UI stopped during start-up.", f"See {fl}", fl.read_text(encoding="utf-8", errors="replace").splitlines()[-25:])
            try:
                if http_get(f"http://127.0.0.1:{self.fp}/", timeout=5)[0] == 200:
                    break
            except Exception:  # noqa: BLE001
                pass
            time.sleep(1)
        else:
            raise SetupError("The web UI did not start within 4 minutes.", f"See {fl}")
        con.ok("web UI is up")
        self.smoke_test()
        url = f"http://127.0.0.1:{self.fp}"
        self.banner(url)
        if not no_browser:
            webbrowser.open(url)
        try:
            while True:
                time.sleep(2)
                for name, p in (("API", be), ("web UI", fe)):
                    if p.poll() is not None:
                        con.err(f"the {name} stopped unexpectedly (exit code {p.returncode}); see logs/. Shutting down.")
                        return 1
        except KeyboardInterrupt:
            con.out()
            con.out("Stopping ...")
            return 0
        finally:
            self.stop_procs()

    def smoke_test(self) -> None:
        """Log in as a demo analyst (development only) and run a real search through the API."""
        con = self.con
        env_text = (BACKEND / ".env").read_text(encoding="utf-8") if (BACKEND / ".env").exists() else ""
        if env_value(env_text, "ENVIRONMENT").lower() == "production":
            return
        base = f"http://127.0.0.1:{self.bp}/api/v1"
        try:
            pw = os.environ.get("SEED_ANALYST_PASSWORD") or DEFAULT_DEMO_PASSWORDS["analyst"]
            code, body = http_get(f"{base}/auth/login", data=json.dumps({"username": "analyst", "password": pw}).encode(), headers={"Content-Type": "application/json"})
            token = json.loads(body)["data"]["access_token"]
            t0 = time.time()
            code, body = http_get(f"{base}/search", data=json.dumps({"query": "port scan reconnaissance probing many ports", "top_k": 3}).encode(),
                                  headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"}, timeout=60)
            data = json.loads(body)["data"]
            con.ok(f"search smoke test: {data['total_matches']} match(es) in {int((time.time() - t0) * 1000)} ms, trace {str(data.get('trace_id'))[:8]}")
        except Exception as e:  # noqa: BLE001
            con.warn(f"smoke test skipped ({e.__class__.__name__}); the app is up, sign in in the browser")

    def banner(self, url: str) -> None:
        con = self.con
        line = "=" * 74
        con.out()
        con.out(line)
        con.out("  SOC Incident Response Assistant is running")
        con.out(f"    Open:   {url}")
        con.out(f"    API:    http://127.0.0.1:{self.bp}/docs")
        con.out("    Sign in (development accounts, created for local use only):")
        con.out("            admin / analyst / viewer   (passwords: see README.md, 'Demo accounts')")
        con.out("    Logs:   logs/backend.log, logs/frontend.log")
        con.out("    Press Ctrl+C here to stop both servers. Next time just run start.bat / ./start.sh")
        con.out(line)

    def stop_procs(self) -> None:
        for p in self.procs:
            kill_tree(p.pid)
        PID_FILE.unlink(missing_ok=True)


def kill_tree(pid: int) -> None:
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, timeout=20)
        else:
            import signal

            os.killpg(os.getpgid(pid), signal.SIGTERM)
    except Exception:  # noqa: BLE001
        pass


# ============================================================================================================
# plan (--check) and main
# ============================================================================================================
def plan(s: Setup) -> None:
    con = s.con
    con.out("Dry run: nothing will be changed.\n")
    con.out(f"  project            {ROOT}")
    con.out(f"  python             {sys.version.split()[0]} at {s.python_exe}  -> {'supported' if python_supported(sys.version_info[:3]) else 'NOT supported (need 3.11/3.12)'}")
    nv = s.node_version()
    con.out(f"  node               {'.'.join(map(str, nv)) if nv else 'not found'}  -> " + ("ok" if nv and node_supported(nv) else "too old for Vite 8 (needs 20.19+ or 22.12+): would be replaced" if nv else "needs installing"))
    con.out(f"  virtual env        {s.venv}  ({s.venv_reason})")
    con.out(f"  free disk          {shutil.disk_usage(ROOT).free / 1e9:.0f} GB (need ~{MIN_FREE_GB:.0f} GB)")
    con.out(f"  ports              api {s.a.backend_port}: {'free' if port_free(s.a.backend_port) else 'BUSY'}, ui {s.a.frontend_port}: {'free' if port_free(s.a.frontend_port) else 'BUSY'}")
    con.out(f"  dataset mode       {s.a.dataset}")
    con.out("")
    rows = [("python environment", s.venv_done()), ("python packages", s.packages_done()),
            ("configuration", ((BACKEND / ".env").exists() and bool(env_value((BACKEND / ".env").read_text(encoding="utf-8"), "JWT_SECRET")), "backend/.env with a JWT secret")),
            ("frontend packages", s.frontend_done()), ("dataset", s.dataset_done()), ("database + models", s.bootstrap_done())]
    for name, (done, detail) in rows:
        con.out(f"  {'[done]' if done else '[todo]'} {name:<20} {detail}")
    con.out(f"  [todo] {'retrieval index':<20} built/verified on every run (fast when up to date)")
    con.out(f"  [todo] {'start':<20} API + UI")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--check", action="store_true", help="dry run: report what is installed and what would be done")
    p.add_argument("--fast", action="store_true", help="already set up: skip dependency/data checks and just start")
    p.add_argument("--stop", action="store_true", help="stop servers started by a previous run")
    p.add_argument("--no-run", action="store_true", help="set everything up but do not start the servers")
    p.add_argument("--no-browser", action="store_true", help="do not open the browser")
    p.add_argument("--dataset", choices=["real", "synthetic", "skip"], default="real",
                   help="real: download CIC-IDS2017 (default); synthetic: generated demo data (offline); skip: do not download")
    p.add_argument("--dataset-mirror", default=os.environ.get("HF_ENDPOINT", ""), help="Hugging Face mirror URL for the dataset download")
    p.add_argument("--reset-data", action="store_true", help="delete the database, models and index first (the downloaded dataset is kept)")
    p.add_argument("--nvidia-key", default="", help="NVIDIA NIM API key (or set NVIDIA_API_KEY); omit to use the offline playbooks")
    p.add_argument("--venv-dir", default="", help="virtual environment location (default: .venv, or a short path on Windows if needed)")
    p.add_argument("--node-dir", default="", help="directory containing node/npm (set by setup.ps1 for a portable install)")
    p.add_argument("--no-constraints", action="store_true", help="install the newest compatible packages instead of the tested versions")
    p.add_argument("--backend-port", type=int, default=8000)
    p.add_argument("--frontend-port", type=int, default=5173)
    p.add_argument("--yes", "-y", action="store_true", help="answer yes to every question")
    p.add_argument("--no-prompt", action="store_true", help="never ask anything (for automation)")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    con = Console(LOG_DIR / f"setup-{stamp}.log")
    state = State()
    s = Setup(args, con, state)
    if args.nvidia_key:
        con.secrets.append(args.nvidia_key)
    if args.stop:
        s.stop_previous()
        con.ok("stopped the servers started by the previous run (if any)")
        return 0
    con.out(f"SOC Incident Response Assistant - setup   ({platform.system()} {platform.release()}, log: logs/setup-{stamp}.log)")
    if args.check:
        plan(s)
        return 0
    t0 = time.time()
    try:
        fast = args.fast and state.get("complete") and s.vpy.exists() and (FRONTEND / "node_modules").exists()
        if fast:
            con.out("Fast start: the project is already set up.")
        else:
            steps = [("Preflight checks", s.preflight), ("Python environment", s.make_venv), ("Python packages", s.install_packages),
                     ("Configuration", s.configure), ("Web UI packages", s.install_frontend), ("Dataset", s.get_dataset),
                     ("Database and models", s.bootstrap), ("Retrieval index", s.build_index)]
            for i, (title, fn) in enumerate(steps, 1):
                con.step(i, len(steps) + 1, title)
                t = time.time()
                fn()
                con.raw(f"step '{title}' took {fmt_duration(time.time() - t)}")
            state.set(complete=True, completed_at=time.strftime("%Y-%m-%d %H:%M:%S"), dataset=args.dataset)
            con.out()
            con.out(f"Setup finished in {fmt_duration(time.time() - t0)}.")
        if args.no_run:
            con.out("Not starting the servers (--no-run). Start them with start.bat / ./start.sh.")
            return 0
        con.step(9 if not fast else 1, 9 if not fast else 1, "Starting the application")
        return s.start(args.no_browser)
    except SetupError as e:
        con.out()
        con.err(str(e))
        for line in e.tail[-15:]:
            con.out("      | " + line)
        if e.hint:
            con.out(f"  What to do: {e.hint}")
        con.out(f"  Full log: {con.log_path}")
        con.out("  Fix the problem and run the same command again: finished steps are skipped.")
        return 1
    except KeyboardInterrupt:
        con.out("\nInterrupted. Run the same command again to continue; finished steps are skipped.")
        return 130
    finally:
        s.stop_procs() if s.procs else None
        con.close()


if __name__ == "__main__":
    sys.exit(main())
