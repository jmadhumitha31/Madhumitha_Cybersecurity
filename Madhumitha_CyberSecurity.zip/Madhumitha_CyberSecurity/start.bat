@echo off
rem Start the SOC Incident Response Assistant (after setup.bat has run once). Ctrl+C stops both servers.
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Fast %*
set RC=%ERRORLEVEL%
if not "%RC%"=="0" pause
exit /b %RC%
