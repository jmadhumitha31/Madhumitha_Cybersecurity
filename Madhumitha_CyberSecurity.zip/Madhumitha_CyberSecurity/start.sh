#!/usr/bin/env bash
# Start the SOC Incident Response Assistant (after ./setup.sh has run once). Ctrl+C stops both servers.
exec "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/setup.sh" --fast "$@"
