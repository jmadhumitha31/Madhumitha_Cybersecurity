@echo off
rem Stop servers left running by setup.bat / start.bat (for example after closing the window).
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Stop
exit /b %ERRORLEVEL%
